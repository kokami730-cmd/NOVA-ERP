const ReimbursementModule = {
  _data: [],
  _filteredData: [],
  _staffData: [],
  _companyData: [],
  _config: null,
  _currentId: null,
  _currentPage: 1,
  _pageSize: 20,
  _sha: null,
  _isAdmin: function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    return config.role === 'admin';
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    const createBtnHtml = this._isAdmin() ? `
      <button class="btn-create" onclick="ReimbursementModule.openEditor()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
        <span>New Claim</span>
      </button>` : '';

    container.innerHTML = `
      <div class="reim-app-wrapper">
        <header class="reim-top-bar">
          <div class="brand-info">
            <h1>Reimbursements</h1>
            </div>
          <div class="top-actions">
            <div class="reim-search-box">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" id="reim-search" placeholder="Search No., name..." oninput="ReimbursementModule.filter()">
            </div>
            ${createBtnHtml}
          </div>
        </header>
        <main class="reim-main-content">
          <div id="reimbursement-list" class="reim-list-container"></div>
          <footer id="reim-pagination"></footer>
        </main>
      </div>

      <div id="reim-modal" class="reim-full-editor">
        <div class="editor-header">
          <div class="header-left">
            <button type="button" onclick="ReimbursementModule.closeEditor()" class="btn-icon-back">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <h2 id="reim-modal-title">Expense Details</h2>
          </div>
          <div class="header-right">
            <button type="button" class="reim-modal-close" onclick="ReimbursementModule.closeEditor()">Close</button>
            <button type="button" id="reim-del-btn" onclick="ReimbursementModule.delete()" class="btn-text-danger">Delete</button>
            <button type="submit" form="reim-form" id="reim-save-btn" class="btn-save-main">Save</button>
          </div>
        </div>
        <div class="editor-scroll-area">
          <form id="reim-form" class="reim-form-layout" onsubmit="ReimbursementModule.save(event)">
            <div class="editor-grid">
              <div class="editor-col basic-info-col">
                <div class="editor-card">
                  <h3>Claim Information</h3>
                  <div class="field-group">
                    <label>Staff Member</label>
                    <input type="text" name="staffName" id="reim-staff-input" list="staff-list" required placeholder="Full Name" oninput="ReimbursementModule.handleStaffInput(this.value)">
                    <datalist id="staff-list"></datalist>
                    <input type="hidden" name="staffId" id="reim-staff-id">
                  </div>
                  <div class="field-group">
                    <label>Company Entity</label>
                    <input type="text" name="company" id="reim-company-field" list="company-list" placeholder="Company Name">
                    <datalist id="company-list"></datalist>
                  </div>
                  <div class="field-row">
                    <div class="field-group">
                      <label>Expense Type</label>
                      <select name="type">
                        <option value="Transport">Transport</option>
                        <option value="Meal">Meal Allowance</option>
                        <option value="Parking">Parking/Toll</option>
                        <option value="Office">Office Supplies</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div class="field-group">
                      <label>Date</label>
                      <input type="date" name="date" required>
                    </div>
                  </div>
                  <div class="field-group">
                    <label>Status</label>
                    <select name="status">
                      <option value="Pending">Pending</option>
                      <option value="Approved">Approved</option>
                      <option value="Paid">Paid</option>
                      <option value="Rejected">Rejected</option>
                    </select>
                  </div>
                  <div class="field-group" style="margin-bottom:0;">
                    <label>Internal Notes</label>
                    <textarea name="remark" rows="3" placeholder="Additional details..."></textarea>
                  </div>
                </div>
              </div>
              <div class="editor-col items-panel">
                <div class="editor-card">
                  <div class="items-header-row">
                    <h3>Line Items</h3>
                    <button type="button" id="reim-add-item-btn" class="btn-add-line" onclick="ReimbursementModule.addItemRow()">+ Add Item</button>
                  </div>
                  <div id="items-container"></div>
                  <div class="total-summary-card">
                    <span>Grand Total</span>
                    <div class="total-value">RM <span id="reim-total-display">0.00</span></div>
                    <input type="hidden" name="amount" id="reim-amount-hidden">
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    `;

    await this.load();
  },

  addItemRow: function(data = { name: '', amount: '' }) {
    const container = document.getElementById('items-container');
    const rowId = 'row-' + Date.now() + Math.random().toString(36).substr(2, 5);
    const div = document.createElement('div');
    div.className = 'item-entry';
    div.id = rowId;

    const removeBtnHtml = this._isAdmin() ? `
      <button type="button" class="btn-remove-row" onclick="ReimbursementModule.removeItemRow('${rowId}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18m-2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
      </button>` : '';

    div.innerHTML = `
      <div class="item-entry-main">
        <input type="text" class="item-name" placeholder="Description" value="${data.name}" required ${!this._isAdmin() ? 'disabled' : ''}>
        <div class="item-amount-wrap">
          <span class="currency-label">RM</span>
          <input type="number" class="item-amount" step="0.01" placeholder="0.00" value="${data.amount}" required oninput="ReimbursementModule.calcTotal()" ${!this._isAdmin() ? 'disabled' : ''}>
        </div>
      </div>
      ${removeBtnHtml}
    `;
    container.appendChild(div);
    this.calcTotal();
  },

  removeItemRow: function(id) {
    if(!this._isAdmin()) return;
    const row = document.getElementById(id);
    if (row) row.remove();
    this.calcTotal();
  },

  calcTotal: function() {
    const amounts = Array.from(document.querySelectorAll('.item-amount')).map(input => parseFloat(input.value) || 0);
    const total = amounts.reduce((a, b) => a + b, 0);
    document.getElementById('reim-total-display').innerText = total.toLocaleString(undefined, {minimumFractionDigits: 2});
    document.getElementById('reim-amount-hidden').value = total.toFixed(2);
  },

  openEditor: function(id = null) {
    this._currentId = id;
    const modal = document.getElementById('reim-modal');
    const form = document.getElementById('reim-form');
    const itemsContainer = document.getElementById('items-container');
    const isAdmin = this._isAdmin();

    form.reset();
    itemsContainer.innerHTML = '';
    document.getElementById('reim-staff-id').value = "";
    document.getElementById('reim-save-btn').style.display = isAdmin ? 'inline-flex' : 'none';
    document.getElementById('reim-add-item-btn').style.display = isAdmin ? 'inline-flex' : 'none';

    if (id) {
      const r = this._data.find(x => x.id === id);
      if (!r) return;

      document.getElementById('reim-modal-title').innerText = (isAdmin ? "Edit #" : "View #") + (r._no || 'Entry');
      document.getElementById('reim-del-btn').style.display = isAdmin ? 'inline-flex' : 'none';

      Array.from(form.elements).forEach(el => {
        if (el.name && r[el.name] !== undefined) {
          el.value = r[el.name];
        }
        if(!isAdmin) el.disabled = true;
        else el.disabled = false;
      });

      if (r.items && r.items.length > 0) {
        r.items.forEach(item => this.addItemRow(item));
      } else {
        this.addItemRow({ name: 'General Expense', amount: r.amount || '' });
      }
    } else {
      if(!isAdmin) return;
      document.getElementById('reim-modal-title').innerText = "New Claim";
      document.getElementById('reim-del-btn').style.display = 'none';
      form.elements['date'].value = new Date().toISOString().split('T')[0];
      Array.from(form.elements).forEach(el => el.disabled = false);
      this.addItemRow();
    }

    this.calcTotal();
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },

  save: async function(e) {
    e.preventDefault();
    if(!this._isAdmin()) return alert("Permission Denied");

    const btn = document.querySelector('.btn-save-main');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Syncing...";

    const fd = new FormData(e.target);
    const itemRows = Array.from(document.querySelectorAll('.item-entry'));
    const items = itemRows.map(row => ({
      name: row.querySelector('.item-name').value,
      amount: row.querySelector('.item-amount').value
    }));

    const entry = {
      id: this._currentId || 'R-' + Date.now(),
      staffId: fd.get('staffId'),
      staffName: fd.get('staffName'),
      company: fd.get('company'),
      date: fd.get('date'),
      type: fd.get('type'),
      items: items,
      amount: fd.get('amount'),
      status: fd.get('status'),
      remark: fd.get('remark'),
      updatedAt: new Date().toISOString()
    };

    try {
      let nextData = [...this._data];
      let isNew = !this._currentId;

      if (!isNew) {
        const i = nextData.findIndex(x => x.id === this._currentId);
        if (i > -1) nextData[i] = entry;
      } else {
        nextData.push(entry);
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));

      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/reimbursements.json`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Update reim",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (typeof LogModule !== 'undefined') {
          const logAction = isNew ? `Created new claim for ${entry.staffName} (RM ${entry.amount})` : `Updated claim for ${entry.staffName} (RM ${entry.amount})`;
          LogModule.addLog('Reimbursement', logAction, this._config.username || "Admin");
        }
        this.closeEditor();
        await this.load();
      }
    } catch (err) {
      alert("Sync Failed");
    } finally {
      btn.disabled = false;
      btn.innerText = originalText;
    }
  },

  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const fetchOptions = {
      headers: {
        'Authorization': `token ${this._config.ghToken}`
      },
      cache: 'no-store'
    };

    try {
      const [resReim, resStaff, resCompany] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/reimbursements.json`, fetchOptions),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/staff.json`, fetchOptions),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/company.json`, fetchOptions)
      ]);

      if (resReim.ok) {
        const data = await resReim.json();
        this._sha = data.sha;
        const parsed = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this._data = this._ensureArray(parsed);
        this._data.forEach((item, index) => item._no = (index + 1).toString());
      }

      if (resStaff.ok) {
        const sData = await resStaff.json();
        const parsedStaff = JSON.parse(decodeURIComponent(escape(atob(sData.content))));
        this._staffData = this._ensureArray(parsedStaff);
      }

      if (resCompany.ok) {
        const cData = await resCompany.json();
        const parsedCompany = JSON.parse(decodeURIComponent(escape(atob(cData.content))));
        this._companyData = this._ensureArray(parsedCompany);
      }

      this.filter();
    } catch (e) {
      console.error(e);
    }
  },

  renderList: function() {
    const list = document.getElementById('reimbursement-list');
    const stats = document.getElementById('reim-stats');
    const start = (this._currentPage - 1) * this._pageSize;
    const paginated = this._filteredData.slice(start, start + this._pageSize);

    if (stats) stats.innerText = `${this._filteredData.length} total claims`;

    if (this._filteredData.length === 0) {
      list.innerHTML = `<div class="empty-view">No records found.</div>`;
      return;
    }

    list.innerHTML = `
      <div class="reim-table-wrapper">
        <table class="reim-table">
          <thead>
            <tr>
              <th class="col-hide-mobile">#</th>
              <th>Claim Details</th>
              <th class="col-hide-mobile">Category</th>
              <th>Status</th>
              <th class="text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            ${paginated.map(r => `
              <tr onclick="ReimbursementModule.openEditor('${r.id}')">
                <td class="col-no col-hide-mobile">${r._no}</td>
                <td>
                  <div class="td-staff">${r.staffName || '---'}</div>
                  <div class="td-date-meta">${r.date} - ${r.company || 'Personal'}</div>
                  <div class="col-show-mobile td-type-mobile">${r.type}</div>
                </td>
                <td class="col-hide-mobile">
                  <div class="td-type">${r.type || 'Other'}</div>
                </td>
                <td><span class="status-pill ${r.status.toLowerCase()}">${r.status}</span></td>
                <td class="text-right">
                  <div class="td-amount-cell">RM ${parseFloat(r.amount).toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    this.renderPagination();
  },

  renderPagination: function() {
    const totalPages = Math.ceil(this._filteredData.length / this._pageSize);
    const container = document.getElementById('reim-pagination');
    if (!container || totalPages <= 1) {
      container.innerHTML = '';
      return;
    }

    let btns = '';
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= this._currentPage - 1 && i <= this._currentPage + 1)) {
        btns += `<button class="page-btn ${i === this._currentPage ? 'active' : ''}" onclick="ReimbursementModule.changePage(${i})">${i}</button>`;
      } else if (i === 2 || i === totalPages - 1) {
        btns += `<span class="page-sep">...</span>`;
      }
    }
    container.innerHTML = `<div class="pagination-flex">${btns}</div>`;
  },

  changePage: function(p) {
    this._currentPage = p;
    this.renderList();
  },

  filter: function() {
    const q = (document.getElementById('reim-search')?.value || '').toLowerCase();
    this._filteredData = this._data.filter(x =>
      (x._no === q) ||
      (x.staffName || '').toLowerCase().includes(q) ||
      (x.company || '').toLowerCase().includes(q)
    );
    this._updateDatalists();
    this.renderList();
  },

  _updateDatalists: function() {
    const sDl = document.getElementById('staff-list');
    if (sDl) {
      sDl.innerHTML = this._staffData.map(s =>
        `<option value="${s.name}" data-id="${s.id}" data-co="${s.company}">`
      ).join('');
    }

    const cDl = document.getElementById('company-list');
    if (cDl) {
      cDl.innerHTML = this._companyData.map(c =>
        `<option value="${c.name || c.companyName}">`
      ).join('');
    }
  },

  handleStaffInput: function(val) {
    if(!this._isAdmin()) return;
    const opt = Array.from(document.getElementById('staff-list').options).find(o => o.value === val);
    if (opt) {
      document.getElementById('reim-staff-id').value = opt.getAttribute('data-id');
      document.getElementById('reim-company-field').value = opt.getAttribute('data-co');
    }
  },

  closeEditor: function() {
    document.getElementById('reim-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },

  delete: async function() {
    if(!this._isAdmin()) return alert("Permission Denied");

    const entry = this._data.find(x => x.id === this._currentId);
    if (!entry) return;

    if (!confirm("Delete this record forever?")) return;

    const nextData = this._data.filter(x => x.id !== this._currentId);
    const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));

    try {
      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/reimbursements.json`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Delete",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (typeof LogModule !== 'undefined') {
          LogModule.addLog('Reimbursement', `Deleted claim #${entry._no} for ${entry.staffName}`, this._config.username || "Admin");
        }
        this.closeEditor();
        await this.load();
      }
    } catch (e) {
      alert("Delete error");
    }
  },

  _ensureArray: function(d) {
    if (Array.isArray(d)) return d;
    if (d && typeof d === 'object') {
      if (d.items && Array.isArray(d.items)) return d.items;
      if (d.data && Array.isArray(d.data)) return d.data;
      return [];
    }
    return [];
  },

  _injectStyles: function() {
    if (document.getElementById('reim-modern-v2-styles')) return;

    const s = document.createElement('style');
    s.id = 'reim-modern-v2-styles';
    s.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .reim-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        width: 100%;
      }

      .reim-top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .brand-info h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .brand-info p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
      }

      .top-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .reim-search-box {
        position: relative;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 40px;
        min-width: 240px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .reim-search-box:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .reim-search-box svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .reim-search-box input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 13px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .btn-create {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .btn-create:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-create:active {
        transform: translateY(0);
      }

      .reim-main-content {
        background: transparent;
      }

      .reim-table-wrapper {
        background: var(--surface);
        border-radius: var(--radius-card);
        overflow-x: auto;
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .reim-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 600px;
      }

      .reim-table th {
        background: var(--surface-soft);
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border);
        text-align: left;
      }

      .reim-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        cursor: pointer;
        transition: background var(--transition-fast);
        color: var(--text);
        font-size: 13px;
        vertical-align: middle;
      }

      .reim-table tr:last-child td {
        border-bottom: none;
      }

      .reim-table tr:hover td {
        background: var(--surface-soft);
      }

      .col-no {
        font-weight: 600;
        color: var(--text-secondary);
        font-family: monospace;
      }

      .td-staff {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        word-break: break-word;
      }

      .td-date-meta {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 3px;
        word-break: break-word;
      }

      .td-type {
        display: inline-block;
        padding: 4px 10px;
        background: var(--surface-soft);
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .status-pill {
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        white-space: nowrap;
      }

      .status-pill.pending {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .status-pill.approved {
        background: var(--green-soft);
        color: var(--green);
      }

      .status-pill.paid {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .status-pill.rejected {
        background: var(--red-soft);
        color: var(--danger);
      }

      .td-amount-cell {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        white-space: nowrap;
      }

      .text-right {
        text-align: right;
      }

      .reim-full-editor {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transition: visibility 0.2s, opacity 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .reim-full-editor.active {
        visibility: visible;
        opacity: 1;
      }

      .editor-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }

      .btn-icon-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .btn-icon-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .header-left h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .header-right {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-shrink: 0;
      }

      .reim-modal-close {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .reim-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .btn-text-danger {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .btn-text-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .btn-save-main {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 36px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-save-main:hover {
        background: var(--primary-dark);
      }

      .editor-scroll-area {
        flex: 1;
        overflow-y: auto;
        padding: 28px 20px;
      }

      .reim-form-layout {
        max-width: 1120px;
        margin: 0 auto;
        width: 100%;
      }

      .editor-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 24px;
        align-items: start;
      }

      .editor-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .editor-card h3 {
        margin: 0 0 18px 0;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .field-group {
        margin-bottom: 18px;
      }

      .field-group label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .field-group input,
      .field-group select,
      .field-group textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .field-group input,
      .field-group select {
        height: 42px;
      }

      .field-group input:focus,
      .field-group select:focus,
      .field-group textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .field-group input:disabled,
      .field-group select:disabled,
      .field-group textarea:disabled {
        background: var(--surface-soft);
        color: var(--text-dim);
        cursor: not-allowed;
        border-color: var(--border);
      }

      .field-group textarea {
        resize: vertical;
      }

      .field-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px;
      }

      .items-header-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        gap: 10px;
        flex-wrap: wrap;
      }

      .items-header-row h3 {
        margin: 0;
      }

      .btn-add-line {
        background: var(--primary-soft);
        border: 1px solid transparent;
        color: var(--primary);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-family: var(--font-sans);
      }

      .btn-add-line:hover {
        background: var(--primary);
        color: white;
      }

      .item-entry {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 14px;
        margin-bottom: 12px;
        display: flex;
        gap: 10px;
        align-items: flex-start;
        transition: all var(--transition-fast);
      }

      .item-entry:hover {
        border-color: var(--border-strong);
      }

      .item-entry-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 10px;
        min-width: 0;
      }

      .item-name {
        width: 100%;
        height: 40px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        background: var(--surface);
        outline: none;
        transition: all var(--transition-fast);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .item-name:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .item-amount-wrap {
        display: flex;
        align-items: center;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        padding: 0 12px;
        height: 40px;
        transition: all var(--transition-fast);
      }

      .item-amount-wrap:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .currency-label {
        font-weight: 600;
        font-size: 12px;
        color: var(--text-secondary);
        margin-right: 6px;
      }

      .item-amount {
        width: 100%;
        padding: 0;
        border: none;
        background: transparent;
        font-weight: 700;
        font-size: 13px;
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .btn-remove-row {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        cursor: pointer;
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        flex-shrink: 0;
      }

      .btn-remove-row:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .total-summary-card {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px 18px;
        margin-top: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: var(--text);
        gap: 12px;
      }

      .total-summary-card span {
        font-weight: 600;
        font-size: 12px;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
      }

      .total-value {
        font-size: 22px;
        font-weight: 700;
        color: var(--primary);
        letter-spacing: -0.02em;
      }

      .pagination-flex {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
      }

      .page-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 34px;
        padding: 0 12px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .page-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .page-btn:hover:not(.active) {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .page-sep {
        padding: 0 6px;
        color: var(--text-dim);
        line-height: 34px;
      }

      .empty-view {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-size: 14px;
      }

      @media (max-width: 1024px) {
        .editor-grid {
          grid-template-columns: 1fr;
          gap: 20px;
        }
      }

      @media (max-width: 768px) {
        .reim-app-wrapper {
          padding: 16px;
        }
        .reim-top-bar {
          flex-direction: column;
          align-items: stretch;
        }
        .top-actions {
          flex-direction: column;
          align-items: stretch;
        }
        .reim-search-box {
          width: 100%;
          min-width: 0;
        }
        .btn-create {
          justify-content: center;
          width: 100%;
        }
        .reim-table {
          min-width: 100%;
        }
        .col-hide-mobile {
          display: none;
        }
        .col-show-mobile {
          display: block;
        }
        .td-type-mobile {
          font-size: 11px;
          color: var(--primary);
          font-weight: 600;
          margin-top: 4px;
        }
        .reim-table th,
        .reim-table td {
          padding: 12px 14px;
        }
        .header-left h2 {
          font-size: 16px;
        }
        .editor-header {
          padding: 14px 16px;
        }
        .editor-scroll-area {
          padding: 18px 14px;
        }
        .editor-card {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .field-row {
          grid-template-columns: 1fr;
        }
      }

      @media (min-width: 769px) {
        .col-show-mobile {
          display: none;
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.ReimbursementModule = ReimbursementModule;

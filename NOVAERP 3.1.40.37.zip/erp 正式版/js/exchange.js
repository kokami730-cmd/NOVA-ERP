const ExchangePortalModule = {
  _products: [],
  _staffs: [],
  _companies: [],
  _exchangeLogs: [],
  _config: null,
  _sha: null,
  _fileName: 'db_date/product.json',
  _staffFileName: 'db_date/staff.json',
  _companyFileName: 'db_date/company.json',
  _logFileName: 'db_date/exchange_logs.json',
  _currentPage: 1,
  _pageSize: 20,
  _editingId: null,
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    this._loadDependencies();

    container.innerHTML = `
      <div class="ex-app-shell">
        <header class="ex-main-header">
          <div class="title-meta">
            <h1>Exchange Portal</h1>
           
          </div>
          <button type="button" class="ex-fab-btn" onclick="ExchangePortalModule.showExchangeModal()">
            <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            <span>New Transfer</span>
          </button>
        </header>

        <div class="ex-toolbar">
          <div class="ex-search-wrapper">
            <svg class="search-icon" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>
            <input type="text" id="log-search" placeholder="Quick find SKU, Staff or Route..." oninput="ExchangePortalModule.handleSearch(this.value)">
          </div>
        </div>

        <div id="exchange-list-area"></div>
      </div>

      <div id="exchange-modal" class="ex-full-modal">
        <div class="ex-modal-container">
          <div class="ex-modal-top">
            <button type="button" class="ex-close-minimal" onclick="ExchangePortalModule.hideModal()">
              <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <div class="ex-title-stack">
              <h2 id="modal-title">Inventory Transfer</h2>
              <p>Sync stock across multiple locations</p>
            </div>
            <button type="button" id="ex-del-btn" class="ex-del-action" onclick="ExchangePortalModule.deleteLog(ExchangePortalModule._editingId)">Delete Record</button>
          </div>

          <div class="ex-modal-body-scroll">
            <form id="exchange-form" class="ex-unified-form">
              <div class="ex-form-inner">
                <section class="ex-form-card">
                  <div class="ex-section-tag">01 / LOGISTICS</div>
                  <div class="ex-field-row">
                    <div class="ex-input-group">
                      <label>Authorized Staff</label>
                      <input type="text" id="ex-staff" list="ex-staff-list" required placeholder="Who is responsible?">
                      <datalist id="ex-staff-list"></datalist>
                    </div>
                    <div class="ex-input-group">
                      <label>Source (From)</label>
                      <select id="ex-from" required></select>
                    </div>
                    <div class="ex-input-group">
                      <label>Destination (To)</label>
                      <select id="ex-to" required></select>
                    </div>
                  </div>
                </section>

                <section class="ex-form-card highlight-card">
                  <div class="ex-section-tag">02 / ITEMS LIST</div>
                  <div class="ex-items-header">
                    <h3>Transfer Content</h3>
                    <button type="button" class="ex-add-row-btn" onclick="ExchangePortalModule.addItemRow()">
                      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                      Add Item
                    </button>
                  </div>
                  <div id="items-container" class="ex-items-stack"></div>
                </section>

                <section class="ex-form-card">
                  <div class="ex-section-tag">03 / ADDITIONAL</div>
                  <div class="ex-input-group">
                    <label>Notes / Justification</label>
                    <textarea id="ex-notes" rows="3" placeholder="Explain the reason for this transfer..."></textarea>
                  </div>
                  <div class="ex-field-row" style="margin-top: 16px;">
                    <div class="ex-input-group">
                      <label>Bank Name (Optional)</label>
                      <input type="text" id="ex-bank-name" placeholder="e.g. HSBC, ICBC">
                    </div>
                    <div class="ex-input-group">
                      <label>Bank Account No (Optional)</label>
                      <input type="text" id="ex-bank-account" placeholder="Account Number">
                    </div>
                  </div>
                </section>
              </div>

              <div class="ex-form-footer">
                <button type="button" class="ex-btn-cancel" onclick="ExchangePortalModule.hideModal()">Discard</button>
                <button type="submit" class="ex-btn-save" id="save-btn">Confirm & Sync to Cloud</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;

    await this.load();
    this._bindEvents();
  },
  _loadDependencies: function() {
    if (window.jspdf) return;
    const s1 = document.createElement('script');
    s1.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    const s2 = document.createElement('script');
    s2.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js";
    document.head.appendChild(s1);
    document.head.appendChild(s2);
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (!this._config.ghToken || !this._config.ghRepo) return;

    const headers = {
      'Authorization': `token ${this._config.ghToken}`
    };

    try {
      const [prodRes, staffRes, logRes, compRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._fileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._staffFileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._logFileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._companyFileName}`, { headers, cache: 'no-store' })
      ]);

      if (prodRes.ok) {
        const d = await prodRes.json();
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = decoded.products || [];
      }

      if (staffRes.ok) {
        const d = await staffRes.json();
        const data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._staffs = data.staffs || (Array.isArray(data) ? data : []);
        this._updateStaffDatalist();
      }

      if (compRes.ok) {
        const d = await compRes.json();
        const data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._companies = data.companies || (Array.isArray(data) ? data : []);
        this._updateCompanySelects();
      }

      if (logRes.ok) {
        const d = await logRes.json();
        this._sha = d.sha;
        const data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._exchangeLogs = data.logs || [];
      } else if (logRes.status === 404) {
        this._exchangeLogs = [];
        this._sha = null;
      }

      this.renderLogs();
    } catch (e) {
      console.error("Exchange Load Error", e);
    }
  },
  addItemRow: function(data = { sku: '', name: '', qty: 1, cost: '', bn: '', exp: '' }) {
    const container = document.getElementById('items-container');
    const rowId = 'row-' + Date.now() + Math.random().toString(16).slice(2);
    const div = document.createElement('div');
    div.className = 'ex-item-row';
    div.id = rowId;

    div.innerHTML = `
      <div class="ex-row-grid">
        <div class="ex-input-group grid-sku">
          <label class="mob-label">SKU</label>
          <input type="text" class="item-sku" placeholder="SKU" value="${data.sku || ''}" oninput="ExchangePortalModule.handleItemLink(this)" required>
        </div>
        <div class="ex-input-group grid-name">
          <label class="mob-label">Product Name</label>
          <input type="text" class="item-name readonly-field" placeholder="Linked Name" value="${data.name || ''}" readonly tabindex="-1">
        </div>
        <div class="ex-input-group">
          <label class="mob-label">Cost</label>
          <input type="number" step="0.01" class="item-cost" placeholder="0.00" value="${data.cost || ''}">
        </div>
        <div class="ex-input-group">
          <label class="mob-label">Batch No (BN)</label>
          <input type="text" class="item-bn" placeholder="Batch No" value="${data.bn || ''}">
        </div>
        <div class="ex-input-group">
          <label class="mob-label">Expiry (EXP)</label>
          <input type="date" class="item-exp" value="${data.exp || ''}">
        </div>
        <div class="ex-input-group">
          <label class="mob-label">Qty</label>
          <input type="number" class="item-qty" value="${data.qty || 1}" min="1">
        </div>
        <button type="button" class="ex-remove-row" onclick="document.getElementById('${rowId}').remove()" title="Remove row">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
    `;

    container.prepend(div);
    if (data.sku) this.handleItemLink(div.querySelector('.item-sku'));
  },
  handleItemLink: function(input) {
    const val = input.value.trim().toLowerCase();
    const product = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === val);
    const row = input.closest('.ex-item-row');
    const nameInput = row.querySelector('.item-name');
    const costInput = row.querySelector('.item-cost');

    if (product) {
      nameInput.value = product.prodName || product.name;
      if (costInput && !costInput.value) {
        costInput.value = product.cost || product.price || '';
      }
      row.classList.add('match-success');
    } else {
      nameInput.value = '';
      row.classList.remove('match-success');
    }
  },
  _updateStaffDatalist: function() {
    const dl = document.getElementById('ex-staff-list');
    if (dl) {
      dl.innerHTML = this._staffs.map(s => {
        const val = (typeof s === 'object') ? (s.name || s.staffName) : s;
        return `<option value="${val}"></option>`;
      }).join('');
    }
  },
  _updateCompanySelects: function() {
    const fromSelect = document.getElementById('ex-from');
    const toSelect = document.getElementById('ex-to');

    if (fromSelect && toSelect) {
      const options = this._companies.map(c => {
        const name = typeof c === 'object' ? (c.companyName || c.name || c.comName) : c;
        return `<option value="${name}">${name}</option>`;
      }).join('');

      fromSelect.innerHTML = `<option value="">Select Source...</option>` + options;
      toSelect.innerHTML = `<option value="">Select Destination...</option>` + options;
    }
  },
  showExchangeModal: function(editId = null) {
    const form = document.getElementById('exchange-form');
    form.reset();
    document.getElementById('items-container').innerHTML = '';
    this._editingId = editId;
    document.body.style.overflow = 'hidden';

    if (editId) {
      const log = this._exchangeLogs.find(l => l.id === editId);
      if (log) {
        document.getElementById('modal-title').innerText = "Edit Transfer Record";
        document.getElementById('ex-staff').value = log.staff;
        document.getElementById('ex-from').value = log.from;
        document.getElementById('ex-to').value = log.to;
        document.getElementById('ex-notes').value = log.notes || '';
        document.getElementById('ex-del-btn').style.display = 'inline-flex';

        const bankNameInput = document.getElementById('ex-bank-name');
        const bankAccountInput = document.getElementById('ex-bank-account');
        if (bankNameInput) bankNameInput.value = log.bankName || '';
        if (bankAccountInput) bankAccountInput.value = log.bankAccount || '';

        if (log.items && log.items.length > 0) {
          log.items.forEach(item => {
            const productMatch = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === (item.sku || '').toLowerCase());
            const finalName = productMatch ? (productMatch.prodName || productMatch.name || item.name) : item.name;
            const finalCost = productMatch ? (productMatch.cost || productMatch.price || item.cost) : item.cost;
            this.addItemRow({ ...item, name: finalName, cost: finalCost });
          });
        } else {
          const productMatch = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === (log.sku || '').toLowerCase());
          const finalName = productMatch ? (productMatch.prodName || productMatch.name || log.name) : log.name;
          const finalCost = productMatch ? (productMatch.cost || productMatch.price || log.cost) : log.cost;
          this.addItemRow({ sku: log.sku, name: finalName, qty: log.qty, cost: finalCost, bn: log.bn, exp: log.exp });
        }
      }
    } else {
      document.getElementById('modal-title').innerText = "New Inventory Transfer";
      document.getElementById('ex-del-btn').style.display = 'none';

      const bankNameInput = document.getElementById('ex-bank-name');
      const bankAccountInput = document.getElementById('ex-bank-account');
      if (bankNameInput) bankNameInput.value = '';
      if (bankAccountInput) bankAccountInput.value = '';

      this.addItemRow();
    }

    document.getElementById('exchange-modal').classList.add('active');
  },
  hideModal: function() {
    document.getElementById('exchange-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
    this._editingId = null;
  },
  _bindEvents: function() {
    const form = document.getElementById('exchange-form');
    form.onsubmit = null;
    form.onsubmit = async (e) => {
      e.preventDefault();
      await this.processExchange();
    };
  },
  processExchange: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = document.getElementById('save-btn');
    const itemRows = document.querySelectorAll('.ex-item-row');

    const items = Array.from(itemRows).map(row => {
      const sku = row.querySelector('.item-sku').value;
      const name = row.querySelector('.item-name').value;
      const cost = row.querySelector('.item-cost').value;
      const bn = row.querySelector('.item-bn').value;
      const exp = row.querySelector('.item-exp').value;
      const qty = parseInt(row.querySelector('.item-qty').value) || 0;

      const productMatch = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === sku.toLowerCase());
      const finalName = productMatch ? (productMatch.prodName || productMatch.name || name) : name;
      const finalCost = productMatch ? (productMatch.cost || productMatch.price || cost) : cost;

      return { sku, name: finalName, cost: finalCost, bn, exp, qty };
    }).filter(i => i.sku);

    const mergedItems = [];
    items.forEach(item => {
      const existing = mergedItems.find(m => m.sku === item.sku && m.bn === item.bn);
      if (existing) {
        existing.qty += item.qty;
      } else {
        mergedItems.push(item);
      }
    });

    if (mergedItems.length === 0) return alert("Please add at least one valid item.");

    const staffName = document.getElementById('ex-staff').value;
    const sourceLoc = document.getElementById('ex-from').value;
    const targetLoc = document.getElementById('ex-to').value;

    const logData = {
      staff: staffName,
      from: sourceLoc,
      to: targetLoc,
      notes: document.getElementById('ex-notes').value || '',
      items: mergedItems,
      sku: mergedItems[0].sku,
      name: mergedItems[0].name,
      qty: mergedItems.reduce((sum, i) => sum + i.qty, 0),
      bankName: document.getElementById('ex-bank-name').value || '',
      bankAccount: document.getElementById('ex-bank-account').value || ''
    };

    btn.disabled = true;
    btn.innerText = "Syncing Data...";

    let targetId = this._editingId;
    let operationType = "Transfer Created";

    if (this._editingId) {
      const index = this._exchangeLogs.findIndex(l => l.id === this._editingId);
      if (index !== -1) {
        this._exchangeLogs[index] = { ...this._exchangeLogs[index], ...logData, editDate: new Date().toLocaleString() };
        operationType = "Transfer Edited";
      }
    } else {
      targetId = 'EX' + Date.now();
      const newLog = { id: targetId, ...logData, date: new Date().toLocaleString() };
      this._exchangeLogs.unshift(newLog);
    }

    this.renderLogs();
    await this.syncLogs();

    if (window.LogModule && typeof window.LogModule.addLog === 'function') {
      const logContent = `${operationType}: ${mergedItems.length} items from ${sourceLoc} to ${targetLoc} (ID: ${targetId})`;
      await window.LogModule.addLog('ExchangePortal', logContent, staffName);
    }

    this.hideModal();
    btn.disabled = false;
    btn.innerText = "Confirm & Sync to Cloud";

    if (confirm("Transfer successfully recorded! Download PDF receipt?")) {
      this.downloadPDF(targetId);
    }
  },
  downloadPDF: function(id) {
    const log = this._exchangeLogs.find(l => l.id === id);
    if (!log || !window.jspdf) return alert("System not ready.");

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'mm', 'a4');

    doc.setFontSize(22);
    doc.text("STOCK TRANSFER RECEIPT", 148, 20, { align: "center" });

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Voucher ID: ${log.id}`, 14, 35);
    doc.text(`Date Issued: ${log.date}`, 14, 40);
    doc.text(`Authorized By: ${log.staff}`, 14, 45);

    doc.setDrawColor(200);
    doc.line(14, 50, 282, 50);

    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`FROM: ${log.from}`, 14, 60);
    doc.text(`TO: ${log.to}`, 148, 60);
    doc.line(14, 65, 282, 65);

    const tableData = log.items.map((item, index) => [
      index + 1,
      item.sku,
      item.name,
      item.cost || '-',
      item.bn || '-',
      item.exp || '-',
      item.qty
    ]);

    doc.autoTable({
      startY: 75,
      head: [['#', 'SKU ID', 'Description', 'Cost', 'BN', 'EXP', 'Qty']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [30, 41, 59] },
    });

    const finalY = doc.lastAutoTable.finalY + 15;

    if (log.notes) {
      doc.setFontSize(10);
      doc.text("REMARKS:", 14, finalY);
      doc.setFontSize(9);
      doc.text(log.notes, 14, finalY + 7, { maxWidth: 260 });
    }

    let bankTextY = finalY;
    if (log.notes) {
      bankTextY = finalY + 7 + 5;
    }

    const bankName = log.bankName ? log.bankName.trim() : '';
    const bankAccount = log.bankAccount ? log.bankAccount.trim() : '';

    if (bankName || bankAccount) {
      let bankLine = '';
      if (bankName && bankAccount) {
        bankLine = `Bank: ${bankName} | Account: ${bankAccount}`;
      } else if (bankName) {
        bankLine = `Bank: ${bankName}`;
      } else if (bankAccount) {
        bankLine = `Account: ${bankAccount}`;
      }
      doc.setFontSize(9);
      doc.setTextColor(80, 80, 80);
      doc.text(bankLine, 14, bankTextY + 10);
    }

    doc.save(`Receipt_${log.id}.pdf`);
  },
  deleteLog: async function(id) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (!id || !confirm("Permanently delete this transfer record?")) return;

    const logToDelete = this._exchangeLogs.find(l => l.id === id);
    this._exchangeLogs = this._exchangeLogs.filter(l => l.id !== id);
    this.renderLogs();
    await this.syncLogs();

    if (window.LogModule && typeof window.LogModule.addLog === 'function') {
      await window.LogModule.addLog('ExchangePortal', `Record Deleted: ${id}`, logToDelete?.staff || 'System');
    }

    this.hideModal();
  },
  renderLogs: function() {
    const area = document.getElementById('exchange-list-area');
    const start = (this._currentPage - 1) * this._pageSize;
    const paged = this._exchangeLogs.slice(start, start + this._pageSize);

    if (this._exchangeLogs.length === 0) {
      area.innerHTML = `<div class="ex-empty-state">No transfer logs found.</div>`;
      return;
    }

    area.innerHTML = `
      <div class="ex-list-table-container">
        <table class="ex-responsive-table">
          <thead>
            <tr>
              <th>Manifest & Details</th>
              <th>Movement Route</th>
              <th class="txt-center">Qty</th>
              <th>Handler</th>
              <th class="txt-right">Operations</th>
            </tr>
          </thead>
          <tbody>
            ${paged.map(l => {
              const itemCount = l.items ? l.items.length : 1;
              const displayName = itemCount > 1 ? `${l.name} (+${itemCount-1} more)` : l.name;
              const bankInfo = (l.bankName || l.bankAccount) ? '<span class="bank-chip">BANK</span>' : '';
              return `
                <tr class="ex-row-entry">
                  <td data-label="Manifest">
                    <div class="ex-item-info">
                      <div class="ex-badge-line">
                        <span class="sku-chip">${l.sku}</span>
                        ${bankInfo}
                        ${itemCount > 1 ? '<span class="multi-chip">MULTI</span>' : ''}
                      </div>
                      <div class="ex-main-name">${displayName}</div>
                      <div class="ex-date-stamp">${l.date}</div>
                    </div>
                  </td>
                  <td data-label="Route">
                    <div class="ex-route-flow">
                      <span class="ex-loc origin">${l.from}</span>
                      <svg class="ex-arrow" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14m-7-7l7 7-7 7"/></svg>
                      <span class="ex-loc destination">${l.to}</span>
                    </div>
                  </td>
                  <td data-label="Total Qty" class="txt-center">
                    <span class="ex-qty-pill">${l.qty}</span>
                  </td>
                  <td data-label="Handler"><span class="ex-staff-label">${l.staff || '---'}</span></td>
                  <td data-label="Operations" class="txt-right">
                    <div class="ex-action-cluster">
                      <button type="button" class="ex-btn-icon pdf" onclick="ExchangePortalModule.downloadPDF('${l.id}')" title="Print PDF">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                      </button>
                      <button type="button" class="ex-btn-icon edit" onclick="ExchangePortalModule.showExchangeModal('${l.id}')" title="Modify">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  },
  syncLogs: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._logFileName}`, {
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify({ logs: this._exchangeLogs }, null, 2))));

    try {
      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._logFileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Update Exchange Logs",
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        const d = await res.json();
        this._sha = d.content.sha;
      } else {
        const errorData = await res.json();
        console.error("Sync Error:", errorData);
      }
    } catch (e) {
      console.error("Sync Error:", e);
    }
  },
  handleSearch: function(val) {
    const q = val.toLowerCase();

    const filtered = this._exchangeLogs.filter(l =>
      l.id.toLowerCase().includes(q) ||
      l.staff.toLowerCase().includes(q) ||
      l.from.toLowerCase().includes(q) ||
      l.to.toLowerCase().includes(q) ||
      (l.bankName && l.bankName.toLowerCase().includes(q)) ||
      (l.bankAccount && l.bankAccount.toLowerCase().includes(q)) ||
      l.items.some(i => i.sku.toLowerCase().includes(q) || i.name.toLowerCase().includes(q))
    );

    const originalLogs = this._exchangeLogs;
    this._exchangeLogs = filtered;
    this.renderLogs();
    this._exchangeLogs = originalLogs;
  },
  _injectStyles: function() {
    if (document.getElementById('ex-portal-v5-css')) return;

    const s = document.createElement('style');
    s.id = 'ex-portal-v5-css';
    s.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .ex-app-shell {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .ex-main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .title-meta h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .title-meta p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .ex-fab-btn {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .ex-fab-btn:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ex-toolbar {
        margin-bottom: 20px;
      }

      .ex-search-wrapper {
        position: relative;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .ex-search-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #log-search {
        width: 100%;
        border: none;
        padding: 0 0 0 10px;
        font-size: 14px;
        background: transparent;
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      #log-search::placeholder {
        color: var(--text-dim);
      }

      .ex-list-table-container {
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        overflow-x: auto;
        box-shadow: var(--shadow-xs);
        width: 100%;
      }

      .ex-responsive-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
      }

      .ex-responsive-table th {
        text-align: left;
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        background: var(--surface-soft);
        border-bottom: 1px solid var(--border);
      }

      .ex-responsive-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        transition: background var(--transition-fast);
        color: var(--text);
        font-size: 14px;
        vertical-align: middle;
      }

      .ex-responsive-table tbody tr:last-child td {
        border-bottom: none;
      }

      .ex-row-entry:hover td {
        background: var(--surface-soft);
      }

      .txt-center {
        text-align: center !important;
      }

      .txt-right {
        text-align: right !important;
      }

      .ex-badge-line {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
      }

      .sku-chip {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        font-weight: 700;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        display: inline-block;
        white-space: nowrap;
      }

      .bank-chip {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 10px;
        font-weight: 700;
        color: var(--text-secondary);
        background: var(--surface-soft);
        border: 1px solid var(--border);
        padding: 3px 6px;
        border-radius: var(--radius-xs);
        display: inline-block;
        white-space: nowrap;
      }

      .multi-chip {
        font-size: 10px;
        font-weight: 700;
        background: var(--amber-soft);
        color: var(--amber);
        border: 1px solid rgba(245, 158, 11, 0.25);
        padding: 3px 8px;
        border-radius: var(--radius-xs);
        display: inline-block;
        white-space: nowrap;
      }

      .ex-main-name {
        font-weight: 700;
        font-size: 14px;
        margin-top: 6px;
        color: var(--text);
        word-break: break-word;
      }

      .ex-date-stamp {
        font-size: 12px;
        color: var(--text-dim);
        margin-top: 2px;
      }

      .ex-route-flow {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        flex-wrap: wrap;
      }

      .ex-loc {
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        font-size: 12px;
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        word-break: break-word;
      }

      .ex-loc.origin {
        background: var(--red-soft);
        color: var(--danger);
        border-color: rgba(239, 68, 68, 0.2);
      }

      .ex-loc.destination {
        background: var(--green-soft);
        color: var(--green);
        border-color: rgba(16, 185, 129, 0.2);
      }

      .ex-arrow {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .ex-qty-pill {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        background: var(--surface-soft);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        font-weight: 700;
        font-size: 13px;
        color: var(--text);
        border: 1px solid var(--border);
        display: inline-block;
      }

      .ex-staff-label {
        font-weight: 600;
        color: var(--text);
        word-break: break-word;
      }

      .ex-action-cluster {
        display: flex;
        gap: 8px;
        justify-content: flex-end;
      }

      .ex-btn-icon {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        width: 36px;
        height: 36px;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .ex-btn-icon:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .ex-full-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: none;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .ex-full-modal.active {
        display: flex;
      }

      .ex-modal-container {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .ex-modal-top {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .ex-close-minimal {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .ex-close-minimal:hover {
        background: var(--border);
        color: var(--text);
      }

      .ex-title-stack {
        flex: 1;
        min-width: 0;
      }

      .ex-title-stack h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .ex-title-stack p {
        margin: 2px 0 0;
        font-size: 12px;
        color: var(--text-dim);
      }

      .ex-del-action {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 38px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
        flex-shrink: 0;
      }

      .ex-del-action:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .ex-modal-body-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        padding-bottom: 104px;
        min-height: 0;
      }

      .ex-unified-form {
        width: 100%;
      }

      .ex-form-inner {
        max-width: 960px;
        margin: 0 auto;
        width: 100%;
      }

      .ex-form-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-xs);
      }

      .ex-form-card.highlight-card {
        border-left: 3px solid var(--primary);
      }

      .ex-section-tag {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: var(--primary);
        margin-bottom: 16px;
      }

      .ex-field-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
      }

      .ex-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .ex-input-group label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-secondary);
        letter-spacing: 0.04em;
      }

      .ex-input-group input,
      .ex-input-group select,
      .ex-input-group textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .ex-input-group input,
      .ex-input-group select {
        height: 42px;
      }

      .ex-input-group textarea {
        resize: vertical;
        min-height: 80px;
      }

      .ex-input-group input:focus,
      .ex-input-group select:focus,
      .ex-input-group textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .ex-items-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 16px;
      }

      .ex-items-header h3 {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: var(--text);
      }

      .ex-add-row-btn {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .ex-add-row-btn:hover {
        background: rgba(79, 70, 229, 0.14);
      }

      .ex-items-stack {
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .ex-item-row {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 14px;
      }

      .ex-row-grid {
        display: grid;
        grid-template-columns: 1.4fr 2fr 1fr 1.2fr 1.4fr 0.8fr 38px;
        gap: 12px;
        align-items: end;
      }

      .readonly-field {
        background: var(--surface) !important;
        font-weight: 600;
        color: var(--text-secondary) !important;
        cursor: default;
      }

      .ex-remove-row {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-dim);
        cursor: pointer;
        border-radius: var(--radius-xs);
        transition: all var(--transition-fast);
        height: 42px;
        width: 38px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        justify-self: end;
      }

      .ex-remove-row:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .ex-form-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 14px 24px;
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        z-index: 20;
        box-shadow: var(--shadow-sm);
      }

      .ex-btn-cancel {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        height: 42px;
        padding: 0 20px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .ex-btn-cancel:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .ex-btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        border-radius: var(--radius-md);
        height: 42px;
        padding: 0 22px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .ex-btn-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ex-btn-save:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .ex-empty-state {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
      }

      @media (max-width: 1024px) {
        .ex-row-grid {
          grid-template-columns: 1fr 1fr 1fr;
        }
        .grid-name {
          grid-column: span 2;
        }
        .ex-remove-row {
          grid-column: span 3;
          width: 100%;
        }
      }

      @media (max-width: 768px) {
        .ex-app-shell {
          padding: 16px;
        }
        .ex-main-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .title-meta h1 {
          font-size: 22px;
        }
        .ex-fab-btn {
          justify-content: center;
          width: 100%;
        }
        .ex-search-wrapper {
          max-width: 100%;
        }
        .ex-list-table-container {
          background: transparent;
          border: none;
          box-shadow: none;
          overflow: visible;
        }
        .ex-responsive-table {
          min-width: 0;
        }
        .ex-responsive-table thead {
          display: none;
        }
        .ex-row-entry {
          display: block;
          margin-bottom: 12px;
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          background: var(--surface);
          box-shadow: var(--shadow-xs);
        }
        .ex-row-entry td {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border-bottom: 1px solid var(--border);
          text-align: right;
        }
        .ex-row-entry td:last-child {
          border-bottom: none;
        }
        .ex-row-entry td::before {
          content: attr(data-label);
          font-weight: 700;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--text-dim);
          text-align: left;
          flex-shrink: 0;
        }
        .ex-item-info {
          text-align: right;
        }
        .ex-badge-line {
          justify-content: flex-end;
        }
        .ex-route-flow {
          justify-content: flex-end;
        }
        .ex-row-grid {
          grid-template-columns: 1fr;
        }
        .grid-name,
        .grid-sku,
        .ex-remove-row {
          grid-column: span 1;
        }
        .ex-modal-top {
          padding: 12px 16px;
        }
        .ex-title-stack h2 {
          font-size: 16px;
        }
        .ex-modal-body-scroll {
          padding: 16px;
          padding-bottom: 116px;
        }
        .ex-form-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .ex-form-footer {
          flex-direction: column;
          padding: 12px 16px;
        }
        .ex-btn-cancel,
        .ex-btn-save {
          width: 100%;
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.ExchangePortalModule = ExchangePortalModule;

const LogModule = {
  allLogs: [],
  _sha: null,
  _currentPage: 1,
  _pageSize: 20,
  _filteredLogs: [],
  render: async function(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = `
      <div class="log-app-wrapper">
        <header class="log-main-header">
          <div class="header-content">
            <h1>System Logs</h1>
            </div>
          <div class="header-actions">
            <button type="button" class="btn-refresh-modern" onclick="LogModule.refresh()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"></path><path d="M1 20v-6h6"></path><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
              <span>Sync Logs</span>
            </button>
            <button type="button" class="btn-delete-modern" onclick="LogModule.showDeleteOptions()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
              <span>Delete Logs</span>
            </button>
          </div>
        </header>

        <section class="log-filter-section">
          <div class="search-input-group">
            <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="logSearch" placeholder="Search operator, action or log ID...">
          </div>
        </section>

        <div class="log-content-card">
          <div class="desktop-table-wrapper">
            <table class="log-table">
              <thead>
                <tr>
                  <th>Log ID</th>
                  <th>Activity Details</th>
                  <th>Node</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody id="logTableBody">
                <tr><td colspan="4" class="initial-msg">Initializing connection...</td></tr>
              </tbody>
            </table>
          </div>
          <div id="logMobileList" class="mobile-log-list">
            <div class="initial-msg">Connecting to cloud logs...</div>
          </div>
          <div class="pagination-container" id="paginationContainer">
            <div class="pagination-info" id="paginationInfo"></div>
            <div class="pagination-controls" id="paginationControls"></div>
          </div>
        </div>

        <div id="deleteModal" class="delete-modal" style="display:none;">
          <div class="delete-modal-content">
            <div class="delete-modal-header">
              <h3>Delete Logs</h3>
              <button type="button" class="delete-modal-icon-close" onclick="LogModule.closeDeleteModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
              </button>
            </div>
            <p>Select an option to delete logs:</p>
            <div class="delete-options">
              <button type="button" class="delete-option-btn" onclick="LogModule.deleteLogs('30days')">
                <span class="delete-option-badge">30D</span>
                <span class="delete-option-text">Delete logs older than 30 days</span>
              </button>
              <button type="button" class="delete-option-btn delete-all" onclick="LogModule.deleteLogs('all')">
                <span class="delete-option-badge">ALL</span>
                <span class="delete-option-text">Delete all logs</span>
              </button>
            </div>
            <button type="button" class="delete-modal-close" onclick="LogModule.closeDeleteModal()">Cancel</button>
          </div>
        </div>
      </div>
    `;

    document.getElementById('logSearch').addEventListener('input', (e) => {
      this._currentPage = 1;
      this.filterLogs(e.target.value);
    });

    await this.refresh();
  },

  refresh: async function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghRepo || !config.ghToken) return;

    const url = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/logs.json`;
    try {
      const res = await fetch(`${url}?t=${Date.now()}`, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        this.allLogs = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this._filteredLogs = [...this.allLogs];
        this._currentPage = 1;
        this.renderUI(this._filteredLogs);
      } else {
        this.showEmpty();
      }
    } catch (e) {
      console.error("Log fetch failed", e);
      this.showEmpty();
    }
  },

  addLog: async function(pos, action, operator = "System") {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghRepo || !config.ghToken) return;

    try {
      const url = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/logs.json`;
      const getRes = await fetch(`${url}?t=${Date.now()}`, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      let currentLogs = [];
      let currentSha = null;

      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
        currentLogs = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      }

      const newLog = {
        no: Date.now().toString().slice(-6),
        operator: operator,
        action: action,
        pos: pos,
        timestamp: new Date().toLocaleString('en-GB', { hour12: false })
      };

      currentLogs.push(newLog);

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(currentLogs, null, 2))));

      await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        body: JSON.stringify({
          message: `Log: ${pos} - ${action}`,
          content: content,
          sha: currentSha
        })
      });

      if (this.allLogs.length > 0) await this.refresh();
    } catch (e) {
      console.error("LogModule: Failed to add log entry", e);
    }
  },

  renderUI: function(logs) {
    const searchQuery = document.getElementById('logSearch')?.value || '';
    let displayLogs = [...logs].reverse();
    
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      displayLogs = displayLogs.filter(log =>
        (log.operator && log.operator.toLowerCase().includes(q)) ||
        (log.no && log.no.toString().toLowerCase().includes(q)) ||
        (log.action && log.action.toLowerCase().includes(q)) ||
        (log.pos && log.pos.toLowerCase().includes(q))
      );
    }

    const totalItems = displayLogs.length;
    const totalPages = Math.ceil(totalItems / this._pageSize) || 1;
    
    if (this._currentPage > totalPages) {
      this._currentPage = Math.max(1, totalPages);
    }
    
    const startIndex = (this._currentPage - 1) * this._pageSize;
    const endIndex = Math.min(startIndex + this._pageSize, totalItems);
    const pageItems = displayLogs.slice(startIndex, endIndex);

    const tbody = document.getElementById('logTableBody');
    if (tbody) {
      if (pageItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="empty-msg">No results found</td></tr>`;
      } else {
        tbody.innerHTML = pageItems.map(log => `
          <tr>
            <td class="log-id-cell">#${log.no}</td>
            <td class="log-info-cell">
              <span class="operator-name">${log.operator}</span>
              <span class="action-desc">${log.action}</span>
            </td>
            <td><span class="node-badge">${log.pos}</span></td>
            <td class="time-cell">${log.timestamp}</td>
          </tr>
        `).join('');
      }
    }

    const mobileList = document.getElementById('logMobileList');
    if (mobileList) {
      if (pageItems.length === 0) {
        mobileList.innerHTML = `<div class="empty-msg">No results found</div>`;
      } else {
        mobileList.innerHTML = pageItems.map(log => `
          <div class="mobile-log-card">
            <div class="card-top">
              <span class="mobile-log-id">#${log.no}</span>
              <span class="node-badge">${log.pos}</span>
            </div>
            <div class="card-mid">
              <div class="mobile-operator">${log.operator}</div>
              <div class="mobile-action">${log.action}</div>
            </div>
            <div class="card-bottom">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              <span>${log.timestamp}</span>
            </div>
          </div>
        `).join('');
      }
    }

    this.renderPagination(totalItems, totalPages);
  },

  renderPagination: function(totalItems, totalPages) {
    const infoEl = document.getElementById('paginationInfo');
    const controlsEl = document.getElementById('paginationControls');
    
    if (!infoEl || !controlsEl) return;

    if (totalItems === 0) {
      infoEl.textContent = 'No logs to display';
      controlsEl.innerHTML = '';
      return;
    }

    const startItem = (this._currentPage - 1) * this._pageSize + 1;
    const endItem = Math.min(this._currentPage * this._pageSize, totalItems);
    infoEl.textContent = `Showing ${startItem}-${endItem} of ${totalItems} logs`;

    let controlsHTML = '';
    
    controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(1)" ${this._currentPage === 1 ? 'disabled' : ''}>First</button>`;
    controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(${this._currentPage - 1})" ${this._currentPage === 1 ? 'disabled' : ''}>Previous</button>`;
    
    const maxVisiblePages = 5;
    let startPage = Math.max(1, this._currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    if (startPage > 1) {
      controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(1)">1</button>`;
      if (startPage > 2) {
        controlsHTML += `<span class="pagination-ellipsis">...</span>`;
      }
    }
    
    for (let i = startPage; i <= endPage; i++) {
      controlsHTML += `<button type="button" class="pagination-btn ${i === this._currentPage ? 'active' : ''}" onclick="LogModule.goToPage(${i})">${i}</button>`;
    }
    
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        controlsHTML += `<span class="pagination-ellipsis">...</span>`;
      }
      controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(${totalPages})">${totalPages}</button>`;
    }
    
    controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(${this._currentPage + 1})" ${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>`;
    controlsHTML += `<button type="button" class="pagination-btn" onclick="LogModule.goToPage(${totalPages})" ${this._currentPage === totalPages ? 'disabled' : ''}>Last</button>`;
    
    controlsEl.innerHTML = controlsHTML;
  },

  goToPage: function(page) {
    const totalItems = this._filteredLogs.length;
    const totalPages = Math.ceil(totalItems / this._pageSize);
    
    if (page < 1 || page > totalPages || page === this._currentPage) return;
    
    this._currentPage = page;
    this.renderUI(this._filteredLogs);
    
    const container = document.querySelector('.log-content-card');
    if (container) {
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  },

  showEmpty: function() {
    const emptyHTML = `
      <div class="empty-state">
        <p>No activity logs found</p>
      </div>
    `;

    const tbody = document.getElementById('logTableBody');
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="4">${emptyHTML}</td></tr>`;
    }

    const mlist = document.getElementById('logMobileList');
    if (mlist) {
      mlist.innerHTML = emptyHTML;
    }

    const infoEl = document.getElementById('paginationInfo');
    const controlsEl = document.getElementById('paginationControls');
    if (infoEl) infoEl.textContent = '';
    if (controlsEl) controlsEl.innerHTML = '';
  },

  filterLogs: function(query) {
    if (!this.allLogs) return;

    const q = query.toLowerCase();
    this._filteredLogs = this.allLogs.filter(log =>
      (log.operator && log.operator.toLowerCase().includes(q)) ||
      (log.no && log.no.toString().toLowerCase().includes(q)) ||
      (log.action && log.action.toLowerCase().includes(q)) ||
      (log.pos && log.pos.toLowerCase().includes(q))
    );

    this._currentPage = 1;
    this.renderUI(this._filteredLogs);
  },

  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },

  showDeleteOptions: function() {
    if (!this._isAdmin()) {
      alert('Only administrators can delete logs.');
      return;
    }
    document.getElementById('deleteModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
  },

  closeDeleteModal: function() {
    document.getElementById('deleteModal').style.display = 'none';
    document.body.style.overflow = 'auto';
  },

  deleteLogs: async function(mode) {
    if (!this._isAdmin()) {
      alert('Only administrators can delete logs.');
      return;
    }

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghRepo || !config.ghToken) {
      alert('Repository configuration not found.');
      return;
    }

    if (!this.allLogs || this.allLogs.length === 0) {
      alert('No logs to delete.');
      this.closeDeleteModal();
      return;
    }

    let logsToKeep = [];
    let message = '';

    if (mode === '30days') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      logsToKeep = this.allLogs.filter(log => {
        const logDate = new Date(log.timestamp.replace(/(\d{2})\/(\d{2})\/(\d{4}), (\d{2}):(\d{2}):(\d{2})/, '$3-$2-$1T$4-$5-$6'));
        return logDate >= thirtyDaysAgo;
      });
      
      message = `Delete logs older than 30 days (${this.allLogs.length - logsToKeep.length} logs will be removed)?`;
    } else if (mode === 'all') {
      logsToKeep = [];
      message = `Delete all ${this.allLogs.length} logs? This action cannot be undone.`;
    }

    if (!confirm(message)) {
      return;
    }

    try {
      const url = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/logs.json`;
      
      let currentSha = this._sha;
      if (!currentSha) {
        const getRes = await fetch(`${url}?t=${Date.now()}`, {
          headers: {
            'Authorization': `token ${config.ghToken}`
          },
          cache: 'no-store'
        });
        if (getRes.ok) {
          const data = await getRes.json();
          currentSha = data.sha;
        }
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(logsToKeep, null, 2))));

      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        body: JSON.stringify({
          message: `Delete logs: ${mode}`,
          content: content,
          sha: currentSha
        })
      });

      if (response.ok) {
        this.closeDeleteModal();
        await this.refresh();
        alert('Logs deleted successfully.');
      } else {
        const errorData = await response.json();
        alert(`Failed to delete logs: ${errorData.message || 'Unknown error'}`);
      }
    } catch (e) {
      console.error("LogModule: Failed to delete logs", e);
      alert('Failed to delete logs. Please try again.');
    }
  },

  _injectStyles: function() {
    if (document.getElementById('log-modern-css')) return;

    const s = document.createElement('style');
    s.id = 'log-modern-css';
    s.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .log-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .log-main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .header-content h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .subtitle {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .header-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .btn-refresh-modern {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        height: 40px;
        padding: 0 16px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        white-space: nowrap;
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .btn-refresh-modern:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .btn-delete-modern {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        height: 40px;
        padding: 0 16px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        color: var(--danger);
        white-space: nowrap;
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .btn-delete-modern:hover {
        border-color: var(--danger);
        background: var(--red-soft);
        color: var(--danger);
      }

      .log-filter-section {
        margin-bottom: 20px;
      }

      .search-input-group {
        position: relative;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .search-input-group:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #logSearch {
        width: 100%;
        border: none;
        padding: 0 0 0 10px;
        font-size: 14px;
        background: transparent;
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      #logSearch::placeholder {
        color: var(--text-dim);
      }

      .log-content-card {
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        overflow: hidden;
        box-shadow: var(--shadow-xs);
      }

      .desktop-table-wrapper {
        overflow-x: auto;
        width: 100%;
      }

      .log-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 680px;
      }

      .log-table th {
        background: var(--surface-soft);
        text-align: left;
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border);
      }

      .log-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        font-size: 14px;
        vertical-align: middle;
        color: var(--text);
      }

      .log-table tbody tr:last-child td {
        border-bottom: none;
      }

      .log-table tbody tr:hover {
        background: var(--surface-soft);
      }

      .log-id-cell {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-weight: 700;
        color: var(--primary);
        font-size: 13px;
        white-space: nowrap;
      }

      .operator-name {
        display: block;
        font-weight: 700;
        color: var(--text);
        margin-bottom: 2px;
        word-break: break-word;
      }

      .action-desc {
        font-size: 13px;
        color: var(--text-secondary);
        line-height: 1.45;
        word-break: break-word;
      }

      .node-badge {
        font-size: 11px;
        font-weight: 700;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        white-space: nowrap;
      }

      .time-cell {
        font-size: 13px;
        color: var(--text-dim);
        white-space: nowrap;
      }

      .mobile-log-list {
        display: none;
        padding: 16px;
        flex-direction: column;
        gap: 12px;
      }

      .mobile-log-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        padding: 16px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .mobile-log-card:hover {
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .card-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        gap: 8px;
        flex-wrap: wrap;
      }

      .mobile-log-id {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-weight: 700;
        color: var(--primary);
        font-size: 12px;
        background: var(--surface-soft);
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
      }

      .mobile-operator {
        font-weight: 700;
        color: var(--text);
        font-size: 15px;
        margin-bottom: 4px;
        word-break: break-word;
      }

      .mobile-action {
        font-size: 13px;
        color: var(--text-secondary);
        line-height: 1.5;
        margin-bottom: 12px;
        word-break: break-word;
      }

      .card-bottom {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: var(--text-dim);
        font-weight: 500;
        border-top: 1px solid var(--border);
        padding-top: 10px;
      }

      .initial-msg,
      .empty-msg {
        text-align: center;
        padding: 48px 20px;
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
      }

      .empty-state {
        text-align: center;
        padding: 48px 20px;
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
      }

      .empty-state p {
        margin: 0;
      }

      .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        border-top: 1px solid var(--border);
        flex-wrap: wrap;
        gap: 12px;
        background: var(--surface-soft);
      }

      .pagination-info {
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 600;
      }

      .pagination-controls {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        align-items: center;
      }

      .pagination-btn {
        height: 36px;
        min-width: 36px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        background: var(--surface);
        color: var(--text-secondary);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        text-align: center;
        font-family: var(--font-sans);
      }

      .pagination-btn:hover:not(:disabled):not(.active) {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .pagination-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .pagination-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .pagination-ellipsis {
        padding: 0 6px;
        color: var(--text-dim);
        font-size: 13px;
      }

      .delete-modal {
        position: fixed;
        inset: 0;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        background: rgba(15, 23, 42, 0.45);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 99999;
        padding: 16px;
      }

      .delete-modal-content {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        max-width: 480px;
        width: 100%;
        box-shadow: var(--shadow-lg);
      }

      .delete-modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 8px;
      }

      .delete-modal-content h3 {
        margin: 0;
        color: var(--text);
        font-size: 18px;
        font-weight: 700;
      }

      .delete-modal-icon-close {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 34px;
        height: 34px;
        border-radius: var(--radius-xs);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: var(--text-secondary);
        cursor: pointer;
        transition: all var(--transition-fast);
      }

      .delete-modal-icon-close:hover {
        background: var(--border);
        color: var(--text);
      }

      .delete-modal-content p {
        margin: 0 0 20px;
        color: var(--text-secondary);
        font-size: 13px;
      }

      .delete-options {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 16px;
      }

      .delete-option-btn {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        background: var(--surface);
        cursor: pointer;
        transition: all var(--transition-fast);
        font-size: 13px;
        font-weight: 600;
        color: var(--text);
        width: 100%;
        text-align: left;
        font-family: var(--font-sans);
      }

      .delete-option-btn:hover {
        border-color: var(--danger);
        background: var(--red-soft);
        color: var(--danger);
      }

      .delete-option-badge {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        flex-shrink: 0;
      }

      .delete-option-btn.delete-all .delete-option-badge {
        background: var(--red-soft);
        color: var(--danger);
        border-color: transparent;
      }

      .delete-option-text {
        flex: 1;
      }

      .delete-modal-close {
        width: 100%;
        height: 40px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        background: var(--surface);
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .delete-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
      }

      @media (max-width: 768px) {
        .log-app-wrapper {
          padding: 16px;
        }
        .log-main-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .header-content h1 {
          font-size: 22px;
        }
        .desktop-table-wrapper {
          display: none;
        }
        .mobile-log-list {
          display: flex;
        }
        .header-actions {
          width: 100%;
        }
        .btn-refresh-modern,
        .btn-delete-modern {
          flex: 1;
          justify-content: center;
        }
        .search-input-group {
          max-width: 100%;
        }
        .pagination-container {
          flex-direction: column;
          align-items: stretch;
          gap: 10px;
          padding: 14px 16px;
        }
        .pagination-controls {
          justify-content: center;
        }
        .delete-modal-content {
          padding: 20px;
          border-radius: var(--radius-lg);
        }
        .log-content-card {
          border-radius: var(--radius-lg);
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.LogModule = LogModule;

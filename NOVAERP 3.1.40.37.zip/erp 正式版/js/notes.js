const NoteModule = {
  allNotes: [],
  currentPage: 1,
  pageSize: 20,
  editingId: null,
  render: async function(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = `
      <div class="note-app-container">
        <header class="note-header">
          <div class="note-brand">
            <h1>System Notes</h1>
            </div>
          <button type="button" id="toggleNoteForm" class="btn-add-note">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>New Note</span>
          </button>
        </header>

        <section class="note-filter-section">
          <div class="search-wrapper">
            <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="noteSearch" placeholder="Search by #No, title or content...">
          </div>
          <button type="button" onclick="NoteModule.refresh()" class="btn-refresh" title="Refresh Data">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6"></path><path d="M1 20v-6h6"></path><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
          </button>
        </section>

        <main id="noteListContainer" class="note-cards-grid">
          <div class="loading-state">Fetching your notes...</div>
        </main>

        <div id="notePagination" class="note-pagination-bar"></div>
      </div>

      <div id="noteFormContainer" class="note-modal-fullscreen">
        <div class="modal-content-wrapper">
          <nav class="modal-nav">
            <div class="modal-nav-left">
              <button type="button" id="closeFormBtn" class="btn-icon-back">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h2 id="formTitle">Note Editor</h2>
            </div>
            <div class="modal-nav-right">
              <button type="button" id="saveNoteBtn" class="btn-save">Sync to Cloud</button>
            </div>
          </nav>
          <div class="modal-body">
            <div class="form-group">
              <label>Note Heading</label>
              <input type="text" id="noteTitle" class="form-input" placeholder="e.g. Weekly Meeting Update">
            </div>
            <div class="form-group full-height">
              <label>Detailed Content</label>
              <textarea id="noteContent" class="form-textarea" placeholder="Start typing your notes here..."></textarea>
            </div>
            <div class="modal-mobile-actions">
              <button type="button" id="cancelNoteBtn" class="btn-cancel">Discard Changes</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const openBtn = document.getElementById('toggleNoteForm');
    const closeBtn = document.getElementById('closeFormBtn');
    const cancelBtn = document.getElementById('cancelNoteBtn');

    const toggleModal = (show, isEdit = false) => {
      this.editingId = isEdit ? this.editingId : null;
      document.getElementById('formTitle').innerText = isEdit ? "Edit Note" : "Create Note";
      document.getElementById('noteFormContainer').classList.toggle('active', show);
      document.body.style.overflow = show ? 'hidden' : 'auto';
      if (!show) {
        document.getElementById('noteTitle').value = "";
        document.getElementById('noteContent').value = "";
      }
    };

    openBtn.onclick = () => toggleModal(true);
    closeBtn.onclick = () => toggleModal(false);
    cancelBtn.onclick = () => toggleModal(false);

    document.getElementById('saveNoteBtn').onclick = () => this.saveNote();

    document.getElementById('noteSearch').addEventListener('input', (e) => {
      this.currentPage = 1;
      this.filterAndRender(e.target.value);
    });

    this.refresh();
  },

  refresh: async function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const status = document.getElementById('note-sync-status');
    const dot = document.getElementById('sync-dot');

    if (status) status.innerText = "Syncing...";
    if (dot) dot.className = "dot syncing";

    try {
      const res = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/notes.json?t=${Date.now()}`, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this.allNotes = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this.filterAndRender();
        if (status) status.innerText = "Cloud Synced";
        if (dot) dot.className = "dot online";
      } else {
        this.allNotes = [];
        this.filterAndRender();
        if (status) status.innerText = "Empty Data";
        if (dot) dot.className = "dot offline";
      }
    } catch (e) {
      if (status) status.innerText = "Sync Failed";
      if (dot) dot.className = "dot offline";
    }
  },

  deleteNote: async function(id) {
    const noteToDelete = this.allNotes.find(n => n.id === id);
    if (!confirm(`Permanently delete note: "${noteToDelete?.title || id}"?`)) return;

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const url = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/notes.json`;
    const headers = {
      'Authorization': `token ${config.ghToken}`
    };

    try {
      const res = await fetch(`${url}?t=${Date.now()}`, { headers, cache: 'no-store' });
      if (!res.ok) return alert("Cloud Fetch Failed");

      const data = await res.json();
      let cloudNotes = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      const filteredNotes = cloudNotes.filter(n => n.id !== id);

      const putRes = await fetch(url, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: `Delete Note ID: ${id}`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(filteredNotes, null, 2)))),
          sha: data.sha
        })
      });

      if (putRes.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          await window.LogModule.addLog('NoteModule', `Deleted note: ${noteToDelete?.title || id}`, config.staff || "Admin");
        }
        this.allNotes = this.allNotes.filter(n => n.id !== id);
        this.filterAndRender();
      }
    } catch (e) {
      alert("Delete failed");
    }
  },

  saveNote: async function() {
    const title = document.getElementById('noteTitle').value.trim();
    const content = document.getElementById('noteContent').value.trim();

    if (!title || !content) {
      alert("Please fill in both title and content.");
      return;
    }

    const btn = document.getElementById('saveNoteBtn');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Processing...";

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const url = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/notes.json`;
    const headers = {
      'Authorization': `token ${config.ghToken}`
    };

    try {
      const res = await fetch(`${url}?t=${Date.now()}`, { headers, cache: 'no-store' });

      let sha = null;
      let notes = [];

      if (res.ok) {
        const data = await res.json();
        sha = data.sha;
        notes = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      }

      const isEdit = this.editingId !== null;

      if (isEdit) {
        const index = notes.findIndex(n => n.id === this.editingId);
        if (index !== -1) {
          notes[index] = {
            ...notes[index],
            title,
            content,
            timestamp: new Date().toLocaleString() + " (Edited)"
          };
        }
      } else {
        notes.unshift({
          id: Date.now(),
          title,
          content,
          operator: config.staff || "Admin",
          pos: window.pos || "Master",
          timestamp: new Date().toLocaleString()
        });
      }

      const putRes = await fetch(url, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: `${isEdit ? 'Edit' : 'Create'} Note: ${title}`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(notes, null, 2)))),
          sha: sha || undefined
        })
      });

      if (putRes.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          const logAction = isEdit ? `Edited note: ${title}` : `Created new note: ${title}`;
          await window.LogModule.addLog('NoteModule', logAction, config.staff || "Admin");
        }
        document.getElementById('closeFormBtn').click();
        await this.refresh();
      }
    } catch (e) {
      alert("Network Sync Error");
    } finally {
      btn.disabled = false;
      btn.innerText = originalText;
    }
  },

  editNote: function(id) {
    const note = this.allNotes.find(n => n.id === id);
    if (!note) return;

    this.editingId = id;
    document.getElementById('noteTitle').value = note.title;
    document.getElementById('noteContent').value = note.content;
    document.getElementById('formTitle').innerText = "Edit Note";
    document.getElementById('noteFormContainer').classList.add('active');
    document.body.style.overflow = 'hidden';
  },

  filterAndRender: function(query = "") {
    const searchTerm = (query || document.getElementById('noteSearch')?.value || "").toLowerCase();

    const notesWithNo = this.allNotes.map((n, index) => ({
      ...n,
      displayNo: (this.allNotes.length - index).toString()
    }));

    const filtered = notesWithNo.filter(n =>
      n.displayNo.includes(searchTerm) ||
      n.title.toLowerCase().includes(searchTerm) ||
      n.content.toLowerCase().includes(searchTerm)
    );

    const totalPages = Math.ceil(filtered.length / this.pageSize);
    const pagedData = filtered.slice(
      (this.currentPage - 1) * this.pageSize,
      this.currentPage * this.pageSize
    );

    const listContainer = document.getElementById('noteListContainer');
    if (!listContainer) return;

    listContainer.innerHTML = pagedData.length === 0
      ? `<div class="empty-placeholder">No matching notes found.</div>`
      : pagedData.map(note => `
        <article class="note-card">
          <div class="note-card-header">
            <div class="header-main">
              <span class="note-badge">#${note.displayNo}</span>
              <h3 class="note-title-text">${note.title}</h3>
            </div>
            <span class="note-pos-tag">${note.pos}</span>
          </div>
          <div class="note-card-body">${note.content}</div>
          <footer class="note-card-footer">
            <div class="meta-info">
              <span class="meta-operator">${note.operator}</span>
              <span class="meta-time">${note.timestamp}</span>
            </div>
            <div class="note-actions">
              <button type="button" class="btn-edit" onclick="NoteModule.editNote(${note.id})">Edit</button>
              <button type="button" class="btn-delete" onclick="NoteModule.deleteNote(${note.id})">Delete</button>
            </div>
          </footer>
        </article>
      `).join('');

    this.renderPagination(totalPages);
  },

  renderPagination: function(totalPages) {
    const pagination = document.getElementById('notePagination');
    if (!pagination || totalPages <= 1) {
      if (pagination) pagination.innerHTML = "";
      return;
    }

    let html = "";
    for (let i = 1; i <= totalPages; i++) {
      const isActive = i === this.currentPage;
      html += `<button type="button" onclick="NoteModule.goToPage(${i})" class="page-btn ${isActive ? 'active' : ''}">${i}</button>`;
    }
    pagination.innerHTML = html;
  },

  goToPage: function(page) {
    this.currentPage = page;
    this.filterAndRender();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  _injectStyles: function() {
    if (document.getElementById('note-modern-v2-css')) return;

    const s = document.createElement('style');
    s.id = 'note-modern-v2-css';
    s.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .note-app-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .note-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .note-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .sync-indicator {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
        margin-top: 4px;
      }

      .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #cbd5e1;
        flex-shrink: 0;
      }

      .dot.online {
        background: var(--green);
      }

      .dot.syncing {
        background: var(--primary);
      }

      .dot.offline {
        background: var(--danger);
      }

      .btn-add-note {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .btn-add-note:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .note-filter-section {
        display: flex;
        gap: 12px;
        margin-bottom: 20px;
        align-items: center;
      }

      .search-wrapper {
        position: relative;
        flex: 1;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .search-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #noteSearch {
        width: 100%;
        border: none;
        padding: 0 0 0 10px;
        font-size: 14px;
        background: transparent;
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      #noteSearch::placeholder {
        color: var(--text-dim);
      }

      .btn-refresh {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        height: 42px;
        width: 42px;
        padding: 0;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: var(--text-secondary);
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
      }

      .btn-refresh:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .note-cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 16px;
        width: 100%;
      }

      .note-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
        display: flex;
        flex-direction: column;
      }

      .note-card:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .note-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 14px;
        gap: 10px;
      }

      .header-main {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        flex-wrap: wrap;
      }

      .note-badge {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
        flex-shrink: 0;
      }

      .note-title-text {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .note-pos-tag {
        font-size: 11px;
        font-weight: 700;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        text-transform: uppercase;
        letter-spacing: 0.04em;
        flex-shrink: 0;
      }

      .note-card-body {
        font-size: 13px;
        color: var(--text-secondary);
        line-height: 1.6;
        white-space: pre-wrap;
        word-break: break-word;
        margin-bottom: 16px;
        flex: 1;
        display: -webkit-box;
        -webkit-line-clamp: 4;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      .note-card-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 14px;
        border-top: 1px solid var(--border);
        gap: 10px;
        flex-wrap: wrap;
        margin-top: auto;
      }

      .meta-info {
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
      }

      .meta-operator {
        font-size: 12px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .meta-time {
        font-size: 11px;
        color: var(--text-dim);
        word-break: break-word;
      }

      .note-actions {
        display: flex;
        gap: 6px;
        flex-shrink: 0;
      }

      .note-actions button {
        height: 30px;
        padding: 0 12px;
        border-radius: var(--radius-xs);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .btn-edit {
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .btn-edit:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .btn-delete {
        background: var(--surface);
        color: var(--danger);
        border: 1px solid var(--border);
      }

      .btn-delete:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .note-modal-fullscreen {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: translateY(12px);
        transition: visibility 0.2s, opacity 0.2s, transform 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .note-modal-fullscreen.active {
        visibility: visible;
        opacity: 1;
        transform: translateY(0);
      }

      .modal-content-wrapper {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
      }

      .modal-nav {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .modal-nav-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
      }

      .btn-icon-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .btn-icon-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .modal-nav-left h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 38px;
        padding: 0 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-save:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        max-width: 960px;
        margin: 0 auto;
        width: 100%;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
      }

      .form-group {
        margin-bottom: 20px;
      }

      .form-group.full-height {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-height: 240px;
      }

      .form-group label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .form-input,
      .form-textarea {
        width: 100%;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 12px 14px;
        font-size: 14px;
        font-family: var(--font-sans);
        outline: none;
        background: var(--surface);
        transition: all var(--transition-fast);
        box-sizing: border-box;
        color: var(--text);
        box-shadow: var(--shadow-xs);
      }

      .form-input {
        height: 42px;
        padding: 0 14px;
      }

      .form-textarea {
        flex: 1;
        min-height: 240px;
        resize: vertical;
        line-height: 1.6;
      }

      .form-input:focus,
      .form-textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .modal-mobile-actions {
        margin-top: 8px;
        display: flex;
        justify-content: flex-end;
      }

      .btn-cancel {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        height: 38px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .btn-cancel:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .note-pagination-bar {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
      }

      .page-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 36px;
        min-width: 36px;
        padding: 0 12px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .page-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .page-btn:hover:not(.active) {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .empty-placeholder {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .loading-state {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 768px) {
        .note-app-container {
          padding: 16px;
        }
        .note-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .note-brand h1 {
          font-size: 22px;
        }
        .btn-add-note {
          width: 100%;
        }
        .note-filter-section {
          flex-direction: row;
        }
        .search-wrapper {
          max-width: 100%;
        }
        .modal-nav {
          padding: 12px 16px;
        }
        .modal-nav-left h2 {
          font-size: 16px;
        }
        .modal-body {
          padding: 16px;
        }
        .note-card-footer {
          flex-direction: column;
          gap: 10px;
          align-items: stretch;
        }
        .note-actions {
          width: 100%;
          justify-content: flex-end;
        }
        .note-cards-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .note-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .modal-mobile-actions .btn-cancel {
          width: 100%;
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.NoteModule = NoteModule;

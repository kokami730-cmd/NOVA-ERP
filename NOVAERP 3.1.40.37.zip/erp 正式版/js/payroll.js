const PayrollModule = {
  _data: [],
  _filteredData: [],
  _staffData: [],
  _config: null,
  _currentId: null,
  _sha: null,
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _loadPDFScripts: function() {
    if (window.jspdf && window.jspdf.jsPDF) return Promise.resolve();
    return new Promise((resolve) => {
      const s1 = document.createElement('script');
      s1.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
      const s2 = document.createElement('script');
      s2.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js";
      s1.onload = () => {
        document.head.appendChild(s2);
        s2.onload = resolve;
      };
      document.head.appendChild(s1);
    });
  },
  exportSingleToPDF: async function() {
    await this._loadPDFScripts();
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const form = document.getElementById('payroll-form');
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());

    doc.setFontSize(20);
    doc.setTextColor(30, 41, 59);
    doc.text("PAYSLIP / SALARY ADVICE", 14, 22);

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(`Company: ${this._config.company || 'ERP Cloud System'}`, 14, 30);
    doc.text(`Date of Issue: ${new Date().toLocaleDateString()}`, 14, 35);

    doc.autoTable({
      startY: 45,
      theme: 'plain',
      head: [['Employee Details', 'Period Information']],
      body: [
        [`Name: ${data.staffName || 'N/A'}`, `Month: ${data.month || 'N/A'}`],
        [`Staff ID: ${data.staffId || 'N/A'}`, `Currency: MYR`]
      ],
      headStyles: {
        fillColor: [241, 245, 249],
        textColor: [30, 41, 59],
        fontStyle: 'bold'
      }
    });

    const tableRows = [];
    tableRows.push([{ content: 'EARNINGS', colSpan: 2, styles: { fillColor: [209, 250, 229], fontStyle: 'bold' } }]);
    tableRows.push(['Basic Salary', parseFloat(data.basicSalary || 0).toFixed(2)]);
    tableRows.push(['Allowance', parseFloat(data.allowance || 0).toFixed(2)]);
    tableRows.push(['Bonus', parseFloat(data.bonus || 0).toFixed(2)]);

    form.querySelectorAll('.p-section-earnings .dynamic-row').forEach(row => {
      const labelInput = row.querySelector('.p-dynamic-name');
      const valueInput = row.querySelector('input[type="number"]');
      if (labelInput && valueInput) {
        tableRows.push([labelInput.value || 'Extra Income', parseFloat(valueInput.value || 0).toFixed(2)]);
      }
    });

    tableRows.push([{ content: 'DEDUCTIONS', colSpan: 2, styles: { fillColor: [254, 226, 226], fontStyle: 'bold' } }]);
    tableRows.push(['EPF / CPF', parseFloat(data.deductionEpf || 0).toFixed(2)]);
    tableRows.push(['Tax (PCB)', parseFloat(data.deductionTax || 0).toFixed(2)]);

    form.querySelectorAll('.p-section-deductions .dynamic-row').forEach(row => {
      const labelInput = row.querySelector('.p-dynamic-name');
      const valueInput = row.querySelector('input[type="number"]');
      if (labelInput && valueInput) {
        tableRows.push([labelInput.value || 'Extra Deduction', parseFloat(valueInput.value || 0).toFixed(2)]);
      }
    });

    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 10,
      head: [['Description', 'Amount (RM)']],
      body: tableRows,
      styles: { fontSize: 10, cellPadding: 5 },
      columnStyles: { 1: { halign: 'right' } }
    });

    const currentY = doc.lastAutoTable.finalY + 15;
    doc.setFontSize(14);
    doc.setFont(undefined, 'bold');
    doc.text(`TOTAL NET PAYABLE: RM ${parseFloat(data.netAmount || 0).toLocaleString(undefined, {minimumFractionDigits:2})}`, 14, currentY);

    doc.save(`Payslip_${data.staffName}_${data.month}.pdf`);
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    await this._loadPDFScripts();

    container.innerHTML = `
      <div class="payroll-app-wrapper">
        <header class="payroll-header">
          <div class="payroll-brand">
            <h1>Payroll</h1>
          </div>
          <div class="payroll-actions">
            ${this._isAdmin() ? `
              <button type="button" class="payroll-btn-primary" onclick="PayrollModule.openEditor()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                <span>Add Record</span>
              </button>` : ''}
          </div>
        </header>

        <div class="payroll-search-section">
          <div class="payroll-search-inner">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="payroll-search" placeholder="Search employee name or month..." oninput="PayrollModule.filter()">
          </div>
        </div>

        <main id="payroll-list" class="payroll-grid"></main>
      </div>

      <div id="payroll-modal" class="payroll-modal">
        <div class="payroll-modal-container">
          <div class="payroll-modal-header">
            <button type="button" class="payroll-btn-back" onclick="PayrollModule.closeEditor()">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <div class="payroll-modal-title">
              <h2 id="payroll-modal-title">Record Detail</h2>
            </div>
            <div class="payroll-modal-actions">
              <button type="button" id="payroll-pdf-btn" onclick="PayrollModule.exportSingleToPDF()" class="payroll-icon-btn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
              </button>
              ${this._isAdmin() ? `
                <button type="button" id="payroll-del-btn" onclick="PayrollModule.delete()" class="payroll-icon-btn delete">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                </button>` : ''}
            </div>
          </div>

          <div class="payroll-modal-body">
            <form id="payroll-form" class="payroll-form" onsubmit="PayrollModule.save(event)">
              <div class="payroll-form-scroll">
                <div class="payroll-form-inner">
                  <div class="payroll-card">
                    <h3 class="payroll-section-title">Employee Profile</h3>
                    <div class="payroll-form-row two-cols">
                      <div class="payroll-field">
                        <label>Staff Name</label>
                        <input type="text" name="staffName" id="payroll-staff-input" list="payroll-staff-list" required placeholder="Search staff..." oninput="PayrollModule.handleStaffInput(this.value)">
                        <datalist id="payroll-staff-list"></datalist>
                        <input type="hidden" name="staffId" id="payroll-staff-id">
                      </div>
                      <div class="payroll-field">
                        <label>Payroll Month</label>
                        <input type="month" name="month" required>
                      </div>
                    </div>
                  </div>

                  <div class="payroll-two-columns">
                    <div class="payroll-card earnings-card p-section-earnings">
                      <h3 class="payroll-section-title text-green">Earnings</h3>
                      <div id="income-list" class="payroll-dynamic-list">
                        <div class="payroll-row-item">
                          <label>Basic Salary</label>
                          <input type="number" name="basicSalary" step="0.01" oninput="PayrollModule.calcNetPay()">
                        </div>
                        <div class="payroll-row-item">
                          <label>Allowance</label>
                          <input type="number" name="allowance" step="0.01" oninput="PayrollModule.calcNetPay()">
                        </div>
                        <div class="payroll-row-item">
                          <label>Bonus</label>
                          <input type="number" name="bonus" step="0.01" oninput="PayrollModule.calcNetPay()">
                        </div>
                      </div>
                      <button type="button" class="payroll-add-btn admin-only" onclick="PayrollModule.addItem('income-list', 'extra_income')">+ Add Earnings Row</button>
                    </div>

                    <div class="payroll-card deductions-card p-section-deductions">
                      <h3 class="payroll-section-title text-red">Deductions</h3>
                      <div id="deduction-list" class="payroll-dynamic-list">
                        <div class="payroll-row-item">
                          <label>EPF / CPF</label>
                          <input type="number" name="deductionEpf" step="0.01" oninput="PayrollModule.calcNetPay()">
                        </div>
                        <div class="payroll-row-item">
                          <label>Tax (PCB)</label>
                          <input type="number" name="deductionTax" step="0.01" oninput="PayrollModule.calcNetPay()">
                        </div>
                      </div>
                      <button type="button" class="payroll-add-btn admin-only" onclick="PayrollModule.addItem('deduction-list', 'extra_deduction')">+ Add Deduction Row</button>
                    </div>
                  </div>
                </div>
              </div>

              <div class="payroll-form-footer">
                <div class="payroll-net-summary">
                  <span class="payroll-net-label">Total Net Pay</span>
                  <div class="payroll-net-value">RM <span id="payroll-net-display">0.00</span></div>
                  <input type="hidden" name="netAmount" id="payroll-net-hidden">
                </div>
                ${this._isAdmin() ? `<button type="submit" class="payroll-btn-save">Save Changes</button>` : ''}
              </div>
            </form>
          </div>
        </div>
      </div>
    `;

    await this.load();
  },
  openEditor: function(id = null) {
    this._currentId = id;
    const modal = document.getElementById('payroll-modal');
    const form = document.getElementById('payroll-form');
    const pdfBtn = document.getElementById('payroll-pdf-btn');
    const isAdmin = this._isAdmin();

    form.reset();
    form.querySelectorAll('.dynamic-row').forEach(r => r.remove());

    if (id) {
      const p = this._data.find(x => x.id === id);
      document.getElementById('payroll-modal-title').innerText = "Edit Payroll Record";
      if (pdfBtn) pdfBtn.style.display = 'flex';
      Array.from(form.elements).forEach(el => {
        if (p && p[el.name] !== undefined) el.value = p[el.name];
      });
    } else {
      document.getElementById('payroll-modal-title').innerText = "New Payroll Record";
      if (pdfBtn) pdfBtn.style.display = 'none';
      form.elements['month'].value = new Date().toISOString().slice(0, 7);
    }

    Array.from(form.elements).forEach(el => {
      el.disabled = !isAdmin;
    });

    form.querySelectorAll('.admin-only').forEach(btn => {
      btn.style.display = isAdmin ? 'flex' : 'none';
    });

    const delBtn = document.getElementById('payroll-del-btn');
    if (delBtn) delBtn.style.display = (id && isAdmin) ? 'flex' : 'none';

    this.calcNetPay();
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('payroll-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  calcNetPay: function() {
    const form = document.getElementById('payroll-form');
    const getV = (n) => parseFloat(form.elements[n]?.value) || 0;

    let total = getV('basicSalary') + getV('allowance') + getV('bonus');
    form.querySelectorAll('.earnings-card .payroll-row-item input[type="number"]').forEach(i => {
      if (!['basicSalary', 'allowance', 'bonus'].includes(i.name)) total += parseFloat(i.value) || 0;
    });

    let ded = getV('deductionEpf') + getV('deductionTax');
    form.querySelectorAll('.deductions-card .payroll-row-item input[type="number"]').forEach(i => {
      if (!['deductionEpf', 'deductionTax'].includes(i.name)) ded += parseFloat(i.value) || 0;
    });

    const net = Math.max(0, total - ded);
    document.getElementById('payroll-net-display').innerText = net.toLocaleString(undefined, {minimumFractionDigits: 2});
    document.getElementById('payroll-net-hidden').value = net.toFixed(2);
  },
  addItem: function(containerId, type) {
    if (!this._isAdmin()) return;
    const container = document.getElementById(containerId);
    const row = document.createElement('div');
    row.className = 'payroll-row-item dynamic-row';
    row.innerHTML = `
      <input type="text" placeholder="Description" class="payroll-dynamic-name">
      <div class="payroll-dynamic-controls">
        <input type="number" name="${type}_${Date.now()}" step="0.01" value="0.00" oninput="PayrollModule.calcNetPay()">
        <button type="button" class="payroll-row-del" onclick="this.parentElement.parentElement.remove(); PayrollModule.calcNetPay();">Remove</button>
      </div>
    `;
    container.appendChild(row);
  },
  handleStaffInput: function(val) {
    const list = document.getElementById('payroll-staff-list');
    if (list && list.options.length === 0) {
      list.innerHTML = this._staffData.map(s => `<option value="${s.name}">`).join('');
    }
    const staff = this._staffData.find(s => s.name === val);
    if (staff) {
      document.getElementById('payroll-staff-id').value = staff.id;
      const form = document.getElementById('payroll-form');
      if (parseFloat(form.elements['basicSalary'].value || 0) === 0) {
        form.elements['basicSalary'].value = parseFloat(staff.salary || staff.basicSalary || 0).toFixed(2);
        this.calcNetPay();
      }
    }
  },
  save: async function(e) {
    e.preventDefault();
    if (!this._isAdmin()) return;

    const btn = e.target.querySelector('.payroll-btn-save');
    if (btn) {
      const originalText = btn.innerHTML;
      btn.innerHTML = "Processing...";
      btn.disabled = true;
    }

    const fd = new FormData(e.target);
    const entry = Object.fromEntries(fd.entries());
    const isEdit = !!this._currentId;
    entry.id = this._currentId || 'P-' + Date.now();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      let nextData = [...this._data];
      if (isEdit) {
        const i = nextData.findIndex(x => x.id === this._currentId);
        if (i !== -1) nextData[i] = entry;
      } else {
        nextData.push(entry);
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));

      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/payroll.json`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Update payroll",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (window.LogModule && window.LogModule.addLog) {
          const actionMsg = isEdit ? `Updated payroll for ${entry.staffName} (${entry.month})` : `Added payroll for ${entry.staffName} (${entry.month})`;
          await window.LogModule.addLog('Payroll', actionMsg, this._config.username || 'Admin');
        }
        this.closeEditor();
        await this.load();
      } else {
        alert("Failed to save: " + res.status);
      }
    } catch (err) {
      alert("Network error: Could not save.");
    } finally {
      if (btn) {
        btn.innerHTML = "Save Changes";
        btn.disabled = false;
      }
    }
  },
  delete: async function() {
    if (!this._isAdmin() || !confirm("Delete this record permanently?")) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const record = this._data.find(x => x.id === this._currentId);
    let nextData = this._data.filter(x => x.id !== this._currentId);

    try {
      const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));
      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/db_date/payroll.json`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Delete",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (window.LogModule && window.LogModule.addLog && record) {
          await window.LogModule.addLog('Payroll', `Deleted payroll record: ${record.staffName} (${record.month})`, this._config.username || 'Admin');
        }
        this.closeEditor();
        await this.load();
      } else {
        alert("Delete failed: " + res.status);
      }
    } catch (e) {
      alert("Delete failed.");
    }
  },
  filter: function() {
    const q = (document.getElementById('payroll-search')?.value || '').toLowerCase();
    this._filteredData = this._data.map((item, index) => ({...item, _autoNo: index + 1}))
      .filter(x =>
        x._autoNo.toString() === q ||
        (x.staffName || '').toLowerCase().includes(q) ||
        (x.month || '').toLowerCase().includes(q)
      );
    this.renderList();
  },
  renderList: function() {
    const grid = document.getElementById('payroll-list');
    const stats = document.getElementById('payroll-stats');

    if (stats) stats.innerText = `${this._filteredData.length} records found`;

    if (this._filteredData.length === 0) {
      grid.innerHTML = `<div class="payroll-empty-state">No records found matching your search.</div>`;
      return;
    }

    grid.innerHTML = this._filteredData.map(r => `
      <div class="payroll-card-item" onclick="PayrollModule.openEditor('${r.id}')">
        <div class="payroll-card-header">
          <span class="payroll-badge">#${r._autoNo}</span>
          <span class="payroll-date">${r.month}</span>
        </div>
        <div class="payroll-card-body">
          <h3 class="payroll-staff-name">${r.staffName}</h3>
          <div class="payroll-net-amount">RM ${parseFloat(r.netAmount || 0).toLocaleString(undefined, {minimumFractionDigits:2})}</div>
        </div>
        <div class="payroll-card-footer">View Details</div>
      </div>
    `).join('');
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    if (!config.ghToken) return;

    const opts = {
      headers: {
        'Authorization': `token ${config.ghToken}`
      },
      cache: 'no-store'
    };

    try {
      const [resP, resS] = await Promise.all([
        fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/payroll.json`, opts),
        fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/staff.json`, opts)
      ]);

      if (resP.ok) {
        const d = await resP.json();
        this._sha = d.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
      }

      if (resS.ok) {
        const d = await resS.json();
        this._staffData = JSON.parse(decodeURIComponent(escape(atob(d.content))));
      }

      this.filter();
    } catch(e) {
      console.error("Payroll load error:", e);
    }
  },
  _injectStyles: function() {
    if (document.getElementById('payroll-modern-styles')) return;

    const style = document.createElement('style');
    style.id = 'payroll-modern-styles';
    style.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .payroll-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .payroll-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .payroll-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .payroll-brand p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .payroll-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .payroll-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .payroll-search-section {
        margin-bottom: 20px;
      }

      .payroll-search-inner {
        position: relative;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .payroll-search-inner:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .payroll-search-inner svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .payroll-search-inner input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .payroll-search-inner input::placeholder {
        color: var(--text-dim);
      }

      .payroll-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
        gap: 16px;
        width: 100%;
      }

      .payroll-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        flex-direction: column;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .payroll-card-item:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .payroll-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
      }

      .payroll-badge {
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 700;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
      }

      .payroll-date {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .payroll-staff-name {
        margin: 0 0 6px;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .payroll-net-amount {
        font-size: 20px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .payroll-card-footer {
        margin-top: auto;
        padding-top: 12px;
        border-top: 1px solid var(--border);
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        text-align: center;
        transition: color var(--transition-fast);
      }

      .payroll-card-item:hover .payroll-card-footer {
        color: var(--primary);
      }

      .payroll-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: translateY(12px);
        transition: visibility 0.2s, opacity 0.2s, transform 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .payroll-modal.active {
        visibility: visible;
        opacity: 1;
        transform: translateY(0);
      }

      .payroll-modal-container {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
      }

      .payroll-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .payroll-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .payroll-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .payroll-modal-title {
        flex: 1;
        min-width: 0;
      }

      .payroll-modal-title h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        text-align: center;
      }

      .payroll-modal-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-shrink: 0;
      }

      .payroll-icon-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }

      .payroll-icon-btn:hover {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .payroll-icon-btn.delete:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .payroll-modal-body {
        flex: 1;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .payroll-form {
        height: 100%;
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .payroll-form-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        min-height: 0;
      }

      .payroll-form-inner {
        max-width: 1000px;
        margin: 0 auto;
        width: 100%;
      }

      .payroll-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-xs);
      }

      .payroll-section-title {
        margin: 0 0 16px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .payroll-section-title.text-green {
        color: var(--green);
      }

      .payroll-section-title.text-red {
        color: var(--danger);
      }

      .payroll-form-row {
        display: grid;
        gap: 16px;
      }

      .payroll-form-row.two-cols {
        grid-template-columns: repeat(2, 1fr);
      }

      .payroll-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .payroll-field label {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .payroll-field input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .payroll-field input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .payroll-two-columns {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
      }

      .payroll-dynamic-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 14px;
      }

      .payroll-row-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        padding: 8px 0;
        border-bottom: 1px solid var(--border);
      }

      .payroll-row-item:last-child {
        border-bottom: none;
      }

      .payroll-row-item label {
        font-size: 13px;
        font-weight: 600;
        color: var(--text);
        min-width: 100px;
      }

      .payroll-row-item input[type="number"] {
        width: 150px;
        height: 38px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        text-align: right;
        font-weight: 600;
        font-size: 14px;
        outline: none;
        transition: all var(--transition-fast);
        color: var(--text);
        background: var(--surface);
        font-family: var(--font-sans);
      }

      .payroll-row-item input[type="number"]:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .payroll-dynamic-name {
        flex: 1;
        height: 38px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        outline: none;
        color: var(--text);
        background: var(--surface);
        font-family: var(--font-sans);
        min-width: 120px;
      }

      .payroll-dynamic-name:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .payroll-dynamic-controls {
        display: flex;
        gap: 8px;
        align-items: center;
      }

      .payroll-row-del {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 34px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .payroll-row-del:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .payroll-add-btn {
        width: 100%;
        height: 38px;
        padding: 0 14px;
        border: 1px dashed var(--border-strong);
        border-radius: var(--radius-sm);
        background: var(--surface-soft);
        font-weight: 600;
        font-size: 12px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .payroll-add-btn:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .payroll-form-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 16px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
        position: sticky;
        bottom: 0;
        box-shadow: var(--shadow-sm);
        flex-shrink: 0;
      }

      .payroll-net-summary {
        display: flex;
        flex-direction: column;
      }

      .payroll-net-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-dim);
        letter-spacing: 0.04em;
      }

      .payroll-net-value {
        font-size: 24px;
        font-weight: 700;
        color: var(--primary);
      }

      .payroll-btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 22px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .payroll-btn-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .payroll-btn-save:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
      }

      .payroll-empty-state {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 768px) {
        .payroll-app-wrapper {
          padding: 16px;
        }
        .payroll-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .payroll-brand h1 {
          font-size: 22px;
        }
        .payroll-btn-primary {
          width: 100%;
        }
        .payroll-search-inner {
          max-width: 100%;
        }
        .payroll-form-row.two-cols,
        .payroll-two-columns {
          grid-template-columns: 1fr;
        }
        .payroll-modal-header {
          padding: 12px 16px;
        }
        .payroll-modal-title h2 {
          font-size: 16px;
        }
        .payroll-form-scroll {
          padding: 16px;
        }
        .payroll-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .payroll-row-item {
          flex-wrap: wrap;
        }
        .payroll-row-item label {
          min-width: auto;
        }
        .payroll-row-item input[type="number"] {
          width: 100%;
          text-align: left;
        }
        .payroll-dynamic-controls {
          width: 100%;
        }
        .payroll-dynamic-controls input[type="number"] {
          flex: 1;
        }
        .payroll-form-footer {
          padding: 14px 16px;
        }
        .payroll-net-value {
          font-size: 20px;
        }
        .payroll-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .payroll-card-item {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
      }
    `;
    document.head.appendChild(style);
  }
};

window.PayrollModule = PayrollModule;

const POSModule = {
  _cart: [],
  _products: [],
  _filteredProducts: [],
  _availableStations: [],
  _members: [],
  _allCompanies: [],
  _allStaff: [],
  _companyInfo: null,
  _selectedMember: null,
  _staffName: "",
  _membersSha: null,
  _heldBills: [],
  _config: null,
  _orderNote: "",
  _bankCardNumber: "",
  _confirmationCode: "",
  _saveState: function() {
    const state = {
      cart: this._cart,
      selectedMember: this._selectedMember,
      heldBills: this._heldBills,
      companyInfo: this._companyInfo,
      staffName: this._staffName,
      orderNote: this._orderNote,
      bankCardNumber: this._bankCardNumber,
      confirmationCode: this._confirmationCode
    };
    localStorage.setItem('POS_SESSION_STATE', JSON.stringify(state));
  },
  _loadState: function() {
    const saved = localStorage.getItem('POS_SESSION_STATE');
    if (saved) {
      try {
        const state = JSON.parse(saved);
        this._cart = state.cart || [];
        this._selectedMember = state.selectedMember || null;
        this._heldBills = state.heldBills || [];
        this._companyInfo = state.companyInfo || null;
        this._staffName = state.staffName || "";
        this._orderNote = state.orderNote || "";
        this._bankCardNumber = state.bankCardNumber || "";
        this._confirmationCode = state.confirmationCode || "";
      } catch (e) {
        console.error("Failed to load session state", e);
      }
    }
  },
  printReceipt: function(txn, received, change) {
    const printWindow = window.open('', '_blank', 'width=450,height=800');
    if (!printWindow) {
      alert("Please allow popups to print receipt.");
      return;
    }

    const company = this._companyInfo || { name: "-", regNo: "-", address: "-", phone: "-" };

    const itemsHtml = txn.items.map(item => `
      <div class="receipt-row">
        <span class="item-name">${item.prodName}</span>
        <span class="item-price">$${(Number(item.price) || 0).toFixed(2)}</span>
      </div>
    `).join('');

    const noteHtml = txn.note ? `
      <div class="divider"></div>
      <div style="margin:8px 0; font-weight:bold;">Note:</div>
      <div style="font-size:12px; margin-bottom:8px;">${txn.note}</div>
    ` : '';

    const bankCardHtml = txn.bankCardNumber ? `
      <div class="receipt-row"><span>Bank Card:</span><span>${txn.bankCardNumber}</span></div>
    ` : '';

    const confirmationCodeHtml = txn.confirmationCode ? `
      <div class="receipt-row"><span>Confirm Code:</span><span>${txn.confirmationCode}</span></div>
    ` : '';

    const receiptData = {
      id: txn.id,
      c: company.name,
      a: txn.amount,
      p: txn.paymentMethod,
      s: txn.staff,
      t: txn.timestamp,
      m: this._selectedMember ? this._selectedMember.name : 'Walk-in',
      i: txn.items.map(it => ({n: it.prodName, p: it.price}))
    };

    const encodedData = btoa(unescape(encodeURIComponent(JSON.stringify(receiptData))));
    const receiptUrl = `${window.location.origin}${window.location.pathname.replace(/\/[^\/]*$/, '/') || '/'}receipt.html?data=${encodedData}`;

    printWindow.document.write(`
      <html>
        <head>
          <title>Receipt - ${txn.id}</title>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
          <style>
            @page { size: auto; margin: 0mm; }
            body { font-family: 'Courier New', Courier, monospace; padding: 20px; color: #000; background: #fff; -webkit-font-smoothing: antialiased; font-size: 13px; line-height: 1.4; }
            .receipt-header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
            .company-name { font-size: 18px; font-weight: 900; margin: 0; text-transform: uppercase; }
            .company-info { font-size: 11px; margin: 2px 0; }
            .receipt-footer { text-align: center; border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; font-size: 11px; }
            .receipt-row { display: flex; justify-content: space-between; margin-bottom: 4px; }
            .bold { font-weight: 900; }
            .divider { border-top: 1px dashed #000; margin: 8px 0; }
            .total-font { font-size: 18px; font-weight: bold; }
            .qr-container { margin: 15px auto; display: flex; flex-direction: column; align-items: center; }
            #qrcode img { margin: 0 auto; border: 4px solid #fff; }
            .qr-label { font-size: 9px; margin-top: 5px; color: #666; }
            @media print { body { margin: 0; padding: 5mm; } .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="receipt-header">
            <p class="company-name">${company.name}</p>
            <p class="company-info">Reg: ${company.regNo || '-'}</p>
            <p class="company-info">${company.address || '-'}</p>
            <p class="company-info">Tel: ${company.phone || '-'}</p>
            <div class="divider"></div>
            <p style="margin:5px 0; font-weight:bold;">OFFICIAL RECEIPT</p>
            <p style="font-size:11px; margin:0;">Station: ${txn.pos || 'Main'} | Staff: ${txn.staff || 'N/A'}</p>
            <p style="font-size:11px; margin:0;">${new Date(txn.timestamp).toLocaleString()}</p>
          </div>
          <div style="margin-bottom:10px;">
            <div class="receipt-row"><span>Order ID:</span><span>${txn.id}</span></div>
            <div class="receipt-row"><span>Customer:</span><span>${this._selectedMember ? this._selectedMember.name : 'Walk-in'}</span></div>
          </div>
          <div class="divider"></div>
          ${itemsHtml}
          ${noteHtml}
          <div class="divider"></div>
          <div class="receipt-row total-font"><span>TOTAL</span><span>$${txn.amount.toFixed(2)}</span></div>
          <div class="receipt-row"><span>Payment:</span><span>${txn.paymentMethod}</span></div>
          ${bankCardHtml}
          ${confirmationCodeHtml}
          <div class="receipt-row"><span>Received:</span><span>$${received.toFixed(2)}</span></div>
          <div class="receipt-row bold"><span>Change:</span><span>$${change.toFixed(2)}</span></div>
          <div class="qr-container"><div id="qrcode"></div><p class="qr-label">Scan to view e-receipt</p></div>
          <div class="receipt-footer"><p>Thank you for shopping with us!</p><p>Items Count: ${txn.items.length}</p></div>
          <script>
            window.onload = function() {
              new QRCode(document.getElementById("qrcode"), {
                text: "${receiptUrl}",
                width: 160,
                height: 160,
                colorDark : "#000000",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.M
              });
              setTimeout(() => {
                window.print();
                setTimeout(() => { window.close(); }, 500);
              }, 600);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  },
  printInstallmentReceipt: function(txn, months, perAmount) {
    const printWindow = window.open('', '_blank', 'width=450,height=800');
    if (!printWindow) {
      alert("Please allow popups to print receipt.");
      return;
    }

    const company = this._companyInfo || { name: "-", regNo: "-", address: "-", phone: "-" };

    const itemsHtml = txn.items.map(item => `
      <div class="receipt-row">
        <span class="item-name">${item.prodName}</span>
        <span class="item-price">$${(Number(item.price) || 0).toFixed(2)}</span>
      </div>
    `).join('');

    const noteHtml = txn.note ? `
      <div class="divider"></div>
      <div style="margin:8px 0; font-weight:bold;">Note:</div>
      <div style="font-size:12px; margin-bottom:8px;">${txn.note}</div>
    ` : '';

    const bankCardHtml = txn.bankCardNumber ? `
      <div class="receipt-row"><span>Bank Card:</span><span>${txn.bankCardNumber}</span></div>
    ` : '';

    const confirmationCodeHtml = txn.confirmationCode ? `
      <div class="receipt-row"><span>Confirm Code:</span><span>${txn.confirmationCode}</span></div>
    ` : '';

    printWindow.document.write(`
      <html>
        <head>
          <title>Installment Receipt - ${txn.id}</title>
          <style>
            @page { size: auto; margin: 0mm; }
            body { font-family: 'Courier New', Courier, monospace; padding: 20px; color: #000; background: #fff; font-size: 13px; line-height: 1.4; }
            .receipt-header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
            .company-name { font-size: 18px; font-weight: 900; margin: 0; text-transform: uppercase; }
            .company-info { font-size: 11px; margin: 2px 0; }
            .receipt-footer { text-align: center; border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; font-size: 11px; }
            .receipt-row { display: flex; justify-content: space-between; margin-bottom: 4px; }
            .bold { font-weight: 900; }
            .divider { border-top: 1px dashed #000; margin: 8px 0; }
            .total-font { font-size: 18px; font-weight: bold; }
            .installment-plan { background: #f1f5f9; padding: 10px; border-radius: 8px; margin: 10px 0; text-align: center; }
          </style>
        </head>
        <body>
          <div class="receipt-header">
            <p class="company-name">${company.name}</p>
            <p class="company-info">Reg: ${company.regNo || '-'}</p>
            <p class="company-info">Tel: ${company.phone || '-'}</p>
            <div class="divider"></div>
            <p style="margin:5px 0; font-weight:bold;">INSTALLMENT RECEIPT</p>
            <p style="font-size:11px; margin:0;">Station: ${txn.pos || 'Main'} | Staff: ${txn.staff || 'N/A'}</p>
            <p style="font-size:11px; margin:0;">${new Date(txn.timestamp).toLocaleString()}</p>
          </div>
          <div style="margin-bottom:10px;">
            <div class="receipt-row"><span>Order ID:</span><span>${txn.id}</span></div>
            <div class="receipt-row"><span>Customer:</span><span>${this._selectedMember ? this._selectedMember.name : 'Walk-in'}</span></div>
          </div>
          <div class="divider"></div>
          ${itemsHtml}
          ${noteHtml}
          <div class="divider"></div>
          <div class="receipt-row total-font"><span>TOTAL</span><span>$${txn.amount.toFixed(2)}</span></div>
          <div class="receipt-row"><span>Payment Method:</span><span>${txn.paymentMethod}</span></div>
          ${bankCardHtml}
          ${confirmationCodeHtml}
          <div class="installment-plan">
            <div><strong>Installment Plan</strong></div>
            <div>Number of installments: ${months} months</div>
            <div>Amount per term: $${perAmount.toFixed(2)}</div>
            <div style="font-size:11px; margin-top:5px;">Please pay each term on time</div>
          </div>
          <div class="receipt-footer"><p>Thank you for your purchase!</p><p>Items Count: ${txn.items.length}</p></div>
        </body>
      </html>
    `);
    printWindow.document.close();

    setTimeout(() => {
      printWindow.print();
      setTimeout(() => { printWindow.close(); }, 500);
    }, 600);
  },
  printAfterpayReceipt: function(txn) {
    const printWindow = window.open('', '_blank', 'width=450,height=800');
    if (!printWindow) {
      alert("Please allow popups to print receipt.");
      return;
    }

    const company = this._companyInfo || { name: "-", regNo: "-", address: "-", phone: "-" };

    const itemsHtml = txn.items.map(item => `
      <div class="receipt-row">
        <span class="item-name">${item.prodName}</span>
        <span class="item-price">$${(Number(item.price) || 0).toFixed(2)}</span>
      </div>
    `).join('');

    const noteHtml = txn.note ? `
      <div class="divider"></div>
      <div style="margin:8px 0; font-weight:bold;">Note:</div>
      <div style="font-size:12px; margin-bottom:8px;">${txn.note}</div>
    ` : '';

    const bankCardHtml = txn.bankCardNumber ? `
      <div class="receipt-row"><span>Bank Card:</span><span>${txn.bankCardNumber}</span></div>
    ` : '';

    const confirmationCodeHtml = txn.confirmationCode ? `
      <div class="receipt-row"><span>Confirm Code:</span><span>${txn.confirmationCode}</span></div>
    ` : '';

    printWindow.document.write(`
      <html>
        <head>
          <title>Afterpay Receipt - ${txn.id}</title>
          <style>
            @page { size: auto; margin: 0mm; }
            body { font-family: 'Courier New', Courier, monospace; padding: 20px; color: #000; background: #fff; font-size: 13px; line-height: 1.4; }
            .receipt-header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
            .company-name { font-size: 18px; font-weight: 900; margin: 0; text-transform: uppercase; }
            .company-info { font-size: 11px; margin: 2px 0; }
            .receipt-footer { text-align: center; border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; font-size: 11px; }
            .receipt-row { display: flex; justify-content: space-between; margin-bottom: 4px; }
            .bold { font-weight: 900; }
            .divider { border-top: 1px dashed #000; margin: 8px 0; }
            .total-font { font-size: 18px; font-weight: bold; }
            .pending-badge { background: #fef3c7; color: #92400e; padding: 8px; border-radius: 8px; text-align: center; font-weight: bold; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="receipt-header">
            <p class="company-name">${company.name}</p>
            <p class="company-info">Reg: ${company.regNo || '-'}</p>
            <p class="company-info">Tel: ${company.phone || '-'}</p>
            <div class="divider"></div>
            <p style="margin:5px 0; font-weight:bold;">AFTERPAY RECEIPT</p>
            <p style="font-size:11px; margin:0;">Station: ${txn.pos || 'Main'} | Staff: ${txn.staff || 'N/A'}</p>
            <p style="font-size:11px; margin:0;">${new Date(txn.timestamp).toLocaleString()}</p>
          </div>
          <div style="margin-bottom:10px;">
            <div class="receipt-row"><span>Order ID:</span><span>${txn.id}</span></div>
            <div class="receipt-row"><span>Customer:</span><span>${this._selectedMember ? this._selectedMember.name : 'Walk-in'}</span></div>
          </div>
          <div class="divider"></div>
          ${itemsHtml}
          ${noteHtml}
          <div class="divider"></div>
          <div class="receipt-row total-font"><span>TOTAL</span><span>$${txn.amount.toFixed(2)}</span></div>
          <div class="receipt-row"><span>Payment Method:</span><span>${txn.paymentMethod}</span></div>
          ${bankCardHtml}
          ${confirmationCodeHtml}
          <div class="pending-badge">Pending payment status - Please settle as soon as possible</div>
          <div class="receipt-footer"><p>Thank you for shopping with us!</p><p>Items Count: ${txn.items.length}</p></div>
        </body>
      </html>
    `);
    printWindow.document.close();

    setTimeout(() => {
      printWindow.print();
      setTimeout(() => { printWindow.close(); }, 500);
    }, 600);
  },
  _injectStyles: function() {
    if (document.getElementById('pos-core-style')) return;

    const style = document.createElement('style');
    style.id = 'pos-core-style';
    style.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-hover: #4338ca;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --surface-alt: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-muted: #94a3b8;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --border-light: #e2e8f0;
        --danger: #ef4444;
        --red: #ef4444;
        --red-hover: #dc2626;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-hover: #059669;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --orange: #f59e0b;
        --purple: #6366f1;
        --pink: #4f46e5;
        --radius: 16px;
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition: 0.15s ease;
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .pos-wrapper {
        min-height: 100vh;
        padding: 24px;
        background: var(--bg);
        color: var(--text);
        font-family: var(--font-sans);
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
      }

      .pos-container {
        display: grid;
        grid-template-columns: 1fr 420px;
        gap: 20px;
        width: 100%;
        align-items: start;
      }

      @media (max-width: 1100px) {
        .pos-container {
          grid-template-columns: 1fr 360px;
        }
      }

      @media (max-width: 860px) {
        .pos-container {
          grid-template-columns: 1fr;
        }
      }

      .product-area {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
        border: 1px solid var(--border);
        display: flex;
        flex-direction: column;
        min-height: 70vh;
      }

      .product-area-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 14px;
        margin-bottom: 20px;
      }

      .product-area-header h2 {
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
        margin: 0;
      }

      .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
      }

      .station-badge {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        height: 36px;
        padding: 0 14px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: 1px solid var(--border);
        transition: all var(--transition-fast);
        user-select: none;
        box-shadow: var(--shadow-xs);
      }

      .station-badge:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
      }

      .station-badge .label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--text-secondary);
      }

      .station-badge .value {
        font-weight: 700;
        font-size: 13px;
        color: var(--primary);
      }

      .hold-badge {
        background: var(--amber-soft);
        border: 1px solid rgba(245, 158, 11, 0.25);
        border-radius: var(--radius-md);
        height: 36px;
        padding: 0 14px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        font-size: 13px;
        color: var(--amber);
        transition: all var(--transition-fast);
        user-select: none;
      }

      .hold-badge:hover {
        border-color: var(--amber);
      }

      .hold-badge .hold-count {
        background: var(--amber);
        color: #fff;
        border-radius: var(--radius-xs);
        min-width: 20px;
        height: 20px;
        font-size: 11px;
        font-weight: 700;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0 6px;
        line-height: 1;
      }

      .staff-input-wrap,
      .company-selector-wrap,
      .member-search-wrap {
        position: relative;
        margin-bottom: 12px;
      }

      .staff-input,
      .company-search-input,
      .member-search-input,
      .search-input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .staff-input:focus,
      .company-search-input:focus,
      .member-search-input:focus,
      .search-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .staff-input::placeholder,
      .company-search-input::placeholder,
      .member-search-input::placeholder,
      .search-input::placeholder {
        color: var(--text-dim);
      }

      .search-input {
        margin-bottom: 16px;
      }

      .staff-results,
      .company-results,
      .member-results {
        position: absolute;
        top: calc(100% + 4px);
        left: 0;
        right: 0;
        background: var(--surface);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        z-index: 100;
        max-height: 220px;
        overflow-y: auto;
        display: none;
        border: 1px solid var(--border);
        padding: 4px 0;
      }

      .staff-item,
      .company-item,
      .member-item {
        padding: 10px 14px;
        cursor: pointer;
        border-bottom: 1px solid var(--border);
        font-size: 13px;
        transition: all var(--transition-fast);
        color: var(--text);
      }

      .staff-item:last-child,
      .company-item:last-child,
      .member-item:last-child {
        border-bottom: none;
      }

      .staff-item:hover,
      .company-item:hover,
      .member-item:hover {
        background: var(--primary-soft);
        color: var(--primary-dark);
      }

      .staff-item strong,
      .company-item strong,
      .member-item strong {
        font-weight: 600;
      }

      .staff-item small {
        color: var(--text-secondary);
        font-size: 12px;
      }

      .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: 14px;
        overflow-y: auto;
        flex: 1;
        max-height: 60vh;
      }

      .product-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        padding: 16px 12px;
        text-align: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        position: relative;
        box-shadow: var(--shadow-xs);
        min-height: 92px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .product-item:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .product-name {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        display: block;
        margin-bottom: 4px;
        word-break: break-word;
        line-height: 1.3;
      }

      .product-price {
        color: var(--primary);
        font-weight: 700;
        font-size: 16px;
      }

      .product-action-btn {
        position: absolute;
        top: 8px;
        right: 8px;
        background: var(--surface-soft);
        border: 1px solid var(--border);
        height: 24px;
        padding: 0 8px;
        border-radius: var(--radius-xs);
        cursor: pointer;
        font-size: 11px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .product-action-btn:hover {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .checkout-aside {
        background: var(--surface);
        border-radius: var(--radius-card);
        display: flex;
        flex-direction: column;
        box-shadow: var(--shadow-xs);
        border: 1px solid var(--border);
        overflow: hidden;
        max-height: 90vh;
        position: sticky;
        top: 24px;
      }

      @media (max-width: 860px) {
        .checkout-aside {
          max-height: none;
          position: static;
        }
      }

      .cart-header {
        padding: 16px 20px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 700;
        font-size: 16px;
        background: var(--surface);
        flex-shrink: 0;
      }

      .cart-header-actions {
        display: flex;
        gap: 8px;
      }

      .cart-header-actions button {
        height: 32px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        background: var(--surface-soft);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .cart-header-actions button:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .cart-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 14px 20px;
        max-height: 36vh;
        min-height: 110px;
      }

      .cart-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--surface-soft);
        padding: 10px 14px;
        border-radius: var(--radius-md);
        margin-bottom: 8px;
        border: 1px solid var(--border);
      }

      .cart-item .name {
        font-weight: 600;
        font-size: 13px;
        color: var(--text);
        word-break: break-word;
        flex: 1;
        margin-right: 10px;
      }

      .cart-item .price {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        white-space: nowrap;
        margin-right: 8px;
      }

      .cart-item .remove-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 26px;
        padding: 0 8px;
        border-radius: var(--radius-xs);
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .cart-item .remove-btn:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .cart-empty {
        text-align: center;
        color: var(--text-dim);
        padding: 32px 0;
        font-size: 13px;
      }

      .selected-member-tag,
      .selected-company-tag {
        background: var(--primary-soft);
        color: var(--primary-dark);
        padding: 8px 12px;
        border-radius: var(--radius-md);
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 12px;
        font-weight: 600;
        border: 1px solid rgba(79, 70, 229, 0.15);
      }

      .selected-member-tag button,
      .selected-company-tag button {
        background: none;
        border: none;
        color: var(--danger);
        cursor: pointer;
        font-weight: 700;
        font-size: 12px;
        padding: 2px 6px;
        font-family: var(--font-sans);
      }

      .notes-input {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 13px;
        background: var(--surface);
        resize: vertical;
        min-height: 48px;
        outline: none;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
        color: var(--text);
        box-shadow: var(--shadow-xs);
      }

      .notes-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .notes-label,
      .pos-sub-label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        margin-bottom: 5px;
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .checkout-footer {
        padding: 16px 20px 20px;
        border-top: 1px solid var(--border);
        background: var(--surface-soft);
        flex-shrink: 0;
      }

      .total-row {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 14px;
        color: var(--text);
      }

      .total-row .total-amount {
        color: var(--primary);
        font-size: 24px;
      }

      .pay-btn-group {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
      }

      @media (max-width: 400px) {
        .pay-btn-group {
          grid-template-columns: repeat(2, 1fr);
        }
      }

      .pay-btn {
        height: 40px;
        padding: 0 10px;
        border-radius: var(--radius-md);
        border: 1px solid transparent;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        color: #fff;
        transition: all var(--transition-fast);
        text-align: center;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        font-family: var(--font-sans);
      }

      .pay-btn:hover {
        filter: brightness(0.95);
        transform: translateY(-1px);
      }

      .pay-cash { background: var(--green); }
      .pay-card { background: var(--primary); box-shadow: var(--shadow-primary); }
      .pay-wallet { background: var(--primary-light); }
      .pay-qr { background: var(--primary-dark); }
      .pay-installment { background: var(--amber); }
      .pay-afterpay { background: var(--text-secondary); }

      #cash-modal,
      #hold-modal,
      #installment-modal,
      #pos-actions-modal {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.55);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        padding: 20px;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .modal-content {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 24px;
        width: 100%;
        max-width: 440px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border);
      }

      .modal-title {
        font-size: 18px;
        font-weight: 700;
        margin-bottom: 16px;
        text-align: center;
        color: var(--text);
      }

      .cash-input,
      .installment-input {
        width: 100%;
        height: 46px;
        padding: 0 14px;
        font-size: 18px;
        font-weight: 700;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        text-align: center;
        margin: 10px 0 14px;
        background: var(--surface);
        outline: none;
        transition: all var(--transition-fast);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .cash-input:focus,
      .installment-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .modal-due {
        text-align: center;
        font-size: 14px;
        color: var(--text-secondary);
        margin-bottom: 8px;
      }

      .modal-due strong {
        color: var(--text);
        font-size: 18px;
      }

      .change-display {
        padding: 12px 14px;
        border-radius: var(--radius-md);
        text-align: center;
        margin-bottom: 18px;
        font-weight: 700;
        font-size: 15px;
      }

      .change-positive {
        background: var(--green-soft);
        color: var(--green);
      }

      .change-negative {
        background: var(--red-soft);
        color: var(--danger);
      }

      .modal-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
      }

      .modal-actions button {
        height: 40px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        cursor: pointer;
        border: 1px solid transparent;
        transition: all var(--transition-fast);
        font-size: 13px;
        font-family: var(--font-sans);
      }

      .modal-actions .btn-secondary {
        background: var(--surface);
        color: var(--text-secondary);
        border-color: var(--border);
      }

      .modal-actions .btn-secondary:hover {
        background: var(--surface-soft);
        color: var(--text);
      }

      .modal-actions .btn-primary {
        background: var(--primary);
        color: #fff;
        box-shadow: var(--shadow-primary);
      }

      .modal-actions .btn-success {
        background: var(--green);
        color: #fff;
      }

      .hold-list-item {
        padding: 12px 14px;
        border-bottom: 1px solid var(--border);
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: all var(--transition-fast);
        border-radius: var(--radius-sm);
      }

      .hold-list-item:hover {
        background: var(--primary-soft);
      }

      .hold-list-item .info {
        flex: 1;
      }

      .hold-list-item .info .title {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
      }

      .hold-list-item .info .meta {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 2px;
      }

      .hold-list-item .info .note {
        font-size: 11px;
        color: var(--primary);
        margin-top: 2px;
      }

      .hold-list-item .amount {
        font-weight: 700;
        color: var(--primary);
        font-size: 16px;
        white-space: nowrap;
        margin-left: 12px;
      }

      #hold-list-container {
        max-height: 300px;
        overflow-y: auto;
        margin-bottom: 14px;
      }

      .actions-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
        margin-top: 12px;
      }

      .action-tile {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 12px 10px;
        text-align: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-size: 12px;
        font-weight: 600;
        color: var(--text);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .action-tile:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary-dark);
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid var(--border);
        font-size: 13px;
        color: var(--text-secondary);
      }

      .info-row:last-child {
        border-bottom: none;
      }

      .info-row strong {
        color: var(--text);
        font-weight: 600;
      }

      #pos-actions-content {
        padding: 4px 0;
      }

      .close-modal-btn {
        width: 100%;
        height: 40px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        background: var(--surface);
        cursor: pointer;
        font-weight: 600;
        font-size: 13px;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        margin-top: 14px;
        font-family: var(--font-sans);
      }

      .close-modal-btn:hover {
        background: var(--surface-soft);
        color: var(--text);
      }

      .cart-section-spacer {
        padding: 16px 20px 0 20px;
      }

      @media (max-width: 768px) {
        .pos-wrapper {
          padding: 16px;
        }
        .product-area {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .checkout-aside {
          border-radius: var(--radius-lg);
        }
        .modal-content {
          padding: 20px;
          border-radius: var(--radius-lg);
        }
        .product-grid {
          grid-template-columns: repeat(auto-fill, minmax(135px, 1fr));
          gap: 10px;
        }
      }
    `;
    document.head.appendChild(style);
  },
  initData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    if (!config.ghToken || !config.ghRepo) return;

    const fetchFile = async (path) => {
      const url = `https://api.github.com/repos/${config.ghRepo}/contents/${path}`;
      try {
        const res = await fetch(url, {
          headers: {
            'Authorization': `token ${config.ghToken}`
          },
          cache: 'no-store'
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (path === 'db_date/members.json') this._membersSha = data.sha;
        const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        return Array.isArray(content) ? content : (content && typeof content === 'object' ? (Object.values(content).find(Array.isArray) || content) : content);
      } catch (e) {
        return null;
      }
    };

    const staffData = await fetchFile('db_date/staff.json');
    if (staffData) {
      this._allStaff = Array.isArray(staffData) ? staffData : [];
    }

    const companies = await fetchFile('db_date/company.json');
    if (companies) {
      this._allCompanies = Array.isArray(companies) ? companies : [companies];
      if (this._allCompanies.length === 1 && !this._companyInfo) {
        this._companyInfo = this._allCompanies[0];
      }
    }

    const remoteProducts = await fetchFile('db_date/product.json');
    if (remoteProducts && Array.isArray(remoteProducts)) {
      this._products = remoteProducts;
      this._filteredProducts = [...this._products];
      this.loadProducts();
    }

    const membersData = await fetchFile('db_date/members.json');
    if (membersData) {
      this._members = Array.isArray(membersData) ? membersData : [];
    }

    const remoteStations = await fetchFile('db_date/counter.json');
    if (remoteStations && Array.isArray(remoteStations)) {
      this._availableStations = [...new Set(remoteStations.filter(s => s.pos).map(s => s.pos))];
      if (!window.pos || window.pos === "Loading...") {
        window.pos = this._availableStations[0] || "Main-Station";
      }
      const sd = document.getElementById('station-id-display');
      if (sd) sd.innerText = window.pos;
    }

    this.updateCompanyUI();

    const staffInput = document.getElementById('pos-staff-input');
    if (staffInput && this._staffName) staffInput.value = this._staffName;

    const notesInput = document.getElementById('pos-notes-input');
    if (notesInput) notesInput.value = this._orderNote;

    const bankCardInput = document.getElementById('pos-bankcard-input');
    if (bankCardInput) bankCardInput.value = this._bankCardNumber;

    const confirmationCodeInput = document.getElementById('pos-confirmationcode-input');
    if (confirmationCodeInput) confirmationCodeInput.value = this._confirmationCode;
  },
  updateStaffName: function(val) {
    this._staffName = val;
    this._saveState();

    const listEl = document.getElementById('staff-search-results');
    if (!val.trim()) {
      listEl.style.display = 'none';
      return;
    }

    const matches = this._allStaff.filter(s => (s.name || '').toLowerCase().includes(val.toLowerCase())).slice(0, 5);

    if (matches.length > 0) {
      listEl.innerHTML = matches.map(s => `
        <div class="staff-item" onclick="POSModule.selectStaff('${s.name}')">
          <strong>${s.name}</strong>
          <small>(${s.role || 'Staff'})</small>
        </div>
      `).join('');
      listEl.style.display = 'block';
    } else {
      listEl.style.display = 'none';
    }
  },
  selectStaff: function(name) {
    this._staffName = name;
    const input = document.getElementById('pos-staff-input');
    if (input) input.value = name;
    document.getElementById('staff-search-results').style.display = 'none';
    this._saveState();
  },
  searchCompany: function(q) {
    const listEl = document.getElementById('company-search-results');
    if (!q.trim()) {
      listEl.style.display = 'none';
      return;
    }

    const matches = this._allCompanies.filter(c => (c.name || '').toLowerCase().includes(q.toLowerCase())).slice(0, 5);

    if (matches.length > 0) {
      listEl.innerHTML = matches.map(c => `
        <div class="company-item" onclick="POSModule.selectCompany('${c.name}')">
          <strong>${c.name}</strong><br>
          <small style="font-size:10px; color:var(--text-muted);">${c.regNo}</small>
        </div>
      `).join('');
      listEl.style.display = 'block';
    } else {
      listEl.style.display = 'none';
    }
  },
  selectCompany: function(name) {
    this._companyInfo = this._allCompanies.find(c => c.name === name);
    document.getElementById('company-search-results').style.display = 'none';
    document.getElementById('pos-company-input').value = '';
    this.updateCompanyUI();
    this._saveState();
  },
  deselectCompany: function() {
    this._companyInfo = null;
    this.updateCompanyUI();
    this._saveState();
  },
  updateCompanyUI: function() {
    const tagBox = document.getElementById('selected-company-box');
    if (!tagBox) return;

    tagBox.innerHTML = this._companyInfo ? `
      <div class="selected-company-tag">
        <span>${this._companyInfo.name}</span>
        <button type="button" onclick="POSModule.deselectCompany()">Remove</button>
      </div>
    ` : '';
  },
  holdCurrentBill: function() {
    if (this._cart.length === 0) return;

    const bill = {
      id: Date.now(),
      cart: [...this._cart],
      member: this._selectedMember ? {...this._selectedMember} : null,
      company: this._companyInfo ? this._companyInfo.name : null,
      total: this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: this._orderNote,
      bankCardNumber: this._bankCardNumber,
      confirmationCode: this._confirmationCode
    };

    this._heldBills.push(bill);
    this.clearCart();
    this._selectedMember = null;
    this._orderNote = "";
    this._bankCardNumber = "";
    this._confirmationCode = "";
    if (document.getElementById('pos-notes-input')) document.getElementById('pos-notes-input').value = "";
    if (document.getElementById('pos-bankcard-input')) document.getElementById('pos-bankcard-input').value = "";
    if (document.getElementById('pos-confirmationcode-input')) document.getElementById('pos-confirmationcode-input').value = "";
    this.updateCartUI();
    this.updateHoldBadge();
    this._saveState();
  },
  showHoldList: function() {
    if (this._heldBills.length === 0) return;

    const modal = document.getElementById('hold-modal');
    const listEl = document.getElementById('hold-list-container');

    listEl.innerHTML = this._heldBills.map((bill, index) => `
      <div class="hold-list-item" onclick="POSModule.restoreBill(${index})">
        <div class="info">
          <div class="title">${bill.member ? bill.member.name : 'Walk-in'} ${bill.company ? '(' + bill.company + ')' : ''}</div>
          <div class="meta">${bill.cart.length} items - ${bill.time}</div>
          ${bill.note ? `<div class="note">Note: ${bill.note}</div>` : ''}
          ${bill.bankCardNumber ? `<div class="note">Card: ${bill.bankCardNumber}</div>` : ''}
        </div>
        <div class="amount">$${bill.total.toFixed(2)}</div>
      </div>
    `).join('');

    modal.style.display = 'flex';
  },
  restoreBill: function(index) {
    const bill = this._heldBills.splice(index, 1)[0];
    this._cart = bill.cart;
    this._selectedMember = bill.member;
    if (bill.company) {
      this._companyInfo = this._allCompanies.find(c => c.name === bill.company) || { name: bill.company };
    }
    this.updateCompanyUI();
    this._orderNote = bill.note || "";
    this._bankCardNumber = bill.bankCardNumber || "";
    this._confirmationCode = bill.confirmationCode || "";
    if (document.getElementById('pos-notes-input')) document.getElementById('pos-notes-input').value = this._orderNote;
    if (document.getElementById('pos-bankcard-input')) document.getElementById('pos-bankcard-input').value = this._bankCardNumber;
    if (document.getElementById('pos-confirmationcode-input')) document.getElementById('pos-confirmationcode-input').value = this._confirmationCode;
    this.updateCartUI();
    this.closeHoldModal();
    this.updateHoldBadge();
    this._saveState();
  },
  closeHoldModal: function() {
    document.getElementById('hold-modal').style.display = 'none';
  },
  updateHoldBadge: function() {
    const badge = document.getElementById('hold-badge-area');
    if (this._heldBills.length > 0) {
      badge.style.display = 'flex';
      document.getElementById('hold-count-val').innerText = this._heldBills.length;
    } else {
      badge.style.display = 'none';
    }
  },
  searchMember: function(q) {
    const listEl = document.getElementById('member-search-results');
    if (!q.trim()) {
      listEl.style.display = 'none';
      return;
    }

    const matches = this._members.filter(m =>
      (m.name || '').toLowerCase().includes(q.toLowerCase()) ||
      (m.phone || '').includes(q)
    ).slice(0, 5);

    if (matches.length > 0) {
      listEl.innerHTML = matches.map(m => `
        <div class="member-item" onclick="POSModule.selectMember('${m.id}')">
          <strong>${m.name}</strong> - ${m.phone}
          <br>
          <small style="font-size:10px; color:var(--text-muted);">Tier: ${m.tier} | Points: ${m.points}</small>
        </div>
      `).join('');
      listEl.style.display = 'block';
    } else {
      listEl.style.display = 'none';
    }
  },
  selectMember: function(id) {
    this._selectedMember = this._members.find(m => m.id === id);
    document.getElementById('member-search-results').style.display = 'none';
    document.getElementById('pos-member-input').value = '';
    this.updateCartUI();
    this._saveState();
  },
  deselectMember: function() {
    this._selectedMember = null;
    this.updateCartUI();
    this._saveState();
  },
  showInstallmentModal: function() {
    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    if (total <= 0) {
      alert("Cart is empty, cannot do installment");
      return;
    }

    document.getElementById('installment-total-amount').innerText = total.toFixed(2);
    document.getElementById('installment-months').value = '';
    document.getElementById('installment-modal').style.display = 'flex';
  },
  closeInstallmentModal: function() {
    document.getElementById('installment-modal').style.display = 'none';
  },
  confirmInstallment: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let months = parseInt(document.getElementById('installment-months').value);
    if (isNaN(months) || months < 1) {
      alert("Please enter a valid number of months (1 or more)");
      return;
    }

    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    if (total <= 0) return;

    const perAmount = total / months;

    const transaction = {
      id: "TXN-" + Date.now(),
      pos: window.pos || "Main-Station",
      staff: this._staffName || "Unknown",
      company: this._companyInfo ? this._companyInfo.name : "N/A",
      status: "Success",
      paymentMethod: "Installment",
      amount: total,
      memberId: this._selectedMember ? this._selectedMember.id : "Walk-in",
      items: this._cart.map(i => {
        const comm = parseFloat(i.commissionRate);
        return {
          prodName: i.prodName,
          pos: i.pos,
          price: Number(i.price) || 0,
          points: i.points || 0,
          commissionRate: (!isNaN(comm) && comm > 0) ? comm : 0
        };
      }),
      timestamp: new Date().toISOString(),
      installmentPlan: {
        months: months,
        amountPerTerm: perAmount,
        totalAmount: total
      },
      note: this._orderNote,
      bankCardNumber: this._bankCardNumber,
      confirmationCode: this._confirmationCode
    };

    this.closeInstallmentModal();

    const success = await this.saveTransaction(transaction);
    if (success) {
      if (this._selectedMember) await this.updateMemberData(total, transaction.items);
      this.printInstallmentReceipt(transaction, months, perAmount);
      this._cart = [];
      this._selectedMember = null;
      this._orderNote = "";
      this._bankCardNumber = "";
      this._confirmationCode = "";
      if (document.getElementById('pos-notes-input')) document.getElementById('pos-notes-input').value = "";
      if (document.getElementById('pos-bankcard-input')) document.getElementById('pos-bankcard-input').value = "";
      if (document.getElementById('pos-confirmationcode-input')) document.getElementById('pos-confirmationcode-input').value = "";
      this.updateCartUI();
      this._saveState();
      alert(`Installment payment successful! Total amount $${total.toFixed(2)}, to be paid in ${months} months, each term $${perAmount.toFixed(2)}`);
    } else {
      alert("Failed to save installment transaction. Please check network or GitHub configuration.");
    }
  },
  processAfterpayPayment: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    if (total <= 0) return;

    if (!confirm(`Confirm using Afterpay?\nTotal amount: $${total.toFixed(2)}\nYou will complete the payment later.`)) return;

    const transaction = {
      id: "TXN-" + Date.now(),
      pos: window.pos || "Main-Station",
      staff: this._staffName || "Unknown",
      company: this._companyInfo ? this._companyInfo.name : "N/A",
      status: "Pending",
      paymentMethod: "Afterpay",
      amount: total,
      memberId: this._selectedMember ? this._selectedMember.id : "Walk-in",
      items: this._cart.map(i => {
        const comm = parseFloat(i.commissionRate);
        return {
          prodName: i.prodName,
          pos: i.pos,
          price: Number(i.price) || 0,
          points: i.points || 0,
          commissionRate: (!isNaN(comm) && comm > 0) ? comm : 0
        };
      }),
      timestamp: new Date().toISOString(),
      afterpayStatus: "Unpaid",
      note: this._orderNote,
      bankCardNumber: this._bankCardNumber,
      confirmationCode: this._confirmationCode
    };

    const success = await this.saveTransaction(transaction);
    if (success) {
      if (this._selectedMember) await this.updateMemberData(total, transaction.items);
      this.printAfterpayReceipt(transaction);
      this._cart = [];
      this._selectedMember = null;
      this._orderNote = "";
      this._bankCardNumber = "";
      this._confirmationCode = "";
      if (document.getElementById('pos-notes-input')) document.getElementById('pos-notes-input').value = "";
      if (document.getElementById('pos-bankcard-input')) document.getElementById('pos-bankcard-input').value = "";
      if (document.getElementById('pos-confirmationcode-input')) document.getElementById('pos-confirmationcode-input').value = "";
      this.updateCartUI();
      this._saveState();
      alert(`Afterpay order saved (pending payment). Please complete the payment within ${new Date().toLocaleDateString()}.`);
    } else {
      alert("Failed to save Afterpay transaction. Please check network or GitHub configuration.");
    }
  },
  openProductActions: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const modal = document.getElementById('pos-actions-modal');
    const titleEl = document.getElementById('pos-actions-title');
    const contentEl = document.getElementById('pos-actions-content');

    titleEl.innerText = product.prodName || 'Product Actions';

    const totalStock = product.qty || 0;
    const locations = product.locations || [];
    const history = product.history || [];
    const isLowStock = totalStock <= (product.minStock || 5);

    contentEl.innerHTML = `
      <div style="margin-bottom:16px;">
        <div class="info-row"><span>SKU</span><strong>${product.sku || 'N/A'}</strong></div>
        <div class="info-row"><span>Price</span><strong>$${(Number(product.price) || 0).toFixed(2)}</strong></div>
        <div class="info-row"><span>Stock</span><strong style="color:${isLowStock ? 'var(--danger)' : 'var(--green)'}">${totalStock} units</strong></div>
        <div class="info-row"><span>Category</span><strong>${product.category || 'N/A'}</strong></div>
        ${product.expiryDate ? `<div class="info-row"><span>Expiry</span><strong>${product.expiryDate}</strong></div>` : ''}
      </div>
      <div class="actions-grid">
        <div class="action-tile" onclick="POSModule.showProductStock('${posId}')">
          <span>Stock Details</span>
        </div>
        <div class="action-tile" onclick="POSModule.showProductLocations('${posId}')">
          <span>Locations</span>
        </div>
        <div class="action-tile" onclick="POSModule.showProductLogs('${posId}')">
          <span>History</span>
        </div>
        <div class="action-tile" onclick="POSModule.printProductLabel('${posId}')">
          <span>Print Label</span>
        </div>
        <div class="action-tile" onclick="POSModule.showProductStats('${posId}')">
          <span>Statistics</span>
        </div>
        <div class="action-tile" onclick="POSModule.addToCart('${posId}'); POSModule.closeProductActions();">
          <span>Add to Cart</span>
        </div>
        <div class="action-tile" onclick="POSModule.showBatchStock('${posId}')">
          <span>Batch Stock</span>
        </div>
        <div class="action-tile" onclick="POSModule.showPurchaseHistory('${posId}')">
          <span>Purchase History</span>
        </div>
        <div class="action-tile" onclick="POSModule.showSalesHistory('${posId}')">
          <span>Sales History</span>
        </div>
        <div class="action-tile" onclick="POSModule.showProfitAnalysis('${posId}')">
          <span>Profit Analysis</span>
        </div>
        <div class="action-tile" onclick="POSModule.showSupplierInfo('${posId}')">
          <span>Supplier Info</span>
        </div>
        <div class="action-tile" onclick="POSModule.showStockMovement('${posId}')">
          <span>Stock Movement</span>
        </div>
        <div class="action-tile" onclick="POSModule.printBarcode('${posId}')">
          <span>Print Barcode</span>
        </div>
        <div class="action-tile" onclick="POSModule.showProductNotes('${posId}')">
          <span>Product Notes</span>
        </div>
      </div>
    `;

    modal.style.display = 'flex';
  },
  closeProductActions: function() {
    document.getElementById('pos-actions-modal').style.display = 'none';
  },
  showProductStock: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const locations = product.locations || [];
    const totalStock = locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);

    let locHtml = '';
    if (locations.length === 0) {
      locHtml = '<p style="text-align:center; color:var(--text-muted);">No batch records available.</p>';
    } else {
      locHtml = locations.map(loc => `
        <div style="background:var(--surface-soft); padding:10px 14px; border-radius:var(--radius-md); margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; border:1px solid var(--border);">
          <span style="font-size:13px; font-weight:600;">${loc.bn || 'N/A'}</span>
          <strong style="color:var(--text);">${loc.qty || 0} units</strong>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Stock Details</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="margin-bottom:12px; background:var(--primary-soft); padding:10px 14px; border-radius:var(--radius-md); font-weight:700; color:var(--primary);">Total: ${totalStock} units</div>
        ${locHtml}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showProductLocations: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const locations = product.locations || [];

    let locHtml = '';
    if (locations.length === 0) {
      locHtml = '<p style="text-align:center; color:var(--text-muted);">No location mapping available.</p>';
    } else {
      locHtml = locations.map(loc => `
        <div style="background:var(--surface-soft); padding:12px 14px; border-radius:var(--radius-md); margin-bottom:8px; border:1px solid var(--border);">
          <div style="font-weight:700; font-size:14px;">${loc.bn || 'N/A'}</div>
          <div style="font-size:12px; color:var(--text-secondary);">Shelf: ${loc.shelf || 'Main Storage'} | Qty: ${loc.qty || 0} | Exp: ${loc.exp || 'N/A'}</div>
          ${loc.company ? `<div style="font-size:11px; color:var(--text-muted);">Supplier: ${loc.company}</div>` : ''}
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Location Mapping</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        ${locHtml}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showProductLogs: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const history = product.history || [];

    let logHtml = '';
    if (history.length === 0) {
      logHtml = '<p style="text-align:center; color:var(--text-muted);">No history records.</p>';
    } else {
      logHtml = history.slice().reverse().map(l => `
        <div style="padding:10px 0; border-bottom:1px solid var(--border); font-size:13px;">
          <div style="display:flex; justify-content:space-between; color:var(--text-secondary); margin-bottom:4px;">
            <span>${new Date(l.time).toLocaleString()}</span>
            <span style="font-weight:600; color:var(--primary);">${l.user || 'N/A'}</span>
          </div>
          <div style="font-weight:700;">${l.action}</div>
          <div style="color:var(--text-secondary); font-size:12px;">${l.details}</div>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Product History</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="overflow-y:auto; max-height:55vh; padding-right:4px;">${logHtml}</div>
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  printProductLabel: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const printWin = window.open('', '_blank', 'width=400,height=300');
    if (!printWin) {
      alert("Please allow popups to print label.");
      return;
    }

    printWin.document.write(`
      <html><head><style>
        @page { size: 80mm 50mm; margin: 0; }
        body { font-family: -apple-system, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background:#fff; }
        .label { text-align: center; padding: 20px; border: 1px dashed #ccc; width: 80mm; height: 50mm; box-sizing: border-box; display: flex; flex-direction: column; justify-content: center; }
        .name { font-size: 16px; font-weight: bold; color:#111; }
        .sku { font-size: 11px; color: #666; margin-top:2px; }
        .price { font-size: 22px; font-weight: 900; margin-top: 8px; color:#4f46e5; }
      </style></head><body>
        <div class="label">
          <div class="name">${product.prodName}</div>
          <div class="sku">SKU: ${product.sku || 'N/A'}</div>
          <div class="price">$${(Number(product.price) || 0).toFixed(2)}</div>
        </div>
        <script>
          window.onload = function() { setTimeout(() => { window.print(); setTimeout(() => window.close(), 500); }, 300); };
        </script>
      </body></html>
    `);
    printWin.document.close();
  },
  showProductStats: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const history = product.history || [];
    const soldLogs = history.filter(l => l.action === 'Sold Out');
    let totalSold = 0;
    soldLogs.forEach(l => {
      const match = l.details.match(/\(-(\d+)\)/);
      if (match) totalSold += parseInt(match[1]);
    });

    const stockValue = (Number(product.qty) || 0) * (Number(product.price) || 0);
    const profitMargin = product.cost ? (((Number(product.price) || 0) - (Number(product.cost) || 0)) / (Number(product.price) || 1) * 100) : 0;

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Product Statistics</div>
        <p style="margin:0 0 16px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:14px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Stock Value</div>
            <div style="font-size:18px; font-weight:700; color:var(--primary); margin-top:4px;">$${stockValue.toFixed(2)}</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:14px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Total Sold</div>
            <div style="font-size:18px; font-weight:700; color:var(--green); margin-top:4px;">${totalSold} units</div>
          </div>
          ${product.cost ? `
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:14px; border-radius:var(--radius-md); text-align:center; grid-column: span 2;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Est. Profit Margin</div>
            <div style="font-size:18px; font-weight:700; color:var(--primary-dark); margin-top:4px;">${profitMargin.toFixed(1)}%</div>
          </div>
          ` : ''}
        </div>
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showBatchStock: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const locations = product.locations || [];
    let html = '';
    if (locations.length === 0) {
      html = '<p style="text-align:center; color:var(--text-muted);">No batch stock records.</p>';
    } else {
      html = locations.map(loc => `
        <div style="background:var(--surface-soft); padding:10px 14px; border-radius:var(--radius-md); margin-bottom:8px; border:1px solid var(--border);">
          <div style="font-weight:700; font-size:14px;">${loc.bn || 'N/A'}</div>
          <div style="font-size:12px; color:var(--text-secondary);">Qty: ${loc.qty || 0} | Exp: ${loc.exp || 'N/A'} | Supplier: ${loc.company || 'N/A'}</div>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Batch Stock</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        ${html}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showPurchaseHistory: async function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const config = this._config || JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghToken || !config.ghRepo) return;

    const fetchFile = async (path) => {
      const url = `https://api.github.com/repos/${config.ghRepo}/contents/${path}`;
      const res = await fetch(url, { headers: { 'Authorization': `token ${config.ghToken}` }, cache: 'no-store' });
      if (!res.ok) return null;
      const data = await res.json();
      return JSON.parse(decodeURIComponent(escape(atob(data.content))));
    };

    const purchaseData = await fetchFile('db_date/purchase_orders.json');
    if (!purchaseData || !Array.isArray(purchaseData)) {
      alert('No purchase data found');
      return;
    }

    const relevant = purchaseData.filter(po => po.items && po.items.some(item => item.name === product.prodName));
    let html = '';
    if (relevant.length === 0) {
      html = '<p style="text-align:center; color:var(--text-muted);">No purchase history for this product.</p>';
    } else {
      html = relevant.slice().reverse().map(po => `
        <div style="background:var(--surface-soft); padding:10px 14px; border-radius:var(--radius-md); margin-bottom:8px; border:1px solid var(--border);">
          <div style="font-weight:700; font-size:14px;">${po.id}</div>
          <div style="font-size:12px; color:var(--text-secondary);">Date: ${po.poDate} | Supplier: ${po.supplierName} | Items: ${po.items.length}</div>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Purchase History</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        ${html}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showSalesHistory: async function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const config = this._config || JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghToken || !config.ghRepo) return;

    const fetchFile = async (path) => {
      const url = `https://api.github.com/repos/${config.ghRepo}/contents/${path}`;
      const res = await fetch(url, { headers: { 'Authorization': `token ${config.ghToken}` }, cache: 'no-store' });
      if (!res.ok) return null;
      const data = await res.json();
      return JSON.parse(decodeURIComponent(escape(atob(data.content))));
    };

    const counterData = await fetchFile('db_date/counter.json');
    if (!counterData || !Array.isArray(counterData)) {
      alert('No sales data found');
      return;
    }

    const relevant = counterData.filter(txn => txn.items && txn.items.some(item => item.prodName === product.prodName));
    let html = '';
    if (relevant.length === 0) {
      html = '<p style="text-align:center; color:var(--text-muted);">No sales history for this product.</p>';
    } else {
      html = relevant.slice().reverse().map(txn => `
        <div style="background:var(--surface-soft); padding:10px 14px; border-radius:var(--radius-md); margin-bottom:8px; border:1px solid var(--border);">
          <div style="font-weight:700; font-size:14px;">${txn.id}</div>
          <div style="font-size:12px; color:var(--text-secondary);">${new Date(txn.timestamp).toLocaleDateString()} | $${txn.amount} | ${txn.paymentMethod}</div>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Sales History</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        ${html}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showProfitAnalysis: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const cost = Number(product.cost) || 0;
    const price = Number(product.price) || 0;
    const profitPerUnit = price - cost;
    const margin = price > 0 ? (profitPerUnit / price) * 100 : 0;
    const stockQty = Number(product.qty) || 0;
    const totalPotentialProfit = profitPerUnit * stockQty;

    const history = product.history || [];
    const soldLogs = history.filter(l => l.action === 'Sold Out');
    let totalSold = 0;
    soldLogs.forEach(l => {
      const match = l.details.match(/\(-(\d+)\)/);
      if (match) totalSold += parseInt(match[1]);
    });
    const totalProfitFromSales = profitPerUnit * totalSold;

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Profit Analysis</div>
        <p style="margin:0 0 16px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Cost</div>
            <div style="font-size:18px; font-weight:700; color:var(--text); margin-top:2px;">$${cost.toFixed(2)}</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Price</div>
            <div style="font-size:18px; font-weight:700; color:var(--primary); margin-top:2px;">$${price.toFixed(2)}</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Profit/Unit</div>
            <div style="font-size:18px; font-weight:700; color:var(--green); margin-top:2px;">$${profitPerUnit.toFixed(2)}</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Margin</div>
            <div style="font-size:18px; font-weight:700; color:var(--amber); margin-top:2px;">${margin.toFixed(1)}%</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center; grid-column: span 2;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Total Potential Profit (Current Stock)</div>
            <div style="font-size:18px; font-weight:700; color:var(--danger); margin-top:2px;">$${totalPotentialProfit.toFixed(2)}</div>
          </div>
          <div style="background:var(--surface-soft); border:1px solid var(--border); padding:12px; border-radius:var(--radius-md); text-align:center; grid-column: span 2;">
            <div style="font-size:11px; color:var(--text-secondary); font-weight:600;">Total Profit from Sales (Lifetime)</div>
            <div style="font-size:18px; font-weight:700; color:var(--green); margin-top:2px;">$${totalProfitFromSales.toFixed(2)}</div>
          </div>
        </div>
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showSupplierInfo: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const locations = product.locations || [];
    const suppliers = new Set(locations.filter(l => l.company).map(l => l.company));

    let html = '';
    if (suppliers.size === 0) {
      html = '<p style="text-align:center; color:var(--text-muted);">No supplier information available.</p>';
    } else {
      suppliers.forEach(sup => {
        const batches = locations.filter(l => l.company === sup);
        const totalQty = batches.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
        html += `
          <div style="background:var(--surface-soft); padding:12px 14px; border-radius:var(--radius-md); margin-bottom:8px; border:1px solid var(--border);">
            <div style="font-weight:700; font-size:14px;">${sup}</div>
            <div style="font-size:12px; color:var(--text-secondary);">Batches: ${batches.length} | Total Qty: ${totalQty}</div>
          </div>
        `;
      });
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Supplier Info</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        ${html}
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  showStockMovement: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const history = product.history || [];
    const movementLogs = history.filter(l => l.action === 'Stock In' || l.action === 'Sold Out' || l.action === 'Edit Stock In' || l.action === 'Delete Stock In');
    let html = '';
    if (movementLogs.length === 0) {
      html = '<p style="text-align:center; color:var(--text-muted);">No stock movement records.</p>';
    } else {
      html = movementLogs.slice().reverse().map(l => `
        <div style="padding:10px 0; border-bottom:1px solid var(--border); font-size:13px;">
          <div style="display:flex; justify-content:space-between; color:var(--text-secondary); margin-bottom:4px;">
            <span>${new Date(l.time).toLocaleString()}</span>
            <span style="font-weight:600; color:var(--primary);">${l.user || 'N/A'}</span>
          </div>
          <div style="font-weight:700;">${l.action}</div>
          <div style="color:var(--text-secondary); font-size:12px;">${l.details}</div>
        </div>
      `).join('');
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Stock Movement</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="overflow-y:auto; max-height:55vh; padding-right:4px;">${html}</div>
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  printBarcode: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const barcodeValue = product.sku || product.pos;
    if (!barcodeValue) {
      alert('No barcode value available');
      return;
    }

    const printWin = window.open('', '_blank', 'width=400,height=200');
    if (!printWin) {
      alert('Please allow popups to print barcode.');
      return;
    }

    printWin.document.write(`
      <html><head><style>
        @page { size: 80mm 30mm; margin: 0; }
        body { font-family: monospace; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background:#fff; }
        .barcode { text-align: center; }
        .barcode-value { font-size: 12px; letter-spacing: 2px; color:#333; margin-top:4px; }
      </style></head><body>
        <div class="barcode">
          <div style="font-size: 28px; font-weight: bold; letter-spacing:4px; color:#111;">${barcodeValue}</div>
          <div class="barcode-value">${barcodeValue}</div>
        </div>
        <script>
          window.onload = function() { setTimeout(() => { window.print(); setTimeout(() => window.close(), 500); }, 300); };
        </script>
      </body></html>
    `);
    printWin.document.close();
  },
  showProductNotes: function(posId) {
    const product = this._products.find(p => String(p.pos) === String(posId));
    if (!product) return;

    const notes = product.notes || 'No notes available.';

    const overlay = document.createElement('div');
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(15,23,42,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-title">Product Notes</div>
        <p style="margin:0 0 12px 0; font-weight:700; font-size:15px;">${product.prodName}</p>
        <div style="background:var(--surface-soft); padding:14px; border-radius:var(--radius-md); font-size:14px; white-space:pre-wrap; border:1px solid var(--border); color:var(--text); min-height:60px;">${notes}</div>
        <button type="button" onclick="this.closest('div').parentElement.remove()" class="close-modal-btn">Close</button>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  render: function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    this._injectStyles();
    this._loadState();

    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = `
      <div class="pos-wrapper">
        <div class="pos-container">
          <section class="product-area">
            <div class="product-area-header">
              <h2>POS</h2>
              <div class="header-actions">
                <div id="hold-badge-area" class="hold-badge" onclick="POSModule.showHoldList()" style="display:none;">
                  <span>Hold</span>
                  <span id="hold-count-val" class="hold-count">0</span>
                </div>
                <div class="station-badge" onclick="POSModule.showHoldList()">
                  <span class="label">Station</span>
                  <span class="value" id="station-id-display">${window.pos || 'Loading...'}</span>
                </div>
              </div>
            </div>

            <div class="staff-input-wrap">
              <input type="text" id="pos-staff-input" class="staff-input" placeholder="Enter Staff Name..." oninput="POSModule.updateStaffName(this.value)">
              <div id="staff-search-results" class="staff-results"></div>
            </div>

            <div class="company-selector-wrap">
              <div id="selected-company-box"></div>
              <input type="text" id="pos-company-input" class="company-search-input" placeholder="Enter Company Name to load info..." oninput="POSModule.searchCompany(this.value)">
              <div id="company-search-results" class="company-results"></div>
            </div>

            <input type="text" id="pos-search" class="search-input" placeholder="Search Products..." oninput="POSModule.filterProducts(this.value)">

            <div class="product-grid" id="pos-menu"></div>
          </section>

          <aside class="checkout-aside">
            <div class="cart-header">
              <span>Order Detail</span>
              <div class="cart-header-actions">
                <button type="button" onclick="POSModule.holdCurrentBill()">Hold</button>
                <button type="button" onclick="POSModule.clearCart()">Clear</button>
              </div>
            </div>

            <div class="cart-section-spacer">
              <div id="selected-member-box"></div>
              <div class="member-search-wrap">
                <input type="text" id="pos-member-input" class="member-search-input" placeholder="Search Member..." oninput="POSModule.searchMember(this.value)">
                <div id="member-search-results" class="member-results"></div>
              </div>
              <div style="margin-bottom:12px;">
                <label class="notes-label">Order Notes</label>
                <textarea id="pos-notes-input" class="notes-input" placeholder="Add notes for this order..." oninput="POSModule.updateOrderNote(this.value)"></textarea>
              </div>
              <div style="margin-bottom:12px;">
                <label class="notes-label">Bank Card Number (Optional)</label>
                <input type="text" id="pos-bankcard-input" class="staff-input" placeholder="Enter Bank Card Number..." oninput="POSModule.updateBankCardNumber(this.value)">
              </div>
              <div style="margin-bottom:12px;">
                <label class="notes-label">Confirmation Code (Optional)</label>
                <input type="text" id="pos-confirmationcode-input" class="staff-input" placeholder="Enter Confirmation Code..." oninput="POSModule.updateConfirmationCode(this.value)">
              </div>
            </div>

            <div class="cart-scroll" id="pos-cart"></div>

            <div class="checkout-footer">
              <div class="total-row">
                <span>Total</span>
                <span class="total-amount" id="pos-total">$0.00</span>
              </div>
              <div class="pay-btn-group">
                <button type="button" class="pay-btn pay-cash" onclick="POSModule.handleCashPayment()">Cash</button>
                <button type="button" class="pay-btn pay-card" onclick="POSModule.processPayment('Card')">Card</button>
                <button type="button" class="pay-btn pay-wallet" onclick="POSModule.processPayment('Wallet')">Wallet</button>
                <button type="button" class="pay-btn pay-qr" onclick="POSModule.processPayment('QR Pay')">QR Pay</button>
                <button type="button" class="pay-btn pay-installment" onclick="POSModule.showInstallmentModal()">Installment</button>
                <button type="button" class="pay-btn pay-afterpay" onclick="POSModule.processAfterpayPayment()">Afterpay</button>
              </div>
            </div>
          </aside>
        </div>
      </div>

      <div id="cash-modal">
        <div class="modal-content">
          <div class="modal-title">Cash Settlement</div>
          <div class="modal-due">Due: <strong id="modal-due-amount">$0.00</strong></div>
          <input type="number" id="cash-received" class="cash-input" placeholder="Enter amount received" oninput="POSModule.calculateChange()">
          <div id="change-box" class="change-display change-negative">Remaining: $0.00</div>
          <div class="modal-actions">
            <button type="button" class="btn-secondary" onclick="POSModule.closeCashModal()">Cancel</button>
            <button type="button" id="confirm-cash-btn" class="btn-success" onclick="POSModule.processPayment('Cash')">Confirm Sale</button>
          </div>
        </div>
      </div>

      <div id="hold-modal">
        <div class="modal-content">
          <div class="modal-title">Held Bills</div>
          <div id="hold-list-container"></div>
          <button type="button" class="close-modal-btn" onclick="POSModule.closeHoldModal()">Close</button>
        </div>
      </div>

      <div id="installment-modal">
        <div class="modal-content">
          <div class="modal-title">Installment Payment</div>
          <div style="text-align:center; margin-bottom:12px; font-size:14px; color:var(--text-secondary);">Order total: <strong style="color:var(--text);" id="installment-total-amount">$0.00</strong></div>
          <label class="pos-sub-label">Number of months</label>
          <input type="number" id="installment-months" class="installment-input" placeholder="e.g., 3, 6, 12, 24" min="1" step="1">
          <div style="font-size:12px; color:var(--text-muted); margin:0 0 16px 0; text-align:center;">* Supports months or years, just enter the number of months</div>
          <div class="modal-actions">
            <button type="button" class="btn-secondary" onclick="POSModule.closeInstallmentModal()">Cancel</button>
            <button type="button" class="btn-primary" onclick="POSModule.confirmInstallment()">Confirm Installment</button>
          </div>
        </div>
      </div>

      <div id="pos-actions-modal">
        <div class="modal-content">
          <div class="modal-title" id="pos-actions-title">Product Actions</div>
          <div id="pos-actions-content"></div>
          <button type="button" class="close-modal-btn" onclick="POSModule.closeProductActions()">Close</button>
        </div>
      </div>
    `;

    this.loadProducts();
    this.updateCartUI();
    this.updateHoldBadge();
    this.initData();
  },
  handleCashPayment: function() {
    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    if (total <= 0) return;

    document.getElementById('modal-due-amount').innerText = `$${total.toFixed(2)}`;
    document.getElementById('cash-received').value = '';
    document.getElementById('cash-modal').style.display = 'flex';
    document.getElementById('cash-received').focus();
    this.calculateChange();
  },
  calculateChange: function() {
    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    const received = parseFloat(document.getElementById('cash-received').value) || 0;
    const change = received - total;

    const changeBox = document.getElementById('change-box');
    const confirmBtn = document.getElementById('confirm-cash-btn');

    if (change >= 0) {
      changeBox.className = "change-display change-positive";
      changeBox.innerText = `Change: $${change.toFixed(2)}`;
      confirmBtn.disabled = false;
      confirmBtn.style.opacity = "1";
    } else {
      changeBox.className = "change-display change-negative";
      changeBox.innerText = `Remaining: $${Math.abs(change).toFixed(2)}`;
      confirmBtn.disabled = true;
      confirmBtn.style.opacity = "0.5";
    }
  },
  closeCashModal: function() {
    document.getElementById('cash-modal').style.display = 'none';
  },
  filterProducts: function(q) {
    const t = (q || "").toLowerCase().trim();
    this._filteredProducts = this._products.filter(p =>
      String(p.prodName || "").toLowerCase().includes(t) ||
      String(p.pos || "").toLowerCase().includes(t)
    );
    this.loadProducts();
  },
  loadProducts: function() {
    const el = document.getElementById('pos-menu');
    if (!el) return;

    if (this._filteredProducts.length === 0) {
      el.innerHTML = `<div style="grid-column:1/-1; text-align:center; padding:50px 0; color:var(--text-muted); font-size:14px;">No products found</div>`;
      return;
    }

    el.innerHTML = this._filteredProducts.map(p => `
      <div class="product-item" onclick="POSModule.addToCart('${p.pos}')">
        <button type="button" class="product-action-btn" onclick="event.stopPropagation(); POSModule.openProductActions('${p.pos}')">Info</button>
        <span class="product-name">${p.prodName || 'Unnamed'}</span>
        <span class="product-price">$${(Number(p.price) || 0).toFixed(2)}</span>
      </div>
    `).join('');
  },
  addToCart: function(posId) {
    const p = this._products.find(p => String(p.pos) === String(posId));
    if (p) {
      this._cart.push({...p, cartId: Date.now()});
      this.updateCartUI();
      this._saveState();
    }
  },
  removeFromCart: function(i) {
    this._cart.splice(i, 1);
    this.updateCartUI();
    this._saveState();
  },
  clearCart: function() {
    this._cart = [];
    this.updateCartUI();
    this._saveState();
  },
  updateCartUI: function() {
    const cEl = document.getElementById('pos-cart');
    const tEl = document.getElementById('pos-total');
    const mEl = document.getElementById('selected-member-box');

    if (!cEl || !tEl || !mEl) return;

    mEl.innerHTML = this._selectedMember ? `
      <div class="selected-member-tag">
        <span>${this._selectedMember.name} (${this._selectedMember.points} pts)</span>
        <button type="button" onclick="POSModule.deselectMember()">Remove</button>
      </div>
    ` : '';

    if (this._cart.length === 0) {
      cEl.innerHTML = `<div class="cart-empty">No items in cart</div>`;
      tEl.innerText = `$0.00`;
      return;
    }

    cEl.innerHTML = this._cart.map((item, i) => `
      <div class="cart-item">
        <span class="name">${item.prodName}</span>
        <div style="display:flex; align-items:center; gap:6px;">
          <span class="price">$${(Number(item.price) || 0).toFixed(2)}</span>
          <button type="button" class="remove-btn" onclick="POSModule.removeFromCart(${i})">Remove</button>
        </div>
      </div>
    `).join('');

    tEl.innerText = `$${this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0).toFixed(2)}`;
  },
  updateOrderNote: function(val) {
    this._orderNote = val;
    this._saveState();
  },
  updateBankCardNumber: function(val) {
    this._bankCardNumber = val;
    this._saveState();
  },
  updateConfirmationCode: function(val) {
    this._confirmationCode = val;
    this._saveState();
  },
  processPayment: async function(method) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const total = this._cart.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
    if (total <= 0) return;

    const received = method === 'Cash' ? parseFloat(document.getElementById('cash-received').value) : total;
    const change = received - total;

    const transaction = {
      id: "TXN-" + Date.now(),
      pos: window.pos || "Main-Station",
      staff: this._staffName || "Unknown",
      company: this._companyInfo ? this._companyInfo.name : "N/A",
      status: "Success",
      paymentMethod: method,
      amount: total,
      memberId: this._selectedMember ? this._selectedMember.id : "Walk-in",
      items: this._cart.map(i => {
        const comm = parseFloat(i.commissionRate);
        return {
          prodName: i.prodName,
          pos: i.pos,
          price: Number(i.price) || 0,
          points: i.points || 0,
          commissionRate: (!isNaN(comm) && comm > 0) ? comm : 0
        };
      }),
      timestamp: new Date().toISOString(),
      note: this._orderNote,
      bankCardNumber: this._bankCardNumber,
      confirmationCode: this._confirmationCode
    };

    this.closeCashModal();

    const success = await this.saveTransaction(transaction);
    if (success) {
      this.printReceipt(transaction, received, change);
      if (this._selectedMember) await this.updateMemberData(total, transaction.items);
      this._cart = [];
      this._selectedMember = null;
      this._orderNote = "";
      this._bankCardNumber = "";
      this._confirmationCode = "";
      if (document.getElementById('pos-notes-input')) document.getElementById('pos-notes-input').value = "";
      if (document.getElementById('pos-bankcard-input')) document.getElementById('pos-bankcard-input').value = "";
      if (document.getElementById('pos-confirmationcode-input')) document.getElementById('pos-confirmationcode-input').value = "";
      this.updateCartUI();
      this._saveState();
      alert(`Payment Success! Change: $${change.toFixed(2)}`);
    } else {
      alert("Error saving transaction. Check connection or GitHub Token.");
    }
  },
  updateMemberData: async function(amount, items) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const memberIdx = this._members.findIndex(m => m.id === this._selectedMember.id);
    if (memberIdx === -1) return;

    let totalPoints = 0;
    items.forEach(i => totalPoints += (parseInt(i.points) || 0));

    this._members[memberIdx].points = (parseInt(this._members[memberIdx].points) || 0) + totalPoints;

    const historyNote = `\n[${new Date().toLocaleDateString()}] Order: ${items.map(i=>i.prodName).join(', ')} (+${totalPoints} pts)`;
    this._members[memberIdx].notes = (this._members[memberIdx].notes || "") + historyNote;

    try {
      const content = btoa(unescape(encodeURIComponent(JSON.stringify(this._members, null, 2))));

      const updateRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/members.json`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        body: JSON.stringify({
          message: "Member points update",
          content,
          sha: this._membersSha
        })
      });

      if (updateRes.ok) {
        const freshData = await updateRes.json();
        this._membersSha = freshData.content.sha;
      }
    } catch (e) {
      console.error("Member update failed", e);
    }
  },
  saveTransaction: async function(txn) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    if (!config.ghRepo || !config.ghToken) {
      return false;
    }

    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const res = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      let records = [];
      let sha = null;

      if (res.ok) {
        const data = await res.json();
        records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        if (!Array.isArray(records)) records = [];
        sha = data.sha;
      } else if (res.status !== 404) {
        return false;
      }

      records.push(txn);

      const body = {
        message: `Transaction ${txn.id}`,
        content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2))))
      };

      if (sha) {
        body.sha = sha;
      }

      const putRes = await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        body: JSON.stringify(body)
      });

      return putRes.ok;
    } catch (e) {
      return false;
    }
  }
};

window.POSModule = POSModule;

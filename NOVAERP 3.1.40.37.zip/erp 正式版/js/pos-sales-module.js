const POSSalesModule = {
  _config: null,
  _enabled: true,
  _targets: [],
  _salesData: [],
  _filteredSales: [],
  _searchQuery: "",
  _itemsPerPage: 20,
  _currentPage: 1,
  _staffSearchQuery: "",
  _expandedCompanies: {},
  _expandedSalesCompanies: {},

  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _initConfig: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
  },

  init: async function(containerId) {
    this._initConfig();
    this._loadState();
    this._injectStyles();
    await this.fetchData(containerId);
  },

  _saveState: function() {
    const state = {
      enabled: this._enabled
    };
    localStorage.setItem('POS_SALES_MODULE_STATE', JSON.stringify(state));
  },

  _loadState: function() {
    const saved = localStorage.getItem('POS_SALES_MODULE_STATE');
    if (saved) {
      try {
        const state = JSON.parse(saved);
        this._enabled = typeof state.enabled === 'boolean' ? state.enabled : true;
      } catch (e) {
        console.error("Failed to load sales module state", e);
      }
    }
  },

  _injectStyles: function() {
    if (document.getElementById('pos-sales-module-style')) return;

    const style = document.createElement('style');
    style.id = 'pos-sales-module-style';
    style.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-hover: #4338ca;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-muted: #94a3b8;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .psm-wrapper {
        padding: 24px;
        max-width: 1400px;
        margin: 0 auto;
        font-family: var(--font-sans);
        color: var(--text);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
      }

      .psm-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 14px;
        margin-bottom: 20px;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        box-shadow: var(--shadow-xs);
        border: 1px solid var(--border);
      }

      .psm-title {
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
        margin: 0;
      }

      .psm-controls {
        display: flex;
        gap: 14px;
        align-items: center;
        flex-wrap: wrap;
      }

      .psm-switch-wrap {
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .psm-toggle {
        position: relative;
        display: inline-block;
        width: 46px;
        height: 24px;
        flex-shrink: 0;
      }

      .psm-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
      }

      .psm-slider {
        position: absolute;
        cursor: pointer;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: var(--border-strong);
        transition: var(--transition-base);
        border-radius: 24px;
      }

      .psm-slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: var(--surface);
        transition: var(--transition-base);
        border-radius: 50%;
        box-shadow: var(--shadow-xs);
      }

      input:checked + .psm-slider {
        background-color: var(--green);
      }

      input:checked + .psm-slider:before {
        transform: translateX(22px);
      }

      .psm-card {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
        border: 1px solid var(--border);
        margin-bottom: 20px;
      }

      .psm-card-title {
        margin: 0 0 14px 0;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
      }

      .psm-disabled-banner {
        background: var(--red-soft);
        border: 1px solid rgba(239, 68, 68, 0.25);
        color: var(--danger);
        padding: 18px 20px;
        border-radius: var(--radius-md);
        text-align: center;
        font-weight: 600;
        font-size: 14px;
      }

      .psm-search-input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        color: var(--text);
        outline: none;
        transition: all var(--transition-fast);
        margin-bottom: 16px;
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .psm-search-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .psm-search-input::placeholder {
        color: var(--text-dim);
      }

      .psm-table-responsive {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
      }

      .psm-table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
        font-size: 14px;
        min-width: 640px;
        background: var(--surface);
      }

      .psm-table th, .psm-table td {
        padding: 12px 16px;
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
        color: var(--text);
      }

      .psm-table th {
        font-weight: 700;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--text-secondary);
        background: var(--surface-soft);
      }

      .psm-table tr:last-child td {
        border-bottom: none;
      }

      .psm-table tr:hover td {
        background: var(--surface-soft);
      }

      .psm-company-group {
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        margin-bottom: 12px;
        background: var(--surface);
        overflow: hidden;
      }

      .psm-company-group:last-child {
        margin-bottom: 0;
      }

      .psm-company-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        background: var(--surface-soft);
        cursor: pointer;
        user-select: none;
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        transition: background var(--transition-fast);
      }

      .psm-company-header:hover {
        background: var(--primary-soft);
      }

      .psm-company-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .psm-company-arrow {
        display: inline-block;
        transition: transform var(--transition-fast);
        font-size: 12px;
        color: var(--text-secondary);
      }

      .psm-company-arrow.open {
        transform: rotate(90deg);
      }

      .psm-company-meta {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .psm-company-body {
        display: none;
        border-top: 1px solid var(--border);
      }

      .psm-company-body.open {
        display: block;
      }

      .psm-company-body .psm-table-responsive {
        border: none;
        border-radius: 0;
      }

      .psm-company-badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: var(--radius-xs);
        background: var(--primary-soft);
        color: var(--primary);
        font-size: 12px;
        font-weight: 600;
      }

      .psm-progress-track {
        flex: 1;
        background: var(--border);
        border-radius: var(--radius-xs);
        height: 8px;
        overflow: hidden;
      }

      .psm-progress-fill {
        background: var(--primary);
        height: 100%;
        border-radius: var(--radius-xs);
        transition: width var(--transition-base);
      }

      .psm-btn {
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        border: 1px solid transparent;
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        background: var(--primary);
        color: #fff;
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .psm-btn:hover {
        background: var(--primary-hover);
      }

      .psm-pagination {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 16px;
        flex-wrap: wrap;
        gap: 12px;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .psm-pagination-controls {
        display: flex;
        gap: 8px;
        align-items: center;
      }

      .psm-page-btn {
        height: 34px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        background: var(--surface);
        color: var(--text-secondary);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .psm-page-btn:hover:not(:disabled) {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .psm-page-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .psm-select {
        height: 34px;
        padding: 0 10px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        background: var(--surface);
        color: var(--text);
        font-size: 13px;
        outline: none;
        cursor: pointer;
        font-family: var(--font-sans);
      }

      .psm-select:focus {
        border-color: var(--primary);
      }

      .psm-modal {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.55);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        padding: 20px;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .psm-modal-content {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 24px;
        width: 100%;
        max-width: 420px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border);
      }

      .psm-modal-title {
        margin: 0 0 12px 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .psm-modal-label {
        font-size: 13px;
        color: var(--text-secondary);
        margin-bottom: 8px;
      }

      .psm-input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 15px;
        font-weight: 600;
        background: var(--surface);
        color: var(--text);
        outline: none;
        margin: 10px 0 18px;
        font-family: var(--font-sans);
        transition: all var(--transition-fast);
      }

      .psm-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .psm-modal-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
      }

      .psm-modal-actions .psm-btn {
        height: 40px;
        font-size: 13px;
        width: 100%;
      }

      .psm-btn-secondary {
        background: var(--surface);
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .psm-btn-secondary:hover {
        background: var(--surface-soft);
        color: var(--text);
      }

      @media (max-width: 768px) {
        .psm-wrapper {
          padding: 16px;
        }
        .psm-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: flex-start;
        }
        .psm-title {
          font-size: 22px;
        }
        .psm-controls {
          width: 100%;
          justify-content: space-between;
        }
        .psm-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .psm-modal-content {
          padding: 20px;
          border-radius: var(--radius-lg);
        }
      }
    `;
    document.head.appendChild(style);
  },

  fetchData: async function(containerId) {
    const config = this._config;
    if (!config.ghToken || !config.ghRepo) {
      this.renderUI(containerId);
      return;
    }

    const fetchFile = async (path) => {
      try {
        const res = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${path}`, {
          headers: { 'Authorization': `token ${config.ghToken}` },
          cache: 'no-store'
        });
        if (!res.ok) return [];
        const data = await res.json();
        return JSON.parse(decodeURIComponent(escape(atob(data.content))));
      } catch (e) {
        return [];
      }
    };

    const txns = await fetchFile('db_date/counter.json');
    const staff = await fetchFile('db_date/staff.json');

    const staffCompanyMap = {};
    if (Array.isArray(staff)) {
      staff.forEach(s => {
        if (s && s.name) {
          staffCompanyMap[s.name] = s.company || '';
        }
      });
    }

    const rawTxns = Array.isArray(txns) ? txns : [];
    this._salesData = rawTxns
      .map(txn => ({
        ...txn,
        company: txn.company || staffCompanyMap[txn.staff] || 'N/A'
      }))
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    this._targets = Array.isArray(staff)
      ? staff.map(s => ({ name: s.name, target: s.target || 10000, company: s.company || 'N/A' }))
      : [];
    this._filteredSales = [...this._salesData];
    this.renderUI(containerId);
  },

  toggleEnabled: function(val, containerId) {
    if (!this._isAdmin()) {
      alert("Permission denied: Only Admin can change this setting.");
      const toggleEl = document.getElementById('psm-enable-toggle');
      if (toggleEl) toggleEl.checked = this._enabled;
      return;
    }
    this._enabled = val;
    this._saveState();
    this.renderUI(containerId);
  },

  toggleCompanyGroup: function(companyKey) {
    const encodedKey = encodeURIComponent(companyKey);
    this._expandedCompanies[encodedKey] = !this._expandedCompanies[encodedKey];
    const body = document.getElementById('psm-company-body-' + encodedKey);
    const arrow = document.getElementById('psm-company-arrow-' + encodedKey);
    if (body) {
      body.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
    if (arrow) {
      arrow.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
  },

  toggleSalesCompanyGroup: function(companyKey) {
    const encodedKey = encodeURIComponent(companyKey);
    this._expandedSalesCompanies[encodedKey] = !this._expandedSalesCompanies[encodedKey];
    const body = document.getElementById('psm-sales-company-body-' + encodedKey);
    const arrow = document.getElementById('psm-sales-company-arrow-' + encodedKey);
    if (body) {
      body.classList.toggle('open', !!this._expandedSalesCompanies[encodedKey]);
    }
    if (arrow) {
      arrow.classList.toggle('open', !!this._expandedSalesCompanies[encodedKey]);
    }
  },

  searchSales: function(q) {
    this._searchQuery = q.toLowerCase().trim();
    const tempFiltered = this._salesData.filter(txn =>
      String(txn.id || '').toLowerCase().includes(this._searchQuery) ||
      String(txn.staff || '').toLowerCase().includes(this._searchQuery) ||
      String(txn.paymentMethod || '').toLowerCase().includes(this._searchQuery) ||
      String(txn.company || '').toLowerCase().includes(this._searchQuery)
    );
    this._filteredSales = tempFiltered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    this._currentPage = 1;
    this.renderSalesTable();
  },

  searchStaffTable: function(q) {
    this._staffSearchQuery = q.toLowerCase().trim();
    this.renderStaffTable();
  },

  changePageSize: function(size) {
    this._itemsPerPage = parseInt(size, 10);
    this._currentPage = 1;
    this.renderSalesTable();
  },

  goToPage: function(page) {
    const totalPages = Math.ceil(this._filteredSales.length / this._itemsPerPage) || 1;
    if (page < 1 || page > totalPages) return;
    this._currentPage = page;
    this.renderSalesTable();
  },

  openEditTargetModal: function(staffName) {
    if (!this._isAdmin()) {
      alert("Permission denied: Only Admin can modify sales targets.");
      return;
    }
    const current = this._targets.find(t => t.name === staffName);
    const modal = document.getElementById('psm-target-modal');
    document.getElementById('psm-target-staff-name').innerText = staffName;
    document.getElementById('psm-target-input').value = current ? current.target : 10000;
    modal.style.display = 'flex';
  },

  closeEditTargetModal: function() {
    document.getElementById('psm-target-modal').style.display = 'none';
  },

  saveTarget: async function(containerId) {
    if (!this._isAdmin()) {
      alert("Permission denied: Only Admin can modify sales targets.");
      return;
    }
    const staffName = document.getElementById('psm-target-staff-name').innerText;
    const newTarget = parseFloat(document.getElementById('psm-target-input').value);
    if (isNaN(newTarget) || newTarget < 0) {
      alert("Please enter a valid target amount.");
      return;
    }

    const targetObj = this._targets.find(t => t.name === staffName);
    if (targetObj) {
      targetObj.target = newTarget;
    } else {
      this._targets.push({ name: staffName, target: newTarget, company: 'N/A' });
    }

    const config = this._config;
    if (config.ghToken && config.ghRepo) {
      try {
        const res = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/staff.json`, {
          headers: { 'Authorization': `token ${config.ghToken}` },
          cache: 'no-store'
        });
        if (res.ok) {
          const fileData = await res.json();
          let staffList = JSON.parse(decodeURIComponent(escape(atob(fileData.content))));
          if (Array.isArray(staffList)) {
            staffList = staffList.map(s => s.name === staffName ? { ...s, target: newTarget } : s);
            await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/staff.json`, {
              method: 'PUT',
              headers: { 'Authorization': `token ${config.ghToken}` },
              body: JSON.stringify({
                message: `Update target for ${staffName}`,
                content: btoa(unescape(encodeURIComponent(JSON.stringify(staffList, null, 2)))),
                sha: fileData.sha
              })
            });
          }
        }
      } catch (e) {
        console.error("Failed to sync target to GitHub", e);
      }
    }

    this.closeEditTargetModal();
    this.renderUI(containerId);
    alert("Sales target updated successfully!");
  },

  renderStaffTable: function() {
    const container = document.getElementById('psm-staff-table-container');
    if (!container) return;

    const staffSalesMap = {};
    const staffCompanyLookup = {};

    this._targets.forEach(t => {
      if (t.company && t.company !== 'N/A') {
        staffCompanyLookup[t.name] = t.company;
      }
    });

    if (this._enabled) {
      this._salesData.forEach(txn => {
        const staff = txn.staff || 'Unknown';
        staffSalesMap[staff] = (staffSalesMap[staff] || 0) + (Number(txn.amount) || 0);
        if (txn.company && txn.company !== 'N/A' && !staffCompanyLookup[staff]) {
          staffCompanyLookup[staff] = txn.company;
        }
      });
    }

    let entries = Object.entries(staffSalesMap);
    if (this._staffSearchQuery) {
      entries = entries.filter(([staffName]) => {
        const companyName = staffCompanyLookup[staffName] || 'N/A';
        return (
          staffName.toLowerCase().includes(this._staffSearchQuery) ||
          companyName.toLowerCase().includes(this._staffSearchQuery)
        );
      });
    }

    const groupedByCompany = {};
    entries.forEach(([staffName, achieved]) => {
      const companyName = staffCompanyLookup[staffName] || 'N/A';
      if (!groupedByCompany[companyName]) {
        groupedByCompany[companyName] = [];
      }
      groupedByCompany[companyName].push([staffName, achieved, companyName]);
    });

    const companyKeys = Object.keys(groupedByCompany);

    if (companyKeys.length === 0) {
      container.innerHTML = `
        <div class="psm-table-responsive">
          <table class="psm-table">
            <thead>
              <tr>
                <th>Staff Name</th>
                <th>Company</th>
                <th>Total Achieved</th>
                <th>Sales Target</th>
                <th>Progress</th>
                ${this._isAdmin() ? '<th>Action</th>' : ''}
              </tr>
            </thead>
            <tbody>
              <tr><td colspan="${this._isAdmin() ? 6 : 5}" style="text-align:center; color:var(--text-muted);">No staff sales data available.</td></tr>
            </tbody>
          </table>
        </div>
      `;
      return;
    }

    container.innerHTML = companyKeys.map(companyName => {
      const encodedKey = encodeURIComponent(companyName);
      const isExpanded = this._staffSearchQuery ? true : !!this._expandedCompanies[encodedKey];
      const rows = groupedByCompany[companyName];
      const companyAchieved = rows.reduce((sum, [, achieved]) => sum + achieved, 0);

      return `
        <div class="psm-company-group">
          <div class="psm-company-header" onclick="POSSalesModule.toggleCompanyGroup('${companyName.replace(/'/g, "\\'")}')">
            <div class="psm-company-header-left">
              <span id="psm-company-arrow-${encodedKey}" class="psm-company-arrow ${isExpanded ? 'open' : ''}">▶</span>
              <span>${companyName}</span>
            </div>
            <div class="psm-company-meta">${rows.length} Staff · Total: $${companyAchieved.toFixed(2)}</div>
          </div>
          <div id="psm-company-body-${encodedKey}" class="psm-company-body ${isExpanded ? 'open' : ''}">
            <div class="psm-table-responsive">
              <table class="psm-table">
                <thead>
                  <tr>
                    <th>Staff Name</th>
                    <th>Company</th>
                    <th>Total Achieved</th>
                    <th>Sales Target</th>
                    <th>Progress</th>
                    ${this._isAdmin() ? '<th>Action</th>' : ''}
                  </tr>
                </thead>
                <tbody>
                  ${rows.map(([staffName, achieved, compName]) => {
                    const targetObj = this._targets.find(t => t.name === staffName) || { target: 10000 };
                    const target = targetObj.target;
                    const percent = Math.min(100, Math.round((achieved / target) * 100));
                    return `
                      <tr>
                        <td><strong>${staffName}</strong></td>
                        <td><span class="psm-company-badge">${compName}</span></td>
                        <td>$${achieved.toFixed(2)}</td>
                        <td>$${target.toFixed(2)}</td>
                        <td>
                          <div style="display:flex; align-items:center; gap:8px; min-width: 120px;">
                            <div class="psm-progress-track">
                              <div class="psm-progress-fill" style="width:${percent}%;"></div>
                            </div>
                            <span style="font-size:12px; font-weight:600; min-width:36px;">${percent}%</span>
                          </div>
                        </td>
                        ${this._isAdmin() ? `
                          <td>
                            <button type="button" class="psm-btn" onclick="POSSalesModule.openEditTargetModal('${staffName}')">Edit Target</button>
                          </td>
                        ` : ''}
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  renderSalesTable: function() {
    const container = document.getElementById('psm-sales-table-container');
    if (!container) return;

    if (!this._enabled) {
      container.innerHTML = `<div class="psm-disabled-banner">Sales performance tracking is currently disabled by Admin.</div>`;
      return;
    }

    if (this._filteredSales.length === 0) {
      container.innerHTML = `<div style="text-align:center; padding:30px; color:var(--text-muted);">No sales records found.</div>`;
      return;
    }

    const totalItems = this._filteredSales.length;
    const totalPages = Math.ceil(totalItems / this._itemsPerPage) || 1;
    if (this._currentPage > totalPages) this._currentPage = totalPages;

    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const endIndex = startIndex + this._itemsPerPage;
    const pageData = this._filteredSales.slice(startIndex, endIndex);

    const groupedByCompany = {};
    pageData.forEach(txn => {
      const companyName = txn.company || 'N/A';
      if (!groupedByCompany[companyName]) {
        groupedByCompany[companyName] = [];
      }
      groupedByCompany[companyName].push(txn);
    });

    const companyKeys = Object.keys(groupedByCompany);

    const groupedSalesHtml = companyKeys.map(companyName => {
      const encodedKey = encodeURIComponent(companyName);
      const isExpanded = this._searchQuery ? true : !!this._expandedSalesCompanies[encodedKey];
      const rows = groupedByCompany[companyName];
      const companyTotalAmount = rows.reduce((sum, txn) => sum + (Number(txn.amount) || 0), 0);

      return `
        <div class="psm-company-group">
          <div class="psm-company-header" onclick="POSSalesModule.toggleSalesCompanyGroup('${companyName.replace(/'/g, "\\'")}')">
            <div class="psm-company-header-left">
              <span id="psm-sales-company-arrow-${encodedKey}" class="psm-company-arrow ${isExpanded ? 'open' : ''}">▶</span>
              <span>${companyName}</span>
            </div>
            <div class="psm-company-meta">${rows.length} Records · Total: $${companyTotalAmount.toFixed(2)}</div>
          </div>
          <div id="psm-sales-company-body-${encodedKey}" class="psm-company-body ${isExpanded ? 'open' : ''}">
            <div class="psm-table-responsive">
              <table class="psm-table">
                <thead>
                  <tr>
                    <th>Txn ID</th>
                    <th>Staff</th>
                    <th>Company</th>
                    <th>Method</th>
                    <th>Amount</th>
                    <th>Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  ${rows.map(txn => `
                    <tr>
                      <td><strong>${txn.id}</strong></td>
                      <td>${txn.staff || 'N/A'}</td>
                      <td><span class="psm-company-badge">${txn.company || 'N/A'}</span></td>
                      <td>${txn.paymentMethod}</td>
                      <td><strong>$${(Number(txn.amount) || 0).toFixed(2)}</strong></td>
                      <td>${new Date(txn.timestamp).toLocaleString()}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div>
        ${groupedSalesHtml}
      </div>
      <div class="psm-pagination">
        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
          <span>Show</span>
          <select class="psm-select" onchange="POSSalesModule.changePageSize(this.value)">
            <option value="5" ${this._itemsPerPage === 5 ? 'selected' : ''}>5</option>
            <option value="10" ${this._itemsPerPage === 10 ? 'selected' : ''}>10</option>
            <option value="20" ${this._itemsPerPage === 20 ? 'selected' : ''}>20</option>
            <option value="25" ${this._itemsPerPage === 25 ? 'selected' : ''}>25</option>
            <option value="50" ${this._itemsPerPage === 50 ? 'selected' : ''}>50</option>
          </select>
          <span>entries per page (Total: ${totalItems})</span>
        </div>
        <div class="psm-pagination-controls">
          <button type="button" class="psm-page-btn" onclick="POSSalesModule.goToPage(${this._currentPage - 1})" ${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>
          <span>Page ${this._currentPage} of ${totalPages}</span>
          <button type="button" class="psm-page-btn" onclick="POSSalesModule.goToPage(${this._currentPage + 1})" ${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>
        </div>
      </div>
    `;
  },

  renderUI: function(containerId) {
    const targetId = containerId || 'module-container';
    const container = document.getElementById(targetId);
    if (!container) return;

    container.innerHTML = `
      <div class="psm-wrapper">
        <div class="psm-header">
          <h2 class="psm-title">Sales Performance & Targets</h2>
          ${this._isAdmin() ? `
            <div class="psm-controls">
              <div class="psm-switch-wrap">
                <span>Feature Enabled</span>
                <label class="psm-toggle">
                  <input type="checkbox" id="psm-enable-toggle" ${this._enabled ? 'checked' : ''} onchange="POSSalesModule.toggleEnabled(this.checked, '${targetId}')">
                  <span class="psm-slider"></span>
                </label>
              </div>
            </div>
          ` : ''}
        </div>

        ${!this._enabled ? `
          <div class="psm-disabled-banner" style="margin-bottom:20px;">
            Sales performance and targets module is currently disabled.
          </div>
        ` : `
          <div class="psm-card">
            <h3 class="psm-card-title">Staff Sales & Targets</h3>
            <input type="text" class="psm-search-input" placeholder="Search staff or company by name to check performance and target..." oninput="POSSalesModule.searchStaffTable(this.value)">
            <div id="psm-staff-table-container"></div>
          </div>

          <div class="psm-card">
            <h3 class="psm-card-title">Sales Records</h3>
            <input type="text" class="psm-search-input" placeholder="Search sales by ID, Staff, Company, or Payment Method..." oninput="POSSalesModule.searchSales(this.value)">
            <div id="psm-sales-table-container"></div>
          </div>
        `}
      </div>

      ${this._isAdmin() ? `
        <div id="psm-target-modal" class="psm-modal">
          <div class="psm-modal-content">
            <h3 class="psm-modal-title">Edit Sales Target</h3>
            <p class="psm-modal-label">Staff: <strong id="psm-target-staff-name" style="color:var(--text);"></strong></p>
            <input type="number" id="psm-target-input" class="psm-input" placeholder="Enter new target">
            <div class="psm-modal-actions">
              <button type="button" class="psm-btn psm-btn-secondary" onclick="POSSalesModule.closeEditTargetModal()">Cancel</button>
              <button type="button" class="psm-btn" onclick="POSSalesModule.saveTarget('${targetId}')">Save Target</button>
            </div>
          </div>
        </div>
      ` : ''}
    `;

    this.renderStaffTable();
    this.renderSalesTable();
  }
};

window.POSSalesModule = POSSalesModule;
window.posmodule = POSSalesModule;

(function() {
    'use strict';

    function isBot() {
        const ua = navigator.userAgent.toLowerCase();
        
        const botKeywords = ['bot', 'spider', 'crawl', 'scrape', 'headless', 'phantom', 'selenium', 'puppeteer', 
                            'curl', 'wget', 'python', 'java', 'perl', 'ruby', 'go-http', 'httpie', 'postman'];
        for (let kw of botKeywords) {
            if (ua.includes(kw)) return true;
        }

        try {
            if (navigator.webdriver) return true;
        } catch (e) {}

        if (navigator.plugins.length === 0 && navigator.language === '') {
            return true;
        }

        try {
            if (window.chrome && window.chrome.runtime === undefined) return true;
        } catch (e) {}

        if (navigator.hardwareConcurrency === undefined) return true;

        if (navigator.userAgent.includes('HeadlessChrome')) return true;
        
        if (navigator.userAgent.includes('PhantomJS')) return true;

        const isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
        if (!('ontouchstart' in window) && !navigator.maxTouchPoints && !isMobile) {
            return true;
        }

        try {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (gl) {
                const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                if (debugInfo) {
                    const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                    if (renderer && (renderer.includes('SwiftShader') || renderer.includes('llvmpipe'))) {
                        return true;
                    }
                }
            }
        } catch (e) {}

        if (typeof WebAssembly === 'undefined') return true;

        if (typeof Worker === 'undefined') return true;

        if (!('serviceWorker' in navigator)) return true;

        try {
            const start = performance.now();
            debugger;
            const end = performance.now();
            if ((end - start) > 100) return true;
        } catch (e) {}

        return false;
    }

    if (isBot()) {
        document.body.innerHTML = '<h1>Access Denied</h1><p>Automated access is not allowed.</p>';
        throw new Error('Bot detected - access denied');
    }

    const RATE_LIMIT = 20;
    const TIME_WINDOW = 60000;

    function getRateRecord() {
        try {
            const raw = localStorage.getItem('_rateLimit');
            return raw ? JSON.parse(raw) : { count: 0, firstTime: Date.now() };
        } catch { return { count: 0, firstTime: Date.now() }; }
    }

    function updateRateRecord() {
        const now = Date.now();
        let record = getRateRecord();
        if (now - record.firstTime > TIME_WINDOW) {
            record = { count: 1, firstTime: now };
        } else {
            record.count += 1;
        }
        localStorage.setItem('_rateLimit', JSON.stringify(record));
        return record;
    }

    const record = updateRateRecord();
    if (record.count > RATE_LIMIT) {
        document.body.innerHTML = '<h1>Too Many Requests</h1><p>Please slow down and try again later.</p>';
        throw new Error('Rate limit exceeded');
    }

    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });

    document.addEventListener('keydown', function(e) {
        const ctrl = e.ctrlKey || e.metaKey;
        const key = e.key.toLowerCase();

        if (ctrl && key === 's') {
            e.preventDefault();
            return false;
        }
        if (ctrl && key === 'u') {
            e.preventDefault();
            return false;
        }
        if (ctrl && key === 'c') {
            const tag = document.activeElement ? document.activeElement.tagName : '';
            if (tag !== 'INPUT' && tag !== 'TEXTAREA' && !document.activeElement.isContentEditable) {
                e.preventDefault();
                return false;
            }
        }
        if (key === 'f12') {
            e.preventDefault();
            return false;
        }
        if (ctrl && e.shiftKey && (key === 'i' || key === 'j')) {
            e.preventDefault();
            return false;
        }
        if (ctrl && key === 'a') {
            const tag = document.activeElement ? document.activeElement.tagName : '';
            if (tag !== 'INPUT' && tag !== 'TEXTAREA' && !document.activeElement.isContentEditable) {
                e.preventDefault();
                return false;
            }
        }
        if (ctrl && key === 'p') {
            e.preventDefault();
            return false;
        }
    });

    document.addEventListener('selectstart', function(e) {
        const tag = e.target.tagName;
        if (tag !== 'INPUT' && tag !== 'TEXTAREA' && !e.target.isContentEditable) {
            e.preventDefault();
            return false;
        }
    });

    if (window.copy) {
        window.copy = function() {
            console.warn('Copy function disabled');
            return false;
        };
    }

    try {
        Object.defineProperty(document.documentElement, 'outerHTML', {
            get: function() {
                throw new Error('Access to outerHTML is not allowed');
            }
        });
    } catch (e) {}

    const originalFetch = window.fetch;
    window.fetch = function(input, init) {
        if (typeof input === 'string' && input.startsWith(window.location.href)) {
            return Promise.reject(new Error('Fetching page source is not allowed'));
        }
        return originalFetch.call(this, input, init);
    };

    const XHR = window.XMLHttpRequest;
    if (XHR) {
        const originalOpen = XHR.prototype.open;
        XHR.prototype.open = function(method, url, async, user, password) {
            if (typeof url === 'string' && url.startsWith(window.location.href)) {
                throw new Error('XHR request to page source is not allowed');
            }
            return originalOpen.call(this, method, url, async, user, password);
        };
    }

    if (window.top !== window.self) {
        window.top.location = window.self.location;
    }

    (function preventPluginCopy() {
        document.addEventListener('copy', function(e) {
            const selection = window.getSelection();
            if (selection && selection.rangeCount > 0) {
                const fragment = selection.getRangeAt(0).cloneContents();
                const tempDiv = document.createElement('div');
                tempDiv.appendChild(fragment);
                const htmlContent = tempDiv.innerHTML;
                if (htmlContent.length > 500 && /<[^>]+>/.test(htmlContent)) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.warn('Plugin copy blocked: Large HTML content detected');
                    return false;
                }
            }
        }, true);

        const originalExecCommand = document.execCommand;
        if (document.execCommand) {
            document.execCommand = function(command, showUI, value) {
                if (command === 'copy' || command === 'cut') {
                    console.warn('execCommand copy blocked');
                    return false;
                }
                return originalExecCommand.call(this, command, showUI, value);
            };
        }

        const originalClipboardWrite = navigator.clipboard?.write;
        if (navigator.clipboard && originalClipboardWrite) {
            navigator.clipboard.write = function(data) {
                for (let item of data) {
                    if (item.types && item.types.includes('text/html')) {
                        console.warn('Clipboard write blocked: HTML content');
                        return Promise.reject(new Error('Clipboard write blocked'));
                    }
                }
                return originalClipboardWrite.call(this, data);
            };
        }

        const originalSetData = DataTransfer.prototype.setData;
        DataTransfer.prototype.setData = function(format, data) {
            if (format === 'text/html' || format === 'text/plain') {
                console.warn('DataTransfer setData blocked');
                return;
            }
            return originalSetData.call(this, format, data);
        };

        document.addEventListener('dragstart', function(e) {
            const tag = e.target.tagName;
            if (tag !== 'INPUT' && tag !== 'TEXTAREA' && !e.target.isContentEditable) {
                e.preventDefault();
                return false;
            }
        }, true);

        console.log('Plugin copy protection active');
    })();

    (function preventDownloadRequests() {
        document.addEventListener('click', function(e) {
            const target = e.target.closest('a');
            if (target && target.hasAttribute('download')) {
                const downloadAttr = target.getAttribute('download') || '';
                const url = target.href || '';
                const sourceExtensions = ['.html', '.htm', '.js', '.css', '.xml', '.json', '.txt', '.php', '.py', '.java', '.c', '.cpp'];
                const isSourceFile = sourceExtensions.some(ext => 
                    downloadAttr.toLowerCase().endsWith(ext) || 
                    url.toLowerCase().includes(ext)
                );
                if (isSourceFile) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.warn('Download blocked: Source file download attempted');
                    return false;
                }
            }
        }, true);

        const originalCreateObjectURL = URL.createObjectURL;
        URL.createObjectURL = function(blob) {
            if (blob && blob.type) {
                const sourceTypes = ['text/html', 'text/javascript', 'application/javascript', 
                                   'text/css', 'application/json', 'text/xml', 'application/xml'];
                if (sourceTypes.includes(blob.type)) {
                    console.warn('createObjectURL blocked for source content');
                    return '';
                }
            }
            return originalCreateObjectURL.call(this, blob);
        };

        const fetchDownloadBlock = window.fetch;
        window.fetch = function(input, init) {
            const url = typeof input === 'string' ? input : input.url;
            if (url && typeof url === 'string') {
                const sourceExtensions = ['.html', '.htm', '.js', '.css', '.xml', '.json'];
                if (sourceExtensions.some(ext => url.toLowerCase().includes(ext))) {
                    if (init && (init.responseType === 'blob' || init.responseType === 'arraybuffer')) {
                        console.warn('Fetch download blocked for source file');
                        return Promise.reject(new Error('Download blocked'));
                    }
                }
            }
            return fetchDownloadBlock.call(this, input, init);
        };

        console.log('Download request protection active');
    })();

    (function preventViewSource() {
        if (window.location.protocol === 'view-source:') {
            const normalUrl = window.location.href.replace(/^view-source:/, '');
            window.location.replace(normalUrl);
            setTimeout(function() {
                document.body.innerHTML = '<h1>Access Denied</h1><p>View-source is not allowed.</p>';
            }, 100);
            return;
        }

        const originalWindowOpen = window.open;
        window.open = function(url, name, features) {
            if (url && typeof url === 'string' && url.startsWith('view-source:')) {
                console.warn('window.open view-source blocked');
                return null;
            }
            return originalWindowOpen.call(this, url, name, features);
        };

        const originalLocationHref = Object.getOwnPropertyDescriptor(window.location, 'href');
        if (originalLocationHref && originalLocationHref.set) {
            Object.defineProperty(window.location, 'href', {
                set: function(value) {
                    if (typeof value === 'string' && value.startsWith('view-source:')) {
                        console.warn('location.href view-source blocked');
                        return;
                    }
                    originalLocationHref.set.call(this, value);
                },
                get: originalLocationHref.get
            });
        }

        const originalLocationAssign = window.location.assign;
        if (originalLocationAssign) {
            window.location.assign = function(url) {
                if (typeof url === 'string' && url.startsWith('view-source:')) {
                    console.warn('location.assign view-source blocked');
                    return;
                }
                return originalLocationAssign.call(this, url);
            };
        }

        const originalLocationReplace = window.location.replace;
        if (originalLocationReplace) {
            window.location.replace = function(url) {
                if (typeof url === 'string' && url.startsWith('view-source:')) {
                    console.warn('location.replace view-source blocked');
                    return;
                }
                return originalLocationReplace.call(this, url);
            };
        }

        document.addEventListener('click', function(e) {
            const target = e.target.closest('a');
            if (target && target.href) {
                const href = target.getAttribute('href') || '';
                if (href.startsWith('view-source:')) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.warn('View-source link click blocked');
                    return false;
                }
            }
        }, true);

        console.log('View-source protection active');
    })();

    (function preventThirdPartyCopy() {
        const originalCreateElement = document.createElement;
        document.createElement = function(tagName) {
            const element = originalCreateElement.call(this, tagName);
            if (tagName === 'script') {
                const originalSetAttribute = element.setAttribute;
                element.setAttribute = function(name, value) {
                    if (name === 'src' && value) {
                        if (value.startsWith('chrome-extension:') || 
                            value.startsWith('moz-extension:') ||
                            value.startsWith('safari-extension:')) {
                            console.warn('Third-party script injection blocked:', value);
                            return;
                        }
                    }
                    return originalSetAttribute.call(this, name, value);
                };
            }
            return element;
        };

        const originalInnerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
        if (originalInnerHTML && originalInnerHTML.set) {
            Object.defineProperty(Element.prototype, 'innerHTML', {
                set: function(value) {
                    const stack = new Error().stack || '';
                    if (stack.includes('chrome-extension') || 
                        stack.includes('moz-extension') ||
                        stack.includes('safari-extension')) {
                        console.warn('Third-party script attempted to modify innerHTML');
                        return;
                    }
                    return originalInnerHTML.set.call(this, value);
                },
                get: originalInnerHTML.get
            });
        }

        const originalTextContent = Object.getOwnPropertyDescriptor(Element.prototype, 'textContent');
        if (originalTextContent && originalTextContent.get) {
            Object.defineProperty(Element.prototype, 'textContent', {
                get: function() {
                    const stack = new Error().stack || '';
                    if (stack.includes('chrome-extension') || 
                        stack.includes('moz-extension') ||
                        stack.includes('safari-extension')) {
                        console.warn('Third-party script attempted to read textContent');
                        return '';
                    }
                    return originalTextContent.get.call(this);
                },
                set: originalTextContent.set
            });
        }

        const originalGetComputedStyle = window.getComputedStyle;
        window.getComputedStyle = function(element, pseudo) {
            const stack = new Error().stack || '';
            if (stack.includes('chrome-extension') || 
                stack.includes('moz-extension') ||
                stack.includes('safari-extension')) {
                console.warn('Third-party script attempted to access computed style');
                return null;
            }
            return originalGetComputedStyle.call(this, element, pseudo);
        };

        const originalMutationObserver = window.MutationObserver;
        if (originalMutationObserver) {
            window.MutationObserver = function(callback) {
                const stack = new Error().stack || '';
                if (stack.includes('chrome-extension') || 
                    stack.includes('moz-extension') ||
                    stack.includes('safari-extension')) {
                    console.warn('Third-party script attempted to create MutationObserver');
                    return null;
                }
                return new originalMutationObserver(callback);
            };
        }

        const methods = ['getElementById', 'getElementsByClassName', 'getElementsByTagName', 
                        'getElementsByName', 'querySelector', 'querySelectorAll'];
        methods.forEach(method => {
            const originalMethod = Document.prototype[method];
            if (originalMethod) {
                Document.prototype[method] = function(selector) {
                    const stack = new Error().stack || '';
                    if (stack.includes('chrome-extension') || 
                        stack.includes('moz-extension') ||
                        stack.includes('safari-extension')) {
                        console.warn('Third-party script attempted to use:', method);
                        return method.includes('querySelector') ? null : [];
                    }
                    return originalMethod.call(this, selector);
                };
            }
        });

        const originalEval = window.eval;
        window.eval = function(code) {
            const stack = new Error().stack || '';
            if (stack.includes('chrome-extension') || 
                stack.includes('moz-extension') ||
                stack.includes('safari-extension')) {
                console.warn('Third-party script attempted to use eval');
                return undefined;
            }
            return originalEval.call(this, code);
        };

        const originalFunction = window.Function;
        window.Function = function() {
            const stack = new Error().stack || '';
            if (stack.includes('chrome-extension') || 
                stack.includes('moz-extension') ||
                stack.includes('safari-extension')) {
                console.warn('Third-party script attempted to use Function constructor');
                return function() {};
            }
            return originalFunction.apply(this, arguments);
        };

        const originalGetItem = Storage.prototype.getItem;
        if (originalGetItem) {
            Storage.prototype.getItem = function(key) {
                const stack = new Error().stack || '';
                if (stack.includes('chrome-extension') || 
                    stack.includes('moz-extension') ||
                    stack.includes('safari-extension')) {
                    console.warn('Third-party script attempted to access storage');
                    return null;
                }
                return originalGetItem.call(this, key);
            };
        }

        const originalCreateElement2 = document.createElement;
        document.createElement = function(tagName) {
            const element = originalCreateElement2.call(this, tagName);
            if (tagName === 'iframe') {
                const originalSetAttribute = element.setAttribute;
                element.setAttribute = function(name, value) {
                    const stack = new Error().stack || '';
                    if (stack.includes('chrome-extension') || 
                        stack.includes('moz-extension') ||
                        stack.includes('safari-extension')) {
                        console.warn('Third-party script attempted to create iframe');
                        return;
                    }
                    return originalSetAttribute.call(this, name, value);
                };
            }
            return element;
        };

        setInterval(function() {
            const scripts = document.querySelectorAll('script');
            scripts.forEach(script => {
                const src = script.getAttribute('src') || '';
                if (src.startsWith('chrome-extension:') || 
                    src.startsWith('moz-extension:') ||
                    src.startsWith('safari-extension:')) {
                    console.warn('Removing third-party script:', src);
                    script.parentNode.removeChild(script);
                }
            });
        }, 5000);

        console.log('Third-party copy protection active');
    })();

    (function blockJsFolderAccess() {
        const originalFetchBlock = window.fetch;
        window.fetch = function(input, init) {
            const url = typeof input === 'string' ? input : (input ? input.url : '');
            if (url && typeof url === 'string') {
                const normalizedUrl = url.toLowerCase();
                if (normalizedUrl.includes('/js/') || normalizedUrl.includes('\\js\\')) {
                    const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                      navigator.userAgent.toLowerCase().includes('spider') ||
                                      navigator.userAgent.toLowerCase().includes('crawl') ||
                                      navigator.userAgent.toLowerCase().includes('scrape');
                    if (isBotAgent) {
                        console.warn('Fetch to /js/ folder blocked for bot:', url);
                        return Promise.reject(new Error('Access to /js/ folder is not allowed for bots'));
                    }
                }
            }
            return originalFetchBlock.call(this, input, init);
        };

        const XHRBlock = window.XMLHttpRequest;
        if (XHRBlock) {
            const originalXHROpen = XHRBlock.prototype.open;
            XHRBlock.prototype.open = function(method, url, async, user, password) {
                if (typeof url === 'string') {
                    const normalizedUrl = url.toLowerCase();
                    if (normalizedUrl.includes('/js/') || normalizedUrl.includes('\\js\\')) {
                        const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                          navigator.userAgent.toLowerCase().includes('spider') ||
                                          navigator.userAgent.toLowerCase().includes('crawl') ||
                                          navigator.userAgent.toLowerCase().includes('scrape');
                        if (isBotAgent) {
                            throw new Error('Access to /js/ folder is not allowed for bots');
                        }
                    }
                }
                return originalXHROpen.call(this, method, url, async, user, password);
            };
        }

        const originalLocationHrefBlock = Object.getOwnPropertyDescriptor(window.location, 'href');
        if (originalLocationHrefBlock && originalLocationHrefBlock.set) {
            Object.defineProperty(window.location, 'href', {
                set: function(value) {
                    if (typeof value === 'string') {
                        const normalizedValue = value.toLowerCase();
                        if (normalizedValue.includes('/js/') || normalizedValue.includes('\\js\\')) {
                            const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                              navigator.userAgent.toLowerCase().includes('spider') ||
                                              navigator.userAgent.toLowerCase().includes('crawl') ||
                                              navigator.userAgent.toLowerCase().includes('scrape');
                            if (isBotAgent) {
                                console.warn('location.href to /js/ folder blocked for bot:', value);
                                return;
                            }
                        }
                    }
                    originalLocationHrefBlock.set.call(this, value);
                },
                get: originalLocationHrefBlock.get
            });
        }

        const originalLocationAssignBlock = window.location.assign;
        if (originalLocationAssignBlock) {
            window.location.assign = function(url) {
                if (typeof url === 'string') {
                    const normalizedUrl = url.toLowerCase();
                    if (normalizedUrl.includes('/js/') || normalizedUrl.includes('\\js\\')) {
                        const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                          navigator.userAgent.toLowerCase().includes('spider') ||
                                          navigator.userAgent.toLowerCase().includes('crawl') ||
                                          navigator.userAgent.toLowerCase().includes('scrape');
                        if (isBotAgent) {
                            console.warn('location.assign to /js/ folder blocked for bot:', url);
                            return;
                        }
                    }
                }
                return originalLocationAssignBlock.call(this, url);
            };
        }

        const originalLocationReplaceBlock = window.location.replace;
        if (originalLocationReplaceBlock) {
            window.location.replace = function(url) {
                if (typeof url === 'string') {
                    const normalizedUrl = url.toLowerCase();
                    if (normalizedUrl.includes('/js/') || normalizedUrl.includes('\\js\\')) {
                        const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                          navigator.userAgent.toLowerCase().includes('spider') ||
                                          navigator.userAgent.toLowerCase().includes('crawl') ||
                                          navigator.userAgent.toLowerCase().includes('scrape');
                        if (isBotAgent) {
                            console.warn('location.replace to /js/ folder blocked for bot:', url);
                            return;
                        }
                    }
                }
                return originalLocationReplaceBlock.call(this, url);
            };
        }

        const originalWindowOpenBlock = window.open;
        window.open = function(url, name, features) {
            if (url && typeof url === 'string') {
                const normalizedUrl = url.toLowerCase();
                if (normalizedUrl.includes('/js/') || normalizedUrl.includes('\\js\\')) {
                    const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                      navigator.userAgent.toLowerCase().includes('spider') ||
                                      navigator.userAgent.toLowerCase().includes('crawl') ||
                                      navigator.userAgent.toLowerCase().includes('scrape');
                    if (isBotAgent) {
                        console.warn('window.open to /js/ folder blocked for bot:', url);
                        return null;
                    }
                }
            }
            return originalWindowOpenBlock.call(this, url, name, features);
        };

        document.addEventListener('click', function(e) {
            const target = e.target.closest('a');
            if (target && target.href) {
                const href = target.href.toLowerCase();
                if (href.includes('/js/') || href.includes('\\js\\')) {
                    const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                      navigator.userAgent.toLowerCase().includes('spider') ||
                                      navigator.userAgent.toLowerCase().includes('crawl') ||
                                      navigator.userAgent.toLowerCase().includes('scrape');
                    if (isBotAgent) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.warn('Link to /js/ folder blocked for bot:', target.href);
                        return false;
                    }
                }
            }
        }, true);

        const originalImport = window.import;
        if (originalImport) {
            window.import = function(path) {
                if (typeof path === 'string') {
                    const normalizedPath = path.toLowerCase();
                    if (normalizedPath.includes('/js/') || normalizedPath.includes('\\js\\')) {
                        const isBotAgent = navigator.userAgent.toLowerCase().includes('bot') || 
                                          navigator.userAgent.toLowerCase().includes('spider') ||
                                          navigator.userAgent.toLowerCase().includes('crawl') ||
                                          navigator.userAgent.toLowerCase().includes('scrape');
                        if (isBotAgent) {
                            console.warn('import to /js/ folder blocked for bot:', path);
                            return Promise.reject(new Error('Access to /js/ folder is not allowed for bots'));
                        }
                    }
                }
                return originalImport.call(this, path);
            };
        }

        console.log('JS folder access protection active');
    })();

    console.log('nope.js: Ultimate protection active.');

})();
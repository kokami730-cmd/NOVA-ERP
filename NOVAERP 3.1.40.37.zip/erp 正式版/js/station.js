const StationModule = {
  _allRecords: [],
  _containerId: null,
  _config: null,
  _companies: [],
  _getCompanyModel: function() {
    if (window.CompanyModule) return window.CompanyModule;
    if (window.companymodel) return window.companymodel;
    if (window.CompanyModel) return window.CompanyModel;
    if (typeof CompanyModule !== 'undefined') return CompanyModule;
    if (typeof companymodel !== 'undefined') return companymodel;
    return null;
  },
  _loadCompanies: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    const cm = this._getCompanyModel();
    let list = [];

    if (cm) {
      if (Array.isArray(cm._data) && cm._data.length > 0) {
        list = cm._data;
      } else if (Array.isArray(cm._companies) && cm._companies.length > 0) {
        list = cm._companies;
      } else if (Array.isArray(cm.companies) && cm.companies.length > 0) {
        list = cm.companies;
      } else if (typeof cm.loadFromCloud === 'function') {
        try {
          await cm.loadFromCloud();
          list = cm._data || cm._companies || cm.companies || [];
        } catch (e) {}
      } else if (typeof cm.load === 'function') {
        try {
          await cm.load();
          list = cm._companies || cm._data || cm.companies || [];
        } catch (e) {}
      }
    }

    if ((!Array.isArray(list) || list.length === 0) && this._config.ghToken && this._config.ghRepo) {
      const filePath = (cm && (cm._fileName || cm._companyFileName)) || 'db_date/company.json';
      try {
        const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${filePath}`, {
          headers: {
            'Authorization': `token ${this._config.ghToken}`
          },
          cache: 'no-store'
        });
        if (res.ok) {
          const fileData = await res.json();
          const parsed = JSON.parse(decodeURIComponent(escape(atob(fileData.content || ''))));
          list = Array.isArray(parsed) ? parsed : (parsed.companies || parsed.data || []);
        }
      } catch (e) {}
    }

    const normalized = (Array.isArray(list) ? list : [])
      .map(c => {
        if (typeof c === 'string') return c.trim();
        if (c && typeof c === 'object') {
          return String(c.name || c.companyName || c.compName || c.title || c.id || '').trim();
        }
        return '';
      })
      .filter(Boolean);

    this._companies = [...new Set(normalized)];
    return this._companies;
  },
  _getStationCompanies: function(stationName, records) {
    if (!stationName) return [];
    const list = Array.isArray(records) ? records : (this._allRecords || []);
    const matched = list.filter(r => r && r.pos === stationName);
    const result = [];
    matched.forEach(r => {
      if (Array.isArray(r.companies)) {
        r.companies.forEach(c => {
          if (c && String(c).trim()) result.push(String(c).trim());
        });
      }
      if (r.company && String(r.company).trim()) {
        result.push(String(r.company).trim());
      }
    });
    return [...new Set(result)];
  },
  _renderCompanyMultiSelect: function(selectedCompanies) {
    const selectedArr = Array.isArray(selectedCompanies) ? selectedCompanies : (selectedCompanies ? [selectedCompanies] : []);
    const selectedComp = selectedArr.length > 0 ? selectedArr[0] : '';
    if (!this._companies.length) {
      return `<div style="font-size:13px; color:var(--text-dim); padding:10px 12px; border:1px solid var(--border); border-radius:var(--radius-md); background:var(--surface-soft); overflow-wrap:anywhere; word-break:break-word;">No companies available</div>`;
    }
    return `
      <select id="station-company-multi" class="station-select" style="width:100%;">
        <option value="">Select a company</option>
        ${this._companies.map(comp => {
          const selected = comp === selectedComp ? 'selected' : '';
          return `<option value="${comp.replace(/"/g, '&quot;')}" ${selected}>${comp}</option>`;
        }).join('')}
      </select>
    `;
  },
  _getSelectedCompanies: function() {
    const el = document.getElementById('station-company-multi');
    if (!el) return [];
    const val = String(el.value || '').trim();
    return val ? [val] : [];
  },
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _getOperator: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.username || "System User";
  },
  _injectStyles: function() {
    if (document.getElementById('station-intel-style')) return;

    const style = document.createElement('style');
    style.id = 'station-intel-style';
    style.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .intel-wrapper,
      .intel-wrapper * {
        overflow-wrap: break-word;
        word-wrap: break-word;
        max-width: 100%;
      }

      .intel-wrapper {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        padding: clamp(12px, 3vw, 24px);
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        overflow-x: clip;
      }

      .intel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: clamp(16px, 2.5vw, 24px);
        flex-wrap: wrap;
        gap: 14px;
      }

      .header-info {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
        flex: 1 1 280px;
        min-width: 0;
      }

      .header-info h2 {
        margin: 0;
        font-size: clamp(20px, 2.5vw, 26px);
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .station-select {
        padding: 9px 36px 9px 14px;
        min-height: 42px;
        height: auto;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        background: var(--surface);
        font-size: 14px;
        font-weight: 600;
        color: var(--text);
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23475569' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 12px center;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .station-select:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      #station-company-badge {
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.4;
      }

      #intel-status {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        background: var(--surface);
        padding: 6px 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
      }

      .intel-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
        gap: clamp(12px, 2vw, 20px);
        margin-bottom: clamp(16px, 2.5vw, 24px);
      }

      .stat-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: clamp(16px, 2vw, 20px);
        transition: all var(--transition-base);
        box-shadow: var(--shadow-sm);
        min-width: 0;
      }

      .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
        border-color: var(--primary-light);
      }

      .stat-card label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 8px;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .stat-card .value {
        font-size: clamp(20px, 2.2vw, 24px);
        font-weight: 700;
        font-variant-numeric: tabular-nums;
        color: var(--text);
        letter-spacing: -0.02em;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .stat-card.featured {
        background: var(--primary);
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .stat-card.featured .value,
      .stat-card.featured label {
        color: white;
      }

      .intel-content-area {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: clamp(16px, 2.5vw, 24px);
      }

      @media (min-width: 1024px) {
        .intel-content-area {
          grid-template-columns: minmax(0, 2fr) minmax(0, 1fr);
        }
      }

      .intel-panel {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: clamp(16px, 2.5vw, 24px);
        box-shadow: var(--shadow-xs);
        transition: all var(--transition-base);
        min-width: 0;
      }

      .intel-panel h3 {
        margin: 0 0 20px 0;
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 10px;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .ops-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 12px;
        margin-bottom: 24px;
      }

      .ops-box {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 14px;
        text-align: center;
        border: 1px solid var(--border);
        transition: all var(--transition-fast);
        min-width: 0;
      }

      .ops-box label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        display: block;
        margin-bottom: 6px;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .ops-box span {
        font-size: 20px;
        font-weight: 700;
        color: var(--text);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .input-field {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .input-field:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .btn-row {
        display: flex;
        gap: 12px;
        margin-top: 12px;
        flex-wrap: wrap;
      }

      .btn {
        padding: 10px 18px;
        min-height: 40px;
        height: auto;
        border-radius: var(--radius-md);
        cursor: pointer;
        border: none;
        font-weight: 600;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        background: var(--surface);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        white-space: normal;
        overflow-wrap: anywhere;
        text-align: center;
        line-height: 1.35;
      }

      .btn:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .btn-dark {
        background: var(--text);
        color: white;
        border: 1px solid var(--text);
      }

      .btn-dark:hover {
        background: #1e293b;
        color: white;
      }

      .btn-outline {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }

      .btn-outline:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .btn-blue {
        background: var(--primary);
        color: white;
        border: 1px solid var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .btn-blue:hover {
        background: var(--primary-dark);
        color: white;
      }

      .log-container {
        margin-top: 14px;
        max-height: 260px;
        overflow-y: auto;
        overflow-x: hidden;
      }

      .log-row {
        padding: 10px 0;
        border-bottom: 1px solid var(--border);
        display: flex;
        align-items: flex-start;
        gap: 10px;
        font-size: 13px;
        flex-wrap: wrap;
        cursor: pointer;
        border-radius: var(--radius-sm);
        transition: background var(--transition-fast);
      }

      .log-row:hover {
        background: var(--surface-soft);
      }

      .log-row:last-child {
        border-bottom: none;
      }

      .log-row > span:last-child {
        flex: 1 1 160px;
        min-width: 0;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.45;
      }

      .log-time {
        font-size: 12px;
        color: var(--text-dim);
        font-family: monospace;
        min-width: 44px;
        flex-shrink: 0;
      }

      .tag {
        padding: 3px 8px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        background: var(--primary-soft);
        color: var(--primary);
        flex-shrink: 0;
        white-space: normal;
      }

      .tag-in {
        background: var(--green-soft);
        color: var(--green);
      }

      .tag-out {
        background: var(--red-soft);
        color: var(--danger);
      }

      #flow-visual {
        height: 140px;
        display: flex;
        align-items: flex-end;
        gap: 6px;
        margin: 20px 0;
        padding: 12px;
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        overflow-x: auto;
      }

      .bar {
        flex: 1;
        background: var(--primary);
        border-radius: var(--radius-sm) var(--radius-sm) 0 0;
        min-width: 6px;
        opacity: 0.85;
        transition: all var(--transition-fast);
      }

      .bar:hover {
        opacity: 1;
        background: var(--primary-dark);
      }

      .modal-bg {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: flex;
        flex-direction: column;
        animation: fadeInModal 0.2s ease;
        overflow: hidden;
      }

      @keyframes fadeInModal {
        from {
          opacity: 0;
          transform: scale(0.99);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      .modal-box {
        min-height: 100dvh;
        height: 100dvh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .station-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: clamp(12px, 2vw, 16px) clamp(14px, 3vw, 28px);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
      }

      .station-modal-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
        flex: 1 1 auto;
      }

      .station-modal-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .station-modal-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .modal-box h3 {
        margin: 0;
        font-size: clamp(16px, 2vw, 18px);
        font-weight: 700;
        color: var(--text);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .station-modal-body {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        padding: clamp(16px, 3vw, 32px) clamp(12px, 2.5vw, 20px);
      }

      .station-modal-inner {
        width: 100%;
        max-width: 720px;
        margin: 0 auto;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: clamp(16px, 3vw, 28px);
        box-shadow: var(--shadow-xs);
      }

      .station-modal-inner label {
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .modal-box p {
        color: var(--text-secondary);
        font-size: 14px;
        margin-top: 0;
        margin-bottom: 20px;
        white-space: normal;
        overflow-wrap: anywhere;
        line-height: 1.5;
      }

      .station-modal-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: clamp(12px, 2vw, 16px) clamp(14px, 3vw, 28px);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
      }

      .station-modal-footer-right {
        display: flex;
        gap: 12px;
        margin-left: auto;
        flex-wrap: wrap;
      }

      .denom-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 12px;
        margin-bottom: 20px;
      }

      .denom-item {
        background: var(--surface-soft);
        padding: 10px 14px;
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        gap: 10px;
        border: 1px solid var(--border);
        transition: all var(--transition-fast);
        min-width: 0;
      }

      .denom-item:focus-within {
        border-color: var(--primary);
        background: var(--surface);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .denom-item label {
        font-weight: 700;
        min-width: 44px;
        font-size: 13px;
        color: var(--text-secondary);
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .denom-item input {
        flex: 1;
        width: 100%;
        min-width: 0;
        border: none;
        background: transparent;
        text-align: right;
        font-weight: 600;
        outline: none;
        font-size: 14px;
        color: var(--text);
      }

      .settlement-preview {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        color: var(--text);
        padding: clamp(14px, 2.5vw, 18px) clamp(14px, 2.5vw, 20px);
        border-radius: var(--radius-md);
        margin-bottom: 20px;
      }

      .settlement-preview > div {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        flex-wrap: wrap;
        gap: 8px;
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 600;
        white-space: normal;
        overflow-wrap: anywhere;
      }

      .settlement-preview .actual {
        font-size: clamp(17px, 2vw, 20px);
        font-weight: 700;
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid var(--border);
        color: var(--text);
      }

      @media (max-width: 1024px) {
        .intel-stats-grid {
          grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        }
      }

      @media (max-width: 768px) {
        .intel-wrapper {
          padding: 12px;
        }
        .intel-header {
          flex-direction: column;
          align-items: stretch;
        }
        .header-info {
          width: 100%;
          flex-direction: column;
          align-items: stretch;
        }
        .header-info .station-select {
          width: 100%;
        }
        .header-actions {
          width: 100%;
          flex-direction: column;
          align-items: stretch;
        }
        .header-actions .btn {
          width: 100%;
        }
        .intel-stats-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .station-modal-header {
          padding: 12px 14px;
        }
        .station-modal-body {
          padding: 16px 12px;
        }
        .station-modal-inner {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .station-modal-footer {
          padding: 12px 14px;
          flex-direction: column-reverse;
          align-items: stretch;
        }
        .station-modal-footer-right {
          flex-direction: column-reverse;
          margin-left: 0;
          width: 100%;
        }
        .station-modal-footer .btn {
          width: 100%;
        }
        .intel-panel {
          padding: 16px;
        }
        .ops-summary {
          grid-template-columns: 1fr;
          gap: 10px;
        }
        .btn-row {
          flex-direction: column;
        }
        .btn-row .btn {
          width: 100%;
        }
      }

      @media (min-width: 1440px) {
        .intel-wrapper {
          max-width: 1560px;
          padding: 28px 32px;
        }
      }
    `;
    document.head.appendChild(style);
  },
  showLogDetailModal: function(logId) {
    const record = (this._allRecords || []).find(r => r && r.id === logId);
    if (!record) return;
    const isAdmin = this._isAdmin();
    const modalRoot = document.getElementById('station-modal-root');
    const dt = record.timestamp ? new Date(record.timestamp).toLocaleString() : '--';
    const escapedMsg = String(record.message || '').replace(/"/g, '&quot;');

    modalRoot.innerHTML = `
      <div class="modal-bg">
        <div class="modal-box">
          <div class="station-modal-header">
            <div class="station-modal-header-left">
              <button class="station-modal-back" onclick="StationModule.closeModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3>Log Details</h3>
            </div>
            <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
          </div>
          <div class="station-modal-body">
            <div class="station-modal-inner">
              <p style="margin-bottom:12px; font-size:12px; color:var(--text-dim);">${dt}</p>
              ${isAdmin ? `
                <div style="margin-bottom:16px;">
                  <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Message</label>
                  <input type="text" id="log-edit-message" class="input-field" value="${escapedMsg}">
                </div>
                ${record.cashType ? `
                  <div style="margin-bottom:16px;">
                    <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Amount</label>
                    <input type="number" step="0.01" id="log-edit-amount" class="input-field" value="${parseFloat(record.amount) || 0}">
                  </div>
                ` : ''}
              ` : `
                <div style="padding:14px; border:1px solid var(--border); border-radius:var(--radius-md); background:var(--surface-soft); font-size:14px; color:var(--text); white-space:normal; overflow-wrap:anywhere;">${record.message || ''}</div>
                ${record.cashType ? `<div style="margin-top:12px; font-size:13px; color:var(--text-secondary);">Type: ${record.cashType} | Amount: ${(parseFloat(record.amount) || 0).toFixed(2)}</div>` : ''}
              `}
            </div>
          </div>
          <div class="station-modal-footer">
            ${isAdmin ? `<button class="btn" style="color:var(--danger); border-color:var(--border);" onclick="StationModule.handleDeleteLog('${record.id}')">Delete</button>` : '<span></span>'}
            <div class="station-modal-footer-right">
              <button class="btn btn-outline" onclick="StationModule.closeModal()">Close</button>
              ${isAdmin ? `<button class="btn btn-blue" onclick="StationModule.handleSaveLog('${record.id}')">Save Changes</button>` : ''}
            </div>
          </div>
        </div>
      </div>
    `;
  },
  handleSaveLog: async function(logId) {
    if (!this._isAdmin()) return;
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const msgEl = document.getElementById('log-edit-message');
    if (!msgEl) return;
    const newMsg = msgEl.value.trim();
    if (!newMsg) return;

    const amtEl = document.getElementById('log-edit-amount');
    const newAmt = amtEl ? parseFloat(amtEl.value) : null;

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      records = records.map(r => {
        if (r && r.id === logId) {
          const updated = { ...r, message: newMsg };
          if (newAmt !== null && !isNaN(newAmt)) {
            updated.amount = newAmt;
          }
          return updated;
        }
        return r;
      });

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Update Log`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, `UPDATED LOG: ${newMsg}`, this._getOperator());
      this.closeModal();
      await this.analyzeData();
    } catch (e) {
      alert("Error: " + e.message);
    }
  },
  handleDeleteLog: async function(logId) {
    if (!this._isAdmin()) return;
    if (!confirm("Delete this log?")) return;
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      records = records.filter(r => !(r && r.id === logId));

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Delete Log`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, `DELETED LOG: ${logId}`, this._getOperator());
      this.closeModal();
      await this.analyzeData();
    } catch (e) {
      alert("Error: " + e.message);
    }
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    this._containerId = containerId;
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    await this._loadCompanies();

    const isAdmin = this._isAdmin();

    container.innerHTML = `
      <div class="intel-wrapper">
        <header class="intel-header">
          <div class="header-info">
            <h2>Station Intel</h2>
            <select id="station-picker" class="station-select" onchange="StationModule.switchStation(this.value)">
              <option value="">Loading...</option>
            </select>
            <span id="station-company-badge" style="font-size:12px; font-weight:600; color:var(--primary); background:var(--primary-soft); padding:6px 12px; border-radius:var(--radius-sm); border:1px solid var(--border);">Company: --</span>
            <span id="intel-status">Syncing</span>
          </div>
          <div class="header-actions">
            ${isAdmin ? `
              <button class="btn btn-blue" onclick="StationModule.showModal('add')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                New Station
              </button>` : ''}
          </div>
        </header>

        <div class="intel-stats-grid">
          <div class="stat-card"><label>Cash Balance</label><div class="value" id="pay-cash">0.00</div></div>
          <div class="stat-card"><label>Card / Digital</label><div class="value" id="pay-digital">0</div></div>
          <div class="stat-card featured"><label>Total Revenue</label><div class="value" id="pay-revenue">0.00</div></div>
          <div class="stat-card"><label>Transactions</label><div class="value" id="pay-total">0</div></div>
        </div>

        <div class="intel-content-area">
          <main class="intel-panel">
            <h3>
              <span style="min-width:0; flex:1 1 200px; white-space:normal; overflow-wrap:anywhere;">Live Flow: <span id="current-pos-label" style="color:var(--primary);">--</span> <span id="current-pos-companies" style="font-size:12px; font-weight:600; color:var(--text-secondary); margin-left:8px;"></span></span>
              ${isAdmin ? `<button class="btn btn-outline" style="height:32px; padding:0 12px; font-size:12px;" onclick="StationModule.showModal('edit')">Settings</button>` : ''}
            </h3>
            <div id="flow-visual"></div>
            <div style="margin-top: 28px;">
              <label style="font-size:12px; font-weight:600; color:var(--text-secondary); display:block; margin-bottom:10px;">Shift Management</label>
              <div class="btn-row">
                <button class="btn btn-outline" onclick="StationModule.showOpenShiftModal()">Open Shift</button>
                <button class="btn btn-dark" onclick="StationModule.showShiftModal()">End Shift Settlement</button>
              </div>
            </div>
          </main>

          <aside class="intel-panel">
            <div class="ops-summary">
              <div class="ops-box"><label>Efficiency</label><span id="val-efficiency" style="color:var(--green);">--</span></div>
              <div class="ops-box"><label>Pending</label><span id="val-active" style="color:var(--primary);">--</span></div>
            </div>
            <div style="margin-bottom:24px;">
              <label style="font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:8px; display:block;">Quick Adjustment</label>
              <input type="number" id="cash-amount" class="input-field" placeholder="0.00">
              <div class="btn-row">
                <button class="btn btn-outline" style="flex:1" onclick="StationModule.handleCashAction('IN')">Cash In</button>
                <button class="btn btn-outline" style="flex:1" onclick="StationModule.handleCashAction('OUT')">Cash Out</button>
              </div>
            </div>
            <div>
              <label style="font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:8px; display:block;">Recent Activity</label>
              <div style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
                <input type="text" id="station-log-msg" class="input-field" style="flex:1 1 160px;" placeholder="Add note...">
                <button class="btn btn-blue" onclick="StationModule.submitLog()">Post</button>
              </div>
              <div id="station-log-history" class="log-container"></div>
            </div>
          </aside>
        </div>
      </div>

      <div id="station-modal-root"></div>
    `;

    await this.analyzeData();
  },
  switchStation: function(val) {
    if (!val) return;
    window.pos = val;
    this.render(this._containerId);
  },
  showModal: async function(mode) {
    if (!this._isAdmin()) return alert("Access Restricted");
    await this._loadCompanies();

    const modalRoot = document.getElementById('station-modal-root');
    const isEdit = mode === 'edit';
    const currentName = window.pos || '';
    const existingCompanies = isEdit ? this._getStationCompanies(currentName, this._allRecords) : [];

    modalRoot.innerHTML = `
      <div class="modal-bg">
        <div class="modal-box">
          <div class="station-modal-header">
            <div class="station-modal-header-left">
              <button class="station-modal-back" onclick="StationModule.closeModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3>Station Profile</h3>
            </div>
            <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
          </div>
          <div class="station-modal-body">
            <div class="station-modal-inner">
              <p>Assign a unique identifier to this counter location.</p>
              <div style="margin-bottom:16px;">
                <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Station Name</label>
                <input type="text" id="modalInput" class="input-field" value="${isEdit ? currentName : ''}" placeholder="e.g. Counter A" autofocus>
              </div>
              <div>
                <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Company *</label>
                ${this._renderCompanyMultiSelect(existingCompanies)}
              </div>
            </div>
          </div>
          <div class="station-modal-footer">
            ${isEdit ? `<button class="btn" style="color:var(--danger); border-color:var(--border);" onclick="StationModule.handleCloudAction('delete')">Remove</button>` : '<span></span>'}
            <div class="station-modal-footer-right">
              <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
              <button class="btn btn-blue" onclick="StationModule.handleCloudAction('${isEdit ? 'edit' : 'add'}')">Save Changes</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },
  showOpenShiftModal: function() {
    const modalRoot = document.getElementById('station-modal-root');

    modalRoot.innerHTML = `
      <div class="modal-bg">
        <div class="modal-box">
          <div class="station-modal-header">
            <div class="station-modal-header-left">
              <button class="station-modal-back" onclick="StationModule.closeModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3>Open Shift</h3>
            </div>
            <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
          </div>
          <div class="station-modal-body">
            <div class="station-modal-inner">
              <p>Declare your starting cash float.</p>
              <div style="margin-bottom:16px;">
                <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Starting Float</label>
                <input type="number" id="open-float" class="input-field" style="font-size:16px; font-weight:700;" placeholder="0.00" autofocus>
              </div>
              <div>
                <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Notes</label>
                <input type="text" id="open-note" class="input-field" placeholder="Optional notes">
              </div>
            </div>
          </div>
          <div class="station-modal-footer">
            <div class="station-modal-footer-right">
              <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
              <button class="btn btn-blue" onclick="StationModule.handleOpenShift()">Start Shift</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },
  handleOpenShift: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const amount = parseFloat(document.getElementById('open-float').value) || 0;
    const note = document.getElementById('open-note').value.trim();
    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      const logMsg = `SHIFT OPEN: $${amount.toFixed(2)}. ${note}`;
      records.push({
        id: "OPEN-" + Date.now(),
        pos: window.pos,
        status: "Log",
        shiftOpen: true,
        cashType: "IN",
        amount: amount,
        message: logMsg,
        timestamp: new Date().toISOString()
      });

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Open Shift: ${window.pos}`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, logMsg, this._getOperator());
      this.closeModal();
      await this.analyzeData();
    } catch (e) {
      alert("Sync Error: " + e.message);
    }
  },
  showShiftModal: function() {
    const modalRoot = document.getElementById('station-modal-root');
    const denoms = [1000, 500, 100, 50, 20, 10, 5, 1, 0.50, 0.20, 0.10, 0.05];
    const systemCash = parseFloat(document.getElementById('pay-cash').innerText) || 0;

    modalRoot.innerHTML = `
      <div class="modal-bg">
        <div class="modal-box">
          <div class="station-modal-header">
            <div class="station-modal-header-left">
              <button class="station-modal-back" onclick="StationModule.closeModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3>Shift Settlement</h3>
            </div>
            <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
          </div>
          <div class="station-modal-body">
            <div class="station-modal-inner" style="max-width:860px;">
              <div class="denom-grid">
                ${denoms.map(d => `
                  <div class="denom-item">
                    <label>$${d}</label>
                    <input type="number" class="denom-input" data-val="${d}" placeholder="0" oninput="StationModule.updateSettlementPreview(${systemCash})">
                  </div>
                `).join('')}
              </div>
              <div class="settlement-preview">
                <div><span>Expected System Cash</span><span>$${systemCash.toFixed(2)}</span></div>
                <div class="actual"><span>Physical Count</span><span id="modal-actual-cash">$0.00</span></div>
              </div>
              <div>
                <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:6px;">Closing Remarks</label>
                <input type="text" id="shift-note" class="input-field" placeholder="Closing remarks">
              </div>
            </div>
          </div>
          <div class="station-modal-footer">
            <div class="station-modal-footer-right">
              <button class="btn btn-outline" onclick="StationModule.closeModal()">Cancel</button>
              <button class="btn btn-blue" onclick="StationModule.handleEndShift()">Complete Settlement</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },
  updateSettlementPreview: function(expected) {
    const inputs = document.querySelectorAll('.denom-input');
    let actual = 0;
    inputs.forEach(input => actual += ((parseFloat(input.dataset.val)) * (parseInt(input.value) || 0)));
    const displayEl = document.getElementById('modal-actual-cash');
    displayEl.innerText = `$${actual.toFixed(2)}`;
    displayEl.style.color = (Math.abs(actual - expected) < 0.01) ? "#10b981" : "#ef4444";
  },
  closeModal: function() {
    document.getElementById('station-modal-root').innerHTML = '';
  },
  handleCashAction: async function(type) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const amtInput = document.getElementById('cash-amount');
    const amount = parseFloat(amtInput.value.trim());
    if (isNaN(amount)) return;

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      const logMsg = `MANUAL ${type}: $${amount}`;
      records.push({
        id: "CASH-" + Date.now(),
        pos: window.pos,
        status: "Log",
        cashType: type,
        amount: amount,
        message: logMsg,
        timestamp: new Date().toISOString()
      });

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Cash Adjustment`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, logMsg, this._getOperator());
      amtInput.value = "";
      await this.analyzeData();
    } catch (e) {
      alert("Error: " + e.message);
    }
  },
  handleEndShift: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const inputs = document.querySelectorAll('.denom-input');
    const note = document.getElementById('shift-note').value.trim();
    const systemCash = parseFloat(document.getElementById('pay-cash').innerText) || 0;

    let calculatedCash = 0;
    inputs.forEach(input => calculatedCash += ((parseFloat(input.dataset.val)) * (parseInt(input.value) || 0)));

    const diff = calculatedCash - systemCash;
    const diffStatus = Math.abs(diff) < 0.01 ? "Balanced" : (diff > 0 ? `Surplus +${diff.toFixed(2)}` : `Shortage ${diff.toFixed(2)}`);

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      const logMsg = `SHIFT END: $${calculatedCash.toFixed(2)} (${diffStatus}). ${note}`;
      records.push({
        id: "SHIFT-" + Date.now(),
        pos: window.pos,
        status: "Log",
        shiftEnd: true,
        message: logMsg,
        timestamp: new Date().toISOString()
      });

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `End Shift`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, logMsg, this._getOperator());
      this.closeModal();
      await this.analyzeData();
    } catch (e) {
      alert("Error: " + e.message);
    }
  },
  submitLog: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const msgInput = document.getElementById('station-log-msg');
    const msg = msgInput.value.trim();
    if (!msg) return;

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      const data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      records.push({
        id: "LOG-" + Date.now(),
        pos: window.pos,
        status: "Log",
        message: msg,
        timestamp: new Date().toISOString()
      });

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Log Entry`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog(window.pos, `NOTE: ${msg}`, this._getOperator());
      msgInput.value = "";
      await this.analyzeData();
    } catch (e) {
      alert("Error: " + e.message);
    }
  },
  handleCloudAction: async function(mode) {
    if (!this._isAdmin()) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (mode === 'delete' && !confirm(`Delete "${window.pos}"?`)) return;

    const newName = document.getElementById('modalInput')?.value.trim();
    if (mode !== 'delete' && !newName) return;

    const selectedCompanies = mode !== 'delete' ? this._getSelectedCompanies() : [];
    if (mode !== 'delete' && selectedCompanies.length === 0) {
      alert("Please select at least one company.");
      return;
    }

    const config = this._config;
    const apiUrl = `https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`;

    try {
      const getRes = await fetch(apiUrl, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (!getRes.ok) {
        throw new Error("Failed to fetch data");
      }

      let data = await getRes.json();
      let records = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      if (!Array.isArray(records)) records = [];

      let actionMsg = "";

      if (mode === 'edit') {
        actionMsg = `Renamed station from ${window.pos} to ${newName} (${selectedCompanies.join(', ')})`;
        records = records.map(r => r.pos === window.pos ? { ...r, pos: newName, companies: selectedCompanies, company: selectedCompanies[0] } : r);
        window.pos = newName;
      } else if (mode === 'delete') {
        actionMsg = `Deleted station: ${window.pos}`;
        records = records.filter(r => r.pos !== window.pos);
        window.pos = "";
      } else {
        actionMsg = `Created new station: ${newName} (${selectedCompanies.join(', ')})`;
        records.push({
          id: "ID-" + Date.now(),
          pos: newName,
          companies: selectedCompanies,
          company: selectedCompanies[0],
          status: "Success",
          items: [],
          timestamp: new Date().toISOString()
        });
        window.pos = newName;
      }

      await fetch(apiUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Station Sync`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(records, null, 2)))),
          sha: data.sha
        })
      });

      if (window.LogModule) await window.LogModule.addLog("SYSTEM", actionMsg, this._getOperator());
      this.closeModal();
      await this.render(this._containerId);
    } catch (e) {
      alert("Sync Error: " + e.message);
    }
  },
  analyzeData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const statusEl = document.getElementById('intel-status');

    if (!config.ghToken || !config.ghRepo) {
      if (statusEl) statusEl.innerText = "No Config";
      return;
    }

    try {
      const res = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/db_date/counter.json`, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const json = await res.json();
        const records = JSON.parse(decodeURIComponent(escape(atob(json.content))));
        const safeRecords = Array.isArray(records) ? records : [];
        this._allRecords = safeRecords;

        const allStations = [...new Set(safeRecords.map(r => r.pos))].filter(Boolean);
        const picker = document.getElementById('station-picker');

        if ((!window.pos || !allStations.includes(window.pos)) && allStations.length > 0) {
          window.pos = allStations[0];
        }

        picker.innerHTML = allStations.map(s => `<option value="${s}" ${s === window.pos ? 'selected' : ''}>${s}</option>`).join('');

        const currentPos = window.pos || 'None';
        document.getElementById('current-pos-label').innerText = currentPos;

        const stationCompanies = this._getStationCompanies(currentPos, safeRecords);
        const companyText = stationCompanies.length > 0 ? stationCompanies.join(', ') : '--';
        const badgeEl = document.getElementById('station-company-badge');
        if (badgeEl) badgeEl.innerText = `Company: ${companyText}`;
        const flowCompaniesEl = document.getElementById('current-pos-companies');
        if (flowCompaniesEl) flowCompaniesEl.innerText = stationCompanies.length > 0 ? `[${companyText}]` : '';

        const nodeRecords = safeRecords.filter(r => r.pos === currentPos);
        const businessRecords = nodeRecords.filter(r => r.status !== 'Log');
        const logRecords = nodeRecords.filter(r => r.status === 'Log').reverse();

        let cashSum = 0, digitalCount = 0;

        businessRecords.forEach(r => {
          const m = (r.paymentMethod || '').toLowerCase();
          if (m.includes('cash')) cashSum += 1;
          else digitalCount++;
        });

        logRecords.forEach(log => {
          const val = parseFloat(log.amount) || 0;
          if (log.cashType === 'IN') cashSum += val;
          else if (log.cashType === 'OUT') cashSum -= val;
        });

        document.getElementById('pay-cash').innerText = cashSum.toFixed(2);
        document.getElementById('pay-digital').innerText = digitalCount;
        document.getElementById('pay-revenue').innerText = (cashSum + digitalCount).toFixed(2);
        document.getElementById('pay-total').innerText = businessRecords.length;

        const pending = businessRecords.filter(r => r.status === 'Pending').length;
        const completed = businessRecords.filter(r => r.status === 'Confirmed' || r.status === 'Success').length;

        document.getElementById('val-efficiency').innerText = `${businessRecords.length === 0 ? "100" : ((completed / businessRecords.length) * 100).toFixed(0)}%`;
        document.getElementById('val-active').innerText = pending;

        const flowVisual = document.getElementById('flow-visual');
        flowVisual.innerHTML = businessRecords.slice(-24).map(r => `<div class="bar" style="height:${Math.min((r.items?.length || 1) * 15, 110)}px;"></div>`).join('');

        const logHistory = document.getElementById('station-log-history');
        logHistory.innerHTML = logRecords.slice(0, 6).map(log => {
          const dt = new Date(log.timestamp);
          let tagClass = "tag", tagText = "LOG";
          if (log.cashType === 'IN') {
            tagClass = "tag-in";
            tagText = "IN";
          }
          if (log.cashType === 'OUT') {
            tagClass = "tag-out";
            tagText = "OUT";
          }
          return `
            <div class="log-row" onclick="StationModule.showLogDetailModal('${String(log.id || '').replace(/'/g, "\\'")}')">
              <span class="log-time">${dt.getHours()}:${String(dt.getMinutes()).padStart(2,'0')}</span>
              <span class="tag ${tagClass}">${tagText}</span>
              <span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${log.message}</span>
            </div>
          `;
        }).join('') || '<div style="font-size:13px; color:var(--text-dim); padding:20px; text-align:center;">No recent logs.</div>';

        statusEl.innerText = "Active Sync";
      } else {
        statusEl.innerText = "Sync Failed";
      }
    } catch (e) {
      statusEl.innerText = "Offline";
      console.error("analyzeData error:", e);
    }
  }
};

window.StationModule = StationModule;

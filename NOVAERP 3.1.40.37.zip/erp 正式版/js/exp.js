const ExpiryModule = {
  _data: [],
  _products: [],
  _companies: [],
  _filteredData: [],
  _config: null,
  _currentId: null,
  _currentPage: 1,
  _pageSize: 20,
  _sha: null,
  _currentShelfLife: null,
  _productFileName: 'db_date/product.json',
  _expiryFileName: 'db_date/expiries.json',
  _companyFileName: 'db_date/company.json',
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = `
      <div class="expiry-app-wrapper">
        <header class="expiry-header">
          <div class="expiry-brand">
            <h1>EXP</h1>
            </div>
          <button type="button" class="expiry-btn-primary" onclick="ExpiryModule.openEditor()">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>Add Batch</span>
          </button>
        </header>

        <div class="expiry-search-section">
          <div class="expiry-search-inner">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="exp-search" placeholder="Search product or batch ID..." oninput="ExpiryModule.filter()">
          </div>
        </div>

        <main id="expiry-list" class="expiry-grid">
          <div class="expiry-loading">Syncing with cloud database...</div>
        </main>

        <div id="exp-pagination" class="expiry-pagination"></div>
      </div>

      <div id="exp-modal" class="expiry-modal">
        <div class="expiry-modal-container">
          <div class="expiry-modal-header">
            <div class="expiry-header-left">
              <button type="button" onclick="ExpiryModule.closeEditor()" class="expiry-btn-back">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <div class="expiry-header-title">
                <h2 id="exp-modal-title">Batch Details</h2>
              </div>
            </div>
            <div class="expiry-header-actions">
              <button type="button" id="exp-del-btn" onclick="ExpiryModule.delete()" class="expiry-btn-delete">Remove</button>
            </div>
          </div>

          <div class="expiry-modal-body">
            <form id="exp-form" class="expiry-form" onsubmit="ExpiryModule.save(event)">
              <div class="expiry-form-scroll">
                <div class="expiry-form-inner">
                  <div class="expiry-card">
                    <div class="expiry-card-header">
                      <span class="expiry-step">01</span>
                      <h3>Company & Selection</h3>
                    </div>
                    <div class="expiry-field">
                      <label>Company *</label>
                      <select name="company" id="exp-company-select" required class="expiry-select-field">
                        <option value="">Select company...</option>
                      </select>
                    </div>
                    <div class="expiry-field">
                      <label>Product Name</label>
                      <input type="text" name="productName" id="product-select" list="exp-product-list" required placeholder="Select or type product..." onchange="ExpiryModule.handleProductSelect(this.value)">
                      <datalist id="exp-product-list"></datalist>
                    </div>
                    <div class="expiry-field">
                      <label>Batch Identifier</label>
                      <input type="text" name="batchNo" required placeholder="e.g. LOT-2026-A1">
                    </div>
                  </div>

                  <div class="expiry-card expiry-card-accent">
                    <div class="expiry-card-header">
                      <span class="expiry-step">02</span>
                      <h3>Stock Allocation</h3>
                    </div>
                    <div class="expiry-row-grid">
                      <div class="expiry-field">
                        <label>Warehouse Qty</label>
                        <input type="number" name="qtyWarehouse" id="qtyWarehouse" value="0" min="0" oninput="ExpiryModule.calcTotal()">
                      </div>
                      <div class="expiry-field">
                        <label>Front Shelf Qty</label>
                        <input type="number" name="qtyShelf" id="qtyShelf" value="0" min="0" oninput="ExpiryModule.calcTotal()">
                      </div>
                    </div>
                    <div class="expiry-total-box">
                      <label>Computed Total Units</label>
                      <input type="number" name="quantity" id="qtyTotal" readonly value="0">
                    </div>
                  </div>

                  <div class="expiry-card">
                    <div class="expiry-card-header">
                      <span class="expiry-step">03</span>
                      <h3>Dates & Compliance</h3>
                    </div>
                    <div class="expiry-row-grid">
                      <div class="expiry-field">
                        <label>Production (MFG)</label>
                        <input type="date" name="mfgDate" id="mfgDate" onchange="ExpiryModule.autoCalcExpiry()">
                      </div>
                      <div class="expiry-field">
                        <label>Expiry (EXP)</label>
                        <input type="date" name="expDate" id="expDate" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="expiry-form-footer">
                <button type="submit" class="expiry-btn-save">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  Save to Cloud Storage
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;

    await this.load();
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (!this._config.ghToken || !this._config.ghRepo) return;

    try {
      const [prodRes, expRes, compRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._productFileName}`, {
          headers: { 'Authorization': `token ${this._config.ghToken}` }
        }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._expiryFileName}`, {
          headers: { 'Authorization': `token ${this._config.ghToken}` },
          cache: 'no-store'
        }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._companyFileName}`, {
          headers: { 'Authorization': `token ${this._config.ghToken}` },
          cache: 'no-store'
        })
      ]);

      if (prodRes.ok) {
        const prodData = await prodRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(prodData.content))));
        this._products = db.products || [];
        this.updateProductDatalist();
      }

      if (expRes.status === 404) {
        this._data = [];
        this._sha = null;
      } else if (expRes.ok) {
        const data = await expRes.json();
        this._sha = data.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      }

      if (compRes.ok) {
        const compData = await compRes.json();
        const parsed = JSON.parse(decodeURIComponent(escape(atob(compData.content))));
        this._companies = parsed.companies || (Array.isArray(parsed) ? parsed : []);
        this.updateCompanySelect();
      }

      this._filteredData = [...this._data];
      this.renderList();
    } catch (e) {
      console.error("Load Error:", e);
    }
  },
  updateProductDatalist: function() {
    const list = document.getElementById('exp-product-list');
    if (list) {
      list.innerHTML = this._products.map(p => `<option value="${p.prodName}">`).join('');
    }
  },
  updateCompanySelect: function() {
    const sel = document.getElementById('exp-company-select');
    if (!sel) return;
    const currentVal = sel.value;
    sel.innerHTML = `<option value="">Select company...</option>` + this._companies.map(c => {
      const name = (typeof c === 'object') ? (c.name || '') : c;
      return `<option value="${name}">${name}</option>`;
    }).join('');
    if (currentVal) sel.value = currentVal;
  },
  handleProductSelect: function(val) {
    const product = this._products.find(p => p.prodName === val);
    if (product && product.shelfLife) {
      this._currentShelfLife = product.shelfLife;
      this.autoCalcExpiry();
    }
  },
  autoCalcExpiry: function() {
    const mfgDate = document.getElementById('mfgDate').value;
    if (mfgDate && this._currentShelfLife) {
      const d = new Date(mfgDate);
      d.setDate(d.getDate() + parseInt(this._currentShelfLife));
      document.getElementById('expDate').value = d.toISOString().split('T')[0];
    }
  },
  calcTotal: function() {
    const warehouse = parseInt(document.getElementById('qtyWarehouse').value) || 0;
    const shelf = parseInt(document.getElementById('qtyShelf').value) || 0;
    document.getElementById('qtyTotal').value = warehouse + shelf;
  },
  toggleCompanySection: function(headerEl) {
    const section = headerEl.closest('.expiry-company-section');
    if (section) {
      section.classList.toggle('is-collapsed');
    }
  },
  renderList: function() {
    const grid = document.getElementById('expiry-list');
    const start = (this._currentPage - 1) * this._pageSize;
    const paginated = this._filteredData.slice(start, start + this._pageSize);

    if (this._filteredData.length === 0) {
      grid.style.display = 'block';
      grid.innerHTML = `<div class="expiry-empty">No matching batch records.</div>`;
      return;
    }

    grid.style.display = 'block';

    const groups = {};
    const unassigned = [];

    paginated.forEach(item => {
      const comp = (item.company || "").trim();
      if (comp) {
        if (!groups[comp]) groups[comp] = [];
        groups[comp].push(item);
      } else {
        unassigned.push(item);
      }
    });

    let html = '';

    const renderCard = (item) => {
      const status = this._getStatus(item.expDate);
      return `
        <div class="expiry-card-item" onclick="ExpiryModule.openEditor('${item.id}')">
          <div class="expiry-status-bar ${status.code}"></div>
          <div class="expiry-card-content">
            <div class="expiry-card-header-row">
              <span class="expiry-category">${this._getProductCategory(item.productName)}</span>
              <span class="expiry-stock">${item.quantity || 0} Units</span>
            </div>
            <h3 class="expiry-product-name">${item.productName}</h3>
            <p class="expiry-batch">Batch: ${item.batchNo}</p>
          </div>
          <div class="expiry-card-footer">
            <div class="expiry-date">
              <label>EXPIRY</label>
              <span class="${status.code === 'expired' ? 'expiry-critical' : ''}">${item.expDate}</span>
            </div>
            <div class="expiry-location">
              WH:${item.qtyWarehouse || 0} | SF:${item.qtyShelf || 0}
            </div>
          </div>
        </div>
      `;
    };

    Object.keys(groups).sort().forEach(compName => {
      const compItems = groups[compName];
      const totalCompQty = compItems.reduce((sum, i) => sum + (i.quantity || 0), 0);
      html += `
        <div class="expiry-company-section is-collapsed">
          <div class="expiry-company-section-header" onclick="ExpiryModule.toggleCompanySection(this)">
            <div class="expiry-company-info">
              <span class="expiry-group-badge">CMP</span>
              <h3>${compName}</h3>
              <span class="expiry-pill">Batches: <b>${compItems.length}</b></span>
              <span class="expiry-pill">Total Units: <b>${totalCompQty}</b></span>
            </div>
            <div class="expiry-expand-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
          </div>
          <div class="expiry-company-section-body">
            <div class="expiry-sub-grid">
              ${compItems.map(item => renderCard(item)).join('')}
            </div>
          </div>
        </div>
      `;
    });

    if (unassigned.length > 0) {
      const totalUnassignedQty = unassigned.reduce((sum, i) => sum + (i.quantity || 0), 0);
      html += `
        <div class="expiry-company-section is-collapsed">
          <div class="expiry-company-section-header" onclick="ExpiryModule.toggleCompanySection(this)">
            <div class="expiry-company-info">
              <span class="expiry-group-badge">OTH</span>
              <h3>Other / Unassigned Company</h3>
              <span class="expiry-pill">Batches: <b>${unassigned.length}</b></span>
              <span class="expiry-pill">Total Units: <b>${totalUnassignedQty}</b></span>
            </div>
            <div class="expiry-expand-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
          </div>
          <div class="expiry-company-section-body">
            <div class="expiry-sub-grid">
              ${unassigned.map(item => renderCard(item)).join('')}
            </div>
          </div>
        </div>
      `;
    }

    grid.innerHTML = html;
    this.renderPagination();
  },
  _getProductCategory: function(name) {
    const p = this._products.find(x => x.prodName === name);
    return p ? p.category : 'General';
  },
  _getStatus: function(expDate) {
    const today = new Date();
    const exp = new Date(expDate);
    const diffDays = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));
    if (diffDays <= 0) return { code: 'expired', label: 'Expired' };
    if (diffDays <= 90) return { code: 'near', label: 'Near' };
    return { code: 'safe', label: 'Safe' };
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = e.target.querySelector('.expiry-btn-save');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerText = "Syncing Data...";

    const fd = new FormData(e.target);
    const isEdit = !!this._currentId;

    const company = fd.get('company');
    if (!company) {
      alert("Please select a company.");
      btn.disabled = false;
      btn.innerHTML = originalText;
      return;
    }

    const productName = fd.get('productName');
    const batchNo = fd.get('batchNo');
    const qtyWarehouse = parseInt(fd.get('qtyWarehouse')) || 0;
    const qtyShelf = parseInt(fd.get('qtyShelf')) || 0;
    const totalQty = parseInt(fd.get('quantity')) || 0;
    const mfgDate = fd.get('mfgDate');
    const expDate = fd.get('expDate');

    const productMatch = this._products.find(p => p.prodName === productName);
    const finalName = productMatch ? (productMatch.prodName || productMatch.name || productName) : productName;

    const newEntry = {
      id: this._currentId || 'EXP-' + Date.now(),
      company: company,
      productName: finalName,
      batchNo: batchNo,
      qtyWarehouse: qtyWarehouse,
      qtyShelf: qtyShelf,
      quantity: totalQty,
      mfgDate: mfgDate,
      expDate: expDate,
      updatedAt: new Date().toISOString()
    };

    try {
      let updatedData = [...this._data];

      if (isEdit) {
        const idx = updatedData.findIndex(x => x.id === this._currentId);
        if (idx !== -1) updatedData[idx] = newEntry;
      } else {
        const existingIdx = updatedData.findIndex(x => x.company === company && x.productName === finalName && x.batchNo === batchNo);
        if (existingIdx !== -1) {
          updatedData[existingIdx].qtyWarehouse += qtyWarehouse;
          updatedData[existingIdx].qtyShelf += qtyShelf;
          updatedData[existingIdx].quantity += totalQty;
          updatedData[existingIdx].expDate = expDate;
          updatedData[existingIdx].mfgDate = mfgDate;
          updatedData[existingIdx].updatedAt = new Date().toISOString();
        } else {
          updatedData.push(newEntry);
        }
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(updatedData, null, 2))));

      let currentSha = this._sha;
      if (!currentSha) {
        const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._expiryFileName}`, {
          headers: {
            'Authorization': `token ${this._config.ghToken}`
          }
        });
        if (getRes.ok) {
          const data = await getRes.json();
          currentSha = data.sha;
        }
      }

      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._expiryFileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: `Update Batch: ${batchNo}`,
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          const actionType = isEdit ? "Updated Batch" : "Created New Batch";
          const logDetails = `${actionType}: ${finalName} (${batchNo}) - Total: ${totalQty}`;
          await window.LogModule.addLog('ExpiryModule', logDetails, this._config.userName || 'Admin');
        }
        this.closeEditor();
        await this.load();
      } else {
        const errorData = await res.json();
        alert("Sync Failed: " + (errorData.message || "Unknown error"));
      }
    } catch (e) {
      console.error(e);
      alert("Network Error: Could not sync.");
    } finally {
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
  },
  delete: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (!confirm("Are you sure you want to delete this batch?")) return;

    const targetItem = this._data.find(x => x.id === this._currentId);
    const updatedData = this._data.filter(x => x.id !== this._currentId);
    const content = btoa(unescape(encodeURIComponent(JSON.stringify(updatedData, null, 2))));

    try {
      let currentSha = this._sha;
      if (!currentSha) {
        const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._expiryFileName}`, {
          headers: {
            'Authorization': `token ${this._config.ghToken}`
          }
        });
        if (getRes.ok) {
          const data = await getRes.json();
          currentSha = data.sha;
        }
      }

      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._expiryFileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "Delete Batch Entry",
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function' && targetItem) {
          await window.LogModule.addLog('ExpiryModule', `Deleted Batch: ${targetItem.productName} (${targetItem.batchNo})`, this._config.userName || 'Admin');
        }
        this.closeEditor();
        await this.load();
      } else {
        alert("Delete failed: " + (await res.json()).message);
      }
    } catch (e) {
      console.error(e);
      alert("Delete failed.");
    }
  },
  openEditor: function(id = null) {
    this._currentId = id;
    const modal = document.getElementById('exp-modal');
    const form = document.getElementById('exp-form');
    form.reset();
    this.updateCompanySelect();

    if (id) {
      const item = this._data.find(x => x.id === id);
      if (!item) return;

      document.getElementById('exp-modal-title').innerText = "Edit Batch Record";
      document.getElementById('exp-del-btn').style.display = 'inline-flex';

      Object.keys(item).forEach(key => {
        if (form.elements[key]) form.elements[key].value = item[key];
      });
      if (item.company) {
        const compSel = document.getElementById('exp-company-select');
        if (compSel) compSel.value = item.company;
      }
    } else {
      document.getElementById('exp-modal-title').innerText = "New Batch Registry";
      document.getElementById('exp-del-btn').style.display = 'none';
      document.getElementById('qtyWarehouse').value = 0;
      document.getElementById('qtyShelf').value = 0;
      document.getElementById('qtyTotal').value = 0;
    }

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('exp-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  filter: function() {
    const q = (document.getElementById('exp-search')?.value || '').toLowerCase();
    this._filteredData = this._data.filter(x =>
      x.productName.toLowerCase().includes(q) ||
      x.batchNo.toLowerCase().includes(q) ||
      (x.company && x.company.toLowerCase().includes(q))
    );
    this._currentPage = 1;
    this.renderList();
  },
  renderPagination: function() {
    const totalPages = Math.ceil(this._filteredData.length / this._pageSize);
    const container = document.getElementById('exp-pagination');
    if (totalPages <= 1) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = `
      <button type="button" class="expiry-page-btn" onclick="ExpiryModule.changePage(${this._currentPage - 1})" ${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>
      <span class="expiry-page-info">${this._currentPage} / ${totalPages}</span>
      <button type="button" class="expiry-page-btn" onclick="ExpiryModule.changePage(${this._currentPage + 1})" ${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>
    `;
  },
  changePage: function(p) {
    this._currentPage = p;
    this.renderList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  _injectStyles: function() {
    if (document.getElementById('expiry-modern-styles')) return;

    const style = document.createElement('style');
    style.id = 'expiry-modern-styles';
    style.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .expiry-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .expiry-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .expiry-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .expiry-subtitle {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .expiry-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .expiry-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .expiry-search-section {
        margin-bottom: 20px;
      }

      .expiry-search-inner {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
        max-width: 420px;
        width: 100%;
      }

      .expiry-search-inner:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .expiry-search-inner svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .expiry-search-inner input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .expiry-search-inner input::placeholder {
        color: var(--text-dim);
      }

      .expiry-company-section {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 16px;
        overflow: hidden;
        box-shadow: var(--shadow-xs);
        transition: all var(--transition-fast);
      }

      .expiry-company-section:hover {
        border-color: var(--border-strong);
      }

      .expiry-company-section-header {
        padding: 16px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        transition: background var(--transition-fast);
        gap: 14px;
      }

      .expiry-company-section.is-collapsed .expiry-company-section-header {
        border-bottom: none;
      }

      .expiry-company-section-header:hover {
        background: var(--surface-soft);
      }

      .expiry-company-info {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        flex: 1;
        min-width: 0;
      }

      .expiry-group-badge {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        background: var(--primary-soft);
        color: var(--primary);
        letter-spacing: 0.04em;
        flex-shrink: 0;
      }

      .expiry-company-info h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .expiry-pill {
        background: var(--surface-soft);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .expiry-pill b {
        color: var(--text);
      }

      .expiry-expand-icon {
        transition: transform var(--transition-base);
        display: flex;
        align-items: center;
        flex-shrink: 0;
        color: var(--text-dim);
      }

      .expiry-company-section.is-collapsed .expiry-expand-icon {
        transform: rotate(-90deg);
      }

      .expiry-company-section-body {
        max-height: 5000px;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
        padding: 18px 20px;
        background: var(--bg);
      }

      .expiry-company-section.is-collapsed .expiry-company-section-body {
        max-height: 0;
        padding-top: 0;
        padding-bottom: 0;
      }

      .expiry-sub-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
        gap: 16px;
      }

      .expiry-grid {
        width: 100%;
      }

      .expiry-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        position: relative;
        overflow: hidden;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        flex-direction: column;
        box-shadow: var(--shadow-xs);
      }

      .expiry-card-item:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .expiry-status-bar {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 5px;
      }

      .expiry-status-bar.safe {
        background: var(--green);
      }

      .expiry-status-bar.near {
        background: var(--amber);
      }

      .expiry-status-bar.expired {
        background: var(--danger);
      }

      .expiry-card-content {
        padding: 18px 20px;
        flex: 1;
      }

      .expiry-card-header-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 10px;
      }

      .expiry-category {
        font-size: 11px;
        font-weight: 700;
        padding: 4px 10px;
        background: var(--surface-soft);
        color: var(--text-secondary);
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
        text-transform: uppercase;
        letter-spacing: 0.03em;
      }

      .expiry-stock {
        font-size: 12px;
        font-weight: 700;
        color: var(--primary);
      }

      .expiry-product-name {
        margin: 0 0 4px;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .expiry-batch {
        margin: 0;
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 500;
        word-break: break-word;
      }

      .expiry-card-footer {
        padding: 14px 20px;
        background: var(--surface-soft);
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
      }

      .expiry-date label {
        display: block;
        font-size: 10px;
        font-weight: 700;
        color: var(--text-dim);
        letter-spacing: 0.05em;
        margin-bottom: 2px;
      }

      .expiry-date span {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 13px;
        font-weight: 700;
        color: var(--text);
      }

      .expiry-critical {
        color: var(--danger) !important;
      }

      .expiry-location {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        background: var(--surface);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
      }

      .expiry-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: translateY(12px);
        transition: visibility 0.2s, opacity 0.2s, transform 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .expiry-modal.active {
        visibility: visible;
        opacity: 1;
        transform: translateY(0);
      }

      .expiry-modal-container {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
      }

      .expiry-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .expiry-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
      }

      .expiry-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .expiry-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .expiry-header-title h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .expiry-header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
      }

      .expiry-btn-delete {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 38px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .expiry-btn-delete:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .expiry-modal-body {
        flex: 1;
        overflow-y: auto;
        min-height: 0;
      }

      .expiry-form {
        height: 100%;
        display: flex;
        flex-direction: column;
      }

      .expiry-form-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        padding-bottom: 104px;
        min-height: 0;
      }

      .expiry-form-inner {
        max-width: 960px;
        margin: 0 auto;
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 20px;
      }

      .expiry-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .expiry-card-accent {
        border-left: 3px solid var(--primary);
      }

      .expiry-card-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 18px;
      }

      .expiry-step {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        width: 28px;
        height: 28px;
        background: var(--primary-soft);
        color: var(--primary);
        border-radius: var(--radius-xs);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 700;
        flex-shrink: 0;
      }

      .expiry-card-header h3 {
        margin: 0;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .expiry-field {
        margin-bottom: 16px;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .expiry-field:last-child {
        margin-bottom: 0;
      }

      .expiry-field label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .expiry-field input, .expiry-select-field {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .expiry-field input:focus, .expiry-select-field:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .expiry-row-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
        margin-bottom: 16px;
      }

      .expiry-total-box {
        background: var(--primary-soft);
        border-radius: var(--radius-md);
        padding: 14px 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        border: 1px solid rgba(79, 70, 229, 0.16);
      }

      .expiry-total-box label {
        font-weight: 700;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--primary);
      }

      .expiry-total-box input {
        background: transparent;
        border: none;
        font-weight: 700;
        font-size: 18px;
        color: var(--primary);
        width: 120px;
        text-align: right;
        outline: none;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      }

      .expiry-form-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 14px 24px;
        display: flex;
        justify-content: flex-end;
        z-index: 20;
        box-shadow: var(--shadow-sm);
      }

      .expiry-btn-save {
        width: 100%;
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 42px;
        padding: 0 22px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .expiry-btn-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .expiry-btn-save:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .expiry-pagination {
        display: flex;
        justify-content: center;
        gap: 12px;
        margin-top: 24px;
        align-items: center;
        flex-wrap: wrap;
      }

      .expiry-page-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 36px;
        padding: 0 14px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .expiry-page-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .expiry-page-btn:hover:not(:disabled) {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .expiry-page-info {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .expiry-loading,
      .expiry-empty {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 768px) {
        .expiry-app-wrapper {
          padding: 16px;
        }
        .expiry-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .expiry-brand h1 {
          font-size: 22px;
        }
        .expiry-btn-primary {
          justify-content: center;
          width: 100%;
        }
        .expiry-search-inner {
          max-width: 100%;
        }
        .expiry-company-section,
        .expiry-card-item {
          border-radius: var(--radius-lg);
        }
        .expiry-company-section-header {
          padding: 14px 16px;
        }
        .expiry-company-section-body {
          padding: 14px 16px;
        }
        .expiry-sub-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .expiry-row-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .expiry-modal-header {
          padding: 12px 16px;
        }
        .expiry-header-title h2 {
          font-size: 16px;
        }
        .expiry-form-scroll {
          padding: 16px;
          padding-bottom: 100px;
        }
        .expiry-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .expiry-form-footer {
          padding: 12px 16px;
        }
      }
    `;
    document.head.appendChild(style);
  }
};

window.ExpiryModule = ExpiryModule;

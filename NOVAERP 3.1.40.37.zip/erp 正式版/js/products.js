const ProductModule = {
  _data: [],
  _sha: '',
  _searchQuery: '',
  _categoryFilter: 'All',
  _editingIndex: null,
  _fileName: 'db_date/product.json',
  _currentPage: 1,
  _itemsPerPage: 20,
  _totalFilteredData: [],
  _isAdmin: function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    return config.role === 'admin';
  },
  _addLog: function(product, action, details) {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const logEntry = {
      time: new Date().toISOString(),
      user: config.user || config.role || 'User',
      action: action,
      details: details,
      prodName: product.prodName,
      sku: product.sku
    };
    if (!product.history) product.history = [];
    product.history.push(logEntry);
    if (product.history.length > 20) product.history.shift();

    if (window.LogModule && typeof window.LogModule.addLog === 'function') {
      window.LogModule.addLog('Inventory', `${action}: ${product.prodName}`, details, config);
    }
  },
  handleAction: async function(actionType, index) {
    const actions = {
      'Stock In': () => this.handleStockInCard(index),
      'Locate': () => this.handleLocate(index),
      'Stats': () => this.handleStats(index),
      'Promo': () => this._isAdmin() ? this.handlePromo(index) : alert('Admin access required.'),
      'Print': () => this.executePrint(this._data[index]),
      'Logs': () => this.showLogs(index),
      'Sold': () => this.handleSold(index),
      'Inflow': () => this.handleInflow(index),
      'Old Exp': () => this.handleExpiry(index),
      'MonthlySales': () => this.handleMonthlySales(index)
    };
    if (actions[actionType]) {
      actions[actionType]();
    }
  },
  handleMonthlySales: function(index) {
    const p = this._data[index];
    const history = p.history || [];
    const soldLogs = history.filter(l => l.action === 'Sold Out');
    
    const monthMap = new Map();
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    
    for (let i = 0; i < 12; i++) {
      const d = new Date(currentYear, currentMonth - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthMap.set(key, { label: `${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`, qty: 0, hasSale: false });
    }
    
    soldLogs.forEach(log => {
      const logDate = new Date(log.time);
      const key = `${logDate.getFullYear()}-${String(logDate.getMonth() + 1).padStart(2, '0')}`;
      if (monthMap.has(key)) {
        const entry = monthMap.get(key);
        entry.hasSale = true;
        const match = log.details.match(/\(-(\d+)\)/);
        if (match) {
          entry.qty += parseInt(match[1]);
        }
      }
    });
    
    const rows = Array.from(monthMap.entries()).reverse().map(([key, data]) => `
      <tr>
        <td style="font-weight:600;">${data.label}</td>
        <td style="text-align:center;">
          ${data.hasSale ? '<span class="prod-status-badge status-ok">Sold</span>' : '<span style="color:var(--text-dim);">-</span>'}
        </td>
        <td style="text-align:right; font-weight:700;">${data.qty > 0 ? data.qty : '-'}</td>
      </tr>
    `).join('');
    
    const overlay = document.createElement('div');
    overlay.id = "monthly-sales-overlay";
    overlay.className = "prod-sub-overlay";
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:520px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Monthly Sales Status</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('monthly-sales-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-table-wrap">
            <table class="prod-data-table">
              <thead>
                <tr>
                  <th>Month</th>
                  <th style="text-align:center;">Status</th>
                  <th style="text-align:right;">Qty Sold</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  },
  handleStockInCard: function(index) {
    const p = this._data[index];
    if (!p.locations) p.locations = [];
    const initialOverlay = this._buildStockInOverlay(p, index);
    document.body.appendChild(initialOverlay);
  },
  _buildStockInOverlay: function(p, index, onCloseRefresh) {
    const overlay = document.createElement('div');
    overlay.id = "stock-in-card-overlay";
    overlay.className = "prod-sub-overlay";
    overlay.onclick = (e) => {
      if (e.target === overlay) {
        overlay.remove();
        if (onCloseRefresh) onCloseRefresh();
      }
    };

    const totalQty = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
    p.qty = totalQty;

    const groups = new Map();
    p.locations.forEach((loc, idx) => {
      const supplier = loc.company && loc.company.trim() !== '' ? loc.company : 'Unknown / N/A';
      if (!groups.has(supplier)) {
        groups.set(supplier, []);
      }
      groups.get(supplier).push({ ...loc, originalIdx: idx });
    });

    let batchesHtml = '';
    if (p.locations.length === 0) {
      batchesHtml = '<div class="prod-empty-box">No inbound records yet. Add one below.</div>';
    } else {
      for (let [supplier, batches] of groups.entries()) {
        const supplierTotal = batches.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
        const groupId = `supplier-group-${Date.now()}-${Math.random()}`;
        batchesHtml += `
          <div class="prod-supplier-group">
            <div class="supplier-header" data-group-id="${groupId}">
              <div class="supplier-header-left">
                <span>${this._escapeHtml(supplier)}</span>
                <span class="supplier-pill">${batches.length} batch(es)</span>
              </div>
              <div class="supplier-header-right">
                <span class="supplier-total">Total: ${supplierTotal} units</span>
                <span class="collapse-icon">v</span>
              </div>
            </div>
            <div class="supplier-content" data-group-id="${groupId}">
              <div class="prod-table-wrap">
                <table class="prod-data-table">
                  <thead>
                    <tr>
                      <th>Batch No.</th>
                      <th>Qty</th>
                      <th>Expiry</th>
                      <th style="text-align:center;">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${batches.map(batch => `
                      <tr>
                        <td>${this._escapeHtml(batch.bn || '-')}</td>
                        <td style="font-weight:700;">${batch.qty || 0}</td>
                        <td>${this._escapeHtml(batch.exp || '-')}</td>
                        <td style="text-align:center;">
                          <div class="prod-row-actions">
                            <button type="button" class="edit-batch-btn prod-mini-btn" data-idx="${batch.originalIdx}">Edit</button>
                            <button type="button" class="del-batch-btn prod-mini-btn danger" data-idx="${batch.originalIdx}">Delete</button>
                          </div>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        `;
      }
    }

    const existingCats = [...new Set(this._data.map(item => item.category))];
    const existingBNs = p.locations.map(l => l.bn).filter(b => b);
    const combinedSuggestions = [...new Set([...existingCats, ...existingBNs])];
    const datalistHtml = combinedSuggestions.map(item => `<option value="${item}">`).join('');

    overlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:760px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Batch Stock In</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="close-overlay-btn prod-sub-close">Close</button>
        </div>

        <div class="prod-sub-body">
          <div class="prod-summary-banner">
            <div>
              <div class="prod-summary-label">Current Total Stock</div>
              <div class="prod-summary-value">${totalQty}</div>
            </div>
            <div class="prod-summary-divider"></div>
            <div style="text-align:right;">
              <div class="prod-summary-label">Last Cost</div>
              <div class="prod-summary-subvalue">$${parseFloat(p.cost || 0).toFixed(2)}</div>
            </div>
          </div>

          <div class="prod-sub-section">
            <div class="prod-sub-section-title">Existing Batches (grouped by supplier)</div>
            <div id="supplier-groups-container">${batchesHtml}</div>
          </div>

          <div class="prod-sub-section prod-dashed-top">
            <div class="prod-sub-section-title">Add New Batch</div>
            <div class="prod-sub-grid-2">
              <div class="form-field">
                <label>Quantity (+)</label>
                <input type="number" id="stock-in-qty" placeholder="0" class="field-input">
              </div>
              <div class="form-field">
                <label>Cost ($)</label>
                <input type="number" id="stock-in-cost" step="0.01" value="${p.cost || ''}" class="field-input">
              </div>
              <div class="form-field">
                <label>Batch No.</label>
                <input type="text" id="stock-in-bn" list="stock-in-datalist" placeholder="e.g. B2025-001" class="field-input">
                <datalist id="stock-in-datalist">${datalistHtml}</datalist>
              </div>
              <div class="form-field">
                <label>Supplier</label>
                <input type="text" id="stock-in-cp" placeholder="Company name" class="field-input">
              </div>
              <div class="form-field full-width">
                <label>Expiry (optional)</label>
                <input type="text" id="stock-in-exp" placeholder="DD/MM/YYYY" class="field-input">
              </div>
            </div>
            <button type="button" id="confirm-stock-in-btn" class="prod-primary-btn" style="width:100%; margin-top:16px;">Confirm Batch</button>
          </div>
        </div>
      </div>
    `;

    overlay.querySelectorAll('.supplier-header').forEach(header => {
      const groupId = header.dataset.groupId;
      const content = overlay.querySelector(`.supplier-content[data-group-id="${groupId}"]`);
      const icon = header.querySelector('.collapse-icon');
      if (content && icon) {
        header.addEventListener('click', () => {
          const isVisible = content.style.display !== 'none';
          content.style.display = isVisible ? 'none' : 'block';
          icon.style.transform = isVisible ? 'rotate(-90deg)' : 'rotate(0deg)';
        });
      }
    });

    overlay.querySelector('.close-overlay-btn').onclick = () => {
      overlay.remove();
      if (onCloseRefresh) onCloseRefresh();
    };

    overlay.querySelectorAll('.edit-batch-btn').forEach(btn => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.idx);
        const batch = p.locations[idx];
        if (!batch) return;

        const editDiv = document.createElement('div');
        editDiv.className = "prod-sub-overlay";
        editDiv.style.zIndex = "60000";
        editDiv.innerHTML = `
          <div class="prod-sub-dialog" style="max-width:420px;" onclick="event.stopPropagation()">
            <div class="prod-sub-header">
              <div><h3>Edit Batch</h3></div>
              <button type="button" id="cancel-edit-btn" class="prod-sub-close">Cancel</button>
            </div>
            <div class="prod-sub-body">
              <div class="form-field" style="margin-bottom:12px;"><label>Quantity</label><input id="edit-qty" type="number" value="${batch.qty}" class="field-input"></div>
              <div class="form-field" style="margin-bottom:12px;"><label>Batch No.</label><input id="edit-bn" value="${this._escapeHtml(batch.bn || '')}" class="field-input"></div>
              <div class="form-field" style="margin-bottom:12px;"><label>Supplier</label><input id="edit-company" value="${this._escapeHtml(batch.company || '')}" class="field-input"></div>
              <div class="form-field" style="margin-bottom:12px;"><label>Expiry</label><input id="edit-exp" value="${this._escapeHtml(batch.exp || '')}" placeholder="DD/MM/YYYY" class="field-input"></div>
              <div class="form-field" style="margin-bottom:16px;"><label>Shelf (optional)</label><input id="edit-shelf" value="${this._escapeHtml(batch.shelf || 'Main Storage')}" class="field-input"></div>
              <div style="display:flex; gap:10px;">
                <button type="button" id="save-edit-btn" class="prod-primary-btn" style="flex:1;">Save</button>
              </div>
            </div>
          </div>
        `;
        document.body.appendChild(editDiv);

        const saveBtn = editDiv.querySelector('#save-edit-btn');
        const cancelBtn = editDiv.querySelector('#cancel-edit-btn');

        saveBtn.onclick = async () => {
          const newQty = parseInt(editDiv.querySelector('#edit-qty').value);
          if (isNaN(newQty) || newQty < 0) return alert("Quantity must be positive.");
          const oldQty = batch.qty;
          batch.qty = newQty;
          batch.bn = editDiv.querySelector('#edit-bn').value;
          batch.company = editDiv.querySelector('#edit-company').value;
          batch.exp = editDiv.querySelector('#edit-exp').value;
          batch.shelf = editDiv.querySelector('#edit-shelf').value || 'Main Storage';

          const newTotal = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
          p.qty = newTotal;

          this._addLog(p, 'Edit Stock In', `Batch modified: ${batch.bn}, qty ${oldQty} -> ${newQty}`);
          await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}'));
          editDiv.remove();
          overlay.remove();
          this.handleStockInCard(index);
          this.renderList();
        };
        cancelBtn.onclick = () => editDiv.remove();
      };
    });

    overlay.querySelectorAll('.del-batch-btn').forEach(btn => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.idx);
        if (!confirm(`Delete batch "${p.locations[idx].bn || 'Unnamed'}"? Stock will be reduced accordingly.`)) return;

        const removed = p.locations.splice(idx, 1)[0];
        const newTotal = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
        p.qty = newTotal;

        this._addLog(p, 'Delete Stock In', `Deleted batch: ${removed.bn || 'N/A'}, qty ${removed.qty}`);
        await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}'));
        overlay.remove();
        this.handleStockInCard(index);
        this.renderList();
      };
    });

    const confirmBtn = overlay.querySelector('#confirm-stock-in-btn');
    confirmBtn.onclick = async () => {
      const addQty = Number(overlay.querySelector('#stock-in-qty').value);
      const newCost = overlay.querySelector('#stock-in-cost').value;
      const bn = overlay.querySelector('#stock-in-bn').value;
      const cp = overlay.querySelector('#stock-in-cp').value;
      const exp = overlay.querySelector('#stock-in-exp').value;

      if (addQty <= 0) return alert("Please enter a valid quantity.");

      confirmBtn.disabled = true;
      confirmBtn.innerText = "Syncing...";

      if (newCost && !isNaN(Number(newCost))) p.cost = Number(newCost);

      p.locations.push({
        bn: bn || 'Manual In',
        exp: exp || 'N/A',
        shelf: 'Main Storage',
        qty: addQty,
        company: cp || 'N/A',
        costAtIn: newCost || p.cost
      });

      const newTotal = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
      p.qty = newTotal;
      p.updatedAt = new Date().toISOString();

      this._addLog(p, 'Stock In', `+${addQty} units | Batch: ${bn || 'N/A'} | Supplier: ${cp || 'N/A'}`);
      await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}'));

      overlay.remove();
      this.closeMoreMenu();
      this.renderList();
      if (onCloseRefresh) onCloseRefresh();
    };

    return overlay;
  },
  _escapeHtml: function(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
      if (m === '&') return '&amp;';
      if (m === '<') return '&lt;';
      if (m === '>') return '&gt;';
      return m;
    });
  },
  handleLocate: function(index) {
    const p = this._data[index];
    if (!p.locations) p.locations = [];

    const renderLocateUI = () => {
      const totalInLocs = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
      const locateOverlay = document.createElement('div');
      locateOverlay.id = "locate-manager-overlay";
      locateOverlay.className = "prod-sub-overlay";

      let locListHtml = p.locations.map((loc, i) => `
        <div class="prod-loc-card">
          <div class="prod-loc-grid">
            <div><label>Batch/Co.</label><div>${this._escapeHtml(loc.bn || '-')}</div></div>
            <div><label>Expiry (EXP)</label><div style="color:var(--danger);">${this._escapeHtml(loc.exp || '-')}</div></div>
            <div><label>Shelf</label><div style="color:var(--primary);">${this._escapeHtml(loc.shelf || '-')}</div></div>
            <div><label>Stock</label><div style="color:var(--green);">${loc.qty || 0}</div></div>
          </div>
          <button type="button" class="prod-loc-remove" onclick="window._deleteLoc(${i})">Remove</button>
        </div>
      `).join('');

      if (p.locations.length === 0) locListHtml = `<div class="prod-empty-box">No locations mapped yet.</div>`;

      locateOverlay.innerHTML = `
        <div class="prod-sub-dialog" style="max-width:480px;" onclick="event.stopPropagation()">
          <div class="prod-sub-header">
            <div>
              <h3>Warehouse Mapping</h3>
              <p>${this._escapeHtml(p.prodName)}</p>
            </div>
            <button type="button" class="prod-sub-close" onclick="document.getElementById('locate-manager-overlay').remove()">Close</button>
          </div>
          <div class="prod-sub-body">
            <div class="prod-metric-bar">
              <span>Total Inventory</span>
              <strong>${totalInLocs} units</strong>
            </div>
            <div style="max-height:45vh; overflow-y:auto;">${locListHtml}</div>
            <div style="margin-top:18px; display:grid; grid-template-columns:1fr 1fr; gap:10px;">
              <button type="button" id="add-loc-btn" class="prod-secondary-btn">+ New Location</button>
              <button type="button" id="save-loc-btn" class="prod-primary-btn">Sync & Close</button>
            </div>
          </div>
        </div>
      `;

      const existing = document.getElementById('locate-manager-overlay');
      if (existing) existing.remove();
      document.body.appendChild(locateOverlay);

      document.getElementById('add-loc-btn').onclick = () => {
        const bn = prompt("Enter Batch Number:", "");
        const exp = prompt("Enter Expiry Date (DD/MM/YYYY):", "");
        const shelf = prompt("Enter Shelf Location:", "");
        const qty = prompt("Enter Stock Quantity:", "");
        if (qty !== null && !isNaN(qty)) {
          p.locations.push({
            bn: bn || 'N/A',
            exp: exp || 'N/A',
            shelf: shelf || 'N/A',
            qty: Number(qty)
          });
          renderLocateUI();
        }
      };

      document.getElementById('save-loc-btn').onclick = async () => {
        p.qty = p.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
        p.updatedAt = new Date().toISOString();
        this._addLog(p, 'Locate Update', `Updated mapping. Total Qty synced to ${p.qty}`);
        document.getElementById('save-loc-btn').innerText = "Syncing...";
        await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG')));
        document.getElementById('locate-manager-overlay').remove();
        this.renderList();
      };
    };

    window._deleteLoc = (i) => {
      if (confirm("Remove this location mapping?")) {
        p.locations.splice(i, 1);
        renderLocateUI();
      }
    };

    renderLocateUI();
  },
  handleStats: function(index) {
    const p = this._data[index];
    const isAdmin = this._isAdmin();
    const stockValue = (p.qty * (p.price || 0)).toFixed(2);
    const stockHealth = Math.min(Math.max((p.qty / (p.minStock * 3)) * 100, 10), 100);
    const healthColor = p.qty <= p.minStock ? 'var(--danger)' : (p.qty <= p.minStock * 1.5 ? 'var(--amber)' : 'var(--green)');

    let adminInsightHtml = '';
    if (isAdmin && p.cost) {
      const unitProfit = (p.price - p.cost).toFixed(2);
      const margin = ((unitProfit / p.price) * 100).toFixed(1);
      const totalPotentialProfit = (unitProfit * p.qty).toFixed(2);
      adminInsightHtml = `
        <div class="prod-sub-section prod-dashed-top">
          <div class="prod-sub-section-title">Financial Insight (Admin Only)</div>
          <div class="prod-sub-grid-2">
            <div class="prod-info-tile"><div class="label">Est. Margin</div><div class="val" style="color:var(--green);">${margin}%</div></div>
            <div class="prod-info-tile"><div class="label">Total Profit</div><div class="val" style="color:var(--primary);">$${totalPotentialProfit}</div></div>
          </div>
        </div>
      `;
    }

    const statsOverlay = document.createElement('div');
    statsOverlay.id = "stats-viewer-overlay";
    statsOverlay.className = "prod-sub-overlay";
    statsOverlay.onclick = (e) => { if (e.target === statsOverlay) statsOverlay.remove(); };
    statsOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:440px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Performance Stats</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('stats-viewer-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-summary-banner">
            <div>
              <div class="prod-summary-label">Current Inventory Value</div>
              <div class="prod-summary-value">$${stockValue}</div>
              <div class="prod-summary-pill">Unit: $${parseFloat(p.price || 0).toFixed(2)}</div>
            </div>
          </div>
          <div style="margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
              <span style="font-size:13px; font-weight:600; color:var(--text-secondary);">Stock Health</span>
              <span style="font-size:13px; font-weight:700; color:${healthColor}">${p.qty > p.minStock ? 'Healthy' : 'Critical'}</span>
            </div>
            <div style="width:100%; height:8px; background:var(--surface-soft); border:1px solid var(--border); border-radius:4px; overflow:hidden;">
              <div style="width:${stockHealth}%; height:100%; background:${healthColor};"></div>
            </div>
            <p style="font-size:12px; color:var(--text-dim); margin-top:6px;">Minimum required: ${p.minStock} units</p>
          </div>
          <div class="prod-info-tile" style="margin-bottom:16px;">
            <div class="label">Inventory Advice</div>
            <div class="val" style="font-size:13px; font-weight:500; margin-top:4px;">${p.qty <= p.minStock ? 'Immediate restock required.' : 'Stock level is optimal.'}</div>
          </div>
          ${adminInsightHtml}
        </div>
      </div>
    `;
    document.body.appendChild(statsOverlay);
  },
  handlePromo: function(index) {
    const p = this._data[index];

    const promoOverlay = document.createElement('div');
    promoOverlay.id = "promo-manager-overlay";
    promoOverlay.className = "prod-sub-overlay";
    promoOverlay.onclick = (e) => { if (e.target === promoOverlay) promoOverlay.remove(); };
    promoOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:420px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Price Promotion</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('promo-manager-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-metric-bar" style="margin-bottom:18px;">
            <span>Original Price</span>
            <strong>$${parseFloat(p.price || 0).toFixed(2)}</strong>
          </div>
          <div style="margin-bottom:18px;">
            <label style="display:block; font-size:12px; font-weight:600; color:var(--text-secondary); margin-bottom:8px;">Quick Discounts</label>
            <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:8px;">
              <button type="button" class="prod-mini-btn" onclick="document.getElementById('promo-price-input').value = (${p.price} * 0.9).toFixed(2)">-10%</button>
              <button type="button" class="prod-mini-btn" onclick="document.getElementById('promo-price-input').value = (${p.price} * 0.8).toFixed(2)">-20%</button>
              <button type="button" class="prod-mini-btn" onclick="document.getElementById('promo-price-input').value = (${p.price} * 0.7).toFixed(2)">-30%</button>
              <button type="button" class="prod-mini-btn danger" onclick="document.getElementById('promo-price-input').value = (${p.price} * 0.5).toFixed(2)">-50%</button>
            </div>
          </div>
          <div class="form-field" style="margin-bottom:20px;">
            <label>Set New Price ($)</label>
            <input type="number" id="promo-price-input" step="0.01" value="${p.price}" class="field-input" style="font-size:16px; font-weight:700;">
          </div>
          <button type="button" id="confirm-promo-btn" class="prod-primary-btn" style="width:100%;">Update Price</button>
        </div>
      </div>
    `;
    document.body.appendChild(promoOverlay);

    const input = document.getElementById('promo-price-input');
    const btn = document.getElementById('confirm-promo-btn');

    btn.onclick = async () => {
      const newPrice = parseFloat(input.value);
      if (isNaN(newPrice) || newPrice < 0) return alert("Please enter a valid price.");
      const oldPrice = p.price;
      if (!confirm(`Change price from $${oldPrice} to $${newPrice}?`)) return;

      btn.innerText = "Syncing...";
      btn.disabled = true;

      p.price = newPrice;
      p.updatedAt = new Date().toISOString();

      this._addLog(p, 'Price Change', `$${oldPrice} -> $${newPrice} (Promo)`);
      await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG')));
      document.getElementById('promo-manager-overlay').remove();
      this.closeMoreMenu();
      this.renderList();
    };
  },
  executePrint: function(p) {
    const printConfigOverlay = document.createElement('div');
    printConfigOverlay.id = "print-config-overlay";
    printConfigOverlay.className = "prod-sub-overlay";
    printConfigOverlay.onclick = (e) => { if (e.target === printConfigOverlay) printConfigOverlay.remove(); };
    printConfigOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:400px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Print Label Settings</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('print-config-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="form-field" style="margin-bottom:14px;">
            <label>Dimensions (Width x Height) mm</label>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
              <input type="number" id="print-w" value="80" class="field-input">
              <input type="number" id="print-h" value="50" class="field-input">
            </div>
          </div>
          <div class="form-field" style="margin-bottom:20px;">
            <label>Number of Copies</label>
            <input type="number" id="print-qty" value="1" min="1" class="field-input">
          </div>
          <button type="button" id="start-print-btn" class="prod-primary-btn" style="width:100%;">Print Now</button>
        </div>
      </div>
    `;
    document.body.appendChild(printConfigOverlay);

    document.getElementById('start-print-btn').onclick = () => {
      const w = document.getElementById('print-w').value || 80;
      const h = document.getElementById('print-h').value || 50;
      const copies = parseInt(document.getElementById('print-qty').value) || 1;

      const printWin = window.open('', '_blank', `width=${w*4},height=${h*4}`);
      let labelsHtml = '';
      for (let i = 0; i < copies; i++) {
        labelsHtml += `
          <div class="label-page" style="width:${w}mm; height:${h}mm; padding:5mm; box-sizing:border-box; border:1px dashed #ccc; margin-bottom:10px; page-break-after:always; display:flex; flex-direction:column; justify-content:center; align-items:center; font-family:sans-serif; text-align:center;">
            <div style="font-size:14px; font-weight:bold; margin-bottom:4px;">${p.prodName}</div>
            <div style="font-size:10px; color:#666;">SKU: ${p.sku || 'N/A'}</div>
            <div style="font-size:18px; font-weight:900; margin-top:8px;">$${parseFloat(p.price || 0).toFixed(2)}</div>
            <div style="font-size:8px; margin-top:5px; color:#999;">Printed: ${new Date().toLocaleDateString()}</div>
          </div>
        `;
      }
      printWin.document.write(`
        <html><head><style>body { margin: 0; padding: 0; } @media print { body { margin: 0; } .label-page { border: none !important; margin: 0 !important; } }</style></head>
        <body>${labelsHtml}</body></html>
      `);
      printWin.document.close();
      printWin.focus();
      setTimeout(() => {
        printWin.print();
        printWin.close();
        document.getElementById('print-config-overlay').remove();
      }, 250);
    };
  },
  handleSold: function(index) {
    const p = this._data[index];
    const logs = p.history || [];
    const totalSold = logs.filter(l => l.action === 'Sold Out').reduce((sum, l) => {
      const match = l.details.match(/-?\d+/);
      return sum + (match ? Math.abs(parseInt(match[0])) : 0);
    }, 0);

    const soldOverlay = document.createElement('div');
    soldOverlay.id = "sold-manager-overlay";
    soldOverlay.className = "prod-sub-overlay";
    soldOverlay.onclick = (e) => { if (e.target === soldOverlay) soldOverlay.remove(); };
    soldOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:420px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Register Sale</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('sold-manager-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-metric-bar" style="margin-bottom:18px;">
            <div>
              <div class="label">On Hand</div>
              <div class="val">${p.qty}</div>
            </div>
            <div style="text-align:right;">
              <div class="label">Lifetime Sold</div>
              <div class="val" style="color:var(--primary);">${totalSold}</div>
            </div>
          </div>
          <div class="form-field" style="margin-bottom:20px;">
            <label>Quantity to Sell</label>
            <input type="number" id="sale-qty-input" placeholder="0" min="1" max="${p.qty}" class="field-input">
            <p id="sale-warning" style="color:var(--danger); font-size:12px; margin-top:6px; display:none;">Not enough stock!</p>
          </div>
          <button type="button" id="confirm-sale-btn" class="prod-primary-btn" style="width:100%;">Confirm Sale</button>
        </div>
      </div>
    `;
    document.body.appendChild(soldOverlay);

    const input = document.getElementById('sale-qty-input');
    const btn = document.getElementById('confirm-sale-btn');
    const warning = document.getElementById('sale-warning');

    btn.onclick = async () => {
      const sellQty = parseInt(input.value);
      if (!sellQty || sellQty <= 0) return alert("Please enter a valid quantity.");
      if (sellQty > p.qty) {
        warning.style.display = 'block';
        return;
      }

      const totalAmount = (sellQty * (p.price || 0)).toFixed(2);
      if (!confirm(`Confirm sale of ${sellQty} units for $${totalAmount}?`)) return;

      btn.innerText = "Processing...";
      btn.disabled = true;

      const oldQty = p.qty;
      p.qty = oldQty - sellQty;
      p.updatedAt = new Date().toISOString();

      this._addLog(p, 'Sold Out', `Qty: ${oldQty} -> ${p.qty} (-${sellQty}) | Revenue: $${totalAmount}`);
      await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG')));
      document.getElementById('sold-manager-overlay').remove();
      this.closeMoreMenu();
      this.renderList();
    };
  },
  handleInflow: function(index) {
    const p = this._data[index];
    const logs = p.history || [];
    const inflowLogs = logs.filter(l => l.action === 'Stock In');

    let avgRestockDays = "N/A", lastRestockDate = "None", frequency = "Low";

    if (inflowLogs.length >= 2) {
      const dates = inflowLogs.map(l => new Date(l.time));
      let totalDiff = 0;
      for (let i = 1; i < dates.length; i++) {
        totalDiff += (dates[i] - dates[i-1]);
      }
      const avgMs = totalDiff / (dates.length - 1);
      avgRestockDays = (avgMs / (1000 * 60 * 60 * 24)).toFixed(1) + " days";
      frequency = (avgMs / (1000 * 60 * 60 * 24)) < 15 ? "High" : "Normal";
    }

    if (inflowLogs.length > 0) {
      lastRestockDate = new Date(inflowLogs[inflowLogs.length - 1].time).toLocaleDateString();
    }

    const inflowOverlay = document.createElement('div');
    inflowOverlay.id = "inflow-overlay";
    inflowOverlay.className = "prod-sub-overlay";
    inflowOverlay.onclick = (e) => { if (e.target === inflowOverlay) inflowOverlay.remove(); };
    inflowOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:420px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Inflow Analysis</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('inflow-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-sub-grid-2">
            <div class="prod-info-tile">
              <div class="label">Avg Cycle</div>
              <div class="val">${avgRestockDays}</div>
            </div>
            <div class="prod-info-tile">
              <div class="label">Frequency</div>
              <div class="val">${frequency}</div>
            </div>
          </div>
          <div class="prod-info-tile" style="margin-top:12px;">
            <div class="label">Last Restock</div>
            <div class="val" style="font-size:14px;">${lastRestockDate}</div>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(inflowOverlay);
  },
  handleExpiry: function(index) {
    const p = this._data[index];
    const currentExp = p.expiryDate || "";

    let statusHtml = '<span style="color:var(--text-dim); font-weight:600;">Not Set</span>';
    if (p.expiryDate) {
      const parts = p.expiryDate.split('/');
      if (parts.length === 3) {
        const [d, m, y] = parts;
        const expDate = new Date(y, m - 1, d);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const diffDays = Math.ceil((expDate - today) / (1000 * 60 * 60 * 24));
        if (diffDays < 0) statusHtml = `<span class="prod-status-badge status-low">EXPIRED</span>`;
        else if (diffDays <= 90) statusHtml = `<span class="prod-status-badge status-warn">EXPIRING SOON</span>`;
        else statusHtml = `<span class="prod-status-badge status-ok">Safe</span>`;
      }
    }

    const expOverlay = document.createElement('div');
    expOverlay.id = "exp-editor-overlay";
    expOverlay.className = "prod-sub-overlay";
    expOverlay.onclick = (e) => { if (e.target === expOverlay) expOverlay.remove(); };
    expOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:420px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Expiry Date</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('exp-editor-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body">
          <div class="prod-metric-bar" style="margin-bottom:18px;">
            <span>Current Status</span>
            <div>${statusHtml}</div>
          </div>
          <div class="form-field" style="margin-bottom:20px;">
            <label>Expiry Date (DD/MM/YYYY)</label>
            <input type="text" id="new-exp-input" placeholder="DD/MM/YYYY" value="${this._escapeHtml(currentExp)}" class="field-input">
          </div>
          <button type="button" id="exp-save-btn" class="prod-primary-btn" style="width:100%;">Update Date</button>
        </div>
      </div>
    `;
    document.body.appendChild(expOverlay);

    document.getElementById('exp-save-btn').onclick = async () => {
      const newExp = document.getElementById('new-exp-input').value.trim();
      if (newExp !== "" && !/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(newExp)) {
        return alert("Invalid format! Use DD/MM/YYYY");
      }

      this._addLog(p, 'Expiry Update', `${p.expiryDate || 'None'} -> ${newExp || 'Removed'}`);
      p.expiryDate = newExp;
      await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG')));
      document.getElementById('exp-editor-overlay').remove();
      this.openMoreMenu(index);
    };
  },
  showLogs: function(index) {
    const p = this._data[index];
    const logs = p.history || [];

    const logHtml = logs.length > 0 ?
      logs.slice().reverse().map(l => `
        <div class="prod-log-item">
          <div class="prod-log-meta">
            <span>${new Date(l.time).toLocaleString()}</span>
            <span class="prod-log-user">${this._escapeHtml(l.user)}</span>
          </div>
          <div class="prod-log-action">${this._escapeHtml(l.action)}</div>
          <div class="prod-log-details">${this._escapeHtml(l.details)}</div>
        </div>
      `).join('') :
      '<div class="prod-empty-box">No historical logs found.</div>';

    const logOverlay = document.createElement('div');
    logOverlay.id = "log-viewer-overlay";
    logOverlay.className = "prod-sub-overlay";
    logOverlay.style.zIndex = "55000";
    logOverlay.onclick = (e) => { if (e.target === logOverlay) logOverlay.remove(); };
    logOverlay.innerHTML = `
      <div class="prod-sub-dialog" style="max-width:460px;" onclick="event.stopPropagation()">
        <div class="prod-sub-header">
          <div>
            <h3>Activity Logs</h3>
            <p>${this._escapeHtml(p.prodName)}</p>
          </div>
          <button type="button" class="prod-sub-close" onclick="document.getElementById('log-viewer-overlay').remove()">Close</button>
        </div>
        <div class="prod-sub-body" style="padding:12px 22px;">${logHtml}</div>
      </div>
    `;
    document.body.appendChild(logOverlay);
  },
  render: async function(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const styleId = 'product-modern-styles';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        :root {
          --primary: #4f46e5;
          --primary-dark: #4338ca;
          --primary-light: #6366f1;
          --primary-soft: rgba(79, 70, 229, 0.08);
          --primary-glow: rgba(79, 70, 229, 0.2);
          --bg: #f8fafc;
          --surface: #ffffff;
          --surface-soft: #f8fafc;
          --text: #0f172a;
          --text-secondary: #475569;
          --text-dim: #94a3b8;
          --border: #e2e8f0;
          --border-strong: #cbd5e1;
          --danger: #ef4444;
          --red-soft: rgba(239, 68, 68, 0.08);
          --green: #10b981;
          --green-soft: rgba(16, 185, 129, 0.08);
          --amber: #f59e0b;
          --amber-soft: rgba(245, 158, 11, 0.08);
          --radius-card: 16px;
          --radius-lg: 14px;
          --radius-md: 10px;
          --radius-sm: 8px;
          --radius-xs: 6px;
          --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
          --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
          --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
          --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
          --transition-fast: 0.15s ease;
          --transition-base: 0.25s ease;
          --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        }

        * {
          box-sizing: border-box;
          -webkit-tap-highlight-color: transparent;
        }

        .product-wrapper {
          max-width: 1400px;
          margin: 0 auto;
          padding: 24px;
          font-family: var(--font-sans);
          background: var(--bg);
          min-height: 100vh;
          color: var(--text);
          -webkit-font-smoothing: antialiased;
          width: 100%;
        }

        .header-flex {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 24px;
          gap: 16px;
          flex-wrap: wrap;
        }

        .header-flex h2 {
          margin: 0;
          font-size: 26px;
          font-weight: 700;
          letter-spacing: -0.025em;
          color: var(--text);
        }

        .prod-header-actions {
          display: flex;
          gap: 10px;
          align-items: center;
          flex-wrap: wrap;
        }

        .search-input-wrapper {
          position: relative;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          padding: 0 14px;
          display: flex;
          align-items: center;
          height: 40px;
          min-width: 220px;
          transition: all var(--transition-fast);
          box-shadow: var(--shadow-xs);
        }

        .search-input-wrapper:focus-within {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px var(--primary-glow);
        }

        .icon-search {
          color: var(--text-dim);
          flex-shrink: 0;
        }

        .search-input-alt {
          border: none;
          outline: none;
          width: 100%;
          font-size: 13px;
          background: transparent;
          padding-left: 10px;
          color: var(--text);
          font-family: var(--font-sans);
        }

        .cat-select-alt {
          height: 40px;
          padding: 0 14px;
          border-radius: var(--radius-md);
          border: 1px solid var(--border);
          background: var(--surface);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          color: var(--text-secondary);
          font-family: var(--font-sans);
          box-shadow: var(--shadow-xs);
          outline: none;
          transition: all var(--transition-fast);
        }

        .cat-select-alt:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px var(--primary-glow);
        }

        .header-flex button {
          background: var(--primary);
          color: white;
          border: 1px solid transparent;
          padding: 0 18px;
          height: 40px;
          border-radius: var(--radius-md);
          font-weight: 600;
          font-size: 13px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all var(--transition-fast);
          box-shadow: var(--shadow-primary);
          white-space: nowrap;
          font-family: var(--font-sans);
        }

        .header-flex button:hover {
          background: var(--primary-dark);
          transform: translateY(-1px);
        }

        .header-flex button:active {
          transform: translateY(0);
        }

        .product-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 20px;
        }

        .product-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 20px;
          transition: all var(--transition-fast);
          cursor: pointer;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          gap: 14px;
          box-shadow: var(--shadow-xs);
          position: relative;
        }

        .product-card:hover {
          border-color: var(--border-strong);
          box-shadow: var(--shadow-md);
          transform: translateY(-2px);
        }

        .prod-card-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
        }

        .no-badge {
          font-family: monospace;
          font-size: 12px;
          font-weight: 600;
          color: var(--text-secondary);
          background: var(--surface-soft);
          padding: 3px 8px;
          border-radius: var(--radius-xs);
          border: 1px solid var(--border);
        }

        .stock-badge {
          display: inline-block;
          padding: 4px 10px;
          border-radius: var(--radius-sm);
          font-size: 11px;
          font-weight: 600;
        }

        .status-low {
          background: var(--red-soft);
          color: var(--danger);
        }

        .status-ok {
          background: var(--green-soft);
          color: var(--green);
        }

        .status-warn {
          background: var(--amber-soft);
          color: var(--amber);
        }

        .prod-card-title {
          font-size: 16px;
          font-weight: 700;
          color: var(--text);
          margin-top: 10px;
          line-height: 1.35;
          word-break: break-word;
        }

        .prod-card-sku {
          margin-top: 6px;
          display: inline-block;
          font-size: 12px;
          font-weight: 500;
          color: var(--text-secondary);
          background: var(--surface-soft);
          padding: 2px 8px;
          border-radius: var(--radius-xs);
          border: 1px solid var(--border);
          word-break: break-word;
        }

        .prod-card-price-box {
          margin-top: 12px;
          padding-top: 12px;
          border-top: 1px solid var(--border);
        }

        .price-tag {
          font-size: 18px;
          font-weight: 700;
          color: var(--primary);
          line-height: 1.2;
        }

        .rsp-tag {
          font-size: 12px;
          text-decoration: line-through;
          color: var(--text-dim);
          font-weight: 500;
          margin-bottom: 2px;
        }

        .more-btn {
          padding: 9px 14px;
          background: var(--surface-soft);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          text-align: center;
          color: var(--text-secondary);
          font-size: 12px;
          font-weight: 600;
          transition: all var(--transition-fast);
          cursor: pointer;
          font-family: var(--font-sans);
        }

        .more-btn:hover {
          background: var(--primary-soft);
          color: var(--primary);
          border-color: var(--primary);
        }

        #product-more-overlay {
          position: fixed;
          inset: 0;
          z-index: 50000;
          background: rgba(15, 23, 42, 0.55);
          display: none;
          align-items: center;
          justify-content: center;
          padding: 20px;
          width: 100vw;
          height: 100vh;
          height: 100dvh;
        }

        .more-container {
          background: var(--surface);
          width: 100%;
          max-width: 520px;
          border-radius: var(--radius-card);
          border: 1px solid var(--border);
          padding: 24px;
          box-shadow: var(--shadow-lg);
          position: relative;
          max-height: 90vh;
          overflow-y: auto;
        }

        .more-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
          margin-top: 20px;
        }

        @media (min-width: 540px) {
          .more-grid {
            grid-template-columns: repeat(3, 1fr);
          }
        }

        .more-item {
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--surface-soft);
          padding: 14px 12px;
          border-radius: var(--radius-md);
          text-align: center;
          cursor: pointer;
          border: 1px solid var(--border);
          transition: all var(--transition-fast);
          font-size: 13px;
          font-weight: 600;
          color: var(--text);
          word-break: break-word;
        }

        .more-item:hover {
          background: var(--primary-soft);
          border-color: var(--primary);
          color: var(--primary-dark);
        }

        #product-editor-modal {
          display: none;
          position: fixed;
          inset: 0;
          z-index: 99999;
          background: var(--bg);
          width: 100vw;
          height: 100vh;
          height: 100dvh;
          flex-direction: column;
        }

        #product-editor-modal.active {
          display: flex;
        }

        .prod-editor-nav {
          background: var(--surface);
          border-bottom: 1px solid var(--border);
          padding: 16px 28px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-shrink: 0;
          gap: 14px;
          flex-wrap: wrap;
          box-shadow: var(--shadow-xs);
        }

        .prod-editor-nav-left {
          display: flex;
          align-items: center;
          gap: 14px;
          min-width: 0;
          flex: 1;
        }

        .prod-editor-nav-left h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: var(--text);
          word-break: break-word;
        }

        .prod-editor-nav-right {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }

        .prod-back-btn {
          background: var(--surface-soft);
          border: 1px solid var(--border);
          width: 38px;
          height: 38px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all var(--transition-fast);
          color: var(--text-secondary);
          flex-shrink: 0;
        }

        .prod-back-btn:hover {
          background: var(--border);
          color: var(--text);
        }

        .prod-nav-close {
          background: var(--surface);
          border: 1px solid var(--border);
          height: 36px;
          padding: 0 14px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          color: var(--text-secondary);
          transition: all var(--transition-fast);
          font-family: var(--font-sans);
        }

        .prod-nav-close:hover {
          background: var(--surface-soft);
          color: var(--text);
          border-color: var(--border-strong);
        }

        .prod-nav-delete {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--danger);
          height: 36px;
          padding: 0 14px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          font-family: var(--font-sans);
        }

        .prod-nav-delete:hover {
          background: var(--red-soft);
          border-color: var(--danger);
        }

        .prod-nav-save {
          background: var(--primary);
          color: white;
          border: 1px solid transparent;
          height: 36px;
          padding: 0 18px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          box-shadow: var(--shadow-primary);
          font-family: var(--font-sans);
        }

        .prod-nav-save:hover {
          background: var(--primary-dark);
        }

        .prod-editor-scroll {
          flex: 1;
          overflow-y: auto;
          padding: 28px 20px;
          width: 100%;
        }

        .prod-editor-container {
          max-width: 920px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 20px;
          width: 100%;
        }

        .form-card {
          background: var(--surface);
          padding: 22px;
          border-radius: var(--radius-card);
          border: 1px solid var(--border);
          box-shadow: var(--shadow-xs);
        }

        .prod-card-heading {
          display: block;
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--text-secondary);
          margin-bottom: 16px;
        }

        .form-grid-alt {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }

        .form-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
          min-width: 0;
        }

        .form-field label {
          font-size: 12px;
          font-weight: 600;
          color: var(--text-secondary);
        }

        .field-input {
          height: 42px;
          padding: 0 14px;
          border-radius: var(--radius-md);
          border: 1px solid var(--border);
          font-size: 14px;
          width: 100%;
          background: var(--surface);
          transition: all var(--transition-fast);
          outline: none;
          color: var(--text);
          font-family: var(--font-sans);
        }

        .field-input:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px var(--primary-glow);
        }

        .prod-editor-footer {
          max-width: 920px;
          margin: 24px auto 0;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 16px 22px;
          display: flex;
          justify-content: flex-end;
          align-items: center;
          gap: 12px;
          box-shadow: var(--shadow-xs);
        }

        .prod-primary-btn {
          background: var(--primary);
          color: white;
          border: 1px solid transparent;
          height: 40px;
          padding: 0 22px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          box-shadow: var(--shadow-primary);
          font-family: var(--font-sans);
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        .prod-primary-btn:hover {
          background: var(--primary-dark);
        }

        .prod-secondary-btn {
          background: var(--surface);
          color: var(--text);
          border: 1px solid var(--border);
          height: 40px;
          padding: 0 18px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          font-family: var(--font-sans);
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        .prod-secondary-btn:hover {
          background: var(--surface-soft);
          border-color: var(--border-strong);
        }

        .prod-danger-btn {
          background: var(--surface);
          color: var(--danger);
          border: 1px solid var(--border);
          height: 40px;
          padding: 0 18px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          font-family: var(--font-sans);
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        .prod-danger-btn:hover {
          background: var(--red-soft);
          border-color: var(--danger);
        }

        .pagination-ctrl {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 12px;
          margin-top: 28px;
          flex-wrap: wrap;
        }

        .page-btn {
          height: 34px;
          padding: 0 14px;
          border-radius: var(--radius-sm);
          border: 1px solid var(--border);
          background: var(--surface);
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
          transition: all var(--transition-fast);
          color: var(--text-secondary);
          font-family: var(--font-sans);
        }

        .page-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }

        .page-btn:hover:not(:disabled) {
          border-color: var(--border-strong);
          color: var(--text);
          background: var(--surface-soft);
        }

        .prod-sub-overlay {
          position: fixed;
          inset: 0;
          background: rgba(15, 23, 42, 0.55);
          z-index: 50000;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          width: 100vw;
          height: 100vh;
          height: 100dvh;
        }

        .prod-sub-dialog {
          background: var(--surface);
          width: 100%;
          max-width: 640px;
          border-radius: var(--radius-card);
          border: 1px solid var(--border);
          box-shadow: var(--shadow-lg);
          max-height: 90vh;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .prod-sub-header {
          padding: 18px 22px;
          border-bottom: 1px solid var(--border);
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          background: var(--surface);
        }

        .prod-sub-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: var(--text);
          word-break: break-word;
        }

        .prod-sub-header p {
          margin: 4px 0 0;
          font-size: 13px;
          color: var(--text-secondary);
          word-break: break-word;
        }

        .prod-sub-close {
          background: var(--surface);
          border: 1px solid var(--border);
          height: 34px;
          padding: 0 12px;
          border-radius: var(--radius-md);
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          color: var(--text-secondary);
          font-family: var(--font-sans);
          flex-shrink: 0;
        }

        .prod-sub-close:hover {
          background: var(--surface-soft);
          color: var(--text);
        }

        .prod-sub-body {
          padding: 20px 22px;
          overflow-y: auto;
          flex: 1;
        }

        .prod-summary-banner {
          background: var(--primary);
          padding: 18px 20px;
          border-radius: var(--radius-card);
          margin-bottom: 20px;
          color: white;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          box-shadow: var(--shadow-primary);
        }

        .prod-summary-label {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          opacity: 0.85;
        }

        .prod-summary-value {
          font-size: 26px;
          font-weight: 700;
          margin-top: 2px;
        }

        .prod-summary-subvalue {
          font-size: 18px;
          font-weight: 700;
          margin-top: 2px;
        }

        .prod-summary-pill {
          display: inline-block;
          margin-top: 8px;
          background: rgba(255, 255, 255, 0.18);
          padding: 3px 10px;
          border-radius: var(--radius-sm);
          font-size: 12px;
          font-weight: 600;
        }

        .prod-summary-divider {
          width: 1px;
          height: 38px;
          background: rgba(255, 255, 255, 0.25);
        }

        .prod-sub-section {
          margin-bottom: 20px;
        }

        .prod-dashed-top {
          border-top: 1px dashed var(--border-strong);
          padding-top: 20px;
          margin-top: 20px;
        }

        .prod-sub-section-title {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--text-secondary);
          margin-bottom: 12px;
        }

        .prod-sub-grid-2 {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }

        .prod-supplier-group {
          margin-bottom: 14px;
          border-radius: var(--radius-lg);
          border: 1px solid var(--border);
          overflow: hidden;
          background: var(--surface);
        }

        .supplier-header {
          background: var(--surface-soft);
          padding: 12px 14px;
          cursor: pointer;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          font-size: 13px;
          font-weight: 600;
          border-bottom: 1px solid var(--border);
        }

        .supplier-header-left {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-wrap: wrap;
        }

        .supplier-pill {
          font-size: 11px;
          background: var(--primary-soft);
          padding: 2px 8px;
          border-radius: var(--radius-xs);
          color: var(--primary);
          font-weight: 600;
        }

        .supplier-header-right {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }

        .supplier-total {
          font-size: 12px;
          color: var(--primary);
          font-weight: 700;
        }

        .collapse-icon {
          font-size: 12px;
          color: var(--text-dim);
          transition: transform var(--transition-fast);
        }

        .prod-table-wrap {
          overflow-x: auto;
        }

        .prod-data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }

        .prod-data-table th {
          padding: 10px 12px;
          text-align: left;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          color: var(--text-secondary);
          background: var(--surface-soft);
          border-bottom: 1px solid var(--border);
        }

        .prod-data-table td {
          padding: 10px 12px;
          border-bottom: 1px solid var(--border);
          color: var(--text);
        }

        .prod-data-table tr:last-child td {
          border-bottom: none;
        }

        .prod-row-actions {
          display: inline-flex;
          gap: 6px;
        }

        .prod-mini-btn {
          height: 28px;
          padding: 0 10px;
          border-radius: var(--radius-xs);
          border: 1px solid var(--border);
          background: var(--surface-soft);
          color: var(--text-secondary);
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          font-family: var(--font-sans);
          transition: all var(--transition-fast);
        }

        .prod-mini-btn:hover {
          border-color: var(--primary);
          color: var(--primary);
          background: var(--primary-soft);
        }

        .prod-mini-btn.danger {
          color: var(--danger);
        }

        .prod-mini-btn.danger:hover {
          border-color: var(--danger);
          background: var(--red-soft);
        }

        .prod-status-badge {
          display: inline-block;
          padding: 3px 8px;
          border-radius: var(--radius-xs);
          font-size: 11px;
          font-weight: 600;
        }

        .prod-metric-bar {
          background: var(--surface-soft);
          border: 1px solid var(--border);
          padding: 12px 16px;
          border-radius: var(--radius-md);
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          font-size: 13px;
          color: var(--text-secondary);
        }

        .prod-metric-bar strong {
          font-size: 15px;
          color: var(--text);
        }

        .prod-metric-bar .label {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          color: var(--text-secondary);
        }

        .prod-metric-bar .val {
          font-size: 18px;
          font-weight: 700;
          color: var(--text);
          margin-top: 2px;
        }

        .prod-info-tile {
          background: var(--surface-soft);
          border: 1px solid var(--border);
          padding: 12px 14px;
          border-radius: var(--radius-md);
        }

        .prod-info-tile .label {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          color: var(--text-secondary);
        }

        .prod-info-tile .val {
          font-size: 16px;
          font-weight: 700;
          color: var(--text);
          margin-top: 4px;
        }

        .prod-loc-card {
          background: var(--surface-soft);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 14px;
          margin-bottom: 10px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
        }

        .prod-loc-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px 16px;
          flex: 1;
        }

        .prod-loc-grid label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          color: var(--text-dim);
          display: block;
        }

        .prod-loc-grid div {
          font-size: 13px;
          font-weight: 600;
          color: var(--text);
        }

        .prod-loc-remove {
          height: 30px;
          padding: 0 10px;
          border-radius: var(--radius-xs);
          border: 1px solid var(--border);
          background: var(--surface);
          color: var(--danger);
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          font-family: var(--font-sans);
          flex-shrink: 0;
        }

        .prod-loc-remove:hover {
          background: var(--red-soft);
          border-color: var(--danger);
        }

        .prod-log-item {
          padding: 12px 0;
          border-bottom: 1px solid var(--border);
          font-size: 13px;
        }

        .prod-log-item:last-child {
          border-bottom: none;
        }

        .prod-log-meta {
          display: flex;
          justify-content: space-between;
          gap: 8px;
          color: var(--text-dim);
          font-size: 11px;
          margin-bottom: 4px;
        }

        .prod-log-user {
          font-weight: 600;
          color: var(--primary);
        }

        .prod-log-action {
          font-weight: 700;
          color: var(--text);
        }

        .prod-log-details {
          color: var(--text-secondary);
          margin-top: 2px;
          word-break: break-word;
        }

        .prod-empty-box {
          text-align: center;
          padding: 28px 16px;
          background: var(--surface-soft);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          color: var(--text-dim);
          font-size: 13px;
        }

        @media (max-width: 768px) {
          .product-wrapper {
            padding: 16px;
          }
          .header-flex {
            flex-direction: column;
            align-items: stretch;
          }
          .prod-header-actions {
            flex-direction: column;
            align-items: stretch;
          }
          .search-input-wrapper {
            width: 100%;
            min-width: 0;
          }
          .cat-select-alt {
            width: 100%;
          }
          .header-flex button {
            width: 100%;
          }
          .product-grid {
            grid-template-columns: 1fr;
            gap: 14px;
          }
          .product-card {
            padding: 18px;
            border-radius: var(--radius-lg);
          }
          .form-grid-alt,
          .prod-sub-grid-2 {
            grid-template-columns: 1fr;
          }
          .prod-editor-nav {
            padding: 14px 16px;
          }
          .prod-editor-nav-left h3 {
            font-size: 16px;
          }
          .prod-editor-scroll {
            padding: 18px 14px;
          }
          .form-card {
            padding: 18px;
            border-radius: var(--radius-lg);
          }
          .prod-editor-footer {
            flex-direction: column-reverse;
            align-items: stretch;
            padding: 14px 16px;
            border-radius: var(--radius-lg);
          }
          .prod-summary-banner {
            flex-direction: column;
            align-items: flex-start;
          }
          .prod-summary-divider {
            display: none;
          }
        }
      `;
      document.head.appendChild(style);
    }

    container.innerHTML = `
      <div class="product-wrapper">
        <div class="header-flex">
          <h2>Product Library</h2>
          <div class="prod-header-actions">
            <div class="search-input-wrapper">
              <svg class="icon-search" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" class="search-input-alt" placeholder="Search No, Name or SKU..." oninput="ProductModule.handleSearch(this.value)">
            </div>
            <select class="cat-select-alt" onchange="ProductModule.handleFilter(this.value)">
              <option value="All">All Categories</option>
              <option value="Raw Material">Raw Material</option>
              <option value="Finished Goods">Finished Goods</option>
              <option value="Other">Other...</option>
            </select>
            <button type="button" onclick="ProductModule.openEditor()">+ Add New</button>
          </div>
        </div>
        <div id="product-list-container" class="product-grid"></div>
        <div id="pagination-container" class="pagination-ctrl"></div>
      </div>

      <div id="product-more-overlay" onclick="ProductModule.closeMoreMenu()">
        <div class="more-container" onclick="event.stopPropagation()">
          <div class="prod-sub-header" style="padding:0 0 16px 0; margin-bottom:0;">
            <div>
              <h3 id="more-menu-title">Product Actions</h3>
              <p id="more-menu-sku"></p>
            </div>
            <button type="button" class="prod-sub-close" onclick="ProductModule.closeMoreMenu()">Close</button>
          </div>
          <div id="more-actions-grid" class="more-grid"></div>
        </div>
      </div>

      <div id="product-editor-modal">
        <nav class="prod-editor-nav">
          <div class="prod-editor-nav-left">
            <button type="button" class="prod-back-btn" onclick="ProductModule.closeEditor()">
              <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <h3 id="product-form-title">Product Details</h3>
          </div>
          <div class="prod-editor-nav-right">
            <button type="button" class="prod-nav-close" onclick="ProductModule.closeEditor()">Close</button>
            <button type="button" id="prod-delete-btn" class="prod-nav-delete" onclick="ProductModule.deleteProduct()" style="display:none;">Delete</button>
            <button type="submit" form="product-form" class="prod-nav-save">Save</button>
          </div>
        </nav>

        <form id="product-form" class="prod-editor-scroll" onsubmit="ProductModule.saveData(event)">
          <div class="prod-editor-container">
            <div class="form-card">
              <label class="prod-card-heading">Basic Info</label>
              <div class="form-grid-alt">
                <div class="form-field" style="grid-column: 1 / -1;">
                  <label>Product Name</label>
                  <input type="text" name="prodName" required placeholder="Product Name" class="field-input">
                </div>
                <div class="form-field">
                  <label>SKU Code</label>
                  <input type="text" name="sku" placeholder="SKU Code" class="field-input">
                </div>
                <div class="form-field">
                  <label>Category</label>
                  <select name="catSelect" class="field-input" onchange="ProductModule.toggleOtherCat(this.value)">
                    <option value="Raw Material">Raw Material</option>
                    <option value="Finished Goods">Finished Goods</option>
                    <option value="Other">Other...</option>
                  </select>
                  <input type="text" id="cat-other-input" name="category" placeholder="Custom Category" class="field-input" style="display:none; margin-top:8px;">
                </div>
              </div>
            </div>

            <div class="form-card">
              <label class="prod-card-heading">Inventory & Price</label>
              <div class="form-grid-alt">
                <div class="form-field">
                  <label>Current Stock</label>
                  <input type="number" name="qty" placeholder="Current Stock" class="field-input">
                </div>
                <div class="form-field">
                  <label>Min Alert Qty</label>
                  <input type="number" name="minStock" placeholder="Min Alert Qty" class="field-input">
                </div>
                <div class="form-field">
                  <label>QTY Per Box (CTN)</label>
                  <input type="number" name="ctn" placeholder="QTY Per Box (CTN)" class="field-input">
                </div>
                <div class="form-field">
                  <label>Selling Price ($)</label>
                  <input type="number" step="0.01" name="price" placeholder="Selling Price ($)" class="field-input">
                </div>
                <div class="form-field">
                  <label>RSP (Market Price) $</label>
                  <input type="number" step="0.01" name="rsp" placeholder="RSP (Market Price) $" class="field-input">
                </div>
                <div class="form-field" id="admin-cost-field">
                  <label>Cost Price (Admin)</label>
                  <input type="number" step="0.01" name="cost" placeholder="Cost Price (Admin)" class="field-input">
                </div>
                <div class="form-field" id="admin-points-field">
                  <label>Points</label>
                  <input type="number" name="points" placeholder="Points" class="field-input">
                </div>
              </div>
            </div>

            <div class="form-card" id="admin-commission-field" style="display:none;">
              <label class="prod-card-heading">Commission Settings</label>
              <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
                <input type="checkbox" id="enable-commission" name="enableCommission" style="width:18px; height:18px; cursor:pointer;" onchange="document.getElementById('commission-input-wrapper').style.display = this.checked ? 'block' : 'none'">
                <label for="enable-commission" style="font-size:14px; font-weight:600; color:var(--text); cursor:pointer;">Enable Commission</label>
              </div>
              <div id="commission-input-wrapper" style="display:none;">
                <div class="form-field">
                  <label>Commission Percentage (%)</label>
                  <input type="number" name="commissionRate" step="0.1" placeholder="Enter commission percentage" class="field-input">
                </div>
              </div>
            </div>

            <div class="form-card" id="admin-extra-fields">
              <label class="prod-card-heading">Admin Extensions</label>
              <div class="form-grid-alt">
                <div class="form-field">
                  <label>Discount %</label>
                  <input type="number" step="0.1" name="discount" placeholder="Discount %" class="field-input">
                </div>
                <div class="form-field">
                  <label>Tax %</label>
                  <input type="number" step="0.1" name="tax" placeholder="Tax %" class="field-input">
                </div>
                <div class="form-field" style="grid-column: 1 / -1;">
                  <label>Service Charge %</label>
                  <input type="number" step="0.1" name="serviceCharge" placeholder="Service Charge %" class="field-input">
                </div>
              </div>
            </div>
          </div>

          <footer class="prod-editor-footer">
            <button type="submit" class="prod-primary-btn">Save Data</button>
          </footer>
        </form>
      </div>
    `;

    await this.loadFromCloud();
  },
  loadFromCloud: async function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (!config.ghToken || !config.ghRepo) return console.warn("GitHub Config missing");

    try {
      const res = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
        headers: {
          'Authorization': `token ${config.ghToken}`
        }
      });

      if (res.status === 404) {
        this._data = [];
        await this.syncToCloud(config, true);
        return;
      }

      const fileData = await res.json();
      this._sha = fileData.sha;
      const db = JSON.parse(decodeURIComponent(escape(atob(fileData.content))));
      this._data = db.products || [];
      this.renderList();
    } catch (e) {
      console.error("Cloud Load Error:", e);
    }
  },
  renderList: function() {
    const container = document.getElementById('product-list-container');
    const paginationContainer = document.getElementById('pagination-container');
    if (!container) return;

    this._totalFilteredData = this._data.map((p, index) => ({ ...p, _originalNo: index + 1 }))
      .filter(p => {
        const query = this._searchQuery.toLowerCase().replace('#', '');
        const matchNo = p._originalNo.toString() === query;
        const matchSearch = p.prodName.toLowerCase().includes(query) || (p.sku && p.sku.toLowerCase().includes(query));
        const matchCat = this._categoryFilter === 'All' || p.category === this._categoryFilter;
        return (matchNo || matchSearch) && matchCat;
      });

    const totalPages = Math.ceil(this._totalFilteredData.length / this._itemsPerPage);
    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const pageData = this._totalFilteredData.slice(startIndex, startIndex + this._itemsPerPage);

    if (this._totalFilteredData.length === 0) {
      container.innerHTML = '<div class="prod-empty-box" style="grid-column:1/-1; padding:60px 20px;">No products matching your search.</div>';
      paginationContainer.innerHTML = '';
      return;
    }

    container.innerHTML = pageData.map(p => {
      const isLow = Number(p.qty || 0) <= Number(p.minStock || 5);
      const idx = p._originalNo - 1;
      const hasRsp = p.rsp && Number(p.rsp) > Number(p.price);

      return `
        <div class="product-card">
          <div onclick="ProductModule.openEditor(${idx})">
            <div class="prod-card-top">
              <span class="no-badge">#${p._originalNo}</span>
              <span class="stock-badge ${isLow ? 'status-low' : 'status-ok'}">${p.qty || 0} In Stock</span>
            </div>
            <div class="prod-card-title">${this._escapeHtml(p.prodName)}</div>
            <div class="prod-card-sku">${this._escapeHtml(p.sku || 'No SKU')}</div>
            <div class="prod-card-price-box">
              ${hasRsp ? `<div class="rsp-tag">$${parseFloat(p.rsp).toFixed(2)}</div>` : ''}
              <div class="price-tag">$${parseFloat(p.price || 0).toFixed(2)}</div>
            </div>
          </div>
          <div class="more-btn" onclick="ProductModule.openMoreMenu(${idx})">Quick Actions</div>
        </div>
      `;
    }).join('');

    paginationContainer.innerHTML = `
      <button type="button" class="page-btn" onclick="ProductModule.changePage(-1)" ${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>
      <span style="font-weight:600; font-size:13px; color:var(--text-secondary);">Page ${this._currentPage} / ${totalPages || 1}</span>
      <button type="button" class="page-btn" onclick="ProductModule.changePage(1)" ${this._currentPage >= totalPages ? 'disabled' : ''}>Next</button>
    `;
  },
  openMoreMenu: function(index) {
    const p = this._data[index];
    const overlay = document.getElementById('product-more-overlay');
    const actionGrid = document.getElementById('more-actions-grid');

    document.getElementById('more-menu-title').innerText = p.prodName;

    const expDisplay = p.expiryDate ? `<br><span style="color:var(--danger); font-weight:600;">EXP: ${this._escapeHtml(p.expiryDate)}</span>` : "";
    document.getElementById('more-menu-sku').innerHTML = `SKU: ${this._escapeHtml(p.sku || 'N/A')} - Stock: ${p.qty}${expDisplay}`;

    const actions = [
      { label: 'Stock in', type: 'Stock In' },
      { label: 'In stock', type: 'Locate' },
      { label: 'Statistics', type: 'Stats' },
      { label: 'Promotion', type: 'Promo' },
      { label: 'Print Label', type: 'Print' },
      { label: 'Log', type: 'Logs' },
      { label: 'Sale', type: 'Sold' },
      { label: 'Cycle', type: 'Inflow' },
      { label: 'Exp', type: 'Old Exp' },
      { label: 'Sold', type: 'MonthlySales' }
    ];

    actionGrid.innerHTML = actions.map(act => `
      <div class="more-item" onclick="ProductModule.handleAction('${act.type}', ${index})">
        <span>${act.label}</span>
      </div>
    `).join('');

    overlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  },
  closeMoreMenu: function() {
    document.getElementById('product-more-overlay').style.display = 'none';
    document.body.style.overflow = 'auto';
  },
  changePage: function(step) {
    this._currentPage += step;
    this.renderList();
  },
  handleSearch: function(val) {
    this._searchQuery = val;
    this._currentPage = 1;
    this.renderList();
  },
  handleFilter: function(val) {
    this._categoryFilter = val;
    this._currentPage = 1;
    this.renderList();
  },
  openEditor: function(index = null) {
    const isAdmin = this._isAdmin();
    this._editingIndex = index;
    const modal = document.getElementById('product-editor-modal');
    const form = document.getElementById('product-form');
    form.reset();
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    document.getElementById('admin-cost-field').style.display = isAdmin ? 'flex' : 'none';
    document.getElementById('admin-points-field').style.display = isAdmin ? 'flex' : 'none';
    document.getElementById('admin-commission-field').style.display = isAdmin ? 'block' : 'none';
    document.getElementById('admin-extra-fields').style.display = isAdmin ? 'block' : 'none';
    document.getElementById('prod-delete-btn').style.display = (index !== null && isAdmin) ? 'inline-flex' : 'none';

    if (index !== null) {
      const p = this._data[index];
      form.prodName.value = p.prodName;
      form.sku.value = p.sku || '';
      form.qty.value = p.qty || 0;
      form.minStock.value = p.minStock || 5;
      form.ctn.value = p.ctn || '';
      form.price.value = p.price || '';
      form.rsp.value = p.rsp || '';
      form.cost.value = p.cost || '';
      form.points.value = p.points || '';
      form.discount.value = p.discount || '';
      form.tax.value = p.tax || '';
      form.serviceCharge.value = p.serviceCharge || '';

      if (isAdmin) {
        form.enableCommission.checked = !!p.enableCommission;
        form.commissionRate.value = p.commissionRate || '';
        document.getElementById('commission-input-wrapper').style.display = p.enableCommission ? 'block' : 'none';
      }

      if (["Raw Material", "Finished Goods"].includes(p.category)) {
        form.catSelect.value = p.category;
      } else {
        form.catSelect.value = "Other";
        document.getElementById('cat-other-input').value = p.category || "";
      }
      this.toggleOtherCat(form.catSelect.value);
    } else {
      document.getElementById('commission-input-wrapper').style.display = 'none';
    }
  },
  toggleOtherCat: function(val) {
    document.getElementById('cat-other-input').style.display = (val === 'Other') ? 'block' : 'none';
  },
  closeEditor: function() {
    document.getElementById('product-editor-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  saveData: async function(e) {
    e.preventDefault();

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const form = e.target;
    const isNew = this._editingIndex === null;
    const oldP = !isNew ? this._data[this._editingIndex] : {};
    const isAdmin = this._isAdmin();

    const commRate = (isAdmin && form.enableCommission.checked) ? Number(form.commissionRate.value) : 0;

    const productObj = {
      ...oldP,
      prodName: form.prodName.value,
      sku: form.sku.value,
      pos: commRate,
      category: form.catSelect.value === 'Other' ? form.category.value : form.catSelect.value,
      qty: Number(form.qty.value),
      minStock: Number(form.minStock.value),
      ctn: form.ctn.value,
      price: Number(form.price.value),
      rsp: form.rsp.value ? Number(form.rsp.value) : null,
      cost: Number(form.cost.value),
      points: form.points.value,
      discount: form.discount.value,
      tax: form.tax.value,
      serviceCharge: form.serviceCharge.value,
      ...(isAdmin && {
        enableCommission: form.enableCommission.checked,
        commissionRate: commRate
      }),
      updatedAt: new Date().toISOString()
    };

    const logMsg = isNew ? `New product created: ${productObj.prodName}` : `Product updated. Commission set to ${commRate}% via Window.pos`;
    this._addLog(productObj, isNew ? 'Created' : 'Updated', logMsg);

    if (!isNew) {
      this._data[this._editingIndex] = productObj;
    } else {
      this._data.push(productObj);
    }

    await this.syncToCloud(config);
  },
  deleteProduct: async function() {
    if (!confirm("Delete this product?")) return;
    const p = this._data[this._editingIndex];
    this._addLog(p, 'Deleted', `Product removed from library.`);
    this._data.splice(this._editingIndex, 1);
    await this.syncToCloud(JSON.parse(localStorage.getItem('ERP_CONFIG')));
    this.closeEditor();
    this.renderList();
  },
  syncToCloud: async function(config, isInitial = false) {
    try {
      if (!isInitial) {
        const getRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
          headers: {
            'Authorization': `token ${config.ghToken}`
          }
        });
        if (getRes.ok) {
          const getFileData = await getRes.json();
          this._sha = getFileData.sha;
        }
      }

      const putRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${config.ghToken}`
        },
        body: JSON.stringify({
          message: "Product Sync (Stock In batches editable/deletable, collapsible supplier groups)",
          content: btoa(unescape(encodeURIComponent(JSON.stringify({ products: this._data }, null, 2)))),
          sha: isInitial ? undefined : this._sha
        })
      });

      if (putRes.ok) {
        this.closeEditor();
        await this.loadFromCloud();
      } else {
        const errorData = await putRes.json();
        console.error("Sync Error:", errorData);
        alert("Sync Failed: " + (errorData.message || "Unknown error"));
      }
    } catch (e) {
      console.error("Sync Error:", e);
      alert("Sync Failed. Please check network/config.");
    }
  },
  processPurchaseStockIn: async function(po) {
    if (!po || !po.items || po.items.length === 0) return;
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    for (const item of po.items) {
      const product = this._data.find(p => p.prodName === item.name);
      if (!product) continue;
      if (!product.locations) product.locations = [];
      const existingLocation = product.locations.find(loc => loc.bn === item.bn && loc.company === po.supplierName);
      if (existingLocation) {
        existingLocation.qty = (Number(existingLocation.qty) || 0) + item.qty;
        if (item.exp) existingLocation.exp = item.exp;
        if (item.costPrice) existingLocation.costAtIn = item.costPrice;
      } else {
        product.locations.push({
          bn: item.bn || 'PO-' + po.id,
          exp: item.exp || 'N/A',
          shelf: 'Main Storage',
          qty: item.qty,
          company: po.supplierName || 'N/A',
          costAtIn: item.costPrice || product.cost
        });
      }
      if (item.costPrice) product.cost = item.costPrice;
      product.qty = product.locations.reduce((sum, loc) => sum + (Number(loc.qty) || 0), 0);
      product.updatedAt = new Date().toISOString();
      this._addLog(product, 'Stock In', `+${item.qty} units from PO ${po.id} | Batch: ${item.bn || 'N/A'} | Supplier: ${po.supplierName}`);
    }
    await this.syncToCloud(config);
    this.renderList();
  }
};

window.ProductModule = ProductModule;

const OrderModule = {
  _data: [],
  _products: [],
  _companies: [],
  _config: null,
  _currentId: null,
  _sha: null,
  _productFileName: 'db_date/product.json',
  _orderFileName: 'db_date/orders.json',
  _companyFileName: 'db_date/company.json',
  _currentPage: 1,
  _pageSize: 20,
  _searchTerm: '',
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!window.html2pdf) {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
      document.head.appendChild(script);
    }

    this._injectStyles();

    container.innerHTML = `
      <div class="ord-app-wrapper">
        <header class="ord-header">
          <div class="ord-brand">
            <h1>Orders & Procurement</h1>
            
          </div>
          <div class="ord-actions">
            <button type="button" class="ord-btn-primary" onclick="OrderModule.openEditor()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              <span>New Order</span>
            </button>
          </div>
        </header>

        <div class="ord-search-section">
          <div class="ord-search-inner">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="ord-search" placeholder="Search by product, customer, from/to or company..." oninput="OrderModule.handleSearch(this.value)">
          </div>
        </div>

        <main id="order-list" class="ord-grid"></main>

        <div id="ord-pagination" class="ord-pager"></div>
      </div>

      <div id="ord-modal" class="ord-modal">
        <div class="ord-modal-container">
          <div class="ord-modal-header">
            <button type="button" class="ord-btn-back" onclick="OrderModule.closeEditor()">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <div class="ord-modal-title">
              <h2 id="ord-modal-title">New Order</h2>
              <span id="ord-status-badge" class="ord-badge-status">DRAFT</span>
            </div>
            <div class="ord-modal-actions">
              <button type="submit" form="ord-form" class="ord-btn-save">Save</button>
            </div>
          </div>

          <div class="ord-modal-body">
            <form id="ord-form" class="ord-form" onsubmit="OrderModule.save(event)">
              <div class="ord-form-scroll">
                <div class="ord-form-inner">
                  <div class="ord-two-columns">
                    <div class="ord-card ord-sidebar">
                      <h3 class="ord-section-title">Basic Information</h3>
                      <div class="ord-field">
                        <label>Order Source (From)</label>
                        <input type="text" name="fromEntity" list="ord-company-list" placeholder="Shipping from...">
                      </div>
                      <div class="ord-field">
                        <label>Order Destination (To)</label>
                        <input type="text" name="toEntity" list="ord-company-list" placeholder="Shipping to...">
                      </div>
                      <div class="ord-field">
                        <label>Company / Branch (Handler)</label>
                        <input type="text" name="companyName" list="ord-company-list" required placeholder="Select entity...">
                        <datalist id="ord-company-list"></datalist>
                      </div>
                      <div class="ord-field">
                        <label>Category</label>
                        <select name="orderType" id="ord-type-select" onchange="OrderModule.toggleOrderType(this.value)">
                          <option value="supplier">Supplier Purchase</option>
                          <option value="customer">Customer Order</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div class="ord-field" id="other-type-field" style="display:none;">
                        <label>Other Enter</label>
                        <input type="text" name="customOrderType" placeholder="Enter Other...">
                      </div>
                      <div id="supplier-fields">
                        <div class="ord-field">
                          <label>Supplier</label>
                          <input type="text" name="supplier" placeholder="Vendor name">
                        </div>
                      </div>
                      <div id="customer-fields" style="display:none;">
                        <div class="ord-field">
                          <label>Customer</label>
                          <input type="text" name="customerName" placeholder="Name">
                        </div>
                        <div class="ord-field">
                          <label>Phone</label>
                          <input type="tel" name="customerPhone" placeholder="Contact number">
                        </div>
                      </div>
                      <div class="ord-row-grid">
                        <div class="ord-field">
                          <label>Order Date</label>
                          <input type="date" name="orderDate" id="orderDate" required>
                        </div>
                        <div class="ord-field">
                          <label>ETA</label>
                          <input type="date" name="etaDate">
                        </div>
                      </div>
                      <div class="ord-row-grid" style="margin-top: 4px;">
                        <div class="ord-field">
                          <label>Bank Name (Optional)</label>
                          <input type="text" name="bankName" id="ord-bank-name" placeholder="e.g. HSBC, ICBC">
                        </div>
                        <div class="ord-field">
                          <label>Bank Account No (Optional)</label>
                          <input type="text" name="bankAccount" id="ord-bank-account" placeholder="Account Number">
                        </div>
                      </div>
                    </div>

                    <div class="ord-card ord-main">
                      <div class="ord-card-header-flex">
                        <h3 class="ord-section-title" style="margin:0;">Order Items</h3>
                        <button type="button" class="ord-btn-add" onclick="OrderModule.addItem()">+ Add Product</button>
                      </div>
                      <div id="items-container" class="ord-items-list"></div>
                      <div class="ord-summary-box">
                        <div class="ord-total-row">
                          <span>Total Amount:</span>
                          <strong id="ord-total-val">$ 0.00</strong>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="ord-form-footer">
                <div class="ord-footer-content">
                  <button type="submit" class="ord-btn-submit">Finalize & Sync Order</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <datalist id="ord-product-list"></datalist>
    `;

    this._setDefaultDate();
    await this.load();
  },
  downloadPDF: function(id) {
    const ord = this._data.find(o => o.id === id);
    if (!ord) return;

    const total = ord.items?.reduce((sum, i) => sum + (i.qty * i.unitCost), 0) || 0;

    const element = document.createElement('div');
    element.style.padding = '40px';
    element.style.color = '#333';
    element.style.fontFamily = 'Arial, sans-serif';
    element.style.wordBreak = 'break-all';
    element.style.whiteSpace = 'normal';

    element.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #4f46e5; padding-bottom: 20px; margin-bottom: 30px; word-break: break-all; white-space: normal;">
        <div>
          <h1 style="margin: 0; color: #4f46e5; font-size: 28px; word-break: break-all; white-space: normal;">INVOICE / ORDER</h1>
          <p style="margin: 5px 0; color: #666; word-break: break-all; white-space: normal;">ID: ${ord.id}</p>
        </div>
        <div style="text-align: right; word-break: break-all; white-space: normal;">
          <h3 style="margin: 0; word-break: break-all; white-space: normal;">${ord.companyName || 'Main Office'}</h3>
          <p style="margin: 5px 0; word-break: break-all; white-space: normal;">Date: ${ord.orderDate}</p>
          <p style="margin: 0; font-weight: bold; color: #4f46e5; word-break: break-all; white-space: normal;">Type: ${ord.orderType.toUpperCase()}</p>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; word-break: break-all; white-space: normal;">
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; word-break: break-all; white-space: normal;">
          <h4 style="margin: 0 0 10px; color: #4f46e5; border-bottom: 1px solid #ddd; padding-bottom: 5px; word-break: break-all; white-space: normal;">FROM</h4>
          <p style="margin: 0; font-weight: bold; word-break: break-all; white-space: normal;">${ord.fromEntity || ord.companyName}</p>
          <p style="margin: 5px 0; font-size: 14px; color: #666; word-break: break-all; white-space: normal;">Supply Chain Division</p>
        </div>
        <div style="background: #f8fafc; padding: 15px; border-radius: 8px; word-break: break-all; white-space: normal;">
          <h4 style="margin: 0 0 10px; color: #4f46e5; border-bottom: 1px solid #ddd; padding-bottom: 5px; word-break: break-all; white-space: normal;">TO</h4>
          <p style="margin: 0; font-weight: bold; word-break: break-all; white-space: normal;">${ord.toEntity || ord.customerName || ord.supplier || 'N/A'}</p>
          <p style="margin: 5px 0; font-size: 14px; color: #666; word-break: break-all; white-space: normal;">Contact: ${ord.customerPhone || '-'}</p>
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; word-break: break-all; white-space: normal;">
        <thead>
          <tr style="background: #4f46e5; color: white;">
            <th style="padding: 12px; text-align: left; border: 1px solid #4f46e5; word-break: break-all; white-space: normal;">Code</th>
            <th style="padding: 12px; text-align: left; border: 1px solid #4f46e5; word-break: break-all; white-space: normal;">Product Name</th>
            <th style="padding: 12px; text-align: center; border: 1px solid #4f46e5; word-break: break-all; white-space: normal;">Qty</th>
            <th style="padding: 12px; text-align: right; border: 1px solid #4f46e5; word-break: break-all; white-space: normal;">Unit Cost</th>
            <th style="padding: 12px; text-align: right; border: 1px solid #4f46e5; word-break: break-all; white-space: normal;">Subtotal</th>
          </tr>
        </thead>
        <tbody>
          ${ord.items.map(i => `
            <tr>
              <td style="padding: 10px; border: 1px solid #eee; word-break: break-all; white-space: normal;">${i.productCode || '-'}</td>
              <td style="padding: 10px; border: 1px solid #eee; word-break: break-all; white-space: normal;">${i.productName}</td>
              <td style="padding: 10px; border: 1px solid #eee; text-align: center; word-break: break-all; white-space: normal;">${i.qty}</td>
              <td style="padding: 10px; border: 1px solid #eee; text-align: right; word-break: break-all; white-space: normal;">$${i.unitCost.toFixed(2)}</td>
              <td style="padding: 10px; border: 1px solid #eee; text-align: right; word-break: break-all; white-space: normal;">$${(i.qty * i.unitCost).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <div style="display: flex; justify-content: flex-end; word-break: break-all; white-space: normal;">
        <div style="width: 250px; word-break: break-all; white-space: normal;">
          <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; word-break: break-all; white-space: normal;">
            <span>Subtotal:</span>
            <span>$${total.toFixed(2)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding: 15px 0; font-weight: bold; font-size: 18px; color: #4f46e5; word-break: break-all; white-space: normal;">
            <span>Grand Total:</span>
            <span>$${total.toFixed(2)}</span>
          </div>
        </div>
      </div>
    `;

    const opt = {
      margin: 10,
      filename: `Order_${ord.id.slice(-6)}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
  },
  printOrder: function(id) {
    const ord = this._data.find(o => o.id === id);
    if (!ord) return;

    const totalAmount = ord.items ? ord.items.reduce((sum, i) => sum + (i.qty * i.unitCost), 0) : 0;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Print Order - ${ord.id}</title>
          <style>
            * { box-sizing: border-box; word-break: break-all; white-space: normal; }
            body { font-family: sans-serif; padding: 30px; line-height: 1.6; word-break: break-all; white-space: normal; }
            .h { display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; word-break: break-all; white-space: normal; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; word-break: break-all; white-space: normal; }
            th { background: #f4f4f4; text-align: left; padding: 10px; border: 1px solid #ddd; word-break: break-all; white-space: normal; }
            td { padding: 10px; border: 1px solid #ddd; word-break: break-all; white-space: normal; }
            .total { text-align: right; font-size: 1.4em; font-weight: bold; word-break: break-all; white-space: normal; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="h">
            <div><h2>${ord.orderType.toUpperCase()} ORDER</h2><p>ID: ${ord.id}</p></div>
            <div style="text-align:right"><strong>${ord.companyName}</strong><br>Date: ${ord.orderDate}</div>
          </div>
          <p><strong>From:</strong> ${ord.fromEntity || 'N/A'}</p>
          <p><strong>To:</strong> ${ord.toEntity || ord.customerName || ord.supplier || 'N/A'}</p>
          <table>
            <thead><tr><th>Code</th><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
            <tbody>${ord.items.map(i => `<tr><td>${i.productCode || '-'}</td><td>${i.productName}</td><td>${i.qty}</td><td>$${i.unitCost.toFixed(2)}</td><td>$${(i.qty * i.unitCost).toFixed(2)}</td></tr>`).join('')}</tbody>
          </table>
          <div class="total">Grand Total: $ ${totalAmount.toFixed(2)}</div>
        </body>
      </html>
    `);
    printWindow.document.close();
  },
  editOrder: function(id) {
    const ord = this._data.find(o => o.id === id);
    if (!ord) return;

    this._currentId = id;
    this.openEditor();
    document.getElementById('ord-modal-title').innerText = `Edit Order #${id.slice(-6)}`;

    const form = document.getElementById('ord-form');
    form.companyName.value = ord.companyName || '';
    form.fromEntity.value = ord.fromEntity || '';
    form.toEntity.value = ord.toEntity || '';

    if (ord.orderType === 'supplier' || ord.orderType === 'customer') {
      form.orderType.value = ord.orderType;
      form.customOrderType.value = '';
    } else {
      form.orderType.value = 'other';
      form.customOrderType.value = ord.orderType;
    }

    form.supplier.value = ord.supplier || '';
    form.customerName.value = ord.customerName || '';
    form.customerPhone.value = ord.customerPhone || '';
    form.orderDate.value = ord.orderDate;
    form.etaDate.value = ord.etaDate || '';

    document.getElementById('ord-bank-name').value = ord.bankName || '';
    document.getElementById('ord-bank-account').value = ord.bankAccount || '';

    this.toggleOrderType(form.orderType.value);

    const container = document.getElementById('items-container');
    container.innerHTML = '';
    if (ord.items) ord.items.forEach(item => this.addItem(item));
    this.calcTotal();
  },
  deleteOrder: async function(id) {
    if (!confirm('Permanently delete this order record?')) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      const targetOrder = this._data.find(o => o.id === id);
      this._data = this._data.filter(o => o.id !== id);
      await this._syncWithGitHub(`Delete Order: ${id}`);

      if (window.LogModule && typeof window.LogModule.addLog === 'function') {
        await window.LogModule.addLog('OrderModule', `Deleted order #${id.slice(-6)} (${targetOrder?.orderType})`, this._config.userName || 'Admin');
      }
      this.renderList();
    } catch (e) {
      alert("Sync Error: " + e.message);
    }
  },
  addItem: function(data = null) {
    const container = document.getElementById('items-container');
    const row = document.createElement('div');
    row.className = 'ord-item-card';

    row.innerHTML = `
      <div class="ord-item-header">
        <span class="ord-item-index">Product Entry</span>
        <button type="button" class="ord-btn-remove" onclick="OrderModule.removeItem(this)">&times;</button>
      </div>
      <div class="ord-item-body">
        <div class="ord-item-grid">
          <div class="ord-field">
            <label>Item Code</label>
            <input type="text" name="item_code[]" class="ord-item-code" value="${data ? (data.productCode || '') : ''}" placeholder="Code..." oninput="OrderModule.handleSkuInput(this)" onchange="OrderModule.handleSkuInput(this)">
          </div>
          <div class="ord-field" style="grid-column: span 1;">
            <label>Product Name</label>
            <input type="text" name="item_prod[]" list="ord-product-list" required value="${data ? data.productName : ''}" placeholder="Search..." onchange="OrderModule.handleProductSelect(this)">
          </div>
        </div>
        <div class="ord-item-row">
          <div class="ord-field">
            <label>Qty</label>
            <input type="number" name="item_qty[]" class="ord-item-qty" min="1" value="${data ? data.qty : 1}" oninput="OrderModule.calcTotal()">
          </div>
          <div class="ord-field">
            <label>Cost</label>
            <input type="number" name="item_cost[]" class="ord-item-cost" step="0.01" value="${data ? data.unitCost : ''}" oninput="OrderModule.calcTotal()">
          </div>
        </div>
      </div>
    `;

    container.prepend(row);
    this.calcTotal();
  },
  removeItem: function(btn) {
    btn.closest('.ord-item-card').remove();
    this.calcTotal();
  },
  handleSkuInput: function(input) {
    const skuValue = input.value.trim();
    if (!skuValue) {
      const row = input.closest('.ord-item-card');
      row.querySelector('[name="item_prod[]"]').value = '';
      row.querySelector('.ord-item-cost').value = '';
      this.calcTotal();
      return;
    }

    const product = this._products.find(p => {
      const sku = (p.sku || p.pos || '').toString().toLowerCase();
      return sku === skuValue.toLowerCase();
    });

    if (product) {
      const row = input.closest('.ord-item-card');
      row.querySelector('[name="item_prod[]"]').value = product.prodName || '';
      row.querySelector('.ord-item-code').value = product.sku || product.pos || '';
      const costField = row.querySelector('.ord-item-cost');
      if (!costField.value || parseFloat(costField.value) === 0) {
        costField.value = product.cost || 0;
      }
      this.calcTotal();
    }
  },
  handleProductSelect: function(input) {
    const product = this._products.find(p => p.prodName === input.value);
    if (product) {
      const row = input.closest('.ord-item-card');
      row.querySelector('.ord-item-code').value = product.sku || product.pos || '';
      const costField = row.querySelector('.ord-item-cost');
      if (!costField.value || parseFloat(costField.value) === 0) {
        costField.value = product.cost || 0;
      }
      this.calcTotal();
    }
  },
  calcTotal: function() {
    let total = 0;
    document.querySelectorAll('.ord-item-card').forEach(row => {
      const q = parseFloat(row.querySelector('.ord-item-qty').value) || 0;
      const c = parseFloat(row.querySelector('.ord-item-cost').value) || 0;
      total += q * c;
    });
    document.getElementById('ord-total-val').innerText = `$ ${total.toFixed(2)}`;
  },
  toggleOrderType: function(type) {
    const otherField = document.getElementById('other-type-field');
    const supplierFields = document.getElementById('supplier-fields');
    const customerFields = document.getElementById('customer-fields');

    otherField.style.display = type === 'other' ? 'block' : 'none';
    supplierFields.style.display = type === 'customer' ? 'none' : 'block';
    customerFields.style.display = type === 'customer' ? 'block' : 'none';
  },
  _setDefaultDate: function() {
    const today = new Date().toISOString().split('T')[0];
    if (document.getElementById('orderDate')) document.getElementById('orderDate').value = today;
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const headers = {
      'Authorization': `token ${this._config.ghToken}`
    };

    try {
      const [pRes, cRes, rRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._productFileName}`, { headers }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._companyFileName}`, { headers }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._orderFileName}`, { headers, cache: 'no-store' })
      ]);

      if (pRes.ok) {
        const d = await pRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = db.products || [];
        document.getElementById('ord-product-list').innerHTML = this._products.map(p => `<option value="${p.prodName}">`).join('');
      }

      if (cRes.ok) {
        const d = await cRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._companies = db.companies || db || [];
        document.getElementById('ord-company-list').innerHTML = this._companies.map(c => `<option value="${c.comName || c.name || c}">`).join('');
      }

      if (rRes.ok) {
        const d = await rRes.json();
        this._sha = d.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
      } else if (rRes.status === 404) {
        this._data = [];
        this._sha = null;
      }

      this.renderList();
    } catch (e) {
      console.error("Load Error", e);
    }
  },
  renderList: function() {
    const container = document.getElementById('order-list');
    const pagination = document.getElementById('ord-pagination');
    const stats = document.getElementById('ord-stats');

    let filtered = this._data.filter(ord => {
      const s = this._searchTerm;
      return (ord.items?.some(i => i.productName.toLowerCase().includes(s) || (i.productCode && i.productCode.toLowerCase().includes(s)))) ||
        (ord.supplier?.toLowerCase().includes(s)) ||
        (ord.customerName?.toLowerCase().includes(s)) ||
        (ord.companyName?.toLowerCase().includes(s)) ||
        (ord.fromEntity?.toLowerCase().includes(s)) ||
        (ord.toEntity?.toLowerCase().includes(s)) ||
        (ord.orderType?.toLowerCase().includes(s));
    }).reverse();

    if (stats) stats.innerText = `${filtered.length} order(s) found`;

    if (!filtered.length) {
      container.innerHTML = `<div class="ord-empty-state">No orders found matching your criteria.</div>`;
      pagination.innerHTML = '';
      return;
    }

    const paginated = filtered.slice((this._currentPage - 1) * this._pageSize, this._currentPage * this._pageSize);

    container.innerHTML = paginated.map(ord => {
      const total = ord.items?.reduce((sum, i) => sum + (i.qty * i.unitCost), 0) || 0;
      const bankInfo = (ord.bankName || ord.bankAccount) ? 'BANK' : '';
      return `
        <div class="ord-card-item" onclick="OrderModule.editOrder('${ord.id}')">
          <div class="ord-card-header">
            <span class="ord-badge ${ord.orderType}">${ord.orderType}${bankInfo ? ` - ${bankInfo}` : ''}</span>
            <span class="ord-date">${ord.orderDate}</span>
          </div>
          <div class="ord-card-body">
            <h3 class="ord-staff-name">#${ord.id.slice(-6)} - ${ord.companyName || 'Main'}</h3>
            <p class="ord-card-route">${ord.fromEntity || '?'} to ${ord.toEntity || ord.customerName || ord.supplier || '?'}</p>
            <p class="ord-card-items">${ord.items?.[0]?.productName || 'No Items'} ${ord.items?.length > 1 ? `(+${ord.items.length-1})` : ''}</p>
          </div>
          <div class="ord-card-footer">
            <span class="ord-card-amount">$ ${total.toFixed(2)}</span>
            <div class="ord-card-actions">
              <button type="button" class="ord-btn-icon" onclick="event.stopPropagation(); OrderModule.printOrder('${ord.id}')" title="Print">Print</button>
              <button type="button" class="ord-btn-icon ord-btn-pdf" onclick="event.stopPropagation(); OrderModule.downloadPDF('${ord.id}')">PDF</button>
              <button type="button" class="ord-btn-icon ord-btn-danger" onclick="event.stopPropagation(); OrderModule.deleteOrder('${ord.id}')" title="Delete">Delete</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    const totalPages = Math.ceil(filtered.length / this._pageSize);
    pagination.innerHTML = totalPages > 1 ? `
      <button type="button" class="ord-page-btn" ${this._currentPage === 1 ? 'disabled' : ''} onclick="OrderModule.changePage(${this._currentPage - 1})">Prev</button>
      <span class="ord-page-info">${this._currentPage} / ${totalPages}</span>
      <button type="button" class="ord-page-btn" ${this._currentPage === totalPages ? 'disabled' : ''} onclick="OrderModule.changePage(${this._currentPage + 1})">Next</button>
    ` : '';
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = e.target.querySelector('.ord-btn-submit');
    btn.disabled = true;
    btn.innerText = "Syncing with Cloud...";

    const items = Array.from(document.querySelectorAll('.ord-item-card')).map(row => {
      const productCode = row.querySelector('.ord-item-code').value;
      const productName = row.querySelector('[name="item_prod[]"]').value;
      const qty = parseInt(row.querySelector('.ord-item-qty').value) || 0;
      const unitCost = parseFloat(row.querySelector('.ord-item-cost').value) || 0;

      const productMatch = this._products.find(p => {
        const sku = (p.sku || p.pos || '').toString().toLowerCase();
        return sku === productCode.toLowerCase() || p.prodName === productName;
      });

      const finalName = productMatch ? (productMatch.prodName || productMatch.name || productName) : productName;
      const finalCost = productMatch ? (productMatch.cost || productMatch.price || unitCost) : unitCost;

      return { productCode, productName: finalName, qty, unitCost: finalCost };
    });

    const mergedItems = [];
    items.forEach(item => {
      const existing = mergedItems.find(m => m.productCode === item.productCode && m.productName === item.productName);
      if (existing) {
        existing.qty += item.qty;
      } else {
        mergedItems.push(item);
      }
    });

    const fd = new FormData(e.target);
    let typeValue = fd.get('orderType');
    if (typeValue === 'other') {
      typeValue = fd.get('customOrderType') || 'Other';
    }

    const orderData = {
      id: this._currentId || ('ORD-' + Date.now()),
      companyName: fd.get('companyName'),
      fromEntity: fd.get('fromEntity'),
      toEntity: fd.get('toEntity'),
      orderType: typeValue,
      supplier: fd.get('supplier'),
      customerName: fd.get('customerName'),
      customerPhone: fd.get('customerPhone'),
      orderDate: fd.get('orderDate'),
      etaDate: fd.get('etaDate'),
      items: mergedItems,
      status: 'Completed',
      bankName: document.getElementById('ord-bank-name').value || '',
      bankAccount: document.getElementById('ord-bank-account').value || ''
    };

    try {
      const isUpdate = !!this._currentId;
      if (isUpdate) {
        const idx = this._data.findIndex(o => o.id === this._currentId);
        if (idx !== -1) this._data[idx] = orderData;
      } else {
        this._data.push(orderData);
      }

      await this._syncWithGitHub(isUpdate ? `Update Order: ${this._currentId}` : `New Order: ${orderData.id}`);

      if (window.LogModule && typeof window.LogModule.addLog === 'function') {
        const logMsg = isUpdate ? `Updated order #${orderData.id.slice(-6)}` : `Created new order #${orderData.id.slice(-6)}`;
        await window.LogModule.addLog('OrderModule', `${logMsg} (${orderData.orderType})`, this._config.userName || 'Admin');
      }

      this.closeEditor();
      await this.load();
    } catch (e) {
      alert("Save Failed: " + e.message);
    } finally {
      btn.disabled = false;
      btn.innerText = "Finalize & Sync Order";
    }
  },
  _syncWithGitHub: async function(message) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._orderFileName}`, {
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(this._data, null, 2))));

    const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._orderFileName}`, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${this._config.ghToken}`
      },
      body: JSON.stringify({
        message,
        content,
        sha: currentSha || undefined
      })
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.message || "GitHub sync failed.");
    }

    const d = await res.json();
    this._sha = d.content.sha;
  },
  openEditor: function() {
    this._currentId = null;
    document.getElementById('ord-modal-title').innerText = "New Order";
    document.getElementById('ord-modal').classList.add('active');
    document.getElementById('items-container').innerHTML = '';
    document.getElementById('other-type-field').style.display = 'none';

    const form = document.getElementById('ord-form');
    form.customOrderType.value = '';
    form.fromEntity.value = '';
    form.toEntity.value = '';

    document.getElementById('ord-bank-name').value = '';
    document.getElementById('ord-bank-account').value = '';

    this.addItem();
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('ord-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  handleSearch: function(v) {
    this._searchTerm = v.toLowerCase();
    this._currentPage = 1;
    this.renderList();
  },
  changePage: function(p) {
    this._currentPage = p;
    this.renderList();
  },
  _injectStyles: function() {
    if (document.getElementById('ord-modern-styles')) return;

    const s = document.createElement('style');
    s.id = 'ord-modern-styles';
    s.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .ord-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .ord-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .ord-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .ord-brand p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .ord-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .ord-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ord-search-section {
        margin-bottom: 20px;
      }

      .ord-search-inner {
        position: relative;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .ord-search-inner:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .ord-search-inner svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .ord-search-inner input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .ord-search-inner input::placeholder {
        color: var(--text-dim);
      }

      .ord-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 16px;
        width: 100%;
      }

      .ord-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        flex-direction: column;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .ord-card-item:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .ord-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }

      .ord-badge {
        font-size: 11px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .ord-badge.supplier {
        background: var(--green-soft);
        color: var(--green);
      }

      .ord-badge.customer {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .ord-badge:not(.supplier):not(.customer) {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .ord-date {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .ord-card-body {
        flex: 1;
      }

      .ord-staff-name {
        margin: 0 0 6px;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .ord-card-route {
        font-size: 13px;
        color: var(--text-secondary);
        margin: 0 0 6px;
        word-break: break-word;
      }

      .ord-card-items {
        font-size: 13px;
        font-weight: 600;
        color: var(--primary);
        margin: 0;
        word-break: break-word;
      }

      .ord-card-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 14px;
        border-top: 1px solid var(--border);
        margin-top: auto;
        gap: 10px;
        flex-wrap: wrap;
      }

      .ord-card-amount {
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .ord-card-actions {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
      }

      .ord-btn-icon {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        height: 30px;
        padding: 0 10px;
        border-radius: var(--radius-xs);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .ord-btn-icon:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .ord-btn-pdf {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
      }

      .ord-btn-pdf:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
        color: white;
      }

      .ord-btn-danger {
        background: var(--surface);
        color: var(--danger);
        border-color: var(--border);
      }

      .ord-btn-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .ord-pager {
        display: flex;
        justify-content: center;
        gap: 12px;
        margin-top: 24px;
        align-items: center;
        flex-wrap: wrap;
      }

      .ord-page-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 36px;
        padding: 0 16px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .ord-page-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .ord-page-btn:hover:not(:disabled) {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .ord-page-info {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .ord-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: translateY(12px);
        transition: visibility 0.2s, opacity 0.2s, transform 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .ord-modal.active {
        visibility: visible;
        opacity: 1;
        transform: translateY(0);
      }

      .ord-modal-container {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
      }

      .ord-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .ord-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .ord-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .ord-modal-title {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-width: 0;
      }

      .ord-modal-title h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .ord-badge-status {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-dim);
        margin-top: 2px;
        letter-spacing: 0.04em;
      }

      .ord-modal-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-shrink: 0;
      }

      .ord-btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 38px;
        padding: 0 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .ord-btn-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ord-modal-body {
        flex: 1;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .ord-form {
        height: 100%;
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .ord-form-scroll {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        min-height: 0;
      }

      .ord-form-inner {
        max-width: 1160px;
        margin: 0 auto;
        width: 100%;
      }

      .ord-two-columns {
        display: grid;
        grid-template-columns: 360px 1fr;
        gap: 20px;
        align-items: start;
      }

      .ord-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .ord-section-title {
        margin: 0 0 16px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .ord-field {
        margin-bottom: 14px;
      }

      .ord-field label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        margin-bottom: 6px;
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .ord-field input,
      .ord-field select {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .ord-field input:focus,
      .ord-field select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .ord-row-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
      }

      .ord-card-header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        gap: 10px;
        flex-wrap: wrap;
      }

      .ord-btn-add {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .ord-btn-add:hover {
        background: var(--primary);
        color: #ffffff;
        border-style: solid;
      }

      .ord-items-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
        margin-bottom: 20px;
      }

      .ord-item-card {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px;
      }

      .ord-item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }

      .ord-item-index {
        font-size: 12px;
        font-weight: 700;
        color: var(--primary);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .ord-btn-remove {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        width: 28px;
        height: 28px;
        border-radius: var(--radius-xs);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .ord-btn-remove:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .ord-item-grid {
        display: grid;
        grid-template-columns: 1fr 2fr;
        gap: 12px;
        margin-bottom: 12px;
      }

      .ord-item-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
      }

      .ord-summary-box {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 16px 20px;
        border: 1px solid var(--border);
      }

      .ord-total-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 15px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .ord-total-row strong {
        font-size: 22px;
        font-weight: 700;
        color: var(--primary);
      }

      .ord-form-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 16px 24px;
        position: sticky;
        bottom: 0;
        z-index: 10;
        box-shadow: var(--shadow-sm);
        flex-shrink: 0;
      }

      .ord-footer-content {
        max-width: 1160px;
        margin: 0 auto;
        width: 100%;
      }

      .ord-btn-submit {
        width: 100%;
        height: 44px;
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .ord-btn-submit:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ord-btn-submit:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .ord-empty-state {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 1024px) {
        .ord-two-columns {
          grid-template-columns: 1fr;
        }
      }

      @media (max-width: 768px) {
        .ord-app-wrapper {
          padding: 16px;
        }
        .ord-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .ord-brand h1 {
          font-size: 22px;
        }
        .ord-btn-primary {
          width: 100%;
        }
        .ord-search-inner {
          max-width: 100%;
        }
        .ord-item-grid,
        .ord-item-row,
        .ord-row-grid {
          grid-template-columns: 1fr;
        }
        .ord-modal-header {
          padding: 12px 16px;
        }
        .ord-modal-title h2 {
          font-size: 16px;
        }
        .ord-form-scroll {
          padding: 16px;
        }
        .ord-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .ord-card-footer {
          flex-direction: column;
          gap: 10px;
          align-items: stretch;
        }
        .ord-card-actions {
          width: 100%;
          justify-content: flex-end;
        }
        .ord-form-footer {
          padding: 14px 16px;
        }
        .ord-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .ord-card-item {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.OrderModule = OrderModule;

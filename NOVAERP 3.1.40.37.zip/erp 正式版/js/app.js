const App = {
    init: async function() {
        console.log("Initializing App...");

        const deploymentStr = localStorage.getItem('ERP_DEPLOYMENT_DATA');
        const configStr = localStorage.getItem('ERP_CONFIG');

        if (!deploymentStr) {
            window.location.href = 'install.html';
            return;
        }

        if (!configStr) {
            window.location.href = 'login.html';
            return;
        }

        const config = JSON.parse(configStr);

        try {
            const isSessionValid = await this.syncAndValidateSession(config);
            if (!isSessionValid) return;

        } catch (error) {
            console.error("Cloud session sync failed:", error);
        }

        if (typeof SettingsModule !== 'undefined') {
            SettingsModule.render('module-container');
        }
    },

    syncAndValidateSession: async function(config) {
        const deployment = JSON.parse(localStorage.getItem('ERP_DEPLOYMENT_DATA') || '{}');

        if (!config.deviceId) {
            this.handleLogout();
            return false;
        }

        const sessions = await this.fetchRemoteSessions(deployment);

        if (sessions && Array.isArray(sessions)) {
            const mySession = sessions.find(s => s.id === config.deviceId);

            if (mySession && mySession.active === false) {
                alert("Access Revoked: This device has been logged out remotely.");
                this.handleLogout();
                return false;
            }

            localStorage.setItem('ERP_CONFIG', JSON.stringify({
                ...config,
                lastVerified: new Date().getTime()
            }));
        }
        return true;
    },

    fetchRemoteSessions: async function(deployment) {
        try {
            const res = await fetch(`https://api.github.com/repos/${deployment.ghRepo}/contents/db_date/login.js`, {
                headers: { 'Authorization': `token ${deployment.ghToken}` },
                cache: 'no-store'
            });

            if (res.ok) {
                const data = await res.json();
                const content = atob(data.content);
                const jsonMatch = content.match(/\[.*\]/s);
                return jsonMatch ? JSON.parse(jsonMatch[0]) : [];
            }
            return [];
        } catch (e) {
            console.warn("Could not fetch remote sessions:", e);
            return null;
        }
    },

    handleLogout: function() {
        localStorage.removeItem('ERP_CONFIG');
        window.location.href = 'login.html';
    }
};

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

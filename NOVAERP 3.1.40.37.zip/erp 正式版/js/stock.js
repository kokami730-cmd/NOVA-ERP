const StockCheckModule = {
  _products: [],
  _inventory: [],
  _staffs: [],
  _companies: [],
  _config: null,
  _sha: null,
  _fileName: 'db_date/product.json',
  _saveFileName: 'db_date/stockcheck.json',
  _staffFileName: 'db_date/staff.json',
  _companyFileName: 'db_date/company.json',
  _searchQuery: '',
  _editingNo: null,
  _currentView: 'audit',
  _currentPage: 1,
  _pageSize: 20,
  _loadPdfScripts: function() {
    if (window.jspdf && window.jspdf.jsPDF.API.autoTable) return;
    const s1 = document.createElement('script');
    s1.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    s1.onload = () => {
      const s2 = document.createElement('script');
      s2.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js";
      document.head.appendChild(s2);
    };
    document.head.appendChild(s1);
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    this._loadPdfScripts();
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = `
      <div class="st-wrapper">
        <header class="st-header">
          <div class="st-brand">
            <div class="">
             </div>
            <div class="st-title-group">
              <h1>Stock Check</h1>
              <p></p>
            </div>
          </div>
          <div class="st-actions">
            <div class="st-search">
              <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
              <input type="text" id="stock-search" placeholder="Search SKU, Staff or Title..." oninput="StockCheckModule.handleSearch(this.value)">
            </div>
            <button class="st-btn-primary" onclick="StockCheckModule.showAddModal()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              <span>New Stock Check</span>
            </button>
          </div>
        </header>

        <div id="stock-stats" class="st-stats"></div>

        <div class="st-nav-tabs">
          <button class="st-tab-btn active" id="btn-view-audit" onclick="StockCheckModule.switchView('audit')">Audit History</button>
          <button class="st-tab-btn" id="btn-view-base" onclick="StockCheckModule.switchView('base')">Master Inventory</button>
        </div>

        <div id="stock-content-area" class="st-content"></div>

        <div id="stock-pagination" class="st-pagination"></div>
      </div>

      <div id="stock-modal" class="st-modal">
        <div class="st-modal-container">
          <div class="st-modal-nav">
            <div class="st-modal-nav-left">
              <button class="st-btn-back" onclick="StockCheckModule.hideAddModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h2 id="modal-title">Batch Audit</h2>
            </div>
            <div class="st-modal-nav-actions">
              <button class="st-btn-secondary" onclick="StockCheckModule.addItemRow()">Add Item</button>
              <button class="st-btn-primary" onclick="StockCheckModule.saveBatchProducts()">Save Changes</button>
            </div>
          </div>
          <div class="st-modal-body">
            <div class="st-form-container">
              <div class="st-form-header-card">
                <div class="st-field">
                  <label>Company</label>
                  <select id="batch-company" class="st-select-field" required>
                    <option value="">Select company...</option>
                  </select>
                </div>
                <div class="st-field">
                  <label>Project Title</label>
                  <input type="text" id="batch-title" placeholder="e.g. Monthly Review">
                </div>
                <div class="st-field">
                  <label>Staff Member</label>
                  <input type="text" id="batch-staff" list="staff-list" placeholder="Select staff...">
                  <datalist id="staff-list"></datalist>
                </div>
                <div class="st-field">
                  <label>Audit Date</label>
                  <input type="date" id="batch-date">
                </div>
                <div class="st-field">
                  <label>Lock Password (Optional)</label>
                  <input type="password" id="batch-lock-password" placeholder="Leave empty for unlocked">
                </div>
              </div>
              <div id="multi-item-container" class="st-items-stack"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    await this.load();
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const headers = {
      'Authorization': `token ${this._config.ghToken}`
    };

    try {
      const [prodRes, invRes, staffRes, compRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._fileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._saveFileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._staffFileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._companyFileName}`, { headers, cache: 'no-store' })
      ]);

      if (prodRes.ok) {
        const d = await prodRes.json();
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = decoded.products || [];
      }

      if (invRes.ok) {
        const d = await invRes.json();
        this._sha = d.sha;
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._inventory = decoded.products || [];
      } else if (invRes.status === 404) {
        this._inventory = [];
        this._sha = null;
      }

      if (staffRes.ok) {
        const d = await staffRes.json();
        const staffData = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._staffs = staffData.staffs || (Array.isArray(staffData) ? staffData : []);
        this._updateStaffDatalist();
      }

      if (compRes.ok) {
        const d = await compRes.json();
        const compData = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._companies = compData.companies || (Array.isArray(compData) ? compData : []);
        this._updateCompanySelect();
      }

      this.renderContent();
    } catch (e) {
      console.error("Cloud Access Error", e);
    }
  },
  switchView: function(view) {
    this._currentView = view;
    this._currentPage = 1;
    document.querySelectorAll('.st-tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`btn-view-${view}`).classList.add('active');
    this.renderContent();
  },
  handleSearch: function(val) {
    this._searchQuery = val.toLowerCase();
    this._currentPage = 1;
    this.renderContent();
  },
  toggleExpand: function(el) {
    const card = el.closest('.st-audit-card');
    card.classList.toggle('is-expanded');
  },
  toggleCompanySection: function(el) {
    const section = el.closest('.st-company-section');
    section.classList.toggle('is-collapsed');
  },
  renderContent: function() {
    const contentArea = document.getElementById('stock-content-area');
    const stats = document.getElementById('stock-stats');

    const filtered = this._inventory.filter(p =>
      (p.prodName || p.name || "").toLowerCase().includes(this._searchQuery) ||
      (p.sku || "").toLowerCase().includes(this._searchQuery) ||
      (p.staff || "").toLowerCase().includes(this._searchQuery) ||
      (p.no || "").toLowerCase().includes(this._searchQuery) ||
      (p.company || "").toLowerCase().includes(this._searchQuery) ||
      (p.sns && p.sns.some(sn => sn.toLowerCase().includes(this._searchQuery)))
    );

    let totalVal = 0, lowStockCount = 0;
    let displayHtml = "";

    if (this._currentView === 'base') {
      const baseItems = filtered.filter(p => !p.no);
      baseItems.forEach(p => {
        const sum = ((p.whStock || 0) + (p.shelfStock || 0));
        totalVal += sum * (p.price || 0);
        if (sum < 10) lowStockCount++;
      });

      const paginatedItems = baseItems.slice(
        (this._currentPage - 1) * this._pageSize,
        this._currentPage * this._pageSize
      );
      displayHtml = this._generateTableHtml(paginatedItems);
      this.renderPagination(baseItems.length);
    } else {
      const auditItems = filtered.filter(p => p.no);
      const grouped = {};
      auditItems.forEach(p => {
        if (!grouped[p.no]) grouped[p.no] = [];
        grouped[p.no].push(p);
        totalVal += ((p.whStock || 0) + (p.shelfStock || 0)) * (p.price || 0);
      });

      const groupKeys = Object.keys(grouped).sort((a, b) => b.split('-')[1] - a.split('-')[1]);
      const paginatedKeys = groupKeys.slice(
        (this._currentPage - 1) * this._pageSize,
        this._currentPage * this._pageSize
      );

      const companyGroups = {};
      const unassignedKeys = [];

      paginatedKeys.forEach(no => {
        const items = grouped[no];
        const head = items[0];
        const companyName = (head.company || "").trim();
        if (companyName) {
          if (!companyGroups[companyName]) companyGroups[companyName] = [];
          companyGroups[companyName].push(no);
        } else {
          unassignedKeys.push(no);
        }
      });

      const renderAuditCardHtml = (no) => {
        const items = grouped[no];
        const head = items[0];
        const gQty = items.reduce((sum, i) => sum + (i.whStock || 0) + (i.shelfStock || 0), 0);
        const isLocked = head.lockPassword && head.lockPassword.trim() !== "";

        return `
          <div class="st-audit-card">
            <div class="st-audit-header" onclick="StockCheckModule.toggleExpand(this)">
              <div class="st-audit-info">
                <span class="st-ref-tag">${no}</span>
                <h3>${head.title || 'Untitled Audit'} ${isLocked ? '<span class="st-lock-badge">[Locked]</span>' : ''}</h3>
                <p>${head.company ? '[' + head.company + '] · ' : ''}${head.staff} · ${head.date}</p>
              </div>
              <div class="st-audit-meta">
                <div class="st-pill">Items: <b>${items.length}</b></div>
                <div class="st-pill">Total: <b>${gQty}</b></div>
                <div class="st-expand-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                </div>
              </div>
            </div>
            <div class="st-audit-actions-bar">
              <div class="st-actions-left">
                <button class="st-action-btn" onclick="StockCheckModule.exportFullGroupPDF('${no}')" title="Export PDF">PDF</button>
                <button class="st-action-btn" onclick="StockCheckModule.verifyAndAction('${no}', 'edit')" title="Edit">Edit</button>
              </div>
              <button class="st-action-btn st-danger" onclick="StockCheckModule.verifyAndAction('${no}', 'delete')">Delete</button>
            </div>
            <div class="st-audit-expandable-content">
              <div class="st-audit-grid">
                ${items.map(item => `
                  <div class="st-grid-item">
                    <div class="st-item-info">
                      <strong>${item.prodName}</strong>
                      <span>SKU: ${item.sku}</span>
                      ${item.sns && item.sns.length > 0 ? `<div class="st-item-sn">SN: ${item.sns.join(', ')}</div>` : ''}
                    </div>
                    <div class="st-item-stock">
                      <div class="st-stock-labels">
                        <span class="st-label-wh">WH: ${item.whStock}</span>
                        <span class="st-label-sf">SF: ${item.shelfStock}</span>
                      </div>
                      <small>BN: ${item.bn || '-'} | EXP: ${item.exp || '-'}</small>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        `;
      };

      let htmlParts = [];
      Object.keys(companyGroups).sort().forEach(compName => {
        const keys = companyGroups[compName];
        const totalCompItems = keys.reduce((sum, k) => sum + grouped[k].reduce((s, i) => s + (i.whStock || 0) + (i.shelfStock || 0), 0), 0);
        htmlParts.push(`
          <div class="st-company-section is-collapsed">
            <div class="st-company-section-header" onclick="StockCheckModule.toggleCompanySection(this)">
              <div class="st-company-info">
                <h3>${compName}</h3>
                <span class="st-pill">Audits: <b>${keys.length}</b></span>
                <span class="st-pill">Total Qty: <b>${totalCompItems}</b></span>
              </div>
              <div class="st-expand-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
              </div>
            </div>
            <div class="st-company-section-body">
              ${keys.map(no => renderAuditCardHtml(no)).join('')}
            </div>
          </div>
        `);
      });

      if (unassignedKeys.length > 0) {
        const totalUnassignedItems = unassignedKeys.reduce((sum, k) => sum + grouped[k].reduce((s, i) => s + (i.whStock || 0) + (i.shelfStock || 0), 0), 0);
        htmlParts.push(`
          <div class="st-company-section is-collapsed">
            <div class="st-company-section-header" onclick="StockCheckModule.toggleCompanySection(this)">
              <div class="st-company-info">
                <h3>Other / Unassigned Company</h3>
                <span class="st-pill">Audits: <b>${unassignedKeys.length}</b></span>
                <span class="st-pill">Total Qty: <b>${totalUnassignedItems}</b></span>
              </div>
              <div class="st-expand-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
              </div>
            </div>
            <div class="st-company-section-body">
              ${unassignedKeys.map(no => renderAuditCardHtml(no)).join('')}
            </div>
          </div>
        `);
      }

      displayHtml = htmlParts.join('') || `<div class="st-empty-state">No records found.</div>`;

      this.renderPagination(groupKeys.length);
    }

    contentArea.innerHTML = displayHtml;

    stats.innerHTML = `
      <div class="st-stat-card"><label>Active Mode</label><b>${this._currentView.toUpperCase()}</b></div>
      <div class="st-stat-card"><label>Total Valuation</label><b>$${totalVal.toLocaleString()}</b></div>
      <div class="st-stat-card ${lowStockCount > 0 ? 'st-warning' : ''}"><label>Low Stock Alerts</label><b>${lowStockCount}</b></div>
    `;
  },
  verifyAndAction: function(no, actionType) {
    const groupItems = this._inventory.filter(p => p.no === no);
    if (!groupItems.length) return;
    const head = groupItems[0];
    const isLocked = head.lockPassword && head.lockPassword.trim() !== "";

    if (isLocked) {
      const pwd = prompt("This audit is locked. Please enter the confirmation password to " + actionType + ":");
      if (pwd === null) return;
      if (pwd !== head.lockPassword) {
        alert("Incorrect password!");
        return;
      }
    }

    if (actionType === 'edit') {
      this.editGroup(no);
    } else if (actionType === 'delete') {
      this.deleteGroup(no);
    }
  },
  renderPagination: function(totalItems) {
    const area = document.getElementById('stock-pagination');
    const totalPages = Math.ceil(totalItems / this._pageSize);

    if (totalPages <= 1) {
      area.innerHTML = '';
      return;
    }

    area.innerHTML = `
      <button class="st-page-control" ${this._currentPage === 1 ? 'disabled' : ''} onclick="StockCheckModule.changePage(${this._currentPage - 1})">Previous</button>
      <div class="st-page-info">${this._currentPage} / ${totalPages}</div>
      <button class="st-page-control" ${this._currentPage === totalPages ? 'disabled' : ''} onclick="StockCheckModule.changePage(${this._currentPage + 1})">Next</button>
    `;
  },
  changePage: function(page) {
    this._currentPage = page;
    this.renderContent();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  _generateTableHtml: function(items) {
    return `
      <div class="st-table-container">
        <table class="st-main-table">
          <thead>
            <tr>
              <th>Product Info</th>
              <th class="desktop-only">Expiration</th>
              <th>Stock (WH / Shelf)</th>
              <th style="text-align:right">Action</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((p) => {
              const idx = this._inventory.indexOf(p);
              return `
                <tr>
                  <td>
                    <div class="st-cell-name">${p.prodName || p.name}</div>
                    <div class="st-cell-sku">${p.sku}</div>
                    ${p.sns && p.sns.length > 0 ? `<div class="st-cell-sn">SN: ${p.sns.join(', ')}</div>` : ''}
                  </td>
                  <td class="desktop-only">
                    <input type="date" class="st-table-input" value="${p.exp || ''}" onchange="StockCheckModule.updateQuickStock(${idx}, 'exp', this.value)">
                  </td>
                  <td>
                    <div class="st-stock-group">
                      <input type="number" value="${p.whStock || 0}" onchange="StockCheckModule.updateQuickStock(${idx}, 'whStock', this.value)">
                      <input type="number" value="${p.shelfStock || 0}" onchange="StockCheckModule.updateQuickStock(${idx}, 'shelfStock', this.value)">
                    </div>
                  </td>
                  <td style="text-align:right">
                    <button class="st-action-btn st-danger" onclick="StockCheckModule.deleteEntry(${idx})">Delete</button>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  },
  addItemRow: function(data = null) {
    const container = document.getElementById('multi-item-container');
    const row = document.createElement('div');
    row.className = 'st-form-card';
    const rowId = 'row-' + Date.now() + Math.floor(Math.random() * 1000);
    row.id = rowId;

    row.innerHTML = `
      <div class="st-form-card-header">
        <h3>Product Entry</h3>
        <button class="st-text-btn-danger" onclick="this.parentElement.parentElement.remove()">Remove Item</button>
      </div>
      <div class="st-form-card-body">
        <div class="st-form-grid">
          <div class="st-field">
            <label>SKU Code</label>
            <input type="text" class="in-sku" value="${data?.sku || ''}" oninput="StockCheckModule.handleSkuLinkage(this)">
          </div>
          <div class="st-field st-col-2">
            <label>Product Name</label>
            <input type="text" class="in-name" value="${data?.prodName || data?.name || ''}">
          </div>
          <div class="st-field">
            <label>Unit Price</label>
            <input type="number" class="in-price" value="${data?.price || 0}">
          </div>
        </div>
        <div class="st-sn-section">
          <div class="st-sn-header">
            <label>Serial Numbers (SN)</label>
            <button type="button" class="st-btn-add-sn" onclick="StockCheckModule.addSnRow('${rowId}')">+ Add SN</button>
          </div>
          <div class="st-sn-list"></div>
        </div>
        <div class="st-batch-section">
          <div class="st-batch-header">
            <label>Stock Batches</label>
            <button type="button" class="st-btn-add-batch" onclick="StockCheckModule.addMoreDetail('${rowId}')">+ Add Batch</button>
          </div>
          <div class="st-batch-list"></div>
        </div>
      </div>
    `;

    container.prepend(row);
    if (data?.sns && data.sns.length > 0) {
      data.sns.forEach(sn => this.addSnRow(rowId, sn));
    }
    this.addMoreDetail(rowId, data);
  },
  addSnRow: function(rowId, snValue = '') {
    const row = document.getElementById(rowId);
    if (!row) return;

    const container = row.querySelector('.st-sn-list');
    const snRow = document.createElement('div');
    snRow.className = 'st-sn-row';

    snRow.innerHTML = `
      <input type="text" class="in-sn" placeholder="Enter SN..." value="${snValue}">
      <button type="button" class="st-sn-del" onclick="this.parentElement.remove()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    `;

    container.prepend(snRow);
  },
  addMoreDetail: function(rowId, data = null) {
    const row = document.getElementById(rowId);
    if (!row) return;

    const container = row.querySelector('.st-batch-list');
    const detailRow = document.createElement('div');
    detailRow.className = 'st-batch-row';

    detailRow.innerHTML = `
      <div class="st-batch-inputs">
        <div class="st-sub-field"><span class="mob-label">BN</span><input type="text" class="in-bn" placeholder="BN" value="${data?.bn || ''}"></div>
        <div class="st-sub-field"><span class="mob-label">EXP</span><input type="date" class="in-exp" value="${data?.exp || ''}"></div>
        <div class="st-sub-field"><span class="mob-label">WH</span><input type="number" class="in-wh" placeholder="WH" value="${data?.whStock || 0}"></div>
        <div class="st-sub-field"><span class="mob-label">Shelf</span><input type="number" class="in-shelf" placeholder="Shelf" value="${data?.shelfStock || 0}"></div>
      </div>
      <button class="st-batch-del" onclick="StockCheckModule.removeDetailRow(this)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    `;

    container.appendChild(detailRow);
  },
  removeDetailRow: function(btn) {
    const container = btn.parentElement.parentElement;
    if (container.children.length > 1) {
      btn.parentElement.remove();
    } else {
      alert("At least one batch entry is required.");
    }
  },
  saveBatchProducts: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const company = document.getElementById('batch-company').value;
    if (!company) return alert("Please select a company");

    const rows = document.querySelectorAll('.st-form-card');
    const title = document.getElementById('batch-title').value;
    const staff = document.getElementById('batch-staff').value;
    const date = document.getElementById('batch-date').value;
    const lockPassword = document.getElementById('batch-lock-password').value;

    if (!staff) return alert("Staff identification required");

    const groupNo = this._editingNo || `AUDIT-${Date.now()}`;
    const isUpdate = !!this._editingNo;

    let existingLockPassword = lockPassword;
    if (isUpdate) {
      const oldGroup = this._inventory.filter(p => p.no === this._editingNo);
      if (oldGroup.length > 0 && !lockPassword) {
        existingLockPassword = oldGroup[0].lockPassword || "";
      }
      this._inventory = this._inventory.filter(p => p.no !== this._editingNo);
    }

    const results = [];

    rows.forEach(row => {
      const sku = row.querySelector('.in-sku').value || "N/A";
      const name = row.querySelector('.in-name').value;
      const price = parseFloat(row.querySelector('.in-price').value) || 0;
      const sns = Array.from(row.querySelectorAll('.in-sn')).map(input => input.value.trim()).filter(Boolean);

      const detailGroups = row.querySelectorAll('.st-batch-row');
      detailGroups.forEach(group => {
        if (name) {
          const bn = group.querySelector('.in-bn').value || "-";
          const exp = group.querySelector('.in-exp').value || "";
          const whStock = parseFloat(group.querySelector('.in-wh').value) || 0;
          const shelfStock = parseFloat(group.querySelector('.in-shelf').value) || 0;

          const existingIndex = results.findIndex(r => r.sku === sku && r.bn === bn && r.prodName === name);
          if (existingIndex !== -1) {
            results[existingIndex].whStock += whStock;
            results[existingIndex].shelfStock += shelfStock;
            sns.forEach(sn => {
              if (!results[existingIndex].sns.includes(sn)) {
                results[existingIndex].sns.push(sn);
              }
            });
          } else {
            const existingSkuIndex = results.findIndex(r => r.sku === sku && r.prodName === name);
            if (existingSkuIndex !== -1) {
              if (bn !== "-") {
                results.push({
                  prodName: name,
                  sku: sku,
                  sns: [...sns],
                  bn: bn,
                  exp: exp,
                  whStock: whStock,
                  shelfStock: shelfStock,
                  price: price,
                  title: title || "Manual Audit",
                  staff: staff,
                  date: date,
                  company: company,
                  lockPassword: existingLockPassword,
                  no: groupNo
                });
              } else {
                results[existingSkuIndex].whStock += whStock;
                results[existingSkuIndex].shelfStock += shelfStock;
                sns.forEach(sn => {
                  if (!results[existingSkuIndex].sns.includes(sn)) {
                    results[existingSkuIndex].sns.push(sn);
                  }
                });
              }
            } else {
              const productMatch = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === sku.toLowerCase());
              const finalName = productMatch ? (productMatch.prodName || productMatch.name || name) : name;

              results.push({
                prodName: finalName,
                sku: sku,
                sns: sns,
                bn: bn,
                exp: exp,
                whStock: whStock,
                shelfStock: shelfStock,
                price: productMatch ? (productMatch.price || price) : price,
                title: title || "Manual Audit",
                staff: staff,
                date: date,
                company: company,
                lockPassword: existingLockPassword,
                no: groupNo
              });
            }
          }
        }
      });
    });

    if (results.length === 0) return alert("Please add at least one product.");

    const mergedResults = [];
    results.forEach(item => {
      const existing = mergedResults.find(r => r.sku === item.sku && r.bn === item.bn && r.prodName === item.prodName);
      if (existing) {
        existing.whStock += item.whStock;
        existing.shelfStock += item.shelfStock;
        if (item.sns) {
          item.sns.forEach(sn => {
            if (!existing.sns.includes(sn)) existing.sns.push(sn);
          });
        }
      } else {
        mergedResults.push(item);
      }
    });

    this._inventory.unshift(...mergedResults);
    this._editingNo = null;
    this.hideAddModal();
    this.renderContent();

    const logMsg = isUpdate ? `Updated Audit Group: ${groupNo}` : `Created New Audit: ${groupNo}`;
    await this.syncData(true, logMsg, staff);
  },
  editGroup: function(no) {
    this._editingNo = no;
    const groupItems = this._inventory.filter(p => p.no === no);
    if (!groupItems.length) return;

    const head = groupItems[0];

    document.getElementById('modal-title').innerText = `Edit Audit: ${no}`;
    document.getElementById('batch-company').value = head.company || "";
    document.getElementById('batch-title').value = head.title || "";
    document.getElementById('batch-staff').value = head.staff || "";
    document.getElementById('batch-date').value = head.date || "";
    document.getElementById('batch-lock-password').value = head.lockPassword || "";

    const container = document.getElementById('multi-item-container');
    container.innerHTML = '';

    const skuMap = {};
    groupItems.forEach(item => {
      if (!skuMap[item.sku]) {
        skuMap[item.sku] = { info: item, details: [] };
      }
      skuMap[item.sku].details.push(item);
    });

    Object.values(skuMap).forEach(group => {
      const rowId = 'row-' + Math.random().toString(36).substr(2, 9);
      const row = document.createElement('div');
      row.className = 'st-form-card';
      row.id = rowId;

      row.innerHTML = `
        <div class="st-form-card-header">
          <h3>Product Entry</h3>
          <button class="st-text-btn-danger" onclick="this.parentElement.parentElement.remove()">Remove Item</button>
        </div>
        <div class="st-form-card-body">
          <div class="st-form-grid">
            <div class="st-field"><label>SKU Code</label><input type="text" class="in-sku" value="${group.info.sku}" oninput="StockCheckModule.handleSkuLinkage(this)"></div>
            <div class="st-field st-col-2"><label>Product Name</label><input type="text" class="in-name" value="${group.info.prodName}"></div>
            <div class="st-field"><label>Unit Price</label><input type="number" class="in-price" value="${group.info.price}"></div>
          </div>
          <div class="st-sn-section">
            <div class="st-sn-header">
              <label>Serial Numbers (SN)</label>
              <button type="button" class="st-btn-add-sn" onclick="StockCheckModule.addSnRow('${rowId}')">+ Add SN</button>
            </div>
            <div class="st-sn-list"></div>
          </div>
          <div class="st-batch-section">
            <div class="st-batch-header">
              <label>Stock Batches</label>
              <button type="button" class="st-btn-add-batch" onclick="StockCheckModule.addMoreDetail('${rowId}')">+ Add Batch</button>
            </div>
            <div class="st-batch-list"></div>
          </div>
        </div>
      `;

      container.appendChild(row);

      if (group.info.sns && group.info.sns.length > 0) {
        group.info.sns.forEach(sn => this.addSnRow(rowId, sn));
      }

      group.details.forEach(det => this.addMoreDetail(rowId, det));
    });

    document.getElementById('stock-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  handleSkuLinkage: function(input) {
    const skuValue = input.value.trim().toLowerCase();
    if (!skuValue) {
      const row = input.closest('.st-form-card');
      row.querySelector('.in-name').value = '';
      row.querySelector('.in-price').value = 0;
      row.style.borderLeftColor = 'var(--primary)';
      return;
    }

    const match = this._products.find(p => {
      const productSku = (p.sku || p.pos || '').toString().toLowerCase();
      return productSku === skuValue;
    });

    const row = input.closest('.st-form-card');
    const nameInput = row.querySelector('.in-name');
    const priceInput = row.querySelector('.in-price');

    if (match) {
      nameInput.value = match.prodName || match.name || '';
      priceInput.value = match.price || 0;
      row.style.borderLeftColor = 'var(--primary)';
    } else {
      nameInput.value = '';
      priceInput.value = 0;
      row.style.borderLeftColor = 'var(--primary)';
    }
  },
  showAddModal: function() {
    this._editingNo = null;
    document.getElementById('modal-title').innerText = "New Audit Entry";
    document.getElementById('multi-item-container').innerHTML = '';
    document.getElementById('batch-company').value = '';
    document.getElementById('batch-title').value = '';
    document.getElementById('batch-staff').value = '';
    document.getElementById('batch-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('batch-lock-password').value = '';

    this.addItemRow();

    document.getElementById('stock-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  hideAddModal: function() {
    document.getElementById('stock-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  deleteGroup: async function(no) {
    if (!confirm(`Permanently delete audit group ${no}?`)) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const staff = this._inventory.find(p => p.no === no)?.staff || "Unknown";
    this._inventory = this._inventory.filter(p => p.no !== no);
    this.renderContent();
    await this.syncData(true, `Deleted Audit Group: ${no}`, staff);
  },
  deleteEntry: async function(index) {
    if (!confirm("Delete this product entry?")) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const item = this._inventory[index];
    this._inventory.splice(index, 1);
    this.renderContent();
    await this.syncData(true, `Deleted SKU: ${item.sku} from Master`, "Admin");
  },
  updateQuickStock: function(index, field, val) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    this._inventory[index][field] = field === 'exp' ? val : (parseFloat(val) || 0);
    this.renderContent();
    this.syncData(false);
  },
  syncData: async function(log = true, logMsg = "", staff = "") {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._saveFileName}`, {
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify({ products: this._inventory }, null, 2))));

    try {
      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._saveFileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        },
        body: JSON.stringify({
          message: "StockSync",
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        const d = await res.json();
        this._sha = d.content.sha;

        if (log && window.LogModule && typeof window.LogModule.addLog === 'function') {
          window.LogModule.addLog("StockCheck", logMsg, staff);
        }
      } else {
        const errorData = await res.json();
        console.error("Sync Error:", errorData);
      }
    } catch (e) {
      console.error("Cloud Sync Error", e);
    }
  },
  exportFullGroupPDF: function(no) {
    const items = this._inventory.filter(p => p.no === no);
    if (items.length === 0 || !window.jspdf) return alert("System busy or no items.");

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const head = items[0];

    doc.setFontSize(18);
    doc.text("STOCK CHECK REPORT", 14, 20);

    doc.setFontSize(10);
    doc.text(`Ref: ${no} | Company: ${head.company || 'N/A'} | Staff: ${head.staff} | Date: ${head.date}`, 14, 28);

    const tableBody = items.map(i => [
      i.prodName,
      i.sku,
      i.sns && i.sns.length > 0 ? i.sns.join(', ') : '-',
      i.bn || '-',
      i.exp || '-',
      i.whStock,
      i.shelfStock
    ]);

    doc.autoTable({
      startY: 35,
      head: [['Product', 'SKU', 'SN', 'BN', 'EXP', 'WH', 'Shelf']],
      body: tableBody,
      headStyles: { fillColor: [79, 70, 229] }
    });

    doc.save(`stockcheck_${no}.pdf`);
  },
  _updateStaffDatalist: function() {
    const dl = document.getElementById('staff-list');
    if (!dl) return;

    dl.innerHTML = this._staffs.map(s => `<option value="${(typeof s === 'object') ? (s.name || s.staffName || '') : s}"></option>`).join('');
  },
  _updateCompanySelect: function() {
    const sel = document.getElementById('batch-company');
    if (!sel) return;

    const currentVal = sel.value;
    sel.innerHTML = `<option value="">Select company...</option>` + this._companies.map(c => {
      const cName = (typeof c === 'object') ? (c.name || '') : c;
      return `<option value="${cName}">${cName}</option>`;
    }).join('');
    if (currentVal) sel.value = currentVal;
  },
  _injectStyles: function() {
    if (document.getElementById('st-css')) return;

    const s = document.createElement('style');
    s.id = 'st-css';
    s.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .st-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
      }

      .st-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .st-brand {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .st-logo-icon {
        background: var(--primary);
        color: white;
        padding: 10px;
        border-radius: var(--radius-md);
        flex-shrink: 0;
        box-shadow: var(--shadow-primary);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .st-title-group h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .st-title-group p {
        margin: 4px 0 0;
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 500;
      }

      .st-actions {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
      }

      .st-search {
        position: relative;
        width: 280px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .st-search:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .st-search input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
      }

      .st-search svg {
        flex-shrink: 0;
        color: var(--text-dim);
      }

      .st-btn-primary {
        background: var(--primary);
        color: white;
        border: none;
        padding: 10px 20px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: var(--shadow-primary);
        transition: all var(--transition-base);
        white-space: nowrap;
        flex-shrink: 0;
      }

      .st-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .st-btn-primary:active {
        transform: translateY(0);
      }

      .st-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 24px;
      }

      .st-stat-card {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 20px;
        border: 1px solid var(--border);
        transition: all var(--transition-base);
        box-shadow: var(--shadow-sm);
      }

      .st-stat-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
      }

      .st-stat-card label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .st-stat-card b {
        font-size: 22px;
        font-weight: 700;
        color: var(--text);
        letter-spacing: -0.02em;
      }

      .st-stat-card.st-warning {
        border-color: var(--danger);
        background: var(--red-soft);
      }

      .st-nav-tabs {
        display: flex;
        gap: 24px;
        border-bottom: 1px solid var(--border);
        margin-bottom: 24px;
        overflow-x: auto;
      }

      .st-tab-btn {
        background: none;
        border: none;
        padding: 12px 4px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        color: var(--text-secondary);
        position: relative;
        transition: all var(--transition-fast);
        white-space: nowrap;
        flex-shrink: 0;
      }

      .st-tab-btn.active {
        color: var(--primary);
      }

      .st-tab-btn.active::after {
        content: '';
        position: absolute;
        bottom: -1px;
        left: 0;
        width: 100%;
        height: 2px;
        background: var(--primary);
        border-radius: 2px;
      }

      .st-tab-btn:hover {
        color: var(--primary);
      }

      .st-company-section {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 20px;
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        transition: all var(--transition-base);
      }

      .st-company-section-header {
        padding: 18px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        background: var(--surface-soft);
        border-bottom: 1px solid var(--border);
        transition: background var(--transition-fast);
        gap: 16px;
      }

      .st-company-section-header:hover {
        background: var(--border);
      }

      .st-company-info {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
        flex: 1;
        min-width: 0;
      }

      .st-company-info h3 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
      }

      .st-company-section-body {
        max-height: 8000px;
        overflow: hidden;
        transition: max-height 0.35s ease;
        padding: 20px;
        background: var(--bg);
      }

      .st-company-section.is-collapsed .st-company-section-body {
        max-height: 0;
        padding-top: 0;
        padding-bottom: 0;
        border-top: none;
      }

      .st-company-section.is-collapsed .st-expand-icon {
        transform: rotate(-90deg);
      }

      .st-audit-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 16px;
        overflow: hidden;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-xs);
      }

      .st-audit-card:last-child {
        margin-bottom: 0;
      }

      .st-audit-card:hover {
        border-color: var(--primary-light);
        box-shadow: var(--shadow-sm);
      }

      .st-audit-header {
        padding: 18px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        background: var(--surface);
        transition: background var(--transition-fast);
        gap: 16px;
      }

      .st-audit-header:hover {
        background: var(--surface-soft);
      }

      .st-audit-info {
        flex: 1;
        min-width: 0;
      }

      .st-audit-info h3 {
        margin: 8px 0 4px;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
      }

      .st-lock-badge {
        color: var(--danger);
        font-size: 12px;
        font-weight: 600;
        margin-left: 6px;
      }

      .st-ref-tag {
        background: var(--primary-soft);
        color: var(--primary);
        padding: 3px 8px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        font-family: monospace;
        display: inline-block;
      }

      .st-audit-info p {
        margin: 0;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .st-audit-meta {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
        flex-wrap: wrap;
      }

      .st-pill {
        background: var(--surface-soft);
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .st-pill b {
        color: var(--text);
      }

      .st-expand-icon {
        transition: transform var(--transition-base);
        display: flex;
        align-items: center;
        flex-shrink: 0;
        color: var(--text-dim);
      }

      .st-audit-card.is-expanded .st-expand-icon {
        transform: rotate(180deg);
        color: var(--primary);
      }

      .st-audit-expandable-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.35s ease;
        background: var(--surface-soft);
      }

      .st-audit-card.is-expanded .st-audit-expandable-content {
        max-height: 8000px;
        border-top: 1px solid var(--border);
      }

      .st-audit-actions-bar {
        padding: 12px 20px;
        display: flex;
        justify-content: space-between;
        border-top: 1px solid var(--border);
        background: var(--surface-soft);
        flex-wrap: wrap;
        gap: 10px;
      }

      .st-actions-left {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .st-action-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        padding: 6px 14px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        white-space: nowrap;
        color: var(--text-secondary);
      }

      .st-action-btn:hover {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .st-action-btn.st-danger {
        color: var(--danger);
      }

      .st-action-btn.st-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .st-audit-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 14px;
        padding: 20px;
      }

      .st-grid-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 14px 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        transition: all var(--transition-fast);
        flex-wrap: wrap;
      }

      .st-grid-item:hover {
        border-color: var(--primary-light);
        box-shadow: var(--shadow-xs);
      }

      .st-item-info {
        flex: 1;
        min-width: 0;
      }

      .st-item-info strong {
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
        display: block;
      }

      .st-item-info span {
        font-size: 12px;
        color: var(--text-secondary);
        display: block;
        margin-top: 2px;
      }

      .st-item-sn,
      .st-cell-sn {
        font-size: 11px;
        color: var(--primary);
        margin-top: 3px;
        font-weight: 500;
      }

      .st-item-stock {
        text-align: right;
        flex-shrink: 0;
      }

      .st-stock-labels {
        display: flex;
        gap: 6px;
        justify-content: flex-end;
        margin-bottom: 4px;
        flex-wrap: wrap;
      }

      .st-label-wh,
      .st-label-sf {
        padding: 2px 8px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
      }

      .st-label-wh {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .st-label-sf {
        background: var(--green-soft);
        color: var(--green);
      }

      .st-item-stock small {
        font-size: 11px;
        color: var(--text-dim);
        font-family: monospace;
      }

      .st-table-container {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow-x: auto;
        box-shadow: var(--shadow-sm);
      }

      .st-main-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 600px;
      }

      .st-main-table th {
        text-align: left;
        padding: 14px 20px;
        background: var(--surface-soft);
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border);
      }

      .st-main-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
      }

      .st-main-table tr:last-child td {
        border-bottom: none;
      }

      .st-cell-name {
        font-weight: 700;
        color: var(--text);
        font-size: 14px;
      }

      .st-cell-sku {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 2px;
      }

      .st-stock-group {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }

      .st-stock-group input {
        width: 72px;
        padding: 8px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        text-align: center;
        font-size: 13px;
        transition: all var(--transition-fast);
        color: var(--text);
        background: var(--surface);
      }

      .st-stock-group input:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .st-table-input {
        padding: 8px 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        width: 100%;
        max-width: 165px;
        transition: all var(--transition-fast);
        color: var(--text);
        background: var(--surface);
      }

      .st-table-input:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .st-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: scale(0.99);
        transition: visibility 0.2s ease, opacity 0.2s ease, transform 0.2s ease;
        display: flex;
        flex-direction: column;
      }

      .st-modal.active {
        visibility: visible;
        opacity: 1;
        transform: scale(1);
      }

      .st-modal-container {
        height: 100vh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .st-modal-nav {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
        gap: 12px;
        flex-wrap: wrap;
      }

      .st-modal-nav-left {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .st-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        flex-shrink: 0;
        color: var(--text-secondary);
      }

      .st-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      #modal-title {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .st-modal-nav-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
      }

      .st-btn-secondary {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        padding: 10px 18px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .st-btn-secondary:hover {
        background: var(--primary);
        color: white;
      }

      .st-modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 32px 20px;
      }

      .st-form-container {
        max-width: 900px;
        margin: 0 auto;
        width: 100%;
      }

      .st-form-header-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 20px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
      }

      .st-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .st-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .st-field input, .st-select-field {
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        outline: none;
        transition: all var(--transition-fast);
        background: var(--surface);
        width: 100%;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .st-field input:focus, .st-select-field:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .st-items-stack {
        display: flex;
        flex-direction: column;
        gap: 20px;
      }

      .st-form-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow: hidden;
        box-shadow: var(--shadow-xs);
        transition: all var(--transition-base);
      }

      .st-form-card-header {
        padding: 16px 24px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--surface-soft);
        flex-wrap: wrap;
        gap: 10px;
      }

      .st-form-card-header h3 {
        margin: 0;
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
      }

      .st-text-btn-danger {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        font-weight: 600;
        cursor: pointer;
        padding: 6px 12px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        transition: all var(--transition-fast);
      }

      .st-text-btn-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .st-form-card-body {
        padding: 24px;
      }

      .st-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
      }

      .st-col-2 {
        grid-column: span 2;
      }

      .st-sn-section {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 16px;
        border: 1px solid var(--border);
        margin-bottom: 16px;
      }

      .st-sn-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }

      .st-sn-header label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .st-btn-add-sn {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        cursor: pointer;
        font-size: 12px;
        transition: all var(--transition-fast);
      }

      .st-btn-add-sn:hover {
        background: var(--primary);
        color: white;
      }

      .st-sn-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .st-sn-row {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .st-sn-row input {
        flex: 1;
        padding: 8px 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        background: var(--surface);
        color: var(--text);
        outline: none;
        transition: all var(--transition-fast);
      }

      .st-sn-row input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .st-sn-del {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        cursor: pointer;
        padding: 6px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        flex-shrink: 0;
      }

      .st-sn-del:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .st-batch-section {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 16px;
        border: 1px solid var(--border);
      }

      .st-batch-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        flex-wrap: wrap;
        gap: 10px;
      }

      .st-batch-header label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .st-btn-add-batch {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        cursor: pointer;
        font-size: 12px;
        transition: all var(--transition-fast);
      }

      .st-btn-add-batch:hover {
        background: var(--primary);
        color: white;
      }

      .st-batch-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .st-batch-row {
        display: flex;
        align-items: center;
        gap: 10px;
        background: var(--surface);
        padding: 12px 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
      }

      .st-batch-inputs {
        flex: 1;
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr;
        gap: 10px;
      }

      .st-sub-field input {
        width: 100%;
        padding: 8px 10px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        transition: all var(--transition-fast);
        color: var(--text);
        background: var(--surface);
        outline: none;
      }

      .st-sub-field input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .st-batch-del {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        cursor: pointer;
        padding: 6px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        flex-shrink: 0;
      }

      .st-batch-del:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .st-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 16px;
        margin-top: 32px;
        flex-wrap: wrap;
      }

      .st-page-control {
        background: var(--surface);
        border: 1px solid var(--border);
        padding: 8px 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }

      .st-page-control:hover:not(:disabled) {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .st-page-control:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .st-page-info {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .st-empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--text-dim);
        background: var(--surface);
        border-radius: var(--radius-card);
        font-size: 14px;
        border: 1px solid var(--border);
      }

      .desktop-only {
        display: table-cell;
      }

      .mob-label {
        display: none;
      }

      @media (max-width: 1024px) {
        .st-batch-inputs {
          grid-template-columns: 1fr 1fr;
        }
        .st-col-2 {
          grid-column: span 1;
        }
      }

      @media (max-width: 768px) {
        .st-wrapper {
          padding: 16px;
        }
        .st-header {
          flex-direction: column;
          align-items: stretch;
        }
        .st-actions {
          width: 100%;
        }
        .st-search {
          flex: 1;
          width: auto;
          min-width: 160px;
        }
        .st-audit-header {
          flex-direction: column;
          align-items: stretch;
          gap: 12px;
        }
        .st-audit-meta {
          width: 100%;
          justify-content: space-between;
          border-top: 1px solid var(--border);
          padding-top: 12px;
        }
        .st-audit-grid {
          grid-template-columns: 1fr;
          padding: 14px;
        }
        .st-stock-group input {
          width: 64px;
        }
        .desktop-only {
          display: none;
        }
        .st-modal-nav {
          padding: 14px 16px;
        }
        .st-modal-body {
          padding: 20px 14px;
        }
        .st-form-header-card {
          padding: 18px;
          gap: 14px;
          grid-template-columns: 1fr;
        }
        .st-form-card-header,
        .st-form-card-body {
          padding: 18px;
        }
        .st-form-grid {
          grid-template-columns: 1fr;
        }
        .st-batch-inputs {
          grid-template-columns: 1fr 1fr;
          gap: 8px;
        }
        .st-batch-row {
          flex-wrap: wrap;
          padding: 12px;
        }
        .st-batch-del {
          align-self: flex-end;
        }
        .mob-label {
          display: inline-block;
          font-size: 11px;
          font-weight: 600;
          color: var(--text-secondary);
          margin-bottom: 3px;
        }
        .st-sub-field {
          display: flex;
          flex-direction: column;
        }
        .st-stats {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .st-audit-actions-bar {
          flex-direction: column;
          align-items: stretch;
        }
        .st-actions-left {
          justify-content: flex-start;
        }
        .st-action-btn {
          flex: 1;
          text-align: center;
        }
      }

      @media (max-width: 480px) {
        .st-batch-inputs {
          grid-template-columns: 1fr;
        }
        .st-modal-nav-actions {
          width: 100%;
        }
        .st-modal-nav-actions .st-btn-secondary,
        .st-modal-nav-actions .st-btn-primary {
          flex: 1;
          justify-content: center;
        }
      }
    `;
    document.head.appendChild(s);
  }
};

window.StockCheckModule = StockCheckModule;

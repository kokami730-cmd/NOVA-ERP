const TableModule = {
  _tables: [],
  _products: [],
  _sha: '',
  _config: null,
  _currentTable: null,
  _cart: [],
  _searchQuery: '',
  _currentPage: 1,
  _itemsPerPage: 20,
  _fileName: 'db_date/tables.json',
  _productFileName: 'db_date/product.json',
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _initConfig: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
  },
  _logAction: function(action) {
    if (typeof LogModule !== 'undefined' && typeof LogModule.addLog === 'function') {
      const posName = window.pos || (this._config && this._config.windowPos) || 'master-root';
      const operatorName = (this._config && this._config.staff) || 'Root';
      LogModule.addLog(posName, action, operatorName);
    }
  },
  fetchData: async function() {
    this._initConfig();
    const config = this._config;
    if (!config.ghToken || !config.ghRepo) return;

    try {
      const prodRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._productFileName}`, {
        headers: { 'Authorization': `token ${config.ghToken}` },
        cache: 'no-store'
      });
      if (prodRes.ok) {
        const prodData = await prodRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(prodData.content))));
        this._products = db.products || [];
      }

      const tableRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
        headers: { 'Authorization': `token ${config.ghToken}` },
        cache: 'no-store'
      });

      if (tableRes.status === 404) {
        this._tables = [];
        await this.syncToCloud(true);
      } else if (tableRes.ok) {
        const tableData = await tableRes.json();
        this._sha = tableData.sha;
        const db = JSON.parse(decodeURIComponent(escape(atob(tableData.content))));
        this._tables = db.tables || [];
      }
      this.renderGrid();
    } catch (e) {
      console.error("Fetch Data Error:", e);
    }
  },
  syncToCloud: async function(isInitial = false) {
    this._initConfig();
    const config = this._config;
    if (!config.ghToken || !config.ghRepo) return;

    try {
      if (!isInitial) {
        const getRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
          headers: { 'Authorization': `token ${config.ghToken}` }
        });
        if (getRes.ok) {
          const getFileData = await getRes.json();
          this._sha = getFileData.sha;
        }
      }

      const putRes = await fetch(`https://api.github.com/repos/${config.ghRepo}/contents/${this._fileName}`, {
        method: 'PUT',
        headers: { 'Authorization': `token ${config.ghToken}` },
        body: JSON.stringify({
          message: "Table System Update",
          content: btoa(unescape(encodeURIComponent(JSON.stringify({ tables: this._tables }, null, 2)))),
          sha: isInitial ? undefined : this._sha
        })
      });

      if (putRes.ok) {
        const fresh = await putRes.json();
        this._sha = fresh.content.sha;
        return true;
      }
      return false;
    } catch (e) {
      console.error("Sync Error:", e);
      return false;
    }
  },
  render: function(containerId) {
    this._initConfig();
    const container = document.getElementById(containerId);
    if (!container) return;

    this._injectStyles();

    container.innerHTML = `
      <div class="table-wrapper">
        <div class="header-flex">
          <h2>Table Management</h2>
          <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap; width:100%; max-width:450px;">
            <input type="text" id="table-search" class="search-input-alt" placeholder="Search table number..." oninput="TableModule.handleSearch(this.value)">
            <button id="add-table-btn" style="display:none;" onclick="TableModule.promptNewTable()">+ Add Table</button>
          </div>
        </div>
        <div id="table-grid-container" class="table-grid"></div>
        <div id="table-pagination-container" class="pagination-container"></div>
      </div>

      <div id="table-modal" class="table-modal-overlay" onclick="TableModule.closeModal(event)">
        <div class="table-modal-content" onclick="event.stopPropagation()">
          <div class="modal-header">
            <div class="modal-header-left">
              <button onclick="TableModule.closeModal()" class="close-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <div>
                <h3 id="modal-table-title">Table</h3>
                <div id="modal-table-status"></div>
              </div>
            </div>
            <div class="modal-header-right">
              <button onclick="TableModule.closeModal()" class="btn-cancel">Cancel</button>
            </div>
          </div>

          <div class="modal-body">
            <div class="modal-body-inner">
              <div class="modal-form-grid">
                <div class="modal-field">
                  <label class="field-label">Customer Name</label>
                  <input type="text" id="modal-cust-name" class="field-input" placeholder="Enter name...">
                </div>
                <div class="modal-field">
                  <label class="field-label">Pax (No. of people)</label>
                  <input type="number" id="modal-pax" class="field-input" placeholder="0" min="1">
                </div>
              </div>

              <div class="modal-section">
                <label class="field-label">Note / Remark</label>
                <textarea id="modal-note" class="field-input" rows="2" placeholder="Enter note or special requests..."></textarea>
              </div>

              <div class="modal-section" style="position:relative;">
                <label class="field-label">Add Product (Name / SKU)</label>
                <input type="text" id="modal-prod-search" class="field-input" placeholder="Search product..." autocomplete="off" oninput="TableModule.searchProducts(this.value)">
                <div id="modal-prod-results" class="search-results-dropdown"></div>
              </div>

              <div class="modal-section">
                <label class="field-label">Current Order</label>
                <div id="modal-cart-list" class="modal-cart-box">
                  <div style="text-align:center; color:var(--text-dim); padding:20px 0;">No items added.</div>
                </div>
              </div>

              <div class="modal-total-row">
                <div class="modal-total-label">Total Amount</div>
                <div id="modal-total-price" class="modal-total-value">$0.00</div>
              </div>
            </div>
          </div>

          <div class="modal-footer" id="modal-footer-actions">
            <button id="modal-clear-btn" onclick="TableModule.clearOrder()" class="btn-danger" style="flex:1;">Clear & Make Available</button>
            <button id="modal-save-btn" onclick="TableModule.saveTableOrder()" class="btn-primary" style="flex:2;">Save Order & Mark Occupied</button>
          </div>
        </div>
      </div>
    `;

    if (this._isAdmin()) {
      document.getElementById('add-table-btn').style.display = 'inline-flex';
    }

    this.fetchData();
  },
  handleSearch: function(val) {
    this._searchQuery = val.toLowerCase();
    this._currentPage = 1;
    this.renderGrid();
  },
  changePage: function(page) {
    this._currentPage = page;
    this.renderGrid();
  },
  renderGrid: function() {
    const container = document.getElementById('table-grid-container');
    const paginationContainer = document.getElementById('table-pagination-container');
    if (!container) return;

    let filtered = this._tables;
    if (this._searchQuery) {
      filtered = this._tables.filter(t => String(t.tableNo).toLowerCase().includes(this._searchQuery));
    }

    const totalPages = Math.ceil(filtered.length / this._itemsPerPage) || 1;
    if (this._currentPage > totalPages) {
      this._currentPage = totalPages;
    }
    if (this._currentPage < 1) {
      this._currentPage = 1;
    }

    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const paginatedItems = filtered.slice(startIndex, startIndex + this._itemsPerPage);

    if (filtered.length === 0) {
      container.innerHTML = '<div class="table-empty">No tables found.</div>';
      if (paginationContainer) paginationContainer.innerHTML = '';
      return;
    }

    container.innerHTML = paginatedItems.map(t => {
      const isOccupied = t.status === 'occupied';
      const bgColor = isOccupied ? 'linear-gradient(135deg, #f43f5e, #e11d48)' : 'linear-gradient(135deg, #10b981, #059669)';
      const textColor = '#ffffff';
      
      return `
        <div class="table-card" style="background: ${bgColor}; color: ${textColor};" onclick="TableModule.openTable(${t.tableNo})">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div style="font-size:32px; font-weight:900; letter-spacing:-1px;">${t.tableNo}</div>
            <div style="font-size:12px; font-weight:700; text-transform:uppercase; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:20px;">
              ${isOccupied ? 'Occupied' : 'Available'}
            </div>
          </div>
          <div style="margin-top:16px; flex:1;">
            ${isOccupied ? `
              <div style="font-size:15px; font-weight:700; margin-bottom:4px;">👤 ${t.customerName || 'Guest'}</div>
              <div style="font-size:13px; opacity:0.9; font-weight:500;">Pax: ${t.pax || 0}</div>
              ${t.note ? `<div style="font-size:12px; opacity:0.9; margin-top:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">📝 ${t.note}</div>` : ''}
            ` : `
              <div style="font-size:14px; opacity:0.8; font-weight:500;">Ready for seating</div>
            `}
          </div>
          <div style="margin-top:12px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.3); display:flex; justify-content:space-between; align-items:center;">
            <div style="font-size:12px; font-weight:600; opacity:0.9;">${isOccupied ? 'Total' : 'Status'}</div>
            <div style="font-size:18px; font-weight:800;">${isOccupied ? '$' + Number(t.totalAmount || 0).toFixed(2) : 'Open'}</div>
          </div>
        </div>
      `;
    }).join('');

    if (paginationContainer) {
      if (totalPages <= 1) {
        paginationContainer.innerHTML = '';
      } else {
        let pagesHtml = '';
        for (let i = 1; i <= totalPages; i++) {
          pagesHtml += `<button class="pagination-btn ${i === this._currentPage ? 'active' : ''}" onclick="TableModule.changePage(${i})">${i}</button>`;
        }
        paginationContainer.innerHTML = `
          <button class="pagination-btn" ${this._currentPage === 1 ? 'disabled' : ''} onclick="TableModule.changePage(${this._currentPage - 1})">Prev</button>
          ${pagesHtml}
          <button class="pagination-btn" ${this._currentPage === totalPages ? 'disabled' : ''} onclick="TableModule.changePage(${this._currentPage + 1})">Next</button>
        `;
      }
    }
  },
  promptNewTable: function() {
    if (!this._isAdmin()) return alert("Admin access required.");
    
    const tableNo = prompt("Enter new Table Number:");
    if (!tableNo || tableNo.trim() === '') return;

    if (this._tables.some(t => String(t.tableNo) === tableNo.trim())) {
      return alert("Table number already exists.");
    }

    this._tables.push({
      tableNo: tableNo.trim(),
      status: 'available',
      customerName: '',
      pax: 0,
      note: '',
      items: [],
      totalAmount: 0,
      updatedAt: new Date().toISOString()
    });

    this.syncToCloud().then(() => {
      this._logAction(`Created Table ${tableNo.trim()}`);
      this.renderGrid();
    });
  },
  openTable: function(tableNo) {
    this._initConfig();
    const table = this._tables.find(t => String(t.tableNo) === String(tableNo));
    if (!table) return;

    this._currentTable = table;
    this._cart = [...(table.items || [])];

    const modal = document.getElementById('table-modal');
    document.getElementById('modal-table-title').innerText = `Table ${table.tableNo}`;
    document.getElementById('modal-cust-name').value = table.customerName || '';
    document.getElementById('modal-pax').value = table.pax || '';
    document.getElementById('modal-note').value = table.note || '';
    
    const statusEl = document.getElementById('modal-table-status');
    if (table.status === 'occupied') {
      statusEl.innerHTML = '<span style="color:#f43f5e;">● Currently Occupied</span>';
    } else {
      statusEl.innerHTML = '<span style="color:#10b981;">● Currently Available</span>';
    }

    const footerActions = document.getElementById('modal-footer-actions');
    if (this._isAdmin()) {
      footerActions.innerHTML = `
        <button id="modal-delete-btn" onclick="TableModule.deleteTable()" class="btn-danger" style="flex:1;">Delete Table</button>
        <button id="modal-clear-btn" onclick="TableModule.clearOrder()" class="btn-danger" style="flex:1;">Clear & Make Available</button>
        <button id="modal-save-btn" onclick="TableModule.saveTableOrder()" class="btn-primary" style="flex:2;">Save Order & Mark Occupied</button>
      `;
    } else {
      footerActions.innerHTML = `
        <button id="modal-clear-btn" onclick="TableModule.clearOrder()" class="btn-danger" style="flex:1;">Clear & Make Available</button>
        <button id="modal-save-btn" onclick="TableModule.saveTableOrder()" class="btn-primary" style="flex:2;">Save Order & Mark Occupied</button>
      `;
    }

    document.getElementById('modal-prod-search').value = '';
    document.getElementById('modal-prod-results').style.display = 'none';

    this.renderCart();
    modal.classList.add('active');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  },
  closeModal: function(e) {
    if (e && e.target !== document.getElementById('table-modal') && e.type === 'click') return;
    const modal = document.getElementById('table-modal');
    modal.classList.remove('active');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
    this._currentTable = null;
    this._cart = [];
  },
  searchProducts: function(q) {
    const listEl = document.getElementById('modal-prod-results');
    if (!q.trim()) {
      listEl.style.display = 'none';
      return;
    }

    const query = q.toLowerCase();
    const matches = this._products.filter(p => 
      (p.prodName && p.prodName.toLowerCase().includes(query)) || 
      (p.sku && p.sku.toLowerCase().includes(query))
    ).slice(0, 5);

    if (matches.length > 0) {
      listEl.innerHTML = matches.map(p => `
        <div class="search-result-item" onclick="TableModule.addItemToCart('${p.sku}', '${p.prodName.replace(/'/g, "\\'")}', ${p.price})">
          <div>
            <div style="font-weight:600; color:var(--text);">${p.prodName}</div>
            <div style="font-size:11px; color:var(--text-dim);">SKU: ${p.sku || 'N/A'}</div>
          </div>
          <div style="font-weight:700; color:var(--primary);">$${Number(p.price).toFixed(2)}</div>
        </div>
      `).join('');
      listEl.style.display = 'block';
    } else {
      listEl.style.display = 'none';
    }
  },
  addItemToCart: function(sku, name, price) {
    const existing = this._cart.find(i => i.sku === sku);
    if (existing) {
      existing.qty += 1;
    } else {
      this._cart.push({ sku, name, price: Number(price), qty: 1 });
    }
    
    document.getElementById('modal-prod-search').value = '';
    document.getElementById('modal-prod-results').style.display = 'none';
    this.renderCart();
  },
  removeCartItem: function(index) {
    this._cart.splice(index, 1);
    this.renderCart();
  },
  renderCart: function() {
    const listEl = document.getElementById('modal-cart-list');
    const totalEl = document.getElementById('modal-total-price');
    let total = 0;

    if (this._cart.length === 0) {
      listEl.innerHTML = '<div style="text-align:center; color:var(--text-dim); padding:20px 0;">No items added.</div>';
      totalEl.innerText = '$0.00';
      return;
    }

    listEl.innerHTML = this._cart.map((item, i) => {
      const lineTotal = item.price * item.qty;
      total += lineTotal;
      return `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--border);">
          <div>
            <div style="font-weight:600; font-size:14px; color:var(--text);">${item.name}</div>
            <div style="font-size:12px; color:var(--text-secondary);">${item.qty} x $${item.price.toFixed(2)}</div>
          </div>
          <div style="display:flex; align-items:center; gap:12px;">
            <div style="font-weight:700; color:var(--text);">$${lineTotal.toFixed(2)}</div>
            <button onclick="TableModule.removeCartItem(${i})" style="border:1px solid var(--border); background:var(--surface); color:var(--danger); width:30px; height:30px; border-radius:var(--radius-sm); cursor:pointer; font-size:16px; display:flex; align-items:center; justify-content:center;">&times;</button>
          </div>
        </div>
      `;
    }).join('');

    totalEl.innerText = `$${total.toFixed(2)}`;
  },
  saveTableOrder: async function() {
    if (!this._currentTable) return;

    const custName = document.getElementById('modal-cust-name').value.trim();
    const pax = parseInt(document.getElementById('modal-pax').value) || 0;
    const note = document.getElementById('modal-note').value.trim();
    
    let totalAmount = 0;
    this._cart.forEach(i => totalAmount += (i.price * i.qty));

    const tableNo = this._currentTable.tableNo;

    this._currentTable.customerName = custName;
    this._currentTable.pax = pax;
    this._currentTable.note = note;
    this._currentTable.items = this._cart;
    this._currentTable.totalAmount = totalAmount;
    this._currentTable.status = 'occupied';
    this._currentTable.updatedAt = new Date().toISOString();

    const btn = document.getElementById('modal-save-btn');
    btn.innerText = "Saving...";
    btn.disabled = true;

    const success = await this.syncToCloud();
    
    btn.innerText = "Save Order & Mark Occupied";
    btn.disabled = false;

    if (success) {
      this._logAction(`Updated Table ${tableNo} order (Occupied)`);
      this.closeModal();
      this.renderGrid();
    } else {
      alert("Failed to save table data.");
    }
  },
  clearOrder: async function() {
    if (!this._currentTable) return;
    if (!confirm("Clear table data and mark as available?")) return;

    const tableNo = this._currentTable.tableNo;

    this._currentTable.customerName = '';
    this._currentTable.pax = 0;
    this._currentTable.note = '';
    this._currentTable.items = [];
    this._currentTable.totalAmount = 0;
    this._currentTable.status = 'available';
    this._currentTable.updatedAt = new Date().toISOString();

    const btn = document.getElementById('modal-clear-btn');
    btn.innerText = "Clearing...";
    btn.disabled = true;

    const success = await this.syncToCloud();

    btn.innerText = "Clear & Make Available";
    btn.disabled = false;

    if (success) {
      this._logAction(`Cleared Table ${tableNo} (Available)`);
      this.closeModal();
      this.renderGrid();
    } else {
      alert("Failed to clear table data.");
    }
  },
  deleteTable: async function() {
    if (!this._isAdmin()) return alert("Admin access required.");
    if (!this._currentTable) return;
    if (!confirm(`Are you sure you want to delete Table ${this._currentTable.tableNo}?`)) return;

    const tableNo = this._currentTable.tableNo;

    const btn = document.getElementById('modal-delete-btn');
    if (btn) {
      btn.innerText = "Deleting...";
      btn.disabled = true;
    }

    this._tables = this._tables.filter(t => String(t.tableNo) !== String(this._currentTable.tableNo));

    const success = await this.syncToCloud();

    if (btn) {
      btn.innerText = "Delete Table";
      btn.disabled = false;
    }

    if (success) {
      this._logAction(`Deleted Table ${tableNo}`);
      this.closeModal();
      this.renderGrid();
    } else {
      alert("Failed to delete table data.");
    }
  },
  _injectStyles: function() {
    if (document.getElementById('table-module-styles')) return;
    const style = document.createElement('style');
    style.id = 'table-module-styles';
    style.textContent = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }
      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }
      .table-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
      }
      .header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }
      .header-flex h2 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }
      .search-input-alt {
        padding: 10px 16px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        outline: none;
        font-size: 14px;
        flex: 1;
        min-width: 180px;
        background: var(--surface);
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
        color: var(--text);
      }
      .search-input-alt:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }
      #add-table-btn {
        background: var(--primary);
        color: white;
        border: none;
        padding: 10px 20px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        white-space: nowrap;
        box-shadow: var(--shadow-primary);
      }
      #add-table-btn:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }
      .table-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
      }
      .table-card {
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-sm);
        position: relative;
        overflow: hidden;
      }
      .table-card:hover {
        transform: translateY(-3px);
        box-shadow: var(--shadow-md);
      }
      .pagination-container {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 6px;
        margin-top: 32px;
        flex-wrap: wrap;
      }
      .pagination-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        padding: 8px 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }
      .pagination-btn:hover:not(:disabled) {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }
      .pagination-btn.active {
        background: var(--primary);
        border-color: var(--primary);
        color: white;
        box-shadow: var(--shadow-primary);
      }
      .pagination-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }
      .table-modal-overlay {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: scale(0.99);
        transition: visibility 0.2s ease, opacity 0.2s ease, transform 0.2s ease;
        display: none;
        flex-direction: column;
      }
      .table-modal-overlay.active {
        visibility: visible;
        opacity: 1;
        transform: scale(1);
      }
      .table-modal-content {
        height: 100vh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }
      .modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
      }
      .modal-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
      }
      .modal-header-left h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }
      #modal-table-status {
        margin-top: 2px;
        font-size: 12px;
        font-weight: 600;
      }
      .close-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }
      .close-btn:hover {
        background: var(--border);
        color: var(--text);
      }
      .btn-cancel {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 8px 16px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }
      .btn-cancel:hover {
        background: var(--border);
        color: var(--text);
      }
      .modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 32px 20px;
      }
      .modal-body-inner {
        max-width: 900px;
        margin: 0 auto;
      }
      .modal-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 24px;
      }
      .modal-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .modal-section {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
      }
      .field-label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }
      .field-input {
        width: 100%;
        padding: 10px 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        font-size: 14px;
        outline: none;
        transition: all var(--transition-fast);
        background: var(--surface);
        color: var(--text);
        font-family: var(--font-sans);
      }
      .field-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }
      textarea.field-input {
        resize: vertical;
        font-family: var(--font-sans);
      }
      .modal-cart-box {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 14px 16px;
        min-height: 84px;
        border: 1px solid var(--border);
      }
      .modal-total-row {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: var(--shadow-xs);
      }
      .modal-total-label {
        font-size: 15px;
        font-weight: 700;
        color: var(--text-secondary);
      }
      .modal-total-value {
        font-size: 26px;
        font-weight: 800;
        color: var(--primary);
      }
      .search-results-dropdown {
        position: absolute;
        top: calc(100% - 16px);
        left: 24px;
        right: 24px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        z-index: 20;
        margin-top: 4px;
        display: none;
        max-height: 220px;
        overflow-y: auto;
      }
      .search-result-item {
        padding: 12px 16px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid var(--border);
        transition: background var(--transition-fast);
      }
      .search-result-item:hover {
        background: var(--primary-soft);
      }
      .search-result-item:last-child {
        border-bottom: none;
      }
      .modal-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        gap: 12px;
        justify-content: flex-end;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
      }
      .btn-primary {
        background: var(--primary);
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-primary);
      }
      .btn-primary:hover:not(:disabled) {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }
      .btn-danger {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        padding: 10px 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
      }
      .btn-danger:hover:not(:disabled) {
        background: var(--red-soft);
        border-color: var(--danger);
      }
      button:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none !important;
      }
      .table-empty {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }
      @media (max-width: 1024px) {
        .table-grid {
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: 16px;
        }
      }
      @media (max-width: 768px) {
        .table-wrapper {
          padding: 16px;
        }
        .header-flex {
          flex-direction: column;
          align-items: stretch;
          margin-bottom: 20px;
        }
        .header-flex > div {
          width: 100% !important;
          max-width: none !important;
        }
        .table-grid {
          grid-template-columns: 1fr;
          gap: 16px;
        }
        .modal-header {
          padding: 14px 16px;
        }
        .modal-body {
          padding: 20px 14px;
        }
        .modal-form-grid {
          grid-template-columns: 1fr;
        }
        .modal-section {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .modal-footer {
          padding: 14px 16px;
          flex-direction: column;
        }
        .btn-primary, .btn-danger {
          width: 100%;
          flex: none !important;
          text-align: center;
        }
      }
    `;
    document.head.appendChild(style);
  }
};

window.TableModule = TableModule;

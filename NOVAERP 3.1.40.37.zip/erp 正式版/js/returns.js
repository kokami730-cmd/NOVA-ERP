const ReturnsPortalModule = {
  _products: [],
  _staffs: [],
  _returnsLogs: [],
  _config: null,
  _sha: null,
  _fileName: 'db_date/product.json',
  _staffFileName: 'db_date/staff.json',
  _returnsFileName: 'db_date/returns_logs.json',
  _currentPage: 1,
  _pageSize: 20,
  _editingId: null,
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    this._loadDependencies();

    container.innerHTML = `
      <div class="ret-main-container">
        <header class="ret-header">
          <div class="ret-header-info">
            <h1>Returns Portal</h1>
            </div>
          <div class="ret-header-actions">
            <button class="ret-btn-primary" onclick="ReturnsPortalModule.showModal()">
              <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
              <span>New Return</span>
            </button>
          </div>
        </header>

        <div class="ret-toolbar">
          <div class="ret-search-wrapper">
            <svg class="ret-search-icon" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>
            <input type="text" id="ret-search" placeholder="Search Title, ID, Staff or Status..." oninput="ReturnsPortalModule.handleSearch(this.value)">
          </div>
        </div>

        <div id="ret-list-area" class="ret-content-area">
          <div class="ret-loading">
            <div class="ret-spinner"></div>
            <p>Loading data...</p>
          </div>
        </div>
      </div>

      <div id="ret-modal" class="ret-modal">
        <div class="ret-modal-inner">
          <div class="ret-modal-header">
            <div class="ret-modal-header-left">
              <button type="button" class="ret-btn-back" onclick="ReturnsPortalModule.hideModal()">
                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <div class="ret-modal-title">
                <h2 id="ret-modal-headline">Return Entry</h2>
              </div>
            </div>
            <div class="ret-modal-header-actions">
              <button type="button" class="ret-modal-close" onclick="ReturnsPortalModule.hideModal()">Close</button>
              <button type="submit" form="ret-form" class="ret-btn-save">Save</button>
            </div>
          </div>

          <form id="ret-form" class="ret-modal-body">
            <div class="ret-modal-body-inner">
              <div class="ret-section">
                <h3 class="ret-section-label">General Information</h3>
                <div class="ret-form-row">
                  <div class="ret-field full-width">
                    <label>Return Title / Case Summary</label>
                    <input type="text" id="ret-title" placeholder="e.g. Broken screen batch, Wrong items sent..." required>
                  </div>
                </div>
                <div class="ret-form-row three-cols">
                  <div class="ret-field">
                    <label>Process Staff</label>
                    <input type="text" id="ret-staff" list="ret-staff-list" required placeholder="Select Staff">
                    <datalist id="ret-staff-list"></datalist>
                  </div>
                  <div class="ret-field">
                    <label>Ref / Order No</label>
                    <input type="text" id="ret-order-ref" placeholder="Invoice/Order #">
                  </div>
                  <div class="ret-field">
                    <label>Status</label>
                    <select id="ret-status">
                      <option value="Pending">Pending Inspection</option>
                      <option value="Inspected">Inspected (Passed)</option>
                      <option value="Damaged">Damaged (Scrap)</option>
                      <option value="Completed">Stock Re-entered</option>
                    </select>
                  </div>
                </div>
              </div>

              <div class="ret-section">
                <div class="ret-section-header">
                  <h3 class="ret-section-label" style="margin:0;">Returned Items</h3>
                  <button type="button" class="ret-btn-add" onclick="ReturnsPortalModule.addItemRow()">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                    Add Product
                  </button>
                </div>
                <div id="ret-items-container" class="ret-items-list"></div>
              </div>

              <div class="ret-section">
                <div class="ret-field full-width" style="margin-bottom:18px;">
                  <label>Internal Remarks</label>
                  <textarea id="ret-notes" rows="4" placeholder="Additional details regarding this return..."></textarea>
                </div>
                <div class="ret-form-row two-cols" style="margin-bottom:0;">
                  <div class="ret-field">
                    <label>Bank Name (Optional)</label>
                    <input type="text" id="ret-bank-name" placeholder="e.g. HSBC, ICBC">
                  </div>
                  <div class="ret-field">
                    <label>Bank Account No (Optional)</label>
                    <input type="text" id="ret-bank-account" placeholder="Account Number">
                  </div>
                </div>
              </div>
            </div>
          </form>

          <div class="ret-modal-footer">
            <button type="button" class="ret-btn-text" onclick="ReturnsPortalModule.hideModal()">Discard</button>
            <button type="submit" form="ret-form" class="ret-btn-primary-large">Confirm & Save Return</button>
          </div>
        </div>
      </div>
    `;

    await this.load();
    this._bindEvents();
  },
  addItemRow: function(data = { sku: '', name: '', qty: 1, bn: '', cost: '', exp: '', invNo: '', invDate: '' }) {
    const container = document.getElementById('ret-items-container');
    const rowId = 'ret-row-' + Math.random().toString(16).slice(2);
    const div = document.createElement('div');
    div.className = 'ret-item-row';
    div.id = rowId;

    div.innerHTML = `
      <div class="ret-item-grid">
        <div class="ret-item-sku">
          <label>SKU</label>
          <input type="text" class="ret-sku" placeholder="SKU" value="${data.sku || ''}" oninput="ReturnsPortalModule.handleItemLink(this)" required>
        </div>
        <div class="ret-item-name">
          <label>Product Name</label>
          <input type="text" class="ret-name readonly" value="${data.name || ''}" readonly placeholder="Auto-sync">
        </div>
        <div class="ret-item-qty">
          <label>Qty</label>
          <input type="number" class="ret-qty" value="${data.qty || 1}" min="1">
        </div>
        <div class="ret-item-bn">
          <label>BN (Batch)</label>
          <input type="text" class="ret-bn" value="${data.bn || ''}" placeholder="Batch No">
        </div>
        <div class="ret-item-cost">
          <label>Unit Cost</label>
          <input type="number" step="0.01" class="ret-cost" value="${data.cost || ''}" placeholder="0.00">
        </div>
        <div class="ret-item-exp">
          <label>Exp Date</label>
          <input type="date" class="ret-exp" value="${data.exp || ''}">
        </div>
        <div class="ret-item-invno">
          <label>Inv No</label>
          <input type="text" class="ret-inv-no" value="${data.invNo || ''}" placeholder="Invoice Ref">
        </div>
        <div class="ret-item-invdate">
          <label>Inv Date</label>
          <input type="date" class="ret-inv-date" value="${data.invDate || ''}">
        </div>
        <button type="button" class="ret-btn-remove" onclick="document.getElementById('${rowId}').remove()">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
    `;

    container.prepend(div);
    if (data.sku) this.handleItemLink(div.querySelector('.ret-sku'));
  },
  processReturn: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const itemRows = document.querySelectorAll('#ret-items-container .ret-item-row');
    const items = Array.from(itemRows).map(row => {
      const sku = row.querySelector('.ret-sku').value;
      const name = row.querySelector('.ret-name').value;
      const qty = parseInt(row.querySelector('.ret-qty').value) || 0;
      const bn = row.querySelector('.ret-bn').value;
      const cost = row.querySelector('.ret-cost').value;
      const exp = row.querySelector('.ret-exp').value;
      const invNo = row.querySelector('.ret-inv-no').value;
      const invDate = row.querySelector('.ret-inv-date').value;

      const existingProduct = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === sku.toLowerCase());
      const finalName = existingProduct ? (existingProduct.prodName || existingProduct.name || name) : name;
      const finalCost = existingProduct ? (existingProduct.cost || existingProduct.price || cost) : cost;

      return { sku, name: finalName, qty, bn, cost: finalCost, exp, invNo, invDate };
    });

    const mergedItems = [];
    items.forEach(item => {
      const existing = mergedItems.find(m => m.sku === item.sku && m.bn === item.bn);
      if (existing) {
        existing.qty += item.qty;
      } else {
        mergedItems.push(item);
      }
    });

    if (mergedItems.length === 0) return alert("Please add at least one item.");

    const logData = {
      title: document.getElementById('ret-title').value,
      staff: document.getElementById('ret-staff').value,
      orderRef: document.getElementById('ret-order-ref').value,
      status: document.getElementById('ret-status').value,
      notes: document.getElementById('ret-notes').value,
      items: mergedItems,
      totalQty: mergedItems.reduce((sum, i) => sum + i.qty, 0),
      bankName: document.getElementById('ret-bank-name').value,
      bankAccount: document.getElementById('ret-bank-account').value
    };

    const saveBtn = document.querySelector('.ret-btn-primary-large');
    saveBtn.disabled = true;
    saveBtn.innerText = "Syncing...";

    let targetId = this._editingId;
    let actionDesc = "";

    if (this._editingId) {
      const idx = this._returnsLogs.findIndex(l => l.id === this._editingId);
      if (idx > -1) {
        this._returnsLogs[idx] = { ...this._returnsLogs[idx], ...logData, lastUpdate: new Date().toLocaleString() };
        actionDesc = `Updated Return Case: ${targetId} (${logData.title})`;
      }
    } else {
      targetId = 'RET' + Date.now();
      this._returnsLogs.unshift({
        id: targetId,
        ...logData,
        date: new Date().toLocaleString()
      });
      actionDesc = `Created New Return Case: ${targetId} (${logData.title})`;
    }

    if (window.LogModule && typeof window.LogModule.addLog === 'function') {
      const currentUser = this._config.username || logData.staff || "System";
      await window.LogModule.addLog('ReturnsPortal', actionDesc, currentUser);
    }

    await this.sync();
    this.hideModal();
    this.renderLogs();

    saveBtn.disabled = false;
    saveBtn.innerText = "Confirm & Save Return";

    if (!this._editingId) {
      if (confirm("Return logged successfully. Download PDF?")) this.downloadPDF(targetId);
    }
  },
  downloadPDF: function(id) {
    const log = this._returnsLogs.find(l => l.id === id);
    if (!log || !window.jspdf) return;

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('landscape');

    doc.setFontSize(20).text(log.title || "Return Merchandise (RMA) Report", 14, 20);
    doc.setFontSize(10).setTextColor(100).text([
      `Case ID: ${log.id}`,
      `Staff: ${log.staff} | Status: ${log.status}`,
      `Date: ${log.date}`,
      `Ref Order: ${log.orderRef || 'N/A'}`,
      `Notes: ${log.notes || 'None'}`
    ], 14, 30);

    doc.autoTable({
      startY: 60,
      head: [['SKU', 'Product Name', 'Qty', 'BN', 'Cost', 'Exp Date', 'Inv No', 'Inv Date']],
      body: log.items.map(i => [i.sku, i.name, i.qty, i.bn, i.cost, i.exp, i.invNo, i.invDate]),
      theme: 'striped',
      headStyles: { fillColor: [30, 41, 59] }
    });

    const finalY = doc.lastAutoTable.finalY + 10;

    const bankName = log.bankName ? log.bankName.trim() : '';
    const bankAccount = log.bankAccount ? log.bankAccount.trim() : '';

    if (bankName || bankAccount) {
      let bankText = '';
      if (bankName && bankAccount) {
        bankText = `Bank: ${bankName} | Account: ${bankAccount}`;
      } else if (bankName) {
        bankText = `Bank: ${bankName}`;
      } else if (bankAccount) {
        bankText = `Account: ${bankAccount}`;
      }
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text(bankText, 14, finalY);
    }

    doc.save(`RMA_${log.id}.pdf`);
  },
  showModal: function(editId = null) {
    this._editingId = editId;
    const form = document.getElementById('ret-form');
    form.reset();
    document.getElementById('ret-items-container').innerHTML = '';

    document.getElementById('ret-modal-headline').innerText = editId ? "Edit Return Case" : "New Return Case";

    const bankNameInput = document.getElementById('ret-bank-name');
    const bankAccountInput = document.getElementById('ret-bank-account');
    if (bankNameInput) bankNameInput.value = '';
    if (bankAccountInput) bankAccountInput.value = '';

    if (editId) {
      const log = this._returnsLogs.find(l => l.id === editId);
      if (log) {
        document.getElementById('ret-title').value = log.title || '';
        document.getElementById('ret-staff').value = log.staff || '';
        document.getElementById('ret-order-ref').value = log.orderRef || '';
        document.getElementById('ret-status').value = log.status || 'Pending';
        document.getElementById('ret-notes').value = log.notes || '';
        if (bankNameInput) bankNameInput.value = log.bankName || '';
        if (bankAccountInput) bankAccountInput.value = log.bankAccount || '';
        if (log.items) log.items.forEach(item => this.addItemRow(item));
      }
    } else {
      this.addItemRow();
    }

    document.getElementById('ret-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  deleteLog: async function(id) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const log = this._returnsLogs.find(l => l.id === id);
    if (!confirm(`Confirm deletion of Case ${id}? This cannot be undone.`)) return;

    const idx = this._returnsLogs.findIndex(l => l.id === id);
    if (idx > -1) {
      if (window.LogModule && typeof window.LogModule.addLog === 'function') {
        const currentUser = this._config.username || "System";
        await window.LogModule.addLog('ReturnsPortal', `Deleted Return Case: ${id} (${log?.title || 'Unknown'})`, currentUser);
      }
      this._returnsLogs.splice(idx, 1);
      await this.sync();
      this.renderLogs();
    }
  },
  renderLogs: function() {
    const area = document.getElementById('ret-list-area');
    const countSpan = document.getElementById('ret-log-count');

    if (countSpan) countSpan.innerText = `${this._returnsLogs.length} Records`;

    if (this._returnsLogs.length === 0) {
      area.innerHTML = `
        <div class="ret-empty">
          <div class="ret-empty-icon"></div>
          <h3>No records found</h3>
          <p>Click "New Return" to start a return process.</p>
        </div>
      `;
      return;
    }

    area.innerHTML = `
      <div class="ret-table-wrapper">
        <table class="ret-table">
          <thead>
            <tr>
              <th>Transaction</th>
              <th>Case Title / Summary</th>
              <th class="ret-hide-small">Staff / Ref</th>
              <th class="ret-hide-mobile">Items Summary</th>
              <th>Status</th>
              <th class="ret-text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            ${this._returnsLogs.map(l => `
              <tr class="ret-data-row">
                <td>
                  <div class="ret-id-tag">${l.id.substring(0, 15)}</div>
                  <div class="ret-time-stamp">${l.date}</div>
                </td>
                <td>
                  <div class="ret-main-text" title="${l.title}">${l.title || 'Untitled Return'}</div>
                  <div class="ret-mobile-only-staff">${l.staff}</div>
                </td>
                <td class="ret-hide-small">
                  <div class="ret-main-text">${l.staff}</div>
                  <div class="ret-sub-text"># ${l.orderRef || '--'}</div>
                </td>
                <td class="ret-hide-mobile">
                  <div class="ret-item-summary">${l.items && l.items[0] ? l.items[0].name : 'Unknown'}</div>
                  ${l.items && l.items.length > 1 ? `<div class="ret-more-badge">+${l.items.length - 1} more</div>` : ''}
                </td>
                <td>
                  <span class="ret-status ${l.status ? l.status.toLowerCase() : 'pending'}">${l.status || 'Pending'}</span>
                </td>
                <td class="ret-text-right">
                  <div class="ret-btn-group">
                    <button class="ret-icon-btn" title="PDF" onclick="ReturnsPortalModule.downloadPDF('${l.id}')">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                    </button>
                    <button class="ret-icon-btn" title="Edit" onclick="ReturnsPortalModule.showModal('${l.id}')">
                      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button class="ret-icon-btn delete" title="Delete" onclick="ReturnsPortalModule.deleteLog('${l.id}')">
                      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  },
  handleSearch: function(val) {
    const term = val.toLowerCase();
    const rows = document.querySelectorAll('.ret-data-row');
    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.style.display = text.includes(term) ? '' : 'none';
    });
  },
  _loadDependencies: function() {
    if (window.jspdf) return;
    const scripts = [
      "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
      "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"
    ];
    scripts.forEach(src => {
      const s = document.createElement('script');
      s.src = src;
      document.head.appendChild(s);
    });
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (!this._config.ghToken || !this._config.ghRepo) return;

    const headers = {
      'Authorization': `token ${this._config.ghToken}`
    };

    try {
      const [prodRes, staffRes, retRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._fileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._staffFileName}`, { headers, cache: 'no-store' }),
        fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._returnsFileName}`, { headers, cache: 'no-store' })
      ]);

      if (prodRes.ok) {
        const d = await prodRes.json();
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = decoded.products || [];
      }

      if (staffRes.ok) {
        const d = await staffRes.json();
        const data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._staffs = data.staffs || (Array.isArray(data) ? data : []);
        this._updateStaffDatalist();
      }

      if (retRes.ok) {
        const d = await retRes.json();
        this._sha = d.sha;
        const data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._returnsLogs = data.returns || [];
      } else if (retRes.status === 404) {
        this._returnsLogs = [];
        this._sha = null;
      }

      this.renderLogs();
    } catch (e) {
      console.error("Returns Load Error", e);
    }
  },
  _updateStaffDatalist: function() {
    const dl = document.getElementById('ret-staff-list');
    if (dl) {
      dl.innerHTML = this._staffs.map(s => `<option value="${s.name || s}"></option>`).join('');
    }
  },
  handleItemLink: function(input) {
    const val = input.value.trim().toLowerCase();
    const product = this._products.find(p => (p.sku || p.pos || '').toString().toLowerCase() === val);
    const row = input.closest('.ret-item-row');
    const nameInput = row.querySelector('.ret-name');
    const costInput = row.querySelector('.ret-cost');
    
    if (product) {
      nameInput.value = product.prodName || product.name || '';
      if (costInput && !costInput.value) {
        costInput.value = product.cost || product.price || '';
      }
      row.style.borderLeft = '3px solid var(--primary)';
    } else {
      nameInput.value = '';
      row.style.borderLeft = '';
    }
  },
  hideModal: function() {
    document.getElementById('ret-modal').classList.remove('active');
    document.body.style.overflow = '';
    this._editingId = null;
  },
  _bindEvents: function() {
    const form = document.getElementById('ret-form');
    form.onsubmit = null;
    form.onsubmit = async (e) => {
      e.preventDefault();
      await this.processReturn();
    };
  },
  sync: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._returnsFileName}`, {
        headers: {
          'Authorization': `token ${this._config.ghToken}`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify({ returns: this._returnsLogs, lastSync: new Date().toISOString() }, null, 2))));

    try {
      const res = await fetch(`https://api.github.com/repos/${this._config.ghRepo}/contents/${this._returnsFileName}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${this._config.ghToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: "Sync Returns Portal Database",
          content: content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.content.sha;
      } else {
        const errorData = await res.json();
        console.error("Sync Error:", errorData);
        alert("Failed to sync with cloud: " + (errorData.message || "Unknown error"));
      }
    } catch (e) {
      console.error("Sync Error:", e);
      alert("Failed to sync with cloud. Check console.");
    }
  },
  _injectStyles: function() {
    if (document.getElementById('ret-portal-styles')) return;

    const style = document.createElement('style');
    style.id = 'ret-portal-styles';
    style.innerHTML = `
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .ret-main-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        width: 100%;
      }

      .ret-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .ret-header-info h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .ret-header-meta {
        margin-top: 6px;
      }

      .ret-count-tag {
        font-size: 12px;
        font-weight: 600;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 4px 12px;
        border-radius: var(--radius-sm);
        display: inline-block;
      }

      .ret-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .ret-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .ret-btn-primary:active {
        transform: translateY(0);
      }

      .ret-toolbar {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        height: 42px;
        display: flex;
        align-items: center;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
        transition: all var(--transition-fast);
      }

      .ret-toolbar:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .ret-search-wrapper {
        position: relative;
        width: 100%;
        display: flex;
        align-items: center;
      }

      .ret-search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .ret-search-wrapper input {
        width: 100%;
        padding: 0 10px;
        border: none;
        font-size: 14px;
        background: transparent;
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .ret-table-wrapper {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow-x: auto;
        box-shadow: var(--shadow-xs);
      }

      .ret-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
      }

      .ret-table th {
        text-align: left;
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        background: var(--surface-soft);
        border-bottom: 1px solid var(--border);
      }

      .ret-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        font-size: 13px;
        color: var(--text);
        vertical-align: middle;
      }

      .ret-table tr:last-child td {
        border-bottom: none;
      }

      .ret-text-right {
        text-align: right;
      }

      .ret-id-tag {
        font-family: monospace;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        display: inline-block;
        border: 1px solid var(--border);
      }

      .ret-time-stamp {
        font-size: 11px;
        color: var(--text-dim);
        margin-top: 4px;
      }

      .ret-main-text {
        font-weight: 600;
        font-size: 13px;
        color: var(--text);
        word-break: break-word;
      }

      .ret-sub-text {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 2px;
        word-break: break-word;
      }

      .ret-item-summary {
        font-size: 13px;
        color: var(--text);
        word-break: break-word;
      }

      .ret-more-badge {
        display: inline-block;
        font-size: 11px;
        font-weight: 600;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 2px 8px;
        border-radius: var(--radius-xs);
        margin-top: 4px;
      }

      .ret-status {
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        white-space: nowrap;
      }

      .ret-status.pending {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .ret-status.inspected {
        background: var(--green-soft);
        color: var(--green);
      }

      .ret-status.damaged {
        background: var(--red-soft);
        color: var(--danger);
      }

      .ret-status.completed {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .ret-btn-group {
        display: flex;
        gap: 6px;
        justify-content: flex-end;
      }

      .ret-icon-btn {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        background: var(--surface);
        cursor: pointer;
        color: var(--text-secondary);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
      }

      .ret-icon-btn:hover {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .ret-icon-btn.delete:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .ret-empty,
      .ret-loading {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-size: 14px;
      }

      .ret-spinner {
        width: 28px;
        height: 28px;
        border: 3px solid var(--border);
        border-top-color: var(--primary);
        border-radius: 50%;
        margin: 0 auto 12px;
        animation: retSpin 0.8s linear infinite;
      }

      @keyframes retSpin {
        to { transform: rotate(360deg); }
      }

      .ret-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: none;
      }

      .ret-modal.active {
        display: block;
      }

      .ret-modal-inner {
        background: var(--bg);
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .ret-modal-header {
        background: var(--surface);
        padding: 16px 28px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .ret-modal-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }

      .ret-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .ret-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .ret-modal-title h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .ret-modal-header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
      }

      .ret-modal-close {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .ret-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .ret-btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 36px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .ret-btn-save:hover {
        background: var(--primary-dark);
      }

      .ret-modal-body {
        padding: 28px 20px;
        overflow-y: auto;
        flex: 1;
      }

      .ret-modal-body-inner {
        max-width: 960px;
        width: 100%;
        margin: 0 auto;
      }

      .ret-section {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-xs);
      }

      .ret-section:last-child {
        margin-bottom: 0;
      }

      .ret-section-label {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        margin: 0 0 18px 0;
      }

      .ret-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 18px;
        gap: 12px;
        flex-wrap: wrap;
      }

      .ret-btn-add {
        background: var(--primary-soft);
        border: 1px solid transparent;
        color: var(--primary);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .ret-btn-add:hover {
        background: var(--primary);
        color: white;
      }

      .ret-form-row {
        display: grid;
        gap: 16px;
        margin-bottom: 18px;
      }

      .ret-form-row:last-child {
        margin-bottom: 0;
      }

      .ret-form-row.three-cols {
        grid-template-columns: repeat(3, 1fr);
      }

      .ret-form-row.two-cols {
        grid-template-columns: repeat(2, 1fr);
      }

      .ret-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .ret-field.full-width {
        grid-column: 1 / -1;
      }

      .ret-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .ret-field input,
      .ret-field select,
      .ret-field textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .ret-field input,
      .ret-field select {
        height: 42px;
      }

      .ret-field input:focus,
      .ret-field select:focus,
      .ret-field textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .ret-field textarea {
        border-radius: var(--radius-md);
        resize: vertical;
      }

      .ret-items-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
      }

      .ret-item-row {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px;
        position: relative;
        transition: all var(--transition-fast);
      }

      .ret-item-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 14px;
        align-items: end;
      }

      .ret-item-grid label {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        display: block;
        margin-bottom: 6px;
      }

      .ret-item-grid input {
        width: 100%;
        height: 38px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        background: var(--surface);
        font-size: 13px;
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        transition: all var(--transition-fast);
      }

      .ret-item-grid input.readonly {
        background: var(--surface-soft);
        color: var(--text-secondary);
      }

      .ret-item-grid input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .ret-btn-remove {
        position: absolute;
        top: 10px;
        right: 10px;
        width: 28px;
        height: 28px;
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        cursor: pointer;
        border-radius: var(--radius-sm);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
      }

      .ret-btn-remove:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .ret-modal-footer {
        background: var(--surface);
        padding: 16px 28px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
        flex-wrap: wrap;
      }

      .ret-btn-text {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        height: 40px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .ret-btn-text:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .ret-btn-primary-large {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 22px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .ret-btn-primary-large:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      @media (max-width: 1024px) {
        .ret-item-grid {
          grid-template-columns: repeat(2, 1fr);
        }
      }

      @media (max-width: 768px) {
        .ret-main-container {
          padding: 16px;
        }
        .ret-form-row.three-cols,
        .ret-form-row.two-cols {
          grid-template-columns: 1fr;
        }
        .ret-item-grid {
          grid-template-columns: 1fr;
        }
        .ret-modal-header {
          padding: 14px 16px;
        }
        .ret-modal-body {
          padding: 18px 14px;
        }
        .ret-section {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .ret-modal-footer {
          padding: 14px 16px;
          flex-direction: column-reverse;
          align-items: stretch;
        }
        .ret-modal-footer button {
          width: 100%;
        }
        .ret-hide-small,
        .ret-hide-mobile {
          display: none;
        }
        .ret-mobile-only-staff {
          font-size: 12px;
          color: var(--text-secondary);
          margin-top: 4px;
        }
      }

      @media (min-width: 769px) {
        .ret-mobile-only-staff {
          display: none;
        }
        .ret-hide-small {
          display: table-cell;
        }
        .ret-hide-mobile {
          display: table-cell;
        }
      }
    `;
    document.head.appendChild(style);
  }
};

window.ReturnsPortalModule = ReturnsPortalModule;

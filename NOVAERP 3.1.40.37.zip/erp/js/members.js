(function(){
const _0x1=[0x5b,0x2e,0x91,0x3c,0x74,0xa8,0x19,0xe3,0x6d,0x47,0xc2,0x85,0x31,0xb9,0x54,0xda];
function _0x2(_0x3){
  const _0x4=new Uint8Array(_0x3.length);
  for(let _0x5=0;_0x5<_0x3.length;_0x5++){
    _0x4[_0x5]=_0x3[_0x5]^_0x1[_0x5%_0x1.length]^((_0x5*73)&0xff);
  }
  return new TextDecoder().decode(_0x4);
}
const _0x6=`const MemberModule = {
  _data: [],
  _filteredData: [],
  _config: null,
  _currentId: null,
  _sha: null,
  _currentPage: 1,
  _pageSize: 20,
  _staffList: [],
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _loadStaffData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    const config = this._config;
    if (!config.ghRepo || !config.ghToken) return;
    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        },
        cache: 'no-store'
      });
      if (res.ok) {
        const data = await res.json();
        this._staffList = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      }
    } catch (e) {
      if (window.StaffModule && Array.isArray(window.StaffModule._data)) {
        this._staffList = window.StaffModule._data;
      }
    }
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    await this._loadStaffData();

    const currentYear = new Date().getFullYear();

    container.innerHTML = \`
      <div class="member-app-wrapper">
        <header class="member-main-header">
          <div class="brand-info">
            <h1>Member Directory</h1>
           </div>
          <button type="button" class="btn-add-member" onclick="MemberModule.openEditor()">
            <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span class="text-label">New Member</span>
          </button>
        </header>

        <div class="member-filter-bar">
          <div class="search-input-wrapper">
            <svg class="icon-search" viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="member-search" placeholder="Search by name, phone or #No..." oninput="MemberModule.filter()">
          </div>
        </div>

        <main id="member-list" class="member-responsive-grid">
          <div class="loading-placeholder">Loading directory...</div>
        </main>

        <footer id="member-pagination" class="modern-pagination"></footer>
      </div>

      <div id="member-modal" class="member-modal-fullscreen">
        <div class="modal-inner-content">
          <nav class="modal-top-nav">
            <div class="nav-left">
              <button type="button" class="btn-back" onclick="MemberModule.closeEditor()">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h2 id="member-modal-title">Member Profile</h2>
            </div>
            <div class="nav-right">
              <button type="button" id="member-del-btn" class="btn-delete-action" onclick="MemberModule.delete()" style="display:none" title="Delete Member">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                <span>Delete</span>
              </button>
            </div>
          </nav>

          <form id="member-form" class="modal-scroll-form" onsubmit="MemberModule.save(event)">
            <div class="form-layout-container">
              <section class="form-section-card">
                <div class="section-header">
                  <h3>Personal Details</h3>
                </div>
                <div class="form-grid">
                  <div class="form-field">
                    <label>Full Name</label>
                    <input type="text" name="name" required placeholder="Full Name">
                  </div>
                  <div class="form-field">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" required placeholder="01x-xxxxxxx">
                  </div>
                  <div class="form-field">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="email@example.com">
                  </div>
                  <div class="form-field">
                    <label>Date of Birth</label>
                    <input type="date" name="birthday">
                  </div>
                  <div class="form-field full-width">
                    <label>Full Address</label>
                    <input type="text" name="address" placeholder="Residential address details">
                  </div>
                  <div class="form-field full-width">
                    <label>In Charge Staff</label>
                    <select name="staffInCharge" class="staff-select">
                      <option value="">-- Select Staff --</option>
                      \${this._staffList.map(st => \`<option value="\${st.name}">\${st.name} (\${st.position || 'Staff'})</option>\`).join('')}
                    </select>
                  </div>
                </div>
              </section>

              <section class="form-section-card appointment-card">
                <div class="section-header">
                  <h3>Appointment Booking</h3>
                </div>
                <div class="form-grid">
                  <div class="form-field">
                    <label>Year (Auto)</label>
                    <input type="text" name="aptYear" value="\${currentYear}" readonly class="readonly-field">
                  </div>
                  <div class="form-field">
                    <label>Date</label>
                    <input type="date" name="aptDate">
                  </div>
                  <div class="form-field">
                    <label>Time</label>
                    <input type="time" name="aptTime">
                  </div>
                  <div class="form-field">
                    <label>Number of Guests</label>
                    <input type="number" name="aptGuests" min="1" placeholder="e.g. 2">
                  </div>
                  <div class="form-field full-width">
                    <label>Booking Content / Service</label>
                    <textarea name="aptContent" rows="2" placeholder="Describe the appointment purpose..."></textarea>
                  </div>
                </div>
              </section>

              <section class="form-section-card highlight-card">
                <div class="section-header">
                  <h3>Membership & Loyalty</h3>
                </div>
                <div class="form-grid">
                  <div class="form-field">
                    <label>Tier Status</label>
                    <select name="tier" onchange="MemberModule.handleTierChange(this.value)">
                      <option value="Bronze">Bronze Tier</option>
                      <option value="Silver">Silver Tier</option>
                      <option value="Gold">Gold Tier</option>
                      <option value="Platinum">Platinum Tier</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div class="form-field" id="custom-tier-wrapper" style="display:none;">
                    <label>Custom Tier Name</label>
                    <input type="text" name="customTier" id="custom-tier-input" placeholder="Enter custom tier...">
                  </div>
                  <div class="form-field">
                    <label>Reward Points</label>
                    <input type="number" name="points" value="0">
                  </div>
                  <div class="form-field full-width">
                    <label>Internal Remarks</label>
                    <textarea name="notes" rows="3" placeholder="Preferences, history, etc..."></textarea>
                  </div>
                </div>
              </section>
            </div>

            <footer class="form-fixed-footer">
              <div class="footer-meta">
                <span class="label">Registration Date</span>
                <span id="member-joined-display" class="value">-</span>
                <input type="hidden" name="joinedDate" id="member-joined-hidden">
              </div>
              <button type="submit" class="btn-submit-save">Update Directory</button>
            </footer>
          </form>
        </div>
      </div>
    \`;

    await this.load();
  },
  handleTierChange: function(val) {
    const customWrapper = document.getElementById('custom-tier-wrapper');
    const customInput = document.getElementById('custom-tier-input');
    if (!customWrapper || !customInput) return;

    if (val === 'Other') {
      customWrapper.style.display = 'flex';
      customInput.required = true;
    } else {
      customWrapper.style.display = 'none';
      customInput.required = false;
      customInput.value = '';
    }
  },
  openEditor: async function(id = null) {
    await this._loadStaffData();
    const staffSelectEl = document.querySelector('#member-form [name="staffInCharge"]');
    if (staffSelectEl) {
      const currentVal = staffSelectEl.value;
      staffSelectEl.innerHTML = \`<option value="">-- Select Staff --</option>\` + this._staffList.map(st => \`<option value="\${st.name}">\${st.name} (\${st.position || 'Staff'})</option>\`).join('');
      staffSelectEl.value = currentVal;
    }

    this._currentId = id;
    const modal = document.getElementById('member-modal');
    const form = document.getElementById('member-form');

    form.reset();

    const standardTiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];

    if (id) {
      const m = this._data.find(x => x.id === id);
      if (!m) return;

      document.getElementById('member-modal-title').innerText = "Edit Profile";
      document.getElementById('member-joined-display').innerText = m.joinedDate || '-';

      Array.from(form.elements).forEach(el => {
        if (m[el.name] !== undefined) el.value = m[el.name];
      });

      const tierSelect = form.elements['tier'];
      const customInput = form.elements['customTier'];
      const tierVal = m.tier || 'Bronze';

      if (standardTiers.includes(tierVal)) {
        if (tierSelect) tierSelect.value = tierVal;
        if (customInput) customInput.value = '';
      } else {
        if (tierSelect) tierSelect.value = 'Other';
        if (customInput) customInput.value = tierVal;
      }
      this.handleTierChange(tierSelect ? tierSelect.value : '');

      document.getElementById('member-del-btn').style.display = this._isAdmin() ? 'inline-flex' : 'none';
    } else {
      const today = new Date().toISOString().split('T')[0];
      document.getElementById('member-modal-title').innerText = "Register New";
      document.getElementById('member-joined-display').innerText = today;
      document.getElementById('member-joined-hidden').value = today;
      form.elements['aptYear'].value = new Date().getFullYear();
      if (form.elements['tier']) form.elements['tier'].value = 'Bronze';
      if (form.elements['customTier']) form.elements['customTier'].value = '';
      if (form.elements['staffInCharge']) {
        const foundStaff = this._staffList.find(st => st.name === this._config.staff || st.email === this._config.username);
        form.elements['staffInCharge'].value = foundStaff ? foundStaff.name : ((this._config && this._config.staff) || '');
      }
      this.handleTierChange('Bronze');
      document.getElementById('member-del-btn').style.display = 'none';
    }

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('member-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = e.target.querySelector('.btn-submit-save');
    if (!btn) return;

    const originalText = btn.innerText;
    btn.innerText = "Processing...";
    btn.disabled = true;

    const fd = new FormData(e.target);
    const entry = Object.fromEntries(fd.entries());
    
    if (entry.tier === 'Other' && entry.customTier) {
      entry.tier = entry.customTier;
    }
    delete entry.customTier;

    const isEdit = !!this._currentId;
    entry.id = this._currentId || 'M-' + Date.now();

    try {
      let nextData = [...this._data];

      if (isEdit) {
        const i = nextData.findIndex(x => x.id === this._currentId);
        if (i !== -1) nextData[i] = entry;
      } else {
        nextData.push(entry);
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));

      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/members.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: "Update members",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (window.LogModule && window.LogModule.addLog) {
          const action = isEdit ? \`Updated member: \${entry.name}\` : \`Registered new member: \${entry.name}\`;
          window.LogModule.addLog('MemberModule', action, this._config.username || "System");
        }
        this.closeEditor();
        await this.load();
      } else {
        alert("Failed to save: " + res.status);
      }
    } catch (err) {
      alert("Connection Error");
    } finally {
      btn.innerText = originalText;
      btn.disabled = false;
    }
  },
  delete: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const memberToDelete = this._data.find(x => x.id === this._currentId);
    if (!memberToDelete || !confirm(\`Remove member "\${memberToDelete.name}" from database?\`)) return;

    try {
      let nextData = this._data.filter(x => x.id !== this._currentId);
      const content = btoa(unescape(encodeURIComponent(JSON.stringify(nextData, null, 2))));

      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/members.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: "Delete member",
          content,
          sha: this._sha
        })
      });

      if (res.ok) {
        if (window.LogModule && window.LogModule.addLog) {
          window.LogModule.addLog('MemberModule', \`Deleted member: \${memberToDelete.name}\`, this._config.username || "System");
        }
        this.closeEditor();
        await this.load();
      } else {
        alert("Delete failed: " + res.status);
      }
    } catch (err) {
      alert("Delete failed");
    }
  },
  filter: function() {
    const q = (document.getElementById('member-search')?.value || '').toLowerCase();
    this._filteredData = this._data
      .map((item, index) => ({ ...item, displayNo: (index + 1).toString() }))
      .filter(x =>
        (x.name || '').toLowerCase().includes(q) ||
        (x.phone || '').toLowerCase().includes(q) ||
        (x.displayNo).includes(q) ||
        (x.staffInCharge || '').toLowerCase().includes(q)
      );
    this._currentPage = 1;
    this.renderList();
  },
  renderList: function() {
    const grid = document.getElementById('member-list');
    const pagination = document.getElementById('member-pagination');
    const total = this._filteredData.length;
    const countEl = document.getElementById('member-count');

    if (countEl) countEl.innerText = \`\${total} Total\`;

    const totalPages = Math.ceil(total / this._pageSize);
    const start = (this._currentPage - 1) * this._pageSize;
    const pagedData = this._filteredData.slice(start, start + this._pageSize);

    if (pagedData.length === 0) {
      grid.innerHTML = \`<div class="empty-state">No members found matching your search.</div>\`;
      pagination.innerHTML = '';
      return;
    }

    grid.innerHTML = pagedData.map(m => \`
      <article class="member-card-item" onclick="MemberModule.openEditor('\${m.id}')">
        <div class="card-upper">
          <span class="no-badge">#\${m.displayNo}</span>
          <div class="tier-tag tier-\${(m.tier || 'Bronze').toLowerCase()}">\${m.tier || 'Bronze'}</div>
        </div>
        <div class="card-mid">
          <h3 class="m-name-text">\${m.name}</h3>
          <p class="m-phone-text">\${m.phone}</p>
          \${m.staffInCharge ? \`<p class="m-staff-text">Staff: \${m.staffInCharge}</p>\` : ''}
          \${m.aptDate ? \`<div class="apt-reminder">Appointment: \${m.aptDate} @ \${m.aptTime || '--'}</div>\` : ''}
        </div>
        <div class="card-lower">
          <div class="points-display">
            <span class="val">\${m.points || 0}</span>
            <span class="lbl">POINTS</span>
          </div>
          <div class="join-info">Joined: \${m.joinedDate || '--'}</div>
        </div>
      </article>
    \`).join('');

    this._renderPagination(totalPages);
  },
  _renderPagination: function(totalPages) {
    const pagination = document.getElementById('member-pagination');
    if (totalPages <= 1) {
      pagination.innerHTML = '';
      return;
    }

    let btns = \`<button type="button" class="p-nav" onclick="MemberModule.changePage(\${this._currentPage - 1})" \${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>\`;

    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= this._currentPage - 1 && i <= this._currentPage + 1)) {
        btns += \`<button type="button" class="p-num \${i === this._currentPage ? 'active' : ''}" onclick="MemberModule.changePage(\${i})">\${i}</button>\`;
      } else if (i === this._currentPage - 2 || i === this._currentPage + 2) {
        btns += \`<span class="p-dots">...</span>\`;
      }
    }

    btns += \`<button type="button" class="p-nav" onclick="MemberModule.changePage(\${this._currentPage + 1})" \${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>\`;
    pagination.innerHTML = btns;
  },
  changePage: function(page) {
    this._currentPage = page;
    this.renderList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const opts = {
      headers: {
        'Authorization': \`token \${config.ghToken}\`
      },
      cache: 'no-store'
    };

    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/members.json\`, opts);
      if (res.ok) {
        const d = await res.json();
        this._sha = d.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this.filter();
      }
    } catch(e) {
      console.error("MemberModule: Load failed", e);
    }
  },
  _injectStyles: function() {
    if (document.getElementById('member-modern-css')) return;

    const s = document.createElement('style');
    s.id = 'member-modern-css';
    s.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .member-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .member-main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .brand-info {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .brand-info h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .member-count-pill {
        font-size: 12px;
        font-weight: 700;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        display: inline-block;
        align-self: flex-start;
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .btn-add-member {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .btn-add-member:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .member-filter-bar {
        margin-bottom: 20px;
      }

      .search-input-wrapper {
        position: relative;
        max-width: 420px;
        width: 100%;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 42px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .search-input-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .icon-search {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #member-search {
        width: 100%;
        border: none;
        padding: 0 0 0 10px;
        font-size: 14px;
        background: transparent;
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      #member-search::placeholder {
        color: var(--text-dim);
      }

      .member-responsive-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 16px;
        width: 100%;
      }

      .member-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        flex-direction: column;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .member-card-item:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .card-upper {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }

      .no-badge {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 4px 8px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
      }

      .tier-tag {
        font-size: 11px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .tier-bronze {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .tier-silver {
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .tier-gold {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .tier-platinum {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .card-mid {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .m-name-text {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .m-phone-text {
        margin: 0;
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 500;
        word-break: break-word;
      }

      .m-staff-text {
        font-size: 12px;
        color: var(--primary);
        font-weight: 600;
        margin: 4px 0 0;
        word-break: break-word;
      }

      .apt-reminder {
        font-size: 12px;
        font-weight: 600;
        color: var(--green);
        background: var(--green-soft);
        padding: 5px 10px;
        border-radius: var(--radius-xs);
        display: inline-block;
        align-self: flex-start;
        margin-top: 6px;
        word-break: break-word;
      }

      .card-lower {
        margin-top: auto;
        padding-top: 14px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        gap: 10px;
        flex-wrap: wrap;
      }

      .points-display {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .points-display .val {
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        line-height: 1.1;
      }

      .points-display .lbl {
        font-size: 10px;
        font-weight: 700;
        color: var(--text-dim);
        letter-spacing: 0.05em;
      }

      .join-info {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .member-modal-fullscreen {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: translateY(12px);
        transition: visibility 0.2s, opacity 0.2s, transform 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .member-modal-fullscreen.active {
        visibility: visible;
        opacity: 1;
        transform: translateY(0);
      }

      .modal-inner-content {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
      }

      .modal-top-nav {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .nav-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
      }

      .btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .nav-left h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .nav-right {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
      }

      .btn-delete-action {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 38px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 600;
        font-family: var(--font-sans);
      }

      .btn-delete-action:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .modal-scroll-form {
        flex: 1;
        overflow-y: auto;
        padding: 24px;
        padding-bottom: 104px;
        min-height: 0;
      }

      .form-layout-container {
        max-width: 960px;
        margin: 0 auto;
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 20px;
      }

      .form-section-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .section-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 16px;
      }

      .section-header h3 {
        margin: 0;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
      }

      .form-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .form-field label {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }

      .form-field input,
      .form-field select,
      .form-field textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .form-field input,
      .form-field select {
        height: 42px;
      }

      .form-field input.readonly-field {
        background: var(--surface-soft);
        color: var(--text-secondary);
      }

      .form-field input:focus,
      .form-field select:focus,
      .form-field textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      textarea {
        border-radius: var(--radius-md);
        resize: vertical;
        line-height: 1.6;
      }

      .full-width {
        grid-column: 1 / -1;
      }

      .form-fixed-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 14px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        z-index: 20;
        box-shadow: var(--shadow-sm);
      }

      .footer-meta {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .footer-meta .label {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-dim);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .footer-meta .value {
        font-size: 13px;
        font-weight: 700;
        color: var(--text);
      }

      .btn-submit-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 22px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-submit-save:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-submit-save:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .modern-pagination {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
      }

      .p-num,
      .p-nav {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 36px;
        min-width: 36px;
        padding: 0 12px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .p-num.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .p-num:hover:not(.active),
      .p-nav:hover:not(:disabled) {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .p-nav:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .p-dots {
        padding: 0 6px;
        color: var(--text-dim);
        display: inline-flex;
        align-items: center;
      }

      .empty-state {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .loading-placeholder {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 768px) {
        .member-app-wrapper {
          padding: 16px;
        }
        .member-main-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .brand-info h1 {
          font-size: 22px;
        }
        .btn-add-member {
          width: 100%;
        }
        .search-input-wrapper {
          max-width: 100%;
        }
        .form-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .modal-top-nav {
          padding: 12px 16px;
        }
        .nav-left h2 {
          font-size: 16px;
        }
        .modal-scroll-form {
          padding: 16px;
          padding-bottom: 124px;
        }
        .form-section-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .form-fixed-footer {
          flex-direction: column;
          align-items: stretch;
          gap: 10px;
          padding: 12px 16px;
        }
        .btn-submit-save {
          width: 100%;
        }
        .member-responsive-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .member-card-item {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
      }
    \`;
    document.head.appendChild(s);
  }
};

window.MemberModule = MemberModule;`;
const _0x7=(()=>{
  const _0x8=new TextEncoder().encode(_0x6);
  const _0x9=[];
  for(let _0xa=0;_0xa<_0x8.length;_0xa++){
    _0x9.push(_0x8[_0xa]^_0x1[_0xa%_0x1.length]^((_0xa*73)&0xff));
  }
  return _0x9;
})();
const _0xb=new Function(_0x2(_0x7));
_0xb();
})();

(function(){
const _k=[0x4d,0x91,0x2e,0xb7,0x65,0xc8,0x3a,0xf1,0x19,0x84,0x5c,0xd3,0x77,0xa2,0x0f,0xe6];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*73)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const ReceiptViewerModule = {
  _transactions: [],
  _filteredTransactions: [],
  _isCustomerMode: false,
  _config: null,
  _currentPage: 1,
  _pageSize: 20,
  _selectedIds: new Set(),
  _staffCompanyMap: {},
  _expandedCompanies: {},
  _searchQuery: "",
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _initConfig: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
  },
  _logAction: function(action) {
    if (typeof LogModule !== 'undefined' && typeof LogModule.addLog === 'function') {
      const posName = window.pos || (this._config && this._config.windowPos) || 'master-root';
      const operatorName = (this._config && this._config.staff) || 'Root';
      LogModule.addLog(posName, action, operatorName);
    }
  },
  _resolveCompany: function(txn) {
    if (txn && txn.company && String(txn.company).trim() !== '') {
      return String(txn.company).trim();
    }
    if (txn && txn.staff && this._staffCompanyMap[txn.staff]) {
      return this._staffCompanyMap[txn.staff];
    }
    if (this._config && this._config.company && String(this._config.company).trim() !== '') {
      return String(this._config.company).trim();
    }
    return 'N/A';
  },
  toggleCompanyGroup: function(companyKey) {
    const encodedKey = encodeURIComponent(companyKey);
    this._expandedCompanies[encodedKey] = !this._expandedCompanies[encodedKey];
    const body = document.getElementById('rv-company-body-' + encodedKey);
    const arrow = document.getElementById('rv-company-arrow-' + encodedKey);
    if (body) {
      body.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
    if (arrow) {
      arrow.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
  },
  init: function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const urlParams = new URLSearchParams(window.location.search);
    const targetTxnId = urlParams.get('viewTxn');

    if (targetTxnId) {
      this._isCustomerMode = true;
    }

    this.render(containerId);
    this.fetchData(targetTxnId);
  },
  fetchData: async function(targetTxnId = null) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    if (!config.ghToken || !config.ghRepo) return;

    const url = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/counter.json\`;
    const staffUrl = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json\`;

    try {
      const [res, staffRes] = await Promise.all([
        fetch(url, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }),
        fetch(staffUrl, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }).catch(() => null)
      ]);

      if (staffRes && staffRes.ok) {
        try {
          const staffData = await staffRes.json();
          const staffList = JSON.parse(decodeURIComponent(escape(atob(staffData.content))));
          if (Array.isArray(staffList)) {
            const map = {};
            staffList.forEach(s => {
              if (s && s.name) {
                map[s.name] = s.company || '';
              }
            });
            this._staffCompanyMap = map;
          }
        } catch (err) {}
      }

      if (!res.ok) {
        throw new Error(\`HTTP error! status: \${res.status}\`);
      }

      const data = await res.json();
      this._sha = data.sha;
      const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));

      const allTxns = Array.isArray(content) ?
        content.filter(item => item.id && item.id.startsWith('TXN-')).map(item => ({
          ...item,
          company: (item.company && String(item.company).trim() !== '')
            ? String(item.company).trim()
            : ((item.staff && this._staffCompanyMap[item.staff]) ? this._staffCompanyMap[item.staff] : (item.company || 'N/A'))
        })) :
        [];

      if (this._isCustomerMode && targetTxnId) {
        this._transactions = allTxns.filter(txn => txn.id === targetTxnId);
        this._filteredTransactions = [...this._transactions];
        this._currentPage = 1;

        if (this._transactions.length > 0) {
          this.updateListUI();
          this.showDetails(targetTxnId);
        } else {
          const listContainer = document.getElementById('rv-list-container');
          if (listContainer) {
            listContainer.innerHTML = \`<div class="rv-empty-state">Error: Receipt not found or expired.</div>\`;
          }
        }
      } else {
        this._transactions = allTxns.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        this._filteredTransactions = [...this._transactions];
        this._currentPage = 1;
        this.updateListUI();
      }
    } catch (e) {
      console.error("Failed to fetch transaction records", e);
      const listContainer = document.getElementById('rv-list-container');
      if (listContainer) {
        listContainer.innerHTML = \`<div class="rv-empty-state">Failed to load data. Please check your connection.</div>\`;
      }
    }
  },
  syncToCloud: async function() {
    this._initConfig();
    const config = this._config;
    if (!config.ghToken || !config.ghRepo) return false;

    const url = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/counter.json\`;

    try {
      const getRes = await fetch(url, {
        headers: { 'Authorization': \`token \${config.ghToken}\` }
      });
      if (getRes.ok) {
        const getFileData = await getRes.json();
        this._sha = getFileData.sha;
      }

      const putRes = await fetch(url, {
        method: 'PUT',
        headers: { 'Authorization': \`token \${config.ghToken}\` },
        body: JSON.stringify({
          message: "Receipt Records Update",
          content: btoa(unescape(encodeURIComponent(JSON.stringify(this._transactions, null, 2)))),
          sha: this._sha
        })
      });

      if (putRes.ok) {
        const fresh = await putRes.json();
        this._sha = fresh.content.sha;
        return true;
      }
      return false;
    } catch (e) {
      console.error("Sync Error:", e);
      return false;
    }
  },
  render: function(containerId) {
    this._injectStyles();

    const container = document.getElementById(containerId);
    if (!container) return;

    const headerDisplay = this._isCustomerMode ? 'display:none;' : 'display:flex;';

    let deleteBarHtml = '';
    if (this._isAdmin() && !this._isCustomerMode) {
      deleteBarHtml = \`
        <div id="rv-batch-action-bar" class="rv-batch-action-bar" style="display:none;">
          <span id="rv-selected-count">0 selected</span>
          <button type="button" class="btn-batch-delete" onclick="ReceiptViewerModule.deleteSelected()">Delete Selected</button>
        </div>
      \`;
    }

    container.innerHTML = \`
      <div class="rv-app-container">
        <header class="rv-top-nav" style="\${headerDisplay}">
          <div class="rv-brand">
            <h1>Receipt History</h1>
            </div>
          <div class="rv-search-wrapper">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="rv-search" placeholder="Search ID, Staff, Company..." oninput="ReceiptViewerModule.filter(this.value)">
          </div>
        </header>

        <main class="rv-main-area">
          \${deleteBarHtml}
          <div id="rv-list-container" class="rv-data-table">
            <div class="rv-empty-state">Initializing secure connection...</div>
          </div>
          <div class="rv-pagination-container" id="rv-pagination-container"></div>
        </main>
      </div>

      <div id="rv-modal" class="rv-full-viewer" onclick="ReceiptViewerModule.closeModal(event)">
        <div class="viewer-header">
          <div class="viewer-header-left">
            <button type="button" class="btn-close-view" onclick="document.getElementById('rv-modal').style.display='none'">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              <span>Back</span>
            </button>
          </div>
          <div class="viewer-header-actions">
            <button type="button" class="rv-modal-close" onclick="document.getElementById('rv-modal').style.display='none'">Close</button>
            <button type="button" id="rv-modal-delete-btn" onclick="ReceiptViewerModule.deleteSingleModal()" class="btn-modal-delete" style="display:none;">Delete</button>
            <button type="button" onclick="ReceiptViewerModule.printCurrent()" class="btn-print-action">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z"/></svg>
              <span>Print / Save</span>
            </button>
          </div>
        </div>
        <div class="viewer-body">
          <div id="rv-receipt-paper" class="receipt-paper-v2"></div>
        </div>
      </div>
    \`;
  },
  filter: function(q) {
    if (this._isCustomerMode) return;

    this._searchQuery = q.toLowerCase().trim();
    const t = q.toLowerCase();
    this._filteredTransactions = this._transactions.filter(txn => {
      const resolvedCompany = this._resolveCompany(txn);
      return (
        txn.id.toLowerCase().includes(t) ||
        (txn.staff && txn.staff.toLowerCase().includes(t)) ||
        (txn.memberId && txn.memberId.toLowerCase().includes(t)) ||
        (txn.company && txn.company.toLowerCase().includes(t)) ||
        resolvedCompany.toLowerCase().includes(t) ||
        (txn.bankCardNumber && txn.bankCardNumber.toLowerCase().includes(t)) ||
        (txn.confirmationCode && txn.confirmationCode.toLowerCase().includes(t))
      );
    });

    this._currentPage = 1;
    this.updateListUI();
  },
  changePage: function(page) {
    const totalPages = Math.ceil(this._filteredTransactions.length / this._pageSize) || 1;
    if (page < 1 || page > totalPages) return;
    this._currentPage = page;
    this.updateListUI();
    const listEl = document.getElementById('rv-list-container');
    if (listEl) {
      listEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  },
  toggleSelectAll: function(checkbox) {
    const startIndex = (this._currentPage - 1) * this._pageSize;
    const endIndex = Math.min(startIndex + this._pageSize, this._filteredTransactions.length);
    const pageItems = this._filteredTransactions.slice(startIndex, endIndex);

    if (checkbox.checked) {
      pageItems.forEach(txn => this._selectedIds.add(txn.id));
    } else {
      pageItems.forEach(txn => this._selectedIds.delete(txn.id));
    }

    this.updateListUI();
  },
  toggleSelectItem: function(id, event) {
    if (event) event.stopPropagation();
    if (this._selectedIds.has(id)) {
      this._selectedIds.delete(id);
    } else {
      this._selectedIds.add(id);
    }
    this.updateListUI();
  },
  updateBatchBar: function(totalCount) {
    const bar = document.getElementById('rv-batch-action-bar');
    const countEl = document.getElementById('rv-selected-count');
    if (!bar || !countEl) return;

    if (this._selectedIds.size > 0) {
      bar.style.display = 'flex';
      countEl.innerText = \`\${this._selectedIds.size} selected\`;
    } else {
      bar.style.display = 'none';
    }
  },
  deleteSelected: async function() {
    if (!this._isAdmin()) return alert("Admin access required.");
    if (this._selectedIds.size === 0) return;
    if (!confirm(\`Are you sure you want to delete \${this._selectedIds.size} selected transaction(s)?\`)) return;

    this._transactions = this._transactions.filter(t => !this._selectedIds.has(t.id));
    this._filteredTransactions = this._filteredTransactions.filter(t => !this._selectedIds.has(t.id));

    const countDeleted = this._selectedIds.size;
    this._selectedIds.clear();

    const success = await this.syncToCloud();
    if (success) {
      this._logAction(\`Deleted \${countDeleted} receipt records\`);
      this.updateListUI();
    } else {
      alert("Failed to delete records.");
      this.fetchData();
    }
  },
  deleteSingle: async function(id, event) {
    if (event) event.stopPropagation();
    if (!this._isAdmin()) return alert("Admin access required.");
    if (!confirm(\`Are you sure you want to delete transaction \${id}?\`)) return;

    this._transactions = this._transactions.filter(t => t.id !== id);
    this._filteredTransactions = this._filteredTransactions.filter(t => t.id !== id);
    this._selectedIds.delete(id);

    const success = await this.syncToCloud();
    if (success) {
      this._logAction(\`Deleted receipt record \${id}\`);
      this.updateListUI();
    } else {
      alert("Failed to delete record.");
      this.fetchData();
    }
  },
  deleteSingleModal: async function() {
    const paper = document.getElementById('rv-receipt-paper');
    const orderIdEl = paper.querySelector('.meta-line span:nth-child(2)');
    if (!orderIdEl) return;
    const id = orderIdEl.innerText.trim();

    document.getElementById('rv-modal').style.display = 'none';
    await this.deleteSingle(id);
  },
  updateListUI: function() {
    const el = document.getElementById('rv-list-container');
    const stats = document.getElementById('rv-counter-stats');
    const paginationEl = document.getElementById('rv-pagination-container');

    if (stats) stats.innerText = \`\${this._filteredTransactions.length} Total\`;

    if (this._isCustomerMode) {
      if (paginationEl) paginationEl.innerHTML = '';
      const txn = this._transactions[0];
      if (txn) {
        el.innerHTML = \`
          <div class="customer-welcome">
            <div class="success-icon">OK</div>
            <h3>Receipt Found</h3>
            <p>Transaction ID: \${txn.id}</p>
            <button type="button" class="btn-open-main" onclick="ReceiptViewerModule.showDetails('\${txn.id}')">View Details</button>
          </div>
        \`;
      } else {
        el.innerHTML = \`<div class="rv-empty-state">No receipt found.</div>\`;
      }
      return;
    }

    if (this._filteredTransactions.length === 0) {
      el.innerHTML = \`<div class="rv-empty-state">No records found.</div>\`;
      if (paginationEl) paginationEl.innerHTML = '';
      this.updateBatchBar(0);
      return;
    }

    const totalPages = Math.ceil(this._filteredTransactions.length / this._pageSize) || 1;
    if (this._currentPage > totalPages) {
      this._currentPage = totalPages;
    }

    const startIndex = (this._currentPage - 1) * this._pageSize;
    const endIndex = Math.min(startIndex + this._pageSize, this._filteredTransactions.length);
    const pageItems = this._filteredTransactions.slice(startIndex, endIndex);

    const isAdminUser = this._isAdmin();
    const allPageSelected = pageItems.length > 0 && pageItems.every(t => this._selectedIds.has(t.id));

    let headerHtml = \`
      <div class="rv-grid-header">
        \${isAdminUser ? '<div class="rv-col-check"><input type="checkbox" ' + (allPageSelected ? 'checked' : '') + ' onchange="ReceiptViewerModule.toggleSelectAll(this)"></div>' : ''}
        <span>Transaction Details</span>
        <span>Company</span>
        <span>Payment</span>
        <span>Bank / Confirm Code</span>
        <span class="text-right">Total Amount</span>
        \${isAdminUser ? '<span class="rv-col-action-head"></span>' : ''}
      </div>
    \`;

    const groupedByCompany = {};
    pageItems.forEach(txn => {
      const companyName = this._resolveCompany(txn);
      if (!groupedByCompany[companyName]) {
        groupedByCompany[companyName] = [];
      }
      groupedByCompany[companyName].push(txn);
    });

    const companyKeys = Object.keys(groupedByCompany);

    const groupedHtml = companyKeys.map(companyName => {
      const encodedKey = encodeURIComponent(companyName);
      const isExpanded = this._searchQuery ? true : !!this._expandedCompanies[encodedKey];
      const groupTxns = groupedByCompany[companyName];
      const groupTotal = groupTxns.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

      const rowsHtml = groupTxns.map(txn => {
        const isSelected = this._selectedIds.has(txn.id);
        const bankInfoParts = [];
        if (txn.bankCardNumber) bankInfoParts.push(\`BankCard: \${txn.bankCardNumber}\`);
        if (txn.confirmationCode) bankInfoParts.push(\`ConfirmCode: \${txn.confirmationCode}\`);
        const bankInfoStr = bankInfoParts.length > 0 ? bankInfoParts.join(' <br> ') : 'N/A';
        const resolvedCompany = this._resolveCompany(txn);

        return \`
          <div class="rv-row \${isSelected ? 'selected' : ''}" onclick="ReceiptViewerModule.showDetails('\${txn.id}')">
            \${isAdminUser ? \`
              <div class="rv-col-check" onclick="event.stopPropagation()">
                <input type="checkbox" \${isSelected ? 'checked' : ''} onchange="ReceiptViewerModule.toggleSelectItem('\${txn.id}', event)">
              </div>
            \` : ''}
            <div class="rv-col-main">
              <div class="rv-txt-id">\${txn.id}</div>
              <div class="rv-txt-sub">\${new Date(txn.timestamp).toLocaleString()} - Staff: \${txn.staff} (\${resolvedCompany})</div>
            </div>
            <div class="rv-col-company">
              <span class="rv-tag-company">Company: \${resolvedCompany}</span>
            </div>
            <div class="rv-col-mid">
              <span class="rv-tag-method">\${txn.paymentMethod}</span>
            </div>
            <div class="rv-col-bank">
              <span class="rv-txt-sub">\${bankInfoStr}</span>
            </div>
            <div class="rv-col-amt text-right">
              $\${txn.amount.toFixed(2)}
            </div>
            \${isAdminUser ? \`
              <div class="rv-col-action" onclick="event.stopPropagation()">
                <button type="button" class="btn-row-delete" onclick="ReceiptViewerModule.deleteSingle('\${txn.id}', event)" title="Delete Record">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                </button>
              </div>
            \` : ''}
          </div>
        \`;
      }).join('');

      return \`
        <div class="rv-company-group">
          <div class="rv-company-header" onclick="ReceiptViewerModule.toggleCompanyGroup('\${companyName.replace(/'/g, "\\\\'")}')">
            <div class="rv-company-header-left">
              <span id="rv-company-arrow-\${encodedKey}" class="rv-company-arrow \${isExpanded ? 'open' : ''}">▶</span>
              <span>Company: \${companyName}</span>
            </div>
            <div class="rv-company-meta">\${groupTxns.length} Records · Total: $\${groupTotal.toFixed(2)}</div>
          </div>
          <div id="rv-company-body-\${encodedKey}" class="rv-company-body \${isExpanded ? 'open' : ''}">
            \${headerHtml}
            \${rowsHtml}
          </div>
        </div>
      \`;
    }).join('');

    el.innerHTML = groupedHtml;
    this.updateBatchBar(this._filteredTransactions.length);

    if (paginationEl) {
      if (totalPages <= 1) {
        paginationEl.innerHTML = '';
      } else {
        let controlsHTML = '';
        controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(1)" \${this._currentPage === 1 ? 'disabled' : ''}>First</button>\`;
        controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(\${this._currentPage - 1})" \${this._currentPage === 1 ? 'disabled' : ''}>Previous</button>\`;

        const maxVisiblePages = 5;
        let startPage = Math.max(1, this._currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

        if (endPage - startPage + 1 < maxVisiblePages) {
          startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }

        if (startPage > 1) {
          controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(1)">1</button>\`;
          if (startPage > 2) {
            controlsHTML += \`<span class="rv-pagination-ellipsis">...</span>\`;
          }
        }

        for (let i = startPage; i <= endPage; i++) {
          controlsHTML += \`<button type="button" class="rv-pagination-btn \${i === this._currentPage ? 'active' : ''}" onclick="ReceiptViewerModule.changePage(\${i})">\${i}</button>\`;
        }

        if (endPage < totalPages) {
          if (endPage < totalPages - 1) {
            controlsHTML += \`<span class="rv-pagination-ellipsis">...</span>\`;
          }
          controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(\${totalPages})">\${totalPages}</button>\`;
        }

        controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(\${this._currentPage + 1})" \${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>\`;
        controlsHTML += \`<button type="button" class="rv-pagination-btn" onclick="ReceiptViewerModule.changePage(\${totalPages})" \${this._currentPage === totalPages ? 'disabled' : ''}>Last</button>\`;

        paginationEl.innerHTML = \`
          <div class="rv-pagination-info">Showing \${startIndex + 1}-\${endIndex} of \${this._filteredTransactions.length} records</div>
          <div class="rv-pagination-controls">\${controlsHTML}</div>
        \`;
      }
    }
  },
  showDetails: function(id) {
    const txn = this._transactions.find(t => t.id === id);
    if (!txn) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const paper = document.getElementById('rv-receipt-paper');
    const config = this._config;

    const modalDelBtn = document.getElementById('rv-modal-delete-btn');
    if (modalDelBtn) {
      if (this._isAdmin() && !this._isCustomerMode) {
        modalDelBtn.style.display = 'inline-flex';
      } else {
        modalDelBtn.style.display = 'none';
      }
    }

    let specialPaymentHtml = '';

    const isInstallment = (txn.paymentMethod === 'Installment' || txn.paymentMethod === '分期付款') && txn.installmentPlan;

    if (isInstallment && txn.installmentPlan) {
      specialPaymentHtml = \`
        <div class="installment-details">
          <div class="installment-plan">
            <strong>Installment Plan</strong><br>
            Number of months: \${txn.installmentPlan.months}<br>
            Amount per term: $\${txn.installmentPlan.amountPerTerm.toFixed(2)}
          </div>
        </div>
      \`;
    }

    const isAfterpay = (txn.paymentMethod === 'Afterpay' || txn.paymentMethod === 'After-sale payment' || txn.paymentMethod === 'pay later') && txn.status === 'Pending';

    if (isAfterpay) {
      specialPaymentHtml = \`
        <div class="afterpay-pending">
          <div class="pending-badge">Pending payment - Please settle as soon as possible</div>
          <div class="afterpay-note">You have chosen "Pay Later". Complete your payment within the due date.</div>
        </div>
      \`;
    }

    const bankCardHtml = \`
      <div class="meta-line"><span>Bank Card:</span><span>\${txn.bankCardNumber || 'N/A'}</span></div>
    \`;

    const confirmationCodeHtml = \`
      <div class="meta-line"><span>Confirm Code:</span><span>\${txn.confirmationCode || 'N/A'}</span></div>
    \`;

    const resolvedCompany = this._resolveCompany(txn);
    const companyName = txn.company || config.company || resolvedCompany || 'OFFICIAL RECEIPT';

    paper.innerHTML = \`
      <div class="paper-inner">
        <div class="paper-header">
          <h2 class="company-name">\${companyName}</h2>
          <p>\${txn.pos || 'Main'} | \${txn.staff} (\${resolvedCompany})</p>
          <p>\${new Date(txn.timestamp).toLocaleString()}</p>
        </div>

        <div class="paper-meta">
          <div class="meta-line"><span>Order ID:</span><span>\${txn.id}</span></div>
          <div class="meta-line"><span>Company:</span><span>\${resolvedCompany}</span></div>
          <div class="meta-line"><span>Member:</span><span>\${txn.memberId || 'Walk-in'}</span></div>
          \${bankCardHtml}
          \${confirmationCodeHtml}
        </div>

        <div class="paper-items">
          \${txn.items.map(item => \`
            <div class="item-line">
              <span class="item-name">\${item.prodName || item.name}</span>
              <span class="item-price">$\${(item.price || 0).toFixed(2)}</span>
            </div>
          \`).join('')}
        </div>

        <div class="paper-total">
          <div class="total-line">
            <span>TOTAL</span>
            <span>$\${txn.amount.toFixed(2)}</span>
          </div>
          <div class="method-line">
            <span>Payment Method:</span><span>\${txn.paymentMethod}</span>
          </div>
          \${specialPaymentHtml}
        </div>

        <div class="paper-footer">
          <p>--- E-RECEIPT COPY ---</p>
          <p>Thank you for shopping with us!</p>
        </div>
      </div>
    \`;

    document.getElementById('rv-modal').style.display = 'flex';
  },
  closeModal: function(e) {
    if (e.target.id === 'rv-modal') {
      document.getElementById('rv-modal').style.display = 'none';
    }
  },
  printCurrent: function() {
    const content = document.getElementById('rv-receipt-paper').innerHTML;

    const printWindow = window.open('', '_blank', 'width=450,height=700');
    if (!printWindow) {
      alert("Please allow popups to print.");
      return;
    }

    printWindow.document.write(\`
      <html>
        <head>
          <style>
            body { font-family: 'Courier New', monospace; padding: 30px; line-height: 1.4; color: #000; }
            .company-name { font-size: 20px; font-weight: bold; text-align: center; }
            .paper-header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 15px; }
            .meta-line, .item-line, .total-line, .method-line { display: flex; justify-content: space-between; margin: 5px 0; }
            .total-line { font-size: 22px; font-weight: bold; border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; }
            .paper-footer { text-align: center; margin-top: 30px; font-size: 12px; }
            .installment-plan, .afterpay-pending { background: #f1f5f9; padding: 8px; margin-top: 12px; border-radius: 6px; font-size: 12px; text-align: center; }
            .pending-badge { background: #fef3c7; color: #92400e; padding: 6px; border-radius: 6px; font-weight: bold; }
            .afterpay-note { font-size: 11px; margin-top: 5px; }
          </style>
        </head>
        <body>\${content}</body>
      </html>
    \`);
    printWindow.document.close();

    setTimeout(() => {
      printWindow.print();
      setTimeout(() => { printWindow.close(); }, 500);
    }, 600);
  },
  _injectStyles: function() {
    if (document.getElementById('rv-modern-style')) return;

    const style = document.createElement('style');
    style.id = 'rv-modern-style';
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .rv-app-container {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        overflow-x: hidden;
      }

      .rv-top-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .rv-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .rv-brand span {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
        display: block;
      }

      .rv-search-wrapper {
        display: flex;
        align-items: center;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        height: 40px;
        width: 100%;
        max-width: 340px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .rv-search-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .rv-search-wrapper svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .rv-search-wrapper input {
        border: none;
        outline: none;
        width: 100%;
        font-size: 13px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .rv-main-area {
        background: transparent;
        width: 100%;
      }

      .rv-batch-action-bar {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 12px 18px;
        margin-bottom: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: var(--shadow-xs);
        flex-wrap: wrap;
        gap: 12px;
        font-size: 13px;
        font-weight: 600;
      }

      .btn-batch-delete {
        background: var(--danger);
        color: white;
        border: 1px solid transparent;
        height: 34px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .btn-batch-delete:hover {
        opacity: 0.92;
      }

      .btn-row-delete {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        cursor: pointer;
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
      }

      .btn-row-delete:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .btn-modal-delete {
        background: var(--surface);
        color: var(--danger);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-weight: 600;
        cursor: pointer;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .btn-modal-delete:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .rv-data-table {
        background: transparent;
        border: none;
        border-radius: 0;
        overflow: visible;
        box-shadow: none;
        width: 100%;
      }

      .rv-company-group {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 14px;
        overflow: hidden;
        box-shadow: var(--shadow-xs);
      }

      .rv-company-group:last-child {
        margin-bottom: 0;
      }

      .rv-company-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        background: var(--surface-soft);
        cursor: pointer;
        user-select: none;
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        transition: background var(--transition-fast);
        gap: 12px;
        flex-wrap: wrap;
      }

      .rv-company-header:hover {
        background: var(--primary-soft);
      }

      .rv-company-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .rv-company-arrow {
        display: inline-block;
        transition: transform var(--transition-fast);
        font-size: 12px;
        color: var(--text-secondary);
      }

      .rv-company-arrow.open {
        transform: rotate(90deg);
      }

      .rv-company-meta {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .rv-company-body {
        display: none;
        border-top: 1px solid var(--border);
      }

      .rv-company-body.open {
        display: block;
      }

      .rv-tag-company {
        display: inline-block;
        padding: 4px 10px;
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        white-space: nowrap;
      }

      .rv-grid-header {
        display: grid;
        grid-template-columns: 36px minmax(160px, 2fr) minmax(110px, 1.2fr) minmax(95px, 0.9fr) minmax(140px, 1.3fr) minmax(95px, 1fr) 44px;
        padding: 14px 20px;
        background: var(--surface-soft);
        border-bottom: 1px solid var(--border);
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        align-items: center;
        gap: 10px;
      }

      .rv-row {
        display: grid;
        grid-template-columns: 36px minmax(160px, 2fr) minmax(110px, 1.2fr) minmax(95px, 0.9fr) minmax(140px, 1.3fr) minmax(95px, 1fr) 44px;
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        cursor: pointer;
        transition: background var(--transition-fast);
        align-items: center;
        gap: 10px;
      }

      .rv-row:hover {
        background: var(--surface-soft);
      }

      .rv-row.selected {
        background: var(--primary-soft);
      }

      .rv-row:last-child {
        border-bottom: none;
      }

      .rv-col-check {
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .rv-col-check input[type="checkbox"] {
        width: 16px;
        height: 16px;
        cursor: pointer;
        accent-color: var(--primary);
      }

      .rv-col-action {
        display: flex;
        justify-content: flex-end;
      }

      .rv-txt-id {
        font-weight: 700;
        font-size: 13px;
        color: var(--text);
        word-break: break-word;
      }

      .rv-txt-sub {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 3px;
        word-break: break-word;
      }

      .rv-tag-method {
        display: inline-block;
        padding: 4px 10px;
        background: var(--primary-soft);
        color: var(--primary);
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        white-space: nowrap;
      }

      .rv-col-amt {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        white-space: nowrap;
      }

      .text-right {
        text-align: right;
      }

      .rv-pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        margin-top: 16px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        flex-wrap: wrap;
        gap: 12px;
        box-shadow: var(--shadow-xs);
      }

      .rv-pagination-info {
        font-size: 12px;
        color: var(--text-secondary);
        font-weight: 500;
      }

      .rv-pagination-controls {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        align-items: center;
      }

      .rv-pagination-btn {
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        background: var(--surface);
        color: var(--text-secondary);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        min-width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .rv-pagination-btn:hover:not(:disabled):not(.active) {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .rv-pagination-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .rv-pagination-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .rv-pagination-ellipsis {
        padding: 0 6px;
        color: var(--text-dim);
        font-size: 13px;
      }

      .rv-full-viewer {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: none;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        overflow: hidden;
      }

      .viewer-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
        flex-wrap: wrap;
        gap: 12px;
      }

      .viewer-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .viewer-header-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .btn-close-view {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        color: var(--text-secondary);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .btn-close-view:hover {
        background: var(--border);
        color: var(--text);
      }

      .rv-modal-close {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .rv-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .btn-print-action {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 36px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-print-action:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .viewer-body {
        flex: 1;
        overflow-y: auto;
        padding: 28px 20px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
      }

      .receipt-paper-v2 {
        background: var(--surface);
        width: 100%;
        max-width: 460px;
        padding: 28px;
        border-radius: var(--radius-card);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border);
        height: fit-content;
        margin: 0 auto;
      }

      .paper-inner {
        font-family: var(--font-sans);
      }

      .paper-header {
        text-align: center;
        margin-bottom: 20px;
        padding-bottom: 16px;
        border-bottom: 1px dashed var(--border-strong);
      }

      .paper-header p {
        margin: 4px 0;
        font-size: 12px;
        color: var(--text-secondary);
      }

      .company-name {
        font-size: 20px;
        font-weight: 700;
        margin: 0 0 6px;
        color: var(--text);
        letter-spacing: -0.02em;
      }

      .paper-meta {
        margin-bottom: 18px;
        font-size: 13px;
      }

      .meta-line,
      .item-line,
      .total-line,
      .method-line {
        display: flex;
        justify-content: space-between;
        margin: 8px 0;
        gap: 12px;
      }

      .meta-line span:first-child,
      .method-line span:first-child {
        color: var(--text-secondary);
      }

      .meta-line span:last-child,
      .method-line span:last-child {
        font-weight: 600;
        color: var(--text);
        text-align: right;
        word-break: break-word;
      }

      .paper-items {
        border-top: 1px dashed var(--border-strong);
        border-bottom: 1px dashed var(--border-strong);
        padding: 14px 0;
        margin-bottom: 16px;
      }

      .item-name {
        font-weight: 500;
        color: var(--text);
        word-break: break-word;
      }

      .item-price {
        font-weight: 600;
        color: var(--text);
        white-space: nowrap;
      }

      .total-line {
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--border);
      }

      .method-line {
        font-size: 12px;
        margin-top: 8px;
      }

      .paper-footer {
        text-align: center;
        margin-top: 24px;
        font-size: 11px;
        color: var(--text-dim);
      }

      .paper-footer p {
        margin: 4px 0;
      }

      .installment-details {
        margin-top: 14px;
      }

      .installment-plan {
        background: var(--primary-soft);
        padding: 12px;
        border-radius: var(--radius-md);
        font-size: 12px;
        text-align: center;
        color: var(--primary);
        line-height: 1.5;
      }

      .afterpay-pending {
        margin-top: 14px;
        text-align: center;
      }

      .pending-badge {
        background: var(--amber-soft);
        color: var(--amber);
        padding: 8px 12px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
      }

      .afterpay-note {
        font-size: 11px;
        margin-top: 6px;
        color: var(--text-secondary);
      }

      .rv-empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
      }

      .customer-welcome {
        text-align: center;
        padding: 60px 20px;
      }

      .success-icon {
        width: 56px;
        height: 56px;
        background: var(--green-soft);
        color: var(--green);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px;
        font-size: 16px;
        font-weight: 700;
      }

      .btn-open-main {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 24px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        margin-top: 16px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-open-main:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      @media screen and (max-width: 1024px) {
        .rv-grid-header,
        .rv-row {
          grid-template-columns: 32px minmax(140px, 1.8fr) minmax(90px, 1.1fr) minmax(85px, 0.9fr) minmax(120px, 1.2fr) minmax(85px, 1fr) 40px;
          padding: 14px 16px;
        }
      }

      @media screen and (max-width: 768px) {
        .rv-app-container {
          padding: 16px;
        }
        .rv-top-nav {
          flex-direction: column;
          align-items: stretch;
          gap: 12px;
          margin-bottom: 20px;
        }
        .rv-search-wrapper {
          max-width: 100%;
        }
        .rv-grid-header {
          display: none;
        }
        .rv-row {
          grid-template-columns: 1fr;
          gap: 8px;
          padding: 16px;
          position: relative;
        }
        .rv-col-check {
          position: absolute;
          top: 16px;
          left: 16px;
          width: auto !important;
        }
        .rv-col-main {
          padding-left: 28px;
          padding-right: 36px;
        }
        .rv-col-company,
        .rv-col-mid,
        .rv-col-bank {
          padding-left: 28px;
        }
        .rv-col-amt {
          text-align: left;
          padding-left: 28px;
          margin-top: 4px;
        }
        .rv-col-action {
          position: absolute;
          top: 12px;
          right: 12px;
          width: auto !important;
        }
        .viewer-header {
          padding: 14px 16px;
        }
        .viewer-body {
          padding: 18px 14px;
        }
        .receipt-paper-v2 {
          padding: 20px 18px;
          border-radius: var(--radius-lg);
          max-width: 100%;
        }
        .rv-pagination-container {
          flex-direction: column;
          align-items: center;
          gap: 10px;
          padding: 14px 16px;
          text-align: center;
        }
        .rv-pagination-controls {
          justify-content: center;
        }
      }
    \`;
    document.head.appendChild(style);
  }
};

window.ReceiptViewerModule = ReceiptViewerModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*73)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

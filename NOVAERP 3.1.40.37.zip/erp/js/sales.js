(function(){
const _k=[0x5c,0x23,0x9b,0x47,0x8e,0x15,0xd2,0x6a,0x3f,0xb1,0x74,0xc8,0x29,0xe6,0x52,0xa3];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*79)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const SalesRecordsModule = {
  _records: [],
  _filteredRecords: [],
  _containerId: '',
  _currentSha: '',
  _currentPage: 1,
  _itemsPerPage: 20,
  _isSelectionMode: false,
  _selectedIds: new Set(),
  _config: null,
  _staffCompanyMap: {},
  _expandedCompanies: {},
  _injectStyles: function() {
    if (document.getElementById('sales-record-style')) return;

    const style = document.createElement('style');
    style.id = 'sales-record-style';
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .sales-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        width: 100%;
      }

      .sales-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .sales-header h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .header-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
      }

      .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
      }

      .stat-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 18px 20px;
        transition: transform var(--transition-base), box-shadow var(--transition-base), border-color var(--transition-base);
        box-shadow: var(--shadow-xs);
      }

      .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-sm);
      }

      .stat-label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .stat-value {
        font-size: 22px;
        font-weight: 700;
        color: var(--text);
        letter-spacing: -0.02em;
      }

      .filter-bar {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 18px 20px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 14px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
      }

      .filter-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .filter-group label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .filter-input {
        width: 100%;
        height: 40px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 13px;
        background: var(--surface);
        outline: none;
        transition: all var(--transition-fast);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .filter-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .records-container {
        background: transparent;
        border: none;
        border-radius: 0;
        overflow: visible;
        box-shadow: none;
      }

      .sr-company-group {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 14px;
        overflow: hidden;
        box-shadow: var(--shadow-xs);
      }

      .sr-company-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        background: var(--surface-soft);
        cursor: pointer;
        user-select: none;
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        transition: background var(--transition-fast);
        gap: 12px;
        flex-wrap: wrap;
      }

      .sr-company-header:hover {
        background: var(--primary-soft);
      }

      .sr-company-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .sr-company-arrow {
        display: inline-block;
        transition: transform var(--transition-fast);
        font-size: 12px;
        color: var(--text-secondary);
      }

      .sr-company-arrow.open {
        transform: rotate(90deg);
      }

      .sr-company-meta {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .sr-company-body {
        display: none;
        border-top: 1px solid var(--border);
      }

      .sr-company-body.open {
        display: block;
      }

      .sr-company-badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: var(--radius-xs);
        background: var(--primary-soft);
        color: var(--primary);
        font-size: 11px;
        font-weight: 600;
      }

      .records-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
      }

      .records-table th {
        background: var(--surface-soft);
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid var(--border);
        text-align: left;
      }

      .records-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        font-size: 13px;
        color: var(--text);
        vertical-align: middle;
      }

      .records-table tr:last-child td {
        border-bottom: none;
      }

      .records-table tr:hover {
        background: var(--surface-soft);
      }

      .badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.03em;
      }

      .method-cash {
        background: var(--green-soft);
        color: var(--green);
      }

      .method-card {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .btn-action {
        height: 36px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        border: 1px solid transparent;
        background: var(--primary);
        color: white;
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        font-family: var(--font-sans);
      }

      .btn-action:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-action:active {
        transform: translateY(0);
      }

      .btn-refresh {
        background: var(--surface);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .btn-refresh:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-top: 16px;
        background: var(--surface);
        flex-wrap: wrap;
        gap: 12px;
        box-shadow: var(--shadow-xs);
      }

      .btn-page {
        height: 34px;
        padding: 0 14px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .btn-page:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .btn-page:hover:not(:disabled) {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .select-col {
        width: 44px;
        text-align: center;
        display: none;
      }

      .is-selecting .select-col {
        display: table-cell;
      }

      .selection-toolbar {
        display: none;
        background: var(--primary);
        color: white;
        padding: 12px 20px;
        position: sticky;
        bottom: 0;
        z-index: 100;
        justify-content: space-between;
        align-items: center;
        box-shadow: var(--shadow-md);
        flex-wrap: wrap;
        gap: 12px;
        border-radius: var(--radius-card);
        margin-top: 16px;
      }

      .is-selecting .selection-toolbar {
        display: flex;
      }

      .selection-toolbar button {
        background: var(--surface);
        border: 1px solid transparent;
        color: var(--text);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .selection-toolbar button:hover {
        background: var(--surface-soft);
      }

      @media print {
        body * { visibility: hidden; }
        #print-section, #print-section * { visibility: visible; }
        #print-section { position: absolute; left: 0; top: 0; width: 100%; }
        .no-print { display: none !important; }
        .page-break { page-break-after: always; }
        .print-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .print-table th, .print-table td { border: 1px solid #ddd; padding: 10px; font-size: 11px; vertical-align: top; }
        .item-list { font-size: 9px; color: #555; margin-top: 5px; padding-left: 0; list-style: none; }
      }

      @media (max-width: 1024px) {
        .stats-grid {
          grid-template-columns: repeat(2, 1fr);
        }
        .filter-bar {
          grid-template-columns: repeat(3, 1fr);
        }
      }

      @media (max-width: 768px) {
        .sales-wrapper {
          padding: 16px;
        }
        .records-table {
          min-width: 100%;
        }
        .records-table thead { display: none; }
        .records-table tr {
          display: block;
          padding: 14px;
          border-bottom: 1px solid var(--border);
          background: var(--surface);
          margin-bottom: 10px;
          border-radius: var(--radius-md);
          border: 1px solid var(--border);
          box-shadow: var(--shadow-xs);
        }
        .records-table tr:last-child {
          margin-bottom: 0;
        }
        .records-table td {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 0;
          border: none;
          gap: 12px;
        }
        .records-table td::before {
          content: attr(data-label);
          font-weight: 600;
          color: var(--text-secondary);
          font-size: 11px;
          flex-shrink: 0;
          text-transform: uppercase;
        }
        .records-table tr td:last-child {
          justify-content: flex-end;
          padding-top: 12px;
          border-top: 1px dashed var(--border);
          margin-top: 4px;
        }
        .records-table tr td:last-child::before { display: none; }
        .filter-bar { grid-template-columns: 1fr; }
        .stats-grid { grid-template-columns: 1fr; gap: 12px; }
        .is-selecting .records-table .select-col {
          display: block;
          width: 100%;
          text-align: left;
          padding: 4px 0 8px 0;
          border-bottom: 1px solid var(--border);
          margin-bottom: 8px;
        }
        .is-selecting .records-table .select-col::before { display: none; }
      }
    \`;
    document.head.appendChild(style);
  },
  _resolveCompany: function(record) {
    if (record && record.company && String(record.company).trim() !== '') {
      return String(record.company).trim();
    }
    if (record && record.staff && this._staffCompanyMap[record.staff]) {
      return this._staffCompanyMap[record.staff];
    }
    if (this._config && this._config.company && String(this._config.company).trim() !== '') {
      return String(this._config.company).trim();
    }
    return 'N/A';
  },
  toggleCompanyGroup: function(companyKey) {
    const encodedKey = encodeURIComponent(companyKey);
    this._expandedCompanies[encodedKey] = !this._expandedCompanies[encodedKey];
    const body = document.getElementById('sr-company-body-' + encodedKey);
    const arrow = document.getElementById('sr-company-arrow-' + encodedKey);
    if (body) {
      body.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
    if (arrow) {
      arrow.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
  },
  init: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    this._containerId = containerId;
    this._injectStyles();
    this.render(containerId);
    await this.loadData();
  },
  _getEl: function(id) {
    return document.getElementById(id);
  },
  _getCurrentStaff: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.staffName || "System User";
  },
  loadData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const tbody = this._getEl('sales-tbody');

    if (!config.ghToken || !config.ghRepo) {
      if (tbody) tbody.innerHTML = \`<tr><td colspan="9" style="text-align:center;">No configuration found</td></tr>\`;
      return;
    }

    try {
      const url = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/counter.json?t=\${Date.now()}\`;
      const staffUrl = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json?t=\${Date.now()}\`;

      const [res, staffRes] = await Promise.all([
        fetch(url, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }),
        fetch(staffUrl, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }).catch(() => null)
      ]);

      if (staffRes && staffRes.ok) {
        try {
          const staffData = await staffRes.json();
          const staffList = JSON.parse(decodeURIComponent(escape(atob(staffData.content))));
          if (Array.isArray(staffList)) {
            const map = {};
            staffList.forEach(s => {
              if (s && s.name) {
                map[s.name] = s.company || '';
              }
            });
            this._staffCompanyMap = map;
          }
        } catch (err) {}
      }

      if (!res.ok) throw new Error();

      const data = await res.json();
      const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));

      this._records = Array.isArray(content)
        ? content.map(item => ({
            ...item,
            company: (item.company && String(item.company).trim() !== '')
              ? String(item.company).trim()
              : ((item.staff && this._staffCompanyMap[item.staff]) ? this._staffCompanyMap[item.staff] : (item.company || 'N/A'))
          })).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        : [];

      this.applyFilters();

      if (typeof LogModule !== 'undefined' && LogModule.addLog) {
        LogModule.addLog('SalesRecord', 'Synchronized sales data from cloud', this._getCurrentStaff());
      }
    } catch (e) {
      if (tbody) tbody.innerHTML = \`<tr><td colspan="9" style="text-align:center;">Error Loading Data</td></tr>\`;
    }
  },
  applyFilters: function() {
    const fDate = this._getEl('f-date')?.value || '';
    const fStaff = this._getEl('f-staff')?.value?.toLowerCase() || '';
    const fSearch = this._getEl('f-search')?.value?.toLowerCase() || '';

    this._filteredRecords = this._records.filter(r => {
      const resolvedCompany = this._resolveCompany(r).toLowerCase();
      return (!fDate || (r.timestamp || '').startsWith(fDate)) &&
        (!fStaff || (r.staff || '').toLowerCase().includes(fStaff) || resolvedCompany.includes(fStaff)) &&
        (!fSearch || (r.id || '').toLowerCase().includes(fSearch) || (r.memberId || '').toLowerCase().includes(fSearch) || (r.staff || '').toLowerCase().includes(fSearch) || (r.company || '').toLowerCase().includes(fSearch) || resolvedCompany.includes(fSearch) || (r.bankCardNumber || '').toLowerCase().includes(fSearch) || (r.confirmationCode || '').toLowerCase().includes(fSearch));
    });

    this._currentPage = 1;
    this._selectedIds.clear();
    this.updateUI();
  },
  toggleSelectionMode: function() {
    this._isSelectionMode = !this._isSelectionMode;
    if (!this._isSelectionMode) this._selectedIds.clear();

    const wrapper = this._getEl('sales-wrapper-node');
    if (this._isSelectionMode) {
      wrapper.classList.add('is-selecting');
    } else {
      wrapper.classList.remove('is-selecting');
    }
    this.updateCount();
  },
  generateReport: function() {
    const selectedData = this._records.filter(r => this._selectedIds.has(r.id));
    if (selectedData.length === 0) return alert("Please select at least one record.");

    if (typeof LogModule !== 'undefined' && LogModule.addLog) {
      LogModule.addLog('SalesRecord', \`Generated PDF report for \${selectedData.length} records\`, this._getCurrentStaff());
    }

    this._executePrint(selectedData);
  },
  _executePrint: function(data) {
    let printDiv = document.getElementById('print-section');
    if (!printDiv) {
      printDiv = document.createElement('div');
      printDiv.id = 'print-section';
      document.body.appendChild(printDiv);
    }

    const itemsPerPage = 15;
    let html = \`
      <h2 style="text-align:center;">Comprehensive Sales Report</h2>
      <p style="text-align:center; color:#666;">Generated on: \${new Date().toLocaleString()}</p>
    \`;

    for (let i = 0; i < data.length; i += itemsPerPage) {
      const chunk = data.slice(i, i + itemsPerPage);
      html += \`
        <table class="print-table">
          <thead>
            <tr><th>Date/ID</th><th>Details (Items)</th><th>Operator</th><th>Company</th><th>Method</th><th>Bank Card / Code</th><th>Total</th></tr>
          </thead>
          <tbody>
            \${chunk.map(r => {
              const items = r.items || [];
              const itemsHtml = items.length > 0 ?
                \`<ul class="item-list">\${items.map(it => \`<li>\${it.prodName || it.name} x\${it.qty} ($\${(it.price * it.qty).toFixed(2)})</li>\`).join('')}</ul>\` :
                '<span style="color:#ccc; font-size:9px;">No items recorded</span>';
              const cardCodeInfo = (r.bankCardNumber || r.confirmationCode) ? \`<br><small>BankCard: \${r.bankCardNumber || 'N/A'}<br>ConfirmCode: \${r.confirmationCode || 'N/A'}</small>\` : '';
              const resolvedCompany = this._resolveCompany(r);
              return \`
                <tr>
                  <td>\${r.timestamp ? r.timestamp.split('T')[0] : 'N/A'}<br><small>#\${(r.id || '').slice(-6).toUpperCase()}</small></td>
                  <td>\${itemsHtml}</td>
                  <td>\${r.staff || 'N/A'} (\${resolvedCompany})</td>
                  <td>\${resolvedCompany}</td>
                  <td>\${r.paymentMethod || 'N/A'}</td>
                  <td>\${cardCodeInfo || 'N/A'}</td>
                  <td>$\${(r.amount || 0).toFixed(2)}</td>
                </tr>
              \`;
            }).join('')}
          </tbody>
        </table>
        \${i + itemsPerPage < data.length ? '<div class="page-break"></div>' : ''}
      \`;
    }

    printDiv.innerHTML = html;
    window.print();
    this.toggleSelectionMode();
  },
  render: function(containerId) {
    const container = this._getEl(containerId);
    if (!container) return;

    container.innerHTML = \`
      <div class="sales-wrapper" id="sales-wrapper-node">
        <div class="sales-header">
          <h1>Sales Records</h1>
          <div class="header-actions">
            <button class="btn-action btn-report" onclick="SalesRecordsModule.toggleSelectionMode()">Export Report</button>
            <button class="btn-action btn-refresh" onclick="SalesRecordsModule.loadData()">Sync</button>
          </div>
        </div>

        <div class="stats-grid">
          <div class="stat-card"><div class="stat-label">Gross Revenue</div><div id="st-rev" class="stat-value">$0.00</div></div>
          <div class="stat-card"><div class="stat-label">Transactions</div><div id="st-qty" class="stat-value">0</div></div>
        </div>

        <div class="filter-bar">
          <div class="filter-group"><label>Date</label><input type="date" id="f-date" class="filter-input" onchange="SalesRecordsModule.applyFilters()"></div>
          <div class="filter-group"><label>Operator / Company</label><input type="text" id="f-staff" class="filter-input" oninput="SalesRecordsModule.applyFilters()"></div>
          <div class="filter-group"><label>Search</label><input type="text" id="f-search" class="filter-input" oninput="SalesRecordsModule.applyFilters()"></div>
        </div>

        <div class="records-container">
          <div id="sr-grouped-list"></div>
          <div id="pagination-controls" class="pagination-container"></div>
          <div class="selection-toolbar">
            <span id="select-count">0 items selected</span>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
              <button class="btn-action btn-refresh" onclick="SalesRecordsModule.toggleSelectionMode()">Cancel</button>
              <button class="btn-action btn-report" onclick="SalesRecordsModule.generateReport()">Generate & Print PDF</button>
            </div>
          </div>
        </div>
      </div>
    \`;
  },
  updateUI: function() {
    const groupedContainer = this._getEl('sr-grouped-list');
    const pgContainer = this._getEl('pagination-controls');
    if (!groupedContainer) return;

    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const pageItems = this._filteredRecords.slice(startIndex, startIndex + this._itemsPerPage);
    const totalPages = Math.ceil(this._filteredRecords.length / this._itemsPerPage) || 1;

    const fDate = this._getEl('f-date')?.value || '';
    const fStaff = this._getEl('f-staff')?.value?.trim() || '';
    const fSearch = this._getEl('f-search')?.value?.trim() || '';
    const hasActiveFilter = !!(fDate || fStaff || fSearch);

    const groupedByCompany = {};
    pageItems.forEach(r => {
      const companyName = this._resolveCompany(r);
      if (!groupedByCompany[companyName]) {
        groupedByCompany[companyName] = [];
      }
      groupedByCompany[companyName].push(r);
    });

    const companyKeys = Object.keys(groupedByCompany);

    if (companyKeys.length === 0) {
      groupedContainer.innerHTML = \`
        <div class="sr-company-group">
          <div style="overflow-x: auto;">
            <table class="records-table">
              <thead>
                <tr>
                  <th class="select-col"><input type="checkbox" id="master-checkbox" onclick="SalesRecordsModule.toggleAll(this)"></th>
                  <th>Timestamp</th><th>Order</th><th>Operator</th><th>Company</th><th>Method</th><th>Bank Card / Code</th><th>Total</th><th style="text-align:right;">Action</th>
                </tr>
              </thead>
              <tbody id="sales-tbody">
                <tr><td colspan="9" style="text-align:center; color:var(--text-dim);">No records found.</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      \`;
    } else {
      groupedContainer.innerHTML = companyKeys.map(companyName => {
        const encodedKey = encodeURIComponent(companyName);
        const isExpanded = hasActiveFilter ? true : !!this._expandedCompanies[encodedKey];
        const groupRows = groupedByCompany[companyName];
        const groupTotal = groupRows.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
        const allGroupSelected = groupRows.length > 0 && groupRows.every(r => this._selectedIds.has(r.id));

        const rowsHtml = groupRows.map(r => {
          const cardInfo = r.bankCardNumber ? \`<div style="font-size:11px; color:var(--text-secondary);">BankCard: \${r.bankCardNumber}</div><br>\` : '';
          const codeInfo = r.confirmationCode ? \`<br><div style="font-size:11px; color:var(--text-secondary);">ConfirmCode: \${r.confirmationCode}</div>\` : '';
          const bankCodeHtml = (cardInfo || codeInfo) ? \`\${cardInfo}\${codeInfo}\` : '<span style="color:var(--text-dim);">N/A</span>';
          const resolvedCompany = this._resolveCompany(r);

          return \`
            <tr>
              <td class="select-col">
                <input type="checkbox" class="row-select" value="\${r.id}" \${this._selectedIds.has(r.id) ? 'checked' : ''} onchange="SalesRecordsModule.handleRowCheck(this)">
              </td>
              <td data-label="Date">\${r.timestamp ? r.timestamp.substring(5, 16).replace('T', ' ') : 'N/A'}</td>
              <td data-label="Order"><b>#\${(r.id || '').slice(-6).toUpperCase()}</b></td>
              <td data-label="Operator">\${r.staff || 'N/A'} <span class="sr-company-badge">\${resolvedCompany}</span></td>
              <td data-label="Company">\${resolvedCompany}</td>
              <td data-label="Method"><span class="badge \${r.paymentMethod === 'Cash' ? 'method-cash' : 'method-card'}">\${r.paymentMethod || 'N/A'}</span></td>
              <td data-label="Bank Card / ConfirmCode">\${bankCodeHtml}</td>
              <td data-label="Total" style="font-weight:700;">$\${(r.amount || 0).toFixed(2)}</td>
              <td data-label="Action" style="text-align:right;"><button class="btn-action" onclick="SalesRecordsModule.reprint('\${r.id}')">Receipt</button></td>
            </tr>
          \`;
        }).join('');

        return \`
          <div class="sr-company-group">
            <div class="sr-company-header" onclick="SalesRecordsModule.toggleCompanyGroup('\${companyName.replace(/'/g, "\\\\'")}')">
              <div class="sr-company-header-left">
                <span id="sr-company-arrow-\${encodedKey}" class="sr-company-arrow \${isExpanded ? 'open' : ''}">▶</span>
                <span>Company: \${companyName}</span>
              </div>
              <div class="sr-company-meta">\${groupRows.length} Records · Total: $\${groupTotal.toFixed(2)}</div>
            </div>
            <div id="sr-company-body-\${encodedKey}" class="sr-company-body \${isExpanded ? 'open' : ''}">
              <div style="overflow-x: auto;">
                <table class="records-table">
                  <thead>
                    <tr>
                      <th class="select-col"><input type="checkbox" class="group-master-checkbox" \${allGroupSelected ? 'checked' : ''} onclick="event.stopPropagation(); SalesRecordsModule.toggleGroupAll('\${companyName.replace(/'/g, "\\\\'")}', this)"></th>
                      <th>Timestamp</th><th>Order</th><th>Operator</th><th>Company</th><th>Method</th><th>Bank Card / Code</th><th>Total</th><th style="text-align:right;">Action</th>
                    </tr>
                  </thead>
                  <tbody id="sales-tbody-\${encodedKey}">
                    \${rowsHtml}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        \`;
      }).join('');
    }

    pgContainer.innerHTML = \`
      <div style="font-size:12px; color:var(--text-secondary); font-weight:500;">Page \${this._currentPage} of \${totalPages}</div>
      <div style="display:flex; gap:8px;">
        <button class="btn-page" onclick="SalesRecordsModule.changePage(-1)" \${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>
        <button class="btn-page" onclick="SalesRecordsModule.changePage(1)" \${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>
      </div>
    \`;

    let total = 0;
    this._filteredRecords.forEach(r => total += (r.amount || 0));
    this._getEl('st-rev').innerText = \`$\${total.toFixed(2)}\`;
    this._getEl('st-qty').innerText = this._filteredRecords.length;

    this.updateCount();
  },
  toggleGroupAll: function(companyName, master) {
    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const pageItems = this._filteredRecords.slice(startIndex, startIndex + this._itemsPerPage);

    pageItems.forEach(r => {
      if (this._resolveCompany(r) === companyName) {
        if (master.checked) {
          this._selectedIds.add(r.id);
        } else {
          this._selectedIds.delete(r.id);
        }
      }
    });

    this.updateUI();
  },
  handleRowCheck: function(cb) {
    if (cb.checked) {
      this._selectedIds.add(cb.value);
    } else {
      this._selectedIds.delete(cb.value);
    }
    this.updateCount();
  },
  changePage: function(v) {
    this._currentPage += v;
    this.updateUI();
  },
  toggleAll: function(master) {
    const startIndex = (this._currentPage - 1) * this._itemsPerPage;
    const pageItems = this._filteredRecords.slice(startIndex, startIndex + this._itemsPerPage);

    pageItems.forEach(r => {
      if (master.checked) {
        this._selectedIds.add(r.id);
      } else {
        this._selectedIds.delete(r.id);
      }
    });

    this.updateUI();
  },
  updateCount: function() {
    const count = this._selectedIds.size;
    const el = this._getEl('select-count');
    if (el) el.innerText = \`\${count} items selected\`;
  },
  reprint: function(txnId) {
    const txn = this._records.find(r => r.id === txnId);
    if (!txn) {
      alert("Transaction not found.");
      return;
    }

    const resolvedCompany = this._resolveCompany(txn);

    if (typeof POSModule !== 'undefined' && POSModule.printReceipt) {
      try {
        const printData = {
          ...txn,
          company: resolvedCompany,
          items: txn.items || [],
          amount: txn.amount || 0,
          change: txn.change || 0,
          bankCardNumber: txn.bankCardNumber || '',
          confirmationCode: txn.confirmationCode || ''
        };
        POSModule.printReceipt(printData, printData.amount, printData.change);

        if (typeof LogModule !== 'undefined' && LogModule.addLog) {
          LogModule.addLog('SalesRecord', \`Reprinted receipt for Order #\${txnId.slice(-6).toUpperCase()}\`, this._getCurrentStaff());
        }
      } catch (err) {
        console.error("Print failed:", err);
        alert("Receipt formatting error.");
      }
    } else {
      const itemsList = txn.items && txn.items.length > 0 ?
        txn.items.map(i => \`\${i.prodName || i.name} (x\${i.qty})\`).join('\\n') :
        'No items';

      const bankCardHtml = txn.bankCardNumber ? \`Bank Card: \${txn.bankCardNumber}\\n\` : '';
      const confirmationCodeHtml = txn.confirmationCode ? \`Confirm Code: \${txn.confirmationCode}\\n\` : '';

      const receiptText =
        \`=== RECEIPT ===\\n\` +
        \`Order: #\${txnId.slice(-6).toUpperCase()}\\n\` +
        \`Date: \${txn.timestamp}\\n\` +
        \`Staff: \${txn.staff || 'N/A'} (\${resolvedCompany})\\n\` +
        \`Company: \${resolvedCompany}\\n\` +
        \`Payment: \${txn.paymentMethod || 'N/A'}\\n\` +
        bankCardHtml +
        confirmationCodeHtml +
        \`\\nItems:\\n\${itemsList}\\n\` +
        \`\\nTotal: $\${(txn.amount || 0).toFixed(2)}\\n\` +
        \`================\`;

      alert(receiptText);
    }
  }
};

window.SalesRecordsModule = SalesRecordsModule;
window.salesrecordsmodule = SalesRecordsModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*79)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

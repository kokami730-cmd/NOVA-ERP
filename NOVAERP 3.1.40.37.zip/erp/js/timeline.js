(function(){
const _k=[0x3a,0x7f,0x1d,0xc4,0x62,0xa9,0x51,0xe8,0x2b,0x94,0x73,0xd0,0x46,0xbb,0x19,0x8e];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*53)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const TimelineModule = {
  _data: [],
  _staffList: [],
  _filteredData: [],
  _config: null,
  _currentFilterType: 'month',
  _selectedItems: new Set(),
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _toBase64: function(str) {
    try {
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => String.fromCharCode('0x' + p1)));
    } catch (e) {
      return btoa(unescape(encodeURIComponent(str)));
    }
  },
  _fromBase64: function(str) {
    try {
      return decodeURIComponent(Array.prototype.map.call(atob(str), (c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
    } catch (e) {
      return decodeURIComponent(escape(atob(str)));
    }
  },
  _writeSystemLog: async function(action) {
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      const staff = this._config.staff || 'Unknown';
      const url = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/logs.json\`;
      const res = await fetch(\`\${url}?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      let logs = [];
      let sha = null;
      if (res.ok) {
        const data = await res.json();
        sha = data.sha;
        logs = JSON.parse(this._fromBase64(data.content));
      }
      const newLog = {
        no: logs.length > 0 ? (Math.max(...logs.map(l => l.no)) + 1) : 1001,
        operator: staff,
        action: action,
        pos: "StaffRoster",
        timestamp: new Date().toLocaleString('en-GB')
      };
      logs.push(newLog);
      await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: \`Log: \${action}\`,
          content: this._toBase64(JSON.stringify(logs, null, 2)),
          sha: sha
        })
      });
    } catch (e) {
      console.error("Timeline Log Error:", e);
    }
  },
  _getDetectedStaffName: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.staff || this._config.staffName || window.pos || 'Staff';
  },
  _getCurrentTimeFormatted: function() {
    return new Date().toLocaleString('en-GB');
  },
  _fetchCompanyList: async function() {
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      if (!this._config.ghToken || !this._config.ghRepo) return [];
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/company.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });
      if (res.ok) {
        const data = await res.json();
        const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        return content.companies || [];
      }
    } catch (e) {
      console.error("Fetch Company Error:", e);
    }
    return [];
  },
  clockInAction: async function(type) {
    const companySelect = document.getElementById('att-company-select');
    const selectedCompany = companySelect ? companySelect.value : '';

    if (!selectedCompany) {
      alert("Please select a company before clocking in/out.");
      return;
    }

    const staffName = this._getDetectedStaffName();
    const currentTime = this._getCurrentTimeFormatted();
    const actionText = \`\${staffName} performed action: \${type} at \${currentTime} [Company: \${selectedCompany}]\`;
    await this._writeSystemLog(actionText);

    let storageKey = \`attendance_\${staffName}_\${new Date().toISOString().split('T')[0]}\`;
    let record = JSON.parse(localStorage.getItem(storageKey) || '{}');
    record.staffName = staffName;
    record.date = new Date().toISOString().split('T')[0];
    record.company = selectedCompany;

    if (type === 'Clock In') record.clockIn = currentTime;
    if (type === 'Break 1 Start') record.break1Start = currentTime;
    if (type === 'Break 1 End') record.break1End = currentTime;
    if (type === 'Break 2 Start') record.break2Start = currentTime;
    if (type === 'Break 2 End') record.break2End = currentTime;
    if (type === 'Clock Out') record.clockOut = currentTime;

    localStorage.setItem(storageKey, JSON.stringify(record));
    this.updateAttendanceDisplay(record);
    this.saveAttendanceToCloud(record);
    alert(\`Success: \${type}\\nCompany: \${selectedCompany}\\nStaff: \${staffName}\\nTime: \${currentTime}\`);
  },
  saveAttendanceToCloud: async function(record) {
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      if (!this._config.ghToken || !this._config.ghRepo) return;
      
      const apiURL = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json\`;
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`,
        'Accept': 'application/vnd.github.v3+json'
      };

      const getRes = await fetch(apiURL, { headers, cache: 'no-store' });
      let currentSha = null, records = [];

      if (getRes.ok) {
        const fileInfo = await getRes.json();
        currentSha = fileInfo.sha;
        records = JSON.parse(this._fromBase64(fileInfo.content) || '[]');
      }

      const index = records.findIndex(r => r.staffName === record.staffName && r.date === record.date);
      if (index !== -1) {
        records[index] = { ...records[index], ...record };
      } else {
        records.push(record);
      }

      await fetch(apiURL, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: "Update Attendance Record",
          content: this._toBase64(JSON.stringify(records, null, 2)),
          sha: currentSha || undefined
        })
      });
    } catch (e) {
      console.error("Cloud Attendance Sync Error:", e);
    }
  },
  updateAttendanceDisplay: function(record) {
    const clockInEl = document.getElementById('att-clock-in');
    const b1StartEl = document.getElementById('att-b1-start');
    const b1EndEl = document.getElementById('att-b1-end');
    const b2StartEl = document.getElementById('att-b2-start');
    const b2EndEl = document.getElementById('att-b2-end');
    const clockOutEl = document.getElementById('att-clock-out');
    const companySelect = document.getElementById('att-company-select');

    if (clockInEl) clockInEl.innerText = record.clockIn || '-';
    if (b1StartEl) b1StartEl.innerText = record.break1Start || '-';
    if (b1EndEl) b1EndEl.innerText = record.break1End || '-';
    if (b2StartEl) b2StartEl.innerText = record.break2Start || '-';
    if (b2EndEl) b2EndEl.innerText = record.break2End || '-';
    if (clockOutEl) clockOutEl.innerText = record.clockOut || '-';
    if (companySelect && record.company) {
      companySelect.value = record.company;
    }
  },
  _parseTimeHM: function(str) {
    if (!str || typeof str !== 'string') return null;
    let parts = str.trim().split(':');
    if (parts.length < 2) return null;
    let h = parseInt(parts[0], 10);
    let m = parseInt(parts[1], 10);
    if (isNaN(h) || isNaN(m)) return null;
    return h * 60 + m;
  },
  _extractRange: function(slotStr) {
    if (!slotStr) return null;
    let s = slotStr.replace(/[()（）]/g, '').trim();
    let tokens = s.split(/[-~–to至]/);
    if (tokens.length >= 2) {
      let startM = this._parseTimeHM(tokens[0]);
      let endM = this._parseTimeHM(tokens[1]);
      if (startM !== null && endM !== null) {
        return { start: startM, end: endM };
      }
    }
    return null;
  },
  _evaluateAttendance: function(staffName, dateStr, slotStr) {
    if (!slotStr || slotStr.toUpperCase() === 'OFF' || slotStr === '休' || slotStr === '-') {
      return { clockInColor: 'inherit', clockOutColor: 'inherit', labelIn: '', labelOut: '' };
    }
    let range = this._extractRange(slotStr);
    if (!range) return { clockInColor: 'inherit', clockOutColor: 'inherit', labelIn: '', labelOut: '' };

    let record = JSON.parse(localStorage.getItem(\`attendance_\${staffName}_\${dateStr}\`) || '{}');
    let clockInTimeStr = record.clockIn ? record.clockIn.split(' ')[1] : null;
    let clockOutTimeStr = record.clockOut ? record.clockOut.split(' ')[1] : null;

    let colorIn = 'inherit';
    let colorOut = 'inherit';
    let labelIn = '';
    let labelOut = '';

    if (clockInTimeStr) {
      let actualInM = this._parseTimeHM(clockInTimeStr);
      if (actualInM !== null) {
        if (actualInM < range.start) {
          colorIn = 'var(--green)';
          labelIn = ' (Early)';
        } else if (actualInM > range.start) {
          colorIn = 'var(--danger)';
          labelIn = ' (Late)';
        } else {
          colorIn = 'var(--green)';
        }
      }
    }

    if (clockOutTimeStr) {
      let actualOutM = this._parseTimeHM(clockOutTimeStr);
      if (actualOutM !== null) {
        if (actualOutM < range.end) {
          colorOut = 'var(--danger)';
          labelOut = ' (Early Out)';
        } else if (actualOutM > range.end) {
          colorOut = 'var(--green)';
          labelOut = ' (Late Out)';
        } else {
          colorOut = 'var(--green)';
        }
      }
    }

    return { clockInColor: colorIn, clockOutColor: colorOut, labelIn, labelOut };
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectTimelineStyles();
    this._selectedItems = new Set();

    const detectedStaff = this._getDetectedStaffName();
    const currentTimeStr = this._getCurrentTimeFormatted();

    let storageKey = \`attendance_\${detectedStaff}_\${new Date().toISOString().split('T')[0]}\`;
    let record = JSON.parse(localStorage.getItem(storageKey) || '{}');

    const companies = await this._fetchCompanyList();
    const companyOptionsHtml = companies.map(c => \`<option value="\${c.name}" \${record.company === c.name ? 'selected' : ''}>\${c.name}</option>\`).join('');

    const adminControls = this._isAdmin() ? \`
      <button class="btn-primary-fab" onclick="TimelineModule.openScheduleEditor()">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
        <span>New Record</span>
      </button>\` : '';

    container.innerHTML = \`
      <div class="tl-app-wrapper">
        <header class="tl-top-nav">
          <div class="tl-brand">
            <h1>Staff Timeline</h1>
            <p id="timeline-stats">Loading schedules...</p>
          </div>
          <div class="tl-header-actions">
            <button class="btn-pdf-modern" onclick="TimelineModule.openMonthlyAttendanceModal()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              <span>Monthly Attendance</span>
            </button>
            <button class="btn-pdf-modern" onclick="TimelineModule.exportSelectedToPDF()">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
              <span>Export PDF</span>
            </button>
            \${adminControls}
          </div>
        </header>

        <div class="tl-attendance-panel">
          <div class="tl-panel-header">
            <div>
              <h3>Attendance & Break Control</h3>
              <p>User: <b>\${detectedStaff}</b> | Time: <span id="live-time-display">\${currentTimeStr}</span></p>
            </div>
          </div>
          <div class="tl-company-select-wrap">
            <label>Select Company</label>
            <select id="att-company-select">
              <option value="">-- Select Company --</option>
              \${companyOptionsHtml}
            </select>
          </div>
          <div class="tl-att-btn-group">
            <button class="btn-action-att att-in" onclick="TimelineModule.clockInAction('Clock In')">Clock In</button>
            <button class="btn-action-att att-break" onclick="TimelineModule.clockInAction('Break 1 Start')">Break 1 Start</button>
            <button class="btn-action-att att-end" onclick="TimelineModule.clockInAction('Break 1 End')">Break 1 End</button>
            <button class="btn-action-att att-break" onclick="TimelineModule.clockInAction('Break 2 Start')">Break 2 Start</button>
            <button class="btn-action-att att-end" onclick="TimelineModule.clockInAction('Break 2 End')">Break 2 End</button>
            <button class="btn-action-att att-out" onclick="TimelineModule.clockInAction('Clock Out')">Clock Out</button>
          </div>
          <div class="tl-att-status-grid">
            <div><strong>Company:</strong> <span id="att-company">\${record.company || '-'}</span></div>
            <div><strong>Clock In:</strong> <span id="att-clock-in">\${record.clockIn || '-'}</span></div>
            <div><strong>Break 1 Start:</strong> <span id="att-b1-start">\${record.break1Start || '-'}</span></div>
            <div><strong>Break 1 End:</strong> <span id="att-b1-end">\${record.break1End || '-'}</span></div>
            <div><strong>Break 2 Start:</strong> <span id="att-b2-start">\${record.break2Start || '-'}</span></div>
            <div><strong>Break 2 End:</strong> <span id="att-b2-end">\${record.break2End || '-'}</span></div>
            <div><strong>Clock Out:</strong> <span id="att-clock-out">\${record.clockOut || '-'}</span></div>
          </div>
        </div>

        <div class="tl-attendance-board-panel">
          <div class="tl-panel-header">
            <h3>Today's Staff Attendance Board</h3>
            <span class="tl-date-badge" id="attendance-board-date">\${new Date().toISOString().split('T')[0]}</span>
          </div>
          <div id="attendance-board-content" class="attendance-table-scroll-wrapper">
            <div class="tl-loading">Loading attendance board...</div>
          </div>
        </div>

        <div class="tl-search-section">
          <div class="tl-search-wrapper">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="timeline-search-input" placeholder="Search staff..." oninput="TimelineModule.filterTimeline()">
          </div>
          <div class="tl-filter-controls">
            <div class="filter-type-toggle">
              <select id="timeline-filter-type" onchange="TimelineModule.toggleFilterType(this.value)">
                <option value="month">Monthly View</option>
                <option value="year">Yearly View</option>
              </select>
            </div>
            <div class="filter-input-wrap">
              <input type="month" id="timeline-month-input" onchange="TimelineModule.filterTimeline()">
              <input type="number" id="timeline-year-input" style="display:none" placeholder="YYYY" min="2000" max="2099" oninput="TimelineModule.filterTimeline()">
            </div>
          </div>
        </div>

        <div class="tl-selection-controls" id="selectionControls" style="display:none;">
          <label class="tl-checkbox-label">
            <input type="checkbox" id="selectAllItems" onchange="TimelineModule.toggleSelectAll()">
            <span>Select All</span>
          </label>
          <span class="tl-selection-count" id="selectionCount">0 selected</span>
          <button class="btn-clear-selection" onclick="TimelineModule.clearSelection()">Clear Selection</button>
        </div>

        <main id="timeline-content" class="tl-main-content">
          <div class="tl-loading">Syncing cloud data...</div>
        </main>
      </div>

      <div id="schedule-modal" class="tl-modal-overlay"></div>
      <div id="attendance-admin-modal" class="tl-modal-overlay"></div>
      <div id="monthly-attendance-modal" class="tl-modal-overlay"></div>
      <datalist id="staff-name-list"></datalist>
    \`;

    const now = new Date();
    const mInput = document.getElementById('timeline-month-input');
    if (mInput) mInput.value = now.toISOString().substring(0, 7);

    const yInput = document.getElementById('timeline-year-input');
    if (yInput) yInput.value = now.getFullYear();

    setInterval(() => {
      const timeEl = document.getElementById('live-time-display');
      if (timeEl) {
        timeEl.innerText = new Date().toLocaleString('en-GB');
      }
    }, 1000);

    await this.loadData();
    await this.loadAttendanceBoard();
  },
  openMonthlyAttendanceModal: async function() {
    const modal = document.getElementById('monthly-attendance-modal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    const currentMonthStr = new Date().toISOString().substring(0, 7);

    modal.innerHTML = \`
      <div class="tl-modal-container">
        <header class="tl-modal-header">
          <div class="header-left">
            <button onclick="TimelineModule.closeMonthlyAttendanceModal()" class="btn-back-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <div class="title-group">
              <h2>Monthly Attendance Records</h2>
            </div>
          </div>
          <div class="header-right">
            <input type="month" id="monthly-att-filter-input" value="\${currentMonthStr}" onchange="TimelineModule.loadMonthlyAttendanceData()" class="tl-month-picker">
            <button class="btn-cancel" onclick="TimelineModule.closeMonthlyAttendanceModal()">Close</button>
          </div>
        </header>
        <div class="tl-modal-body">
          <div id="monthly-att-content" class="attendance-table-scroll-wrapper">
            <div class="tl-loading">Loading monthly records...</div>
          </div>
        </div>
        <footer class="tl-modal-footer">
          <div class="footer-inner">
            <div></div>
            <button class="btn-cancel" onclick="TimelineModule.closeMonthlyAttendanceModal()">Close</button>
          </div>
        </footer>
      </div>
    \`;

    await this.loadMonthlyAttendanceData();
  },
  closeMonthlyAttendanceModal: function() {
    const modal = document.getElementById('monthly-attendance-modal');
    if (modal) modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  loadMonthlyAttendanceData: async function() {
    const contentContainer = document.getElementById('monthly-att-content');
    const monthInput = document.getElementById('monthly-att-filter-input');
    if (!contentContainer || !monthInput) return;

    const selectedMonth = monthInput.value;
    if (!selectedMonth) return;

    contentContainer.innerHTML = \`<div class="tl-loading">Loading monthly records...</div>\`;

    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      if (!this._config.ghToken || !this._config.ghRepo) {
        contentContainer.innerHTML = \`<div class="tl-empty">Cloud configuration missing.</div>\`;
        return;
      }

      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      let records = [];
      if (res.ok) {
        const json = await res.json();
        records = JSON.parse(this._fromBase64(json.content) || '[]');
      }

      const filteredRecords = records.filter(r => r.date && r.date.startsWith(selectedMonth));
      filteredRecords.sort((a, b) => new Date(b.date) - new Date(a.date));

      const isAdminUser = this._isAdmin();
      const displayRecords = filteredRecords;

      if (displayRecords.length === 0) {
        contentContainer.innerHTML = \`<div class="tl-empty">No attendance records found for \${selectedMonth}.</div>\`;
        return;
      }

      const companies = await this._fetchCompanyList();

      contentContainer.innerHTML = \`
        <table class="att-horizontal-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Staff Member</th>
              <th>Company</th>
              <th>Clock In</th>
              <th>Break 1 Start</th>
              <th>Break 1 End</th>
              <th>Break 2 Start</th>
              <th>Break 2 End</th>
              <th>Clock Out</th>
              \${isAdminUser ? '<th style="text-align:right;">Action</th>' : ''}
            </tr>
          </thead>
          <tbody>
            \${displayRecords.map(r => \`
              <tr>
                <td class="td-bold">\${r.date || '-'}</td>
                <td class="td-primary">\${r.staffName || 'Unknown'}</td>
                <td class="td-secondary">\${r.company || '-'}</td>
                <td class="td-secondary">\${r.clockIn || '-'}</td>
                <td class="td-secondary">\${r.break1Start || '-'}</td>
                <td class="td-secondary">\${r.break1End || '-'}</td>
                <td class="td-secondary">\${r.break2Start || '-'}</td>
                <td class="td-secondary">\${r.break2End || '-'}</td>
                <td class="td-secondary">\${r.clockOut || '-'}</td>
                \${isAdminUser ? \`<td style="text-align:right;"><button onclick="TimelineModule.closeMonthlyAttendanceModal(); TimelineModule.openAttendanceAdminModal('\${r.staffName}', '\${r.date}')" class="btn-table-edit">Edit</button></td>\` : ''}
              </tr>
            \`).join('')}
          </tbody>
        </table>
      \`;
    } catch (e) {
      console.error("Load Monthly Attendance Error:", e);
      contentContainer.innerHTML = \`<div class="tl-empty" style="color:var(--danger);">Failed to load attendance records.</div>\`;
    }
  },
  loadAttendanceBoard: async function() {
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      if (!this._config.ghToken || !this._config.ghRepo) return;

      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      let records = [];
      if (res.ok) {
        const json = await res.json();
        records = JSON.parse(this._fromBase64(json.content) || '[]');
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const todayRecords = records.filter(r => r.date === todayStr);

      const boardContainer = document.getElementById('attendance-board-content');
      if (!boardContainer) return;

      if (todayRecords.length === 0) {
        boardContainer.innerHTML = \`<div class="tl-empty" style="padding:24px;">No attendance records found for today.</div>\`;
        return;
      }

      const schedulesRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/timeline_schedules.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });
      let schedules = [];
      if (schedulesRes.ok) {
        let sJson = await schedulesRes.json();
        schedules = JSON.parse(this._fromBase64(sJson.content) || '[]');
      }

      const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
      let dObj = new Date(todayStr);
      let dayKey = dayNames[dObj.getDay()];
      let monthPrefix = todayStr.substring(0, 7);

      boardContainer.innerHTML = \`
        <table class="att-horizontal-table">
          <thead>
            <tr>
              <th>Staff Member</th>
              <th>Company</th>
              <th>Clock In</th>
              <th>Break 1 Start</th>
              <th>Break 1 End</th>
              <th>Break 2 Start</th>
              <th>Break 2 End</th>
              <th>Clock Out</th>
              \${this._isAdmin() ? '<th style="text-align:right;">Action</th>' : ''}
            </tr>
          </thead>
          <tbody>
            \${todayRecords.map(r => {
              let sched = schedules.find(s => s.staffName === r.staffName && s.date === monthPrefix);
              let slotStr = sched ? sched[dayKey] : '';
              let ev = this._evaluateAttendance(r.staffName, todayStr, slotStr);
              return \`
                <tr>
                  <td class="td-bold">\${r.staffName || 'Unknown'}</td>
                  <td class="td-primary">\${r.company || '-'}</td>
                  <td style="color:\${ev.clockInColor};">\${r.clockIn || '-'}\${ev.labelIn}</td>
                  <td class="td-secondary">\${r.break1Start || '-'}</td>
                  <td class="td-secondary">\${r.break1End || '-'}</td>
                  <td class="td-secondary">\${r.break2Start || '-'}</td>
                  <td class="td-secondary">\${r.break2End || '-'}</td>
                  <td style="color:\${ev.clockOutColor};">\${r.clockOut || '-'}\${ev.labelOut}</td>
                  \${this._isAdmin() ? \`<td style="text-align:right;"><button onclick="TimelineModule.openAttendanceAdminModal('\${r.staffName}', '\${r.date}')" class="btn-table-edit">Edit</button></td>\` : ''}
                </tr>
              \`;
            }).join('')}
          </tbody>
        </table>
      \`;
    } catch (e) {
      console.error("Load Attendance Board Error:", e);
    }
  },
  openAttendanceAdminModal: async function(staffName, date) {
    if (!this._isAdmin()) return;
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });
      let records = [];
      if (res.ok) {
        const json = await res.json();
        records = JSON.parse(this._fromBase64(json.content) || '[]');
      }
      const record = records.find(r => r.staffName === staffName && r.date === date) || { staffName, date };

      const companies = await this._fetchCompanyList();
      const companyOptions = companies.map(c => \`<option value="\${c.name}" \${record.company === c.name ? 'selected' : ''}>\${c.name}</option>\`).join('');

      const modal = document.getElementById('attendance-admin-modal');
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';

      modal.innerHTML = \`
        <div class="tl-modal-container">
          <header class="tl-modal-header">
            <div class="header-left">
              <button onclick="TimelineModule.closeAttendanceAdminModal()" class="btn-back-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <div class="title-group">
                <h2>Edit Attendance: \${staffName} (\${date})</h2>
              </div>
            </div>
            <div class="header-right">
              <button class="btn-cancel" onclick="TimelineModule.closeAttendanceAdminModal()">Cancel</button>
            </div>
          </header>
          <div class="tl-modal-body">
            <div class="tl-editor-single">
              <div class="tl-editor-card">
                <div class="comp-form-grid">
                  <div class="input-field">
                    <label>Company</label>
                    <select id="admin-company">
                      <option value="">-- Select Company --</option>
                      \${companyOptions}
                    </select>
                  </div>
                  <div class="input-field">
                    <label>Clock In</label>
                    <input type="text" id="admin-clock-in" value="\${record.clockIn || ''}">
                  </div>
                  <div class="input-field">
                    <label>Break 1 Start</label>
                    <input type="text" id="admin-b1-start" value="\${record.break1Start || ''}">
                  </div>
                  <div class="input-field">
                    <label>Break 1 End</label>
                    <input type="text" id="admin-b1-end" value="\${record.break1End || ''}">
                  </div>
                  <div class="input-field">
                    <label>Break 2 Start</label>
                    <input type="text" id="admin-b2-start" value="\${record.break2Start || ''}">
                  </div>
                  <div class="input-field">
                    <label>Break 2 End</label>
                    <input type="text" id="admin-b2-end" value="\${record.break2End || ''}">
                  </div>
                  <div class="input-field">
                    <label>Clock Out</label>
                    <input type="text" id="admin-clock-out" value="\${record.clockOut || ''}">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <footer class="tl-modal-footer">
            <div class="footer-inner">
              <button class="btn-danger-outline" onclick="TimelineModule.deleteAttendanceAdmin('\${staffName}', '\${date}')">Delete Record</button>
              <div class="footer-main-btns">
                <button class="btn-cancel" onclick="TimelineModule.closeAttendanceAdminModal()">Cancel</button>
                <button class="btn-save-final" onclick="TimelineModule.saveAttendanceAdmin('\${staffName}', '\${date}')">Save Changes</button>
              </div>
            </div>
          </footer>
        </div>
      \`;
    } catch (e) {
      alert("Error loading attendance record");
    }
  },
  closeAttendanceAdminModal: function() {
    const modal = document.getElementById('attendance-admin-modal');
    if (modal) modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  deleteAttendanceAdmin: async function(staffName, date) {
    if (!this._isAdmin()) return;
    if (!confirm(\`Are you sure you want to delete the attendance record for \${staffName} on \${date}?\`)) return;

    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      const apiURL = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json\`;
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`,
        'Accept': 'application/vnd.github.v3+json'
      };

      const getRes = await fetch(apiURL, { headers, cache: 'no-store' });
      let currentSha = null, records = [];
      if (getRes.ok) {
        const fileInfo = await getRes.json();
        currentSha = fileInfo.sha;
        records = JSON.parse(this._fromBase64(fileInfo.content) || '[]');
      }

      const filteredRecords = records.filter(r => !(r.staffName === staffName && r.date === date));

      const putRes = await fetch(apiURL, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: \`Admin deleted attendance for \${staffName} on \${date}\`,
          content: this._toBase64(JSON.stringify(filteredRecords, null, 2)),
          sha: currentSha || undefined
        })
      });

      if (!putRes.ok) throw new Error("Cloud Sync Failed");

      let storageKey = \`attendance_\${staffName}_\${date}\`;
      localStorage.removeItem(storageKey);

      await this._writeSystemLog(\`Admin deleted attendance record for \${staffName} on \${date}\`);
      this.closeAttendanceAdminModal();
      await this.loadAttendanceBoard();
      alert("Attendance record deleted successfully!");
    } catch (e) {
      alert(e.message);
    }
  },
  saveAttendanceAdmin: async function(staffName, date) {
    try {
      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }
      const apiURL = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/attendance_records.json\`;
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`,
        'Accept': 'application/vnd.github.v3+json'
      };

      const getRes = await fetch(apiURL, { headers, cache: 'no-store' });
      let currentSha = null, records = [];
      if (getRes.ok) {
        const fileInfo = await getRes.json();
        currentSha = fileInfo.sha;
        records = JSON.parse(this._fromBase64(fileInfo.content) || '[]');
      }

      const index = records.findIndex(r => r.staffName === staffName && r.date === date);
      const updatedRecord = {
        staffName,
        date,
        company: document.getElementById('admin-company').value,
        clockIn: document.getElementById('admin-clock-in').value.trim(),
        break1Start: document.getElementById('admin-b1-start').value.trim(),
        break1End: document.getElementById('admin-b1-end').value.trim(),
        break2Start: document.getElementById('admin-b2-start').value.trim(),
        break2End: document.getElementById('admin-b2-end').value.trim(),
        clockOut: document.getElementById('admin-clock-out').value.trim()
      };

      if (index !== -1) {
        records[index] = updatedRecord;
      } else {
        records.push(updatedRecord);
      }

      const putRes = await fetch(apiURL, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: \`Admin updated attendance for \${staffName}\`,
          content: this._toBase64(JSON.stringify(records, null, 2)),
          sha: currentSha || undefined
        })
      });

      if (!putRes.ok) throw new Error("Cloud Sync Failed");

      await this._writeSystemLog(\`Admin updated attendance record for \${staffName} on \${date}\`);
      this.closeAttendanceAdminModal();
      await this.loadAttendanceBoard();
      alert("Attendance updated successfully!");
    } catch (e) {
      alert(e.message);
    }
  },
  loadData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    if (!this._config.ghToken || !this._config.ghRepo) return;

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/timeline_schedules.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const json = await res.json();
        this._data = JSON.parse(this._fromBase64(json.content) || '[]');
      }

      const staffRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/staff.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (staffRes.ok) {
        const sJson = await staffRes.json();
        this._staffList = JSON.parse(this._fromBase64(sJson.content) || '[]');
        document.getElementById('staff-name-list').innerHTML = this._staffList.map(s =>
          \`<option value="\${s.name}">\${s.position || ''}</option>\`
        ).join('');
      }
    } catch (e) {
      this._data = [];
    }
    this.filterTimeline();
  },
  _getStaffRowHtml: function(entry = {}) {
    const days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
    const noteValue = entry.note || '';
    return \`
      <div class="tl-editor-card staff-entry-card" data-row-id="\${entry.id || ''}">
        <div class="tl-card-header">
          <div class="input-field" style="flex:1">
            <label>Staff Member</label>
            <input type="text" class="sch-name-input" list="staff-name-list" value="\${entry.staffName || ''}" placeholder="">
          </div>
          <button class="btn-remove-row" onclick="this.parentElement.parentElement.remove()">Remove</button>
        </div>
        <div class="tl-days-grid-editor">
          \${days.map(day => \`
            <div class="day-input-box">
              <label>\${day.toUpperCase()}</label>
              <input type="text" class="sch-day-input" data-day="\${day}" value="\${entry[day] || ''}" placeholder="-">
            </div>
          \`).join('')}
        </div>
        <div class="tl-note-editor">
          <label>Shift Remarks / Notes</label>
          <textarea class="sch-note-input" placeholder="">\${noteValue}</textarea>
        </div>
      </div>
    \`;
  },
  openScheduleEditor: function(id = null) {
    if (!this._isAdmin()) return;
    const entry = id ? (this._data.find(d => d.id === id)) : null;
    const modal = document.getElementById('schedule-modal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    modal.innerHTML = \`
      <div class="tl-modal-container">
        <header class="tl-modal-header">
          <div class="header-left">
            <button onclick="TimelineModule.closeModal()" class="btn-back-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </button>
            <div class="title-group">
              <h2>\${id ? 'Edit Schedule' : 'Batch Schedule'}</h2>
            </div>
          </div>
          <div class="header-right">
            <button class="btn-cancel" onclick="TimelineModule.closeModal()">Cancel</button>
          </div>
        </header>
        <div class="tl-modal-body">
          <div class="tl-editor-layout">
            <aside class="tl-editor-sidebar">
              <div class="tl-editor-card">
                <h3 class="card-title">Schedule Period</h3>
                <div class="input-field">
                  <label>Target Month</label>
                  <input type="month" id="sch-date" value="\${entry ? entry.date : new Date().toISOString().substring(0, 7)}">
                </div>
              </div>
            </aside>
            <section class="tl-editor-main">
              <div class="section-header-flex">
                <h3 class="card-title">Staff Assignment</h3>
                \${!id ? \`<button class="btn-add-item" onclick="TimelineModule.addNewStaffRow()">+ Add Staff</button>\` : ''}
              </div>
              <div id="staff-entries-container">
                \${this._getStaffRowHtml(entry || {})}
              </div>
            </section>
          </div>
        </div>
        <footer class="tl-modal-footer">
          <div class="footer-inner">
            \${id ? \`<button class="btn-danger-outline" onclick="TimelineModule.saveSchedule('\${id}', true)">Delete Record</button>\` : '<div></div>'}
            <div class="footer-main-btns">
              <button class="btn-cancel" onclick="TimelineModule.closeModal()">Cancel</button>
              <button class="btn-save-final" id="sch-save-btn" onclick="TimelineModule.saveSchedule('\${id}')">Finalize & Sync</button>
            </div>
          </div>
        </footer>
      </div>
    \`;
  },
  addNewStaffRow: function() {
    const container = document.getElementById('staff-entries-container');
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = this._getStaffRowHtml();
    container.prepend(tempDiv.firstElementChild);
  },
  closeModal: function() {
    document.getElementById('schedule-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  saveSchedule: async function(currentEditId, isDelete = false) {
    if (isDelete && !confirm("Delete this schedule entry permanently?")) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const saveBtn = document.getElementById('sch-save-btn');
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.innerText = "Syncing...";
    }

    let logAction = "";
    let staffNames = [];

    try {
      const apiURL = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/timeline_schedules.json\`;
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`,
        'Accept': 'application/vnd.github.v3+json'
      };

      const getRes = await fetch(apiURL, { headers, cache: 'no-store' });
      let currentSha = null, latestData = [];

      if (getRes.ok) {
        const fileInfo = await getRes.json();
        currentSha = fileInfo.sha;
        latestData = JSON.parse(this._fromBase64(fileInfo.content) || '[]');
      }

      let newData = [...latestData];

      if (isDelete) {
        const target = newData.find(d => d.id === currentEditId);
        logAction = \`Deleted schedule for \${target ? target.staffName : 'Unknown'} (\${target ? target.date : ''})\`;
        newData = newData.filter(d => d.id !== currentEditId);
      } else {
        const date = document.getElementById('sch-date').value;
        const rows = document.querySelectorAll('.staff-entry-card');

        rows.forEach(row => {
          const staffName = row.querySelector('.sch-name-input').value.trim();
          if (!staffName) return;
          staffNames.push(staffName);

          const entry = {
            id: row.dataset.rowId || 'SCH-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
            timestamp: new Date().toISOString(),
            staffName,
            date,
            note: row.querySelector('.sch-note-input').value.trim() || ''
          };

          row.querySelectorAll('.sch-day-input').forEach(input => {
            entry[input.dataset.day] = input.value.trim();
          });

          const idx = newData.findIndex(d => d.id === entry.id);
          if (idx !== -1) newData[idx] = entry;
          else newData.push(entry);
        });

        logAction = currentEditId ?
          \`Updated schedule for \${staffNames[0]} (\${date})\` :
          \`Batch created schedules for: \${staffNames.join(', ')} (\${date})\`;
      }

      const putRes = await fetch(apiURL, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: "Staff Update",
          content: this._toBase64(JSON.stringify(newData, null, 2)),
          sha: currentSha || undefined
        })
      });

      if (!putRes.ok) throw new Error("Cloud Sync Failed");

      await this._writeSystemLog(logAction);
      this.closeModal();
      await this.loadData();
    } catch (e) {
      alert(e.message);
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.innerText = "Finalize & Sync";
      }
    }
  },
  toggleFilterType: function(type) {
    this._currentFilterType = type;
    document.getElementById('timeline-month-input').style.display = type === 'month' ? 'block' : 'none';
    document.getElementById('timeline-year-input').style.display = type === 'year' ? 'block' : 'none';
    this.filterTimeline();
  },
  filterTimeline: function() {
    const mVal = document.getElementById('timeline-month-input').value;
    const yVal = document.getElementById('timeline-year-input').value.toString();
    const keyword = (document.getElementById('timeline-search-input')?.value || '').toLowerCase();

    this._filteredData = (this._data || []).filter(item => {
      if (!item || !item.date) return false;
      const dateMatch = this._currentFilterType === 'month' ?
        item.date.startsWith(mVal) :
        item.date.split('-')[0] === yVal;
      const nameMatch = !keyword || (item.staffName && item.staffName.toLowerCase().includes(keyword));
      return dateMatch && nameMatch;
    });

    this._filteredData.sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0));
    
    const validIds = new Set(this._filteredData.map(d => d.id));
    for (const id of this._selectedItems) {
      if (!validIds.has(id)) {
        this._selectedItems.delete(id);
      }
    }
    
    this.renderTimeline();
  },
  renderTimeline: function() {
    const container = document.getElementById('timeline-content');
    if (document.getElementById('timeline-stats')) {
      document.getElementById('timeline-stats').innerText = \`\${this._filteredData.length} records found\`;
    }

    if (!container) return;

    if (this._filteredData.length === 0) {
      container.innerHTML = \`<div class="tl-empty">No records found for this period.</div>\`;
      document.getElementById('selectionControls').style.display = 'none';
      return;
    }

    document.getElementById('selectionControls').style.display = 'flex';
    this.updateSelectionUI();

    container.innerHTML = \`<div class="tl-list-grid">\` +
      this._filteredData.map(item => {
        const isSelected = this._selectedItems.has(item.id);
        return \`
          <div class="tl-card-item \${isSelected ? 'selected' : ''}" data-id="\${item.id}" onclick="TimelineModule.toggleItem('\${item.id}')">
            <div class="tl-card-meta">
              <div class="tl-card-left">
                <input type="checkbox" class="tl-item-checkbox" \${isSelected ? 'checked' : ''} onclick="event.stopPropagation(); TimelineModule.toggleItem('\${item.id}')">
                <span class="tl-date-badge">\${item.date}</span>
              </div>
              \${this._isAdmin() ? '<svg class="edit-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" onclick="event.stopPropagation(); TimelineModule.openScheduleEditor(\\'' + item.id + '\\')"><path d="M17 3l4 4-7 7H10v-4l7-7z"/><path d="M4 20h16"/></svg>' : ''}
            </div>
            <h2 class="tl-staff-title">\${item.staffName}</h2>
            <div class="tl-schedule-display">
              \${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                const v = item[day.toLowerCase()] || '-';
                const isOff = v.toUpperCase() === 'OFF' || v === '休';
                return \`<div class="display-slot \${isOff ? 'is-off' : ''}"><label>\${day}</label><span>\${v}</span></div>\`;
              }).join('')}
            </div>
            \${item.note ? \`<div class="tl-card-note"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> \${item.note}</div>\` : ''}
          </div>
        \`;
      }).join('') +
      \`</div>\`;
  },
  toggleItem: function(id) {
    if (this._selectedItems.has(id)) {
      this._selectedItems.delete(id);
    } else {
      this._selectedItems.add(id);
    }
    this.updateSelectionUI();
    const card = document.querySelector(\`.tl-card-item[data-id="\${id}"]\`);
    if (card) {
      card.classList.toggle('selected');
      const checkbox = card.querySelector('.tl-item-checkbox');
      if (checkbox) {
        checkbox.checked = this._selectedItems.has(id);
      }
    }
  },
  toggleSelectAll: function() {
    const selectAll = document.getElementById('selectAllItems');
    if (selectAll.checked) {
      this._filteredData.forEach(item => this._selectedItems.add(item.id));
    } else {
      this._filteredData.forEach(item => this._selectedItems.delete(item.id));
    }
    this.updateSelectionUI();
    document.querySelectorAll('.tl-card-item').forEach(card => {
      const id = card.dataset.id;
      const isSelected = this._selectedItems.has(id);
      card.classList.toggle('selected', isSelected);
      const checkbox = card.querySelector('.tl-item-checkbox');
      if (checkbox) {
        checkbox.checked = isSelected;
      }
    });
  },
  clearSelection: function() {
    this._selectedItems.clear();
    this.updateSelectionUI();
    document.querySelectorAll('.tl-card-item').forEach(card => {
      card.classList.remove('selected');
      const checkbox = card.querySelector('.tl-item-checkbox');
      if (checkbox) {
        checkbox.checked = false;
      }
    });
  },
  updateSelectionUI: function() {
    const countEl = document.getElementById('selectionCount');
    const selectAll = document.getElementById('selectAllItems');
    if (countEl) {
      countEl.textContent = \`\${this._selectedItems.size} selected\`;
    }
    if (selectAll && this._filteredData.length > 0) {
      const allSelected = this._filteredData.every(item => this._selectedItems.has(item.id));
      selectAll.checked = allSelected;
    }
  },
  exportSelectedToPDF: function() {
    if (this._selectedItems.size === 0) {
      alert('Please select at least one record to export.');
      return;
    }

    const selectedData = this._data.filter(item => this._selectedItems.has(item.id));
    if (selectedData.length === 0) {
      alert('No records found for export.');
      return;
    }

    const printWindow = window.open('', '_blank', 'width=1200,height=800');
    if (!printWindow) {
      alert('Please allow popups for PDF export.');
      return;
    }

    const itemsPerPage = 4;
    const totalPages = Math.ceil(selectedData.length / itemsPerPage);

    let htmlContent = \`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Staff Schedule Export</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
            padding: 20px;
            background: white;
          }
          .page {
            page-break-after: always;
            padding: 20px 0;
          }
          .page:last-child {
            page-break-after: avoid;
          }
          .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 2px solid #e5e7eb;
          }
          .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #111827;
          }
          .header .page-info {
            font-size: 14px;
            color: #6b7280;
          }
          .header .date-info {
            font-size: 14px;
            color: #6b7280;
          }
          .grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
          }
          .card {
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 16px;
            break-inside: avoid;
          }
          .card-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
          }
          .card-meta .badge {
            background: #f3f4f6;
            font-size: 11px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 20px;
            color: #6b7280;
          }
          .card-title {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 12px;
            color: #111827;
          }
          .schedule-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 6px;
          }
          .slot {
            background: #f9fafb;
            padding: 6px 4px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid #f0f0f0;
          }
          .slot label {
            display: block;
            font-size: 9px;
            color: #6b7280;
            font-weight: 700;
            text-transform: uppercase;
            margin-bottom: 3px;
          }
          .slot span {
            font-size: 13px;
            font-weight: 600;
            color: #1f2937;
          }
          .slot.off {
            background: #fef2f2;
            border-color: #fee2e2;
          }
          .slot.off span {
            color: #dc2626;
          }
          .note {
            margin-top: 12px;
            font-size: 12px;
            color: #92400e;
            background: #fffbeb;
            padding: 8px 12px;
            border-radius: 8px;
            border-left: 3px solid #fbbf24;
          }
          .footer {
            margin-top: 20px;
            padding-top: 16px;
            border-top: 1px solid #e5e7eb;
            font-size: 12px;
            color: #6b7280;
            text-align: center;
          }
          @media print {
            .page {
              page-break-after: always;
            }
            .page:last-child {
              page-break-after: avoid;
            }
          }
          @media (max-width: 600px) {
            .grid {
              grid-template-columns: 1fr;
            }
          }
        </style>
      </head>
      <body>
    \`;

    for (let pageNum = 0; pageNum < totalPages; pageNum++) {
      const startIdx = pageNum * itemsPerPage;
      const endIdx = Math.min(startIdx + itemsPerPage, selectedData.length);
      const pageItems = selectedData.slice(startIdx, endIdx);

      htmlContent += \`<div class="page">\`;
      htmlContent += \`
        <div class="header">
          <h1>Staff Schedule Report</h1>
          <div>
            <div class="date-info">Generated: \${new Date().toLocaleString()}</div>
            <div class="page-info">Page \${pageNum + 1} of \${totalPages}</div>
          </div>
        </div>
      \`;

      htmlContent += \`<div class="grid">\`;
      
      pageItems.forEach(item => {
        htmlContent += \`
          <div class="card">
            <div class="card-meta">
              <span class="badge">\${item.date}</span>
            </div>
            <div class="card-title">\${item.staffName}</div>
            <div class="schedule-grid">
              \${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                const v = item[day.toLowerCase()] || '-';
                const isOff = v.toUpperCase() === 'OFF' || v === '休';
                return \`<div class="slot \${isOff ? 'off' : ''}"><label>\${day}</label><span>\${v}</span></div>\`;
              }).join('')}
            </div>
            \${item.note ? \`<div class="note">\${item.note}</div>\` : ''}
          </div>
        \`;
      });

      htmlContent += \`</div>\`;
      htmlContent += \`<div class="footer">\${selectedData.length} records exported</div>\`;
      htmlContent += \`</div>\`;
    }

    htmlContent += \`
      </body>
      </html>
    \`;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    
    setTimeout(() => {
      printWindow.print();
    }, 500);
  },
  _injectTimelineStyles: function() {
    if (document.getElementById('tl-unified-styles')) return;

    const s = document.createElement('style');
    s.id = 'tl-unified-styles';
    s.innerHTML = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.35s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .tl-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
      }

      .tl-top-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .tl-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .tl-brand p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
      }

      .tl-header-actions {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
      }

      .btn-primary-fab {
        padding: 10px 20px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        border: none;
        background: var(--primary);
        color: white;
        box-shadow: var(--shadow-primary);
      }

      .btn-primary-fab:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-primary-fab:active {
        transform: translateY(0);
      }

      .btn-pdf-modern {
        padding: 10px 18px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }

      .btn-pdf-modern:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .tl-attendance-panel,
      .tl-attendance-board-panel {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-sm);
      }

      .tl-panel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 18px;
        gap: 12px;
        flex-wrap: wrap;
      }

      .tl-panel-header h3 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
      }

      .tl-panel-header p {
        margin: 4px 0 0;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .tl-company-select-wrap {
        margin-bottom: 18px;
        max-width: 340px;
      }

      .tl-company-select-wrap label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .tl-company-select-wrap select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        font-weight: 500;
        background: var(--surface);
        color: var(--text);
        outline: none;
        transition: all var(--transition-fast);
      }

      .tl-company-select-wrap select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-att-btn-group {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
      }

      .btn-action-att {
        padding: 9px 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        border: none;
        color: white;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-xs);
      }

      .btn-action-att:hover {
        transform: translateY(-1px);
        box-shadow: var(--shadow-sm);
      }

      .btn-action-att:active {
        transform: translateY(0);
      }

      .btn-action-att.att-in,
      .btn-action-att.att-end {
        background: var(--primary);
      }

      .btn-action-att.att-in:hover,
      .btn-action-att.att-end:hover {
        background: var(--primary-dark);
      }

      .btn-action-att.att-break {
        background: var(--text-secondary);
      }

      .btn-action-att.att-break:hover {
        background: var(--text);
      }

      .btn-action-att.att-out {
        background: var(--danger);
      }

      .tl-att-status-grid {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .tl-att-status-grid strong {
        color: var(--text);
        font-weight: 600;
      }

      .tl-att-status-grid span {
        color: var(--primary);
        font-weight: 600;
      }

      .attendance-table-scroll-wrapper {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .att-horizontal-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        font-size: 13px;
        text-align: left;
        min-width: 780px;
      }

      .att-horizontal-table th {
        background: var(--surface-soft);
        color: var(--text-secondary);
        font-weight: 600;
        padding: 12px 16px;
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
        font-size: 12px;
      }

      .att-horizontal-table td {
        padding: 13px 16px;
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
        background: var(--surface);
      }

      .att-horizontal-table tr:hover td {
        background: var(--surface-soft);
      }

      .td-bold {
        font-weight: 700;
        color: var(--text);
      }

      .td-primary {
        font-weight: 600;
        color: var(--primary);
      }

      .td-secondary {
        color: var(--text-secondary);
      }

      .btn-table-edit {
        background: var(--primary-soft);
        color: var(--primary);
        border: 1px dashed var(--primary);
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
      }

      .btn-table-edit:hover {
        background: var(--primary);
        color: white;
      }

      .tl-search-section {
        margin-bottom: 24px;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: center;
      }

      .tl-search-wrapper {
        position: relative;
        flex: 1;
        min-width: 240px;
        max-width: 450px;
      }

      .tl-search-wrapper svg {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-dim);
        pointer-events: none;
      }

      .tl-search-wrapper input {
        width: 100%;
        padding: 10px 16px 10px 42px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        box-shadow: var(--shadow-xs);
        color: var(--text);
      }

      .tl-search-wrapper input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-filter-controls {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .filter-type-toggle select,
      .filter-input-wrap input,
      .tl-month-picker {
        height: 42px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        background: var(--surface);
        padding: 0 14px;
        font-weight: 500;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text);
        outline: none;
        box-shadow: var(--shadow-xs);
      }

      .filter-type-toggle select:focus,
      .filter-input-wrap input:focus,
      .tl-month-picker:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-selection-controls {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-bottom: 20px;
        padding: 12px 18px;
        background: var(--surface);
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        flex-wrap: wrap;
        box-shadow: var(--shadow-xs);
      }

      .tl-checkbox-label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        color: var(--text-secondary);
      }

      .tl-checkbox-label input[type="checkbox"] {
        width: 17px;
        height: 17px;
        cursor: pointer;
        accent-color: var(--primary);
      }

      .tl-selection-count {
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 500;
      }

      .btn-clear-selection {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        padding: 6px 12px;
        border-radius: var(--radius-sm);
        transition: all var(--transition-fast);
      }

      .btn-clear-selection:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .tl-list-grid {
        display: grid;
        gap: 20px;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      }

      .tl-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-sm);
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }

      .tl-card-item:hover {
        transform: translateY(-3px);
        border-color: var(--primary-light);
        box-shadow: var(--shadow-md);
      }

      .tl-card-item.selected {
        border-color: var(--primary);
        background: var(--primary-soft);
      }

      .tl-card-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }

      .tl-card-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .tl-item-checkbox {
        width: 17px;
        height: 17px;
        cursor: pointer;
        accent-color: var(--primary);
      }

      .tl-date-badge {
        display: inline-block;
        font-family: monospace;
        font-size: 11px;
        font-weight: 600;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 3px 8px;
        border-radius: var(--radius-sm);
      }

      .edit-icon {
        color: var(--text-dim);
        transition: all var(--transition-fast);
        cursor: pointer;
        padding: 4px;
        border-radius: var(--radius-xs);
      }

      .edit-icon:hover {
        color: var(--primary);
        background: var(--primary-soft);
      }

      .tl-staff-title {
        margin: 0 0 14px;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        letter-spacing: -0.01em;
      }

      .tl-schedule-display {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 6px;
        margin-bottom: 10px;
      }

      .display-slot {
        background: var(--surface-soft);
        padding: 7px 4px;
        border-radius: var(--radius-sm);
        text-align: center;
        border: 1px solid var(--border);
      }

      .display-slot label {
        display: block;
        font-size: 10px;
        color: var(--text-secondary);
        font-weight: 700;
        margin-bottom: 3px;
        text-transform: uppercase;
      }

      .display-slot span {
        font-size: 12px;
        font-weight: 600;
        color: var(--text);
      }

      .display-slot.is-off {
        background: var(--red-soft);
        border-color: rgba(239, 68, 68, 0.25);
      }

      .display-slot.is-off span {
        color: var(--danger);
      }

      .tl-card-note {
        margin-top: 10px;
        font-size: 12px;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 8px 12px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 500;
        border: 1px solid var(--border);
      }

      .tl-modal-overlay {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: scale(0.99);
        transition: visibility 0.2s ease, opacity 0.2s ease, transform 0.2s ease;
        display: flex;
        flex-direction: column;
      }

      .tl-modal-overlay.active {
        visibility: visible;
        opacity: 1;
        transform: scale(1);
      }

      .tl-modal-container {
        height: 100vh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .tl-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
        gap: 12px;
        flex-wrap: wrap;
      }

      .header-left {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .header-right {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .btn-back-icon {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }

      .btn-back-icon:hover {
        background: var(--border);
        color: var(--text);
      }

      .title-group h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .tl-modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 32px 24px;
      }

      .tl-editor-layout {
        max-width: 960px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        gap: 24px;
      }

      .tl-editor-single {
        max-width: 900px;
        margin: 0 auto;
      }

      .comp-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 20px;
      }

      .tl-editor-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        margin-bottom: 16px;
        box-shadow: var(--shadow-xs);
      }

      .card-title {
        margin: 0;
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
      }

      .input-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .input-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .input-field input,
      .input-field textarea,
      .input-field select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        outline: none;
        transition: all var(--transition-fast);
        background: var(--surface);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .input-field input:focus,
      .input-field textarea:focus,
      .input-field select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-card-header {
        display: flex;
        gap: 12px;
        align-items: flex-end;
        margin-bottom: 18px;
      }

      .btn-remove-row {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        padding: 0 14px;
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        color: var(--danger);
        transition: all var(--transition-fast);
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }

      .btn-remove-row:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .tl-days-grid-editor {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 10px;
        margin-bottom: 18px;
      }

      .day-input-box label {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        display: block;
        text-align: center;
        margin-bottom: 5px;
      }

      .day-input-box input {
        width: 100%;
        text-align: center;
        height: 40px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 13px;
        background: var(--surface);
        color: var(--text);
        transition: all var(--transition-fast);
        outline: none;
      }

      .day-input-box input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-note-editor {
        margin-top: 14px;
        border-top: 1px solid var(--border);
        padding-top: 16px;
      }

      .tl-note-editor label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        margin-bottom: 6px;
      }

      .sch-note-input {
        width: 100%;
        min-height: 76px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 10px 14px;
        font-size: 14px;
        resize: vertical;
        font-family: var(--font-sans);
        color: var(--text);
        background: var(--surface);
        outline: none;
        transition: all var(--transition-fast);
      }

      .sch-note-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .tl-modal-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 16px 28px;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
      }

      .footer-inner {
        max-width: 960px;
        margin: 0 auto;
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
      }

      .footer-main-btns {
        display: flex;
        gap: 12px;
        justify-content: flex-end;
      }

      .btn-save-final {
        background: var(--primary);
        color: white;
        border: none;
        padding: 10px 26px;
        border-radius: var(--radius-md);
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-base);
        font-size: 14px;
        box-shadow: var(--shadow-primary);
      }

      .btn-save-final:hover {
        background: var(--primary-dark);
      }

      .btn-save-final:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .btn-cancel {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        padding: 10px 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }

      .btn-cancel:hover {
        background: var(--border);
        color: var(--text);
      }

      .btn-danger-outline {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        padding: 10px 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
      }

      .btn-danger-outline:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .btn-add-item {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        font-weight: 600;
        padding: 6px 14px;
        border-radius: var(--radius-sm);
        cursor: pointer;
        transition: all var(--transition-fast);
        font-size: 12px;
      }

      .btn-add-item:hover {
        background: var(--primary);
        color: white;
      }

      .tl-empty,
      .tl-loading {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .section-header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 14px;
      }

      @media (min-width: 1024px) {
        .tl-editor-layout {
          display: grid;
          grid-template-columns: 280px 1fr;
          gap: 24px;
          align-items: start;
        }
      }

      @media (max-width: 768px) {
        .tl-app-wrapper {
          padding: 16px;
        }
        .tl-top-nav {
          flex-direction: column;
          align-items: stretch;
        }
        .tl-header-actions {
          width: 100%;
        }
        .tl-header-actions button {
          flex: 1;
        }
        .tl-attendance-panel,
        .tl-attendance-board-panel {
          padding: 18px;
        }
        .tl-company-select-wrap {
          max-width: 100%;
        }
        .tl-schedule-display {
          grid-template-columns: repeat(4, 1fr);
        }
        .tl-days-grid-editor {
          grid-template-columns: repeat(2, 1fr);
        }
        .tl-modal-header {
          padding: 14px 16px;
        }
        .tl-modal-body {
          padding: 20px 14px;
        }
        .tl-modal-footer {
          padding: 14px 16px;
        }
        .footer-inner {
          flex-direction: column-reverse;
          align-items: stretch;
        }
        .footer-main-btns {
          flex-direction: column-reverse;
          width: 100%;
        }
        .btn-save-final,
        .btn-cancel,
        .btn-danger-outline {
          width: 100%;
          text-align: center;
          justify-content: center;
        }
        .tl-search-wrapper {
          max-width: 100%;
        }
      }

      @media (max-width: 480px) {
        .tl-schedule-display {
          grid-template-columns: repeat(2, 1fr);
        }
        .tl-filter-controls {
          width: 100%;
        }
        .filter-type-toggle,
        .filter-input-wrap {
          flex: 1;
        }
        .filter-type-toggle select,
        .filter-input-wrap input {
          width: 100%;
        }
      }
    \`;
    document.head.appendChild(s);
  }
};

window.TimelineModule = TimelineModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*53)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

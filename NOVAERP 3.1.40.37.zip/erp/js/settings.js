(function(){
const _k=[0x5c,0xa3,0x19,0xe7,0x4b,0x8d,0x2f,0xc1,0x76,0xb2,0x38,0xf4,0x61,0x9a,0x14,0xd9,0x53,0x87,0x2e,0xe0,0x69,0xa8,0x31,0xc6];
const _s=`const SettingsModule = {
  _monitorIntervalId: null,
  _isChecking: false,
  render: async function(containerId) {
    const deploymentStr = localStorage.getItem('ERP_DEPLOYMENT_DATA') || '{}';
    const deployment = JSON.parse(deploymentStr);
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const cloneCode = btoa(unescape(encodeURIComponent(deploymentStr)));
    const container = document.getElementById(containerId);
    if (!container) return;

    const styleId = 'settings-module-styles';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = \`
        :root {
          --primary: #4f46e5;
          --primary-dark: #4338ca;
          --primary-light: #6366f1;
          --primary-soft: rgba(79, 70, 229, 0.08);
          --primary-glow: rgba(79, 70, 229, 0.2);
          --bg: #f8fafc;
          --surface: #ffffff;
          --surface-soft: #f8fafc;
          --text: #0f172a;
          --text-secondary: #475569;
          --text-dim: #94a3b8;
          --border: #e2e8f0;
          --border-strong: #cbd5e1;
          --danger: #ef4444;
          --red-soft: rgba(239, 68, 68, 0.08);
          --green: #10b981;
          --green-soft: rgba(16, 185, 129, 0.08);
          --radius-card: 16px;
          --radius-lg: 14px;
          --radius-md: 10px;
          --radius-sm: 8px;
          --radius-xs: 6px;
          --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
          --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
          --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
          --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
          --transition-fast: 0.15s ease;
          --transition-base: 0.25s ease;
          --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        }
        * {
          box-sizing: border-box;
          -webkit-tap-highlight-color: transparent;
        }
        .settings-wrapper {
          max-width: 1400px;
          margin: 0 auto;
          padding: 24px;
          font-family: var(--font-sans);
          background: var(--bg);
          min-height: 100vh;
          color: var(--text);
          -webkit-font-smoothing: antialiased;
          width: 100%;
        }
        .settings-header {
          margin-bottom: 24px;
          text-align: left;
        }
        .settings-header h2 {
          margin: 0;
          font-size: 26px;
          font-weight: 700;
          letter-spacing: -0.025em;
          color: var(--text);
        }
        .settings-header p {
          margin: 6px 0 0 0;
          font-size: 13px;
          color: var(--text-secondary);
          font-weight: 500;
        }
        .settings-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
          gap: 20px;
        }
        .settings-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 22px;
          display: flex;
          flex-direction: column;
          transition: transform var(--transition-base), box-shadow var(--transition-base), border-color var(--transition-base);
          box-shadow: var(--shadow-sm);
        }
        .settings-card:hover {
          transform: translateY(-2px);
          border-color: var(--primary-light);
          box-shadow: var(--shadow-md);
        }
        .settings-card h3 {
          margin: 0 0 18px 0;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.05em;
          color: var(--text-secondary);
          text-transform: uppercase;
        }
        .setting-item {
          margin-bottom: 18px;
        }
        .setting-label {
          display: block;
          font-size: 11px;
          font-weight: 600;
          color: var(--text-secondary);
          margin-bottom: 6px;
        }
        .setting-value-box {
          padding: 10px 14px;
          background: var(--surface-soft);
          border-radius: var(--radius-md);
          font-family: monospace;
          font-size: 13px;
          color: var(--text);
          word-break: break-all;
          border: 1px solid var(--border);
        }
        .clone-box {
          background: var(--red-soft);
          border: 1px solid var(--border);
          padding: 12px 14px;
          border-radius: var(--radius-md);
          font-size: 12px;
          color: var(--danger);
          word-break: break-all;
          font-family: monospace;
          max-height: 110px;
          overflow-y: auto;
          margin-bottom: 18px;
          line-height: 1.5;
        }
        .device-list {
          margin-bottom: 20px;
          flex-grow: 1;
        }
        .device-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 14px;
          background: var(--surface-soft);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          margin-bottom: 10px;
          gap: 10px;
          transition: all var(--transition-fast);
        }
        .device-item:last-child {
          margin-bottom: 0;
        }
        .device-item:hover {
          border-color: var(--border-strong);
        }
        .badge-me {
          background: var(--primary-soft);
          color: var(--primary);
          font-size: 10px;
          padding: 2px 8px;
          border-radius: var(--radius-sm);
          margin-left: 6px;
          font-weight: 700;
          display: inline-block;
        }
        .status-active {
          color: var(--green);
          background: var(--green-soft);
          padding: 4px 10px;
          border-radius: var(--radius-sm);
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
        }
        .status-inactive {
          color: var(--text-dim);
          font-size: 11px;
          font-weight: 500;
          white-space: nowrap;
        }
        .btn-action {
          width: 100%;
          height: 40px;
          padding: 0 18px;
          border-radius: var(--radius-md);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all var(--transition-fast);
          border: 1px solid transparent;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-family: var(--font-sans);
        }
        .btn-action:hover {
          transform: translateY(-1px);
        }
        .btn-action:active {
          transform: translateY(0);
        }
        .btn-secondary {
          background: var(--surface);
          color: var(--text-secondary);
          border: 1px solid var(--border);
          box-shadow: var(--shadow-xs);
        }
        .btn-secondary:hover {
          background: var(--surface-soft);
          border-color: var(--border-strong);
          color: var(--text);
        }
        .btn-copy-clone {
          background: var(--primary);
          color: white;
          box-shadow: var(--shadow-primary);
        }
        .btn-copy-clone:hover {
          background: var(--primary-dark);
        }
        .btn-danger {
          background: var(--surface);
          color: var(--danger);
          border: 1px solid var(--border);
          margin-top: 10px;
        }
        .btn-danger:hover {
          background: var(--red-soft);
          border-color: var(--danger);
        }
        .btn-critical {
          background: var(--danger);
          color: white;
          border: 1px solid transparent;
          margin-top: 10px;
        }
        .btn-critical:hover {
          opacity: 0.92;
        }
        .user-profile-box {
          background: var(--surface-soft);
          padding: 16px;
          border-radius: var(--radius-md);
          border: 1px solid var(--border);
          margin-bottom: 18px;
        }
        @media (max-width: 1024px) {
          .settings-grid {
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          }
        }
        @media (max-width: 768px) {
          .settings-wrapper {
            padding: 16px;
          }
          .settings-header {
            margin-bottom: 20px;
          }
          .settings-grid {
            grid-template-columns: 1fr;
            gap: 16px;
          }
          .settings-card {
            padding: 18px;
            border-radius: var(--radius-lg);
          }
        }
      \`;
      document.head.appendChild(style);
    }

    container.innerHTML = \`
      <div class="settings-wrapper">
        <div class="settings-header">
          <h2>System Settings</h2>
          <p></p>
        </div>
        <div class="settings-grid">
          <div class="settings-card">
            <h3 style="color: var(--primary);">Device Cloning</h3>
            <div class="setting-item">
              <label class="setting-label">Fast Deployment Access Code</label>
              <div class="clone-box" id="clone-code-text">\${cloneCode}</div>
            </div>
            <button onclick="SettingsModule.copyCloneCode()" class="btn-action btn-copy-clone">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
              Copy Access Code
            </button>
            <div style="margin-top: 14px; font-size: 11px; color: var(--text-dim); text-align: center; line-height: 1.4;">
              Keep this code private. It contains your cloud credentials.
            </div>
          </div>
          <div class="settings-card">
            <h3>Cloud Storage</h3>
            <div class="setting-item">
              <label class="setting-label">Data Repository</label>
              <div class="setting-value-box">\${deployment.ghRepo || "Connection Pending"}</div>
            </div>
            <div class="setting-item">
              <label class="setting-label">Security Token</label>
              <div class="setting-value-box">
                SHA256-••••••\${(deployment.ghToken || "").slice(-6)}
              </div>
            </div>
            <div style="margin-top: auto; padding-top: 16px; border-top: 1px solid var(--border);">
              <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin: 0;">
                System data is synchronized via secure API tunneling.
              </p>
            </div>
          </div>
          <div class="settings-card">
            <h3>Authorized Devices</h3>
            <div id="device-list-container" class="device-list">
              <p style="font-size:13px; color:var(--text-dim); text-align:center; padding: 32px 12px; margin:0;">Synchronizing device list...</p>
            </div>
            <button onclick="SettingsModule.logoutOthers()" class="btn-action btn-secondary">
              Revoke Other Sessions
            </button>
          </div>
          <div class="settings-card">
            <h3>Session Control</h3>
            <div class="user-profile-box">
              <label class="setting-label">Active Operator</label>
              <div style="font-size: 20px; font-weight: 700; color: var(--text); letter-spacing: -0.02em;">\${config.staff || "Guest"}</div>
              <div style="font-size: 12px; color: var(--text-secondary); margin-top: 4px; font-weight: 500;">
                \${config.role || "Unassigned Role"}
              </div>
            </div>
            <div class="setting-item">
              <label class="setting-label">Unique Instance ID</label>
              <div class="setting-value-box" style="background:transparent; border-style:dashed; color:var(--text-secondary);">
                \${config.deviceId || "System-Generated"}
              </div>
            </div>
            <div style="margin-top: auto;">
              <button onclick="SettingsModule.clearDeployment()" class="btn-action btn-danger">
                Disconnect Instance
              </button>
              <button onclick="SettingsModule.deleteFullDatabase()" class="btn-action btn-critical">
                DELETE ENTIRE DATABASE
              </button>
            </div>
          </div>
        </div>
      </div>
    \`;

    const listContainer = document.getElementById("device-list-container");
    try {
      const res = await fetch(
        \`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/login.js\`,
        {
          headers: {
            Authorization: \`token \${deployment.ghToken}\`,
          },
          cache: "no-store",
        }
      );
      if (res.ok) {
        const data = await res.json();
        const content = atob(data.content);
        const sessions = JSON.parse(content.match(/\\[.*\\]/s)[0]);
        listContainer.innerHTML = sessions
          .map((dev) => {
            const isMe = dev.id === config.deviceId;
            return \`
              <div class="device-item">
                <div style="min-width:0; flex:1;">
                  <div style="font-size:13px; font-weight:700; color:\${
                    dev.active ? "var(--text)" : "var(--text-dim)"
                  }; word-break:break-word;">
                    \${dev.name} \${
              isMe ? '<span class="badge-me">CURRENT</span>' : ""
            }
                  </div>
                  <div style="font-size:11px; color:var(--text-secondary); margin-top:3px;">Last Login: \${
                    dev.lastLogin || "N/A"
                  }</div>
                </div>
                <div>
                  \${
                    dev.active
                      ? isMe
                        ? '<span class="status-active">Active</span>'
                        : \`<button onclick="SettingsModule.logoutDevice('\${dev.id}')" style="height:30px; font-size:11px; padding:0 12px; border:1px solid var(--border); color:var(--danger); background:var(--surface); border-radius:var(--radius-sm); cursor:pointer; font-weight:600;">Revoke</button>\`
                      : '<span class="status-inactive">Disconnected</span>'
                  }
                </div>
              </div>
            \`;
          })
          .join("");
      }
    } catch (e) {
      if (listContainer)
        listContainer.innerHTML =
          '<div style="padding:32px 12px; text-align:center; color:var(--danger); font-size:13px; font-weight:600;">System synchronization failed.</div>';
    }
    this.startSessionMonitor();
  },
  startSessionMonitor: function() {
    if (this._monitorIntervalId !== null) return;
    this.checkCurrentSessionStatus();
    this._monitorIntervalId = setInterval(() => {
      this.checkCurrentSessionStatus();
    }, 30000);
  },
  stopSessionMonitor: function() {
    if (this._monitorIntervalId !== null) {
      clearInterval(this._monitorIntervalId);
      this._monitorIntervalId = null;
    }
  },
  checkCurrentSessionStatus: async function() {
    if (this._isChecking) return;
    this._isChecking = true;
    try {
      const config = JSON.parse(localStorage.getItem("ERP_CONFIG") || "{}");
      const deployment = JSON.parse(
        localStorage.getItem("ERP_DEPLOYMENT_DATA") || "{}"
      );
      if (!config.deviceId || !deployment.ghRepo || !deployment.ghToken) {
        this.stopSessionMonitor();
        return;
      }
      const url = \`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/login.js\`;
      const response = await fetch(url, {
        headers: {
          Authorization: \`token \${deployment.ghToken}\`,
        },
        cache: "no-store",
      });
      if (!response.ok) {
        console.warn("Session status check failed:", response.status);
        return;
      }
      const data = await response.json();
      const content = atob(data.content);
      const sessionsMatch = content.match(/\\[.*\\]/s);
      if (!sessionsMatch) return;
      const sessions = JSON.parse(sessionsMatch[0]);
      const currentDevice = sessions.find(
        (device) => device.id === config.deviceId
      );
      if (currentDevice && currentDevice.active === false) {
        console.log("Device has been remotely revoked, performing auto-logout");
        this.forceRedirect();
      }
    } catch (error) {
      console.error("Session status check error:", error);
    } finally {
      this._isChecking = false;
    }
  },
  deleteFullDatabase: async function() {
    const password = prompt(
      "Please enter the administrator password to confirm total database deletion:"
    );
    if (password !== "ADMIN_SECRET_KEY") {
      alert("Incorrect password. Operation cancelled.");
      return;
    }
    if (
      !confirm(
        "WARNING: This operation will permanently delete all cloud data and cannot be recovered. Are you sure you want to continue?"
      )
    )
      return;

    const deployment = JSON.parse(
      localStorage.getItem("ERP_DEPLOYMENT_DATA") || "{}"
    );
    const url = \`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/database.json\`;
    const headers = {
      Authorization: \`token \${deployment.ghToken}\`,
      "Content-Type": "application/json",
    };

    try {
      const res = await fetch(url, { headers, cache: "no-store" });
      if (!res.ok) {
        throw new Error("Unable to connect to the repository database.");
      }
      const data = await res.json();

      const deleteRes = await fetch(url, {
        method: "DELETE",
        headers,
        body: JSON.stringify({
          message: "Critical: Full database deletion by admin",
          sha: data.sha,
        }),
      });

      if (!deleteRes.ok) {
        throw new Error("Delete operation failed with status: " + deleteRes.status);
      }

      alert("Database deleted. The system will now reset.");
      this.forceRedirect();
    } catch (e) {
      alert("Deletion failed: " + e.message);
    }
  },
  copyCloneCode: function() {
    const text = document.getElementById("clone-code-text").innerText;
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert("Clone Access Code copied to clipboard!");
      })
      .catch((err) => {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        alert("Clone Access Code copied!");
      });
  },
  logoutDevice: async function(targetId) {
    if (
      !confirm(
        "Are you sure you want to revoke access for this device? It will be forced to log in again."
      )
    )
      return;
    const deployment = JSON.parse(
      localStorage.getItem("ERP_DEPLOYMENT_DATA") || "{}"
    );
    const url = \`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/login.js\`;
    const headers = {
      Authorization: \`token \${deployment.ghToken}\`,
      "Content-Type": "application/json",
    };
    try {
      const res = await fetch(url, { headers, cache: "no-store" });
      const data = await res.json();
      let sessions = JSON.parse(atob(data.content).match(/\\[.*\\]/s)[0]);
      sessions = sessions.map((s) =>
        s.id === targetId ? { ...s, active: false } : s
      );
      const newContent = \`var _DEVICE_SESSIONS = \${JSON.stringify(
        sessions,
        null,
        2
      )};\`;
      await fetch(url, {
        method: "PUT",
        headers,
        body: JSON.stringify({
          message: \`Security: Revoke device \${targetId}\`,
          content: btoa(unescape(encodeURIComponent(newContent))),
          sha: data.sha,
        }),
      });
      this.render("module-container");
    } catch (e) {
      alert("Action failed: " + e.message);
    }
  },
  logoutOthers: async function() {
    if (
      !confirm(
        "Sign out all other active sessions? Only this device will remain connected."
      )
    )
      return;
    const config = JSON.parse(localStorage.getItem("ERP_CONFIG") || "{}");
    const deployment = JSON.parse(
      localStorage.getItem("ERP_DEPLOYMENT_DATA") || "{}"
    );
    const url = \`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/login.js\`;
    const headers = {
      Authorization: \`token \${deployment.ghToken}\`,
      "Content-Type": "application/json",
    };
    try {
      const res = await fetch(url, { headers, cache: "no-store" });
      const data = await res.json();
      let sessions = JSON.parse(atob(data.content).match(/\\[.*\\]/s)[0]);
      sessions = sessions.map((s) =>
        s.id === config.deviceId ? s : { ...s, active: false }
      );
      const newContent = \`var _DEVICE_SESSIONS = \${JSON.stringify(
        sessions,
        null,
        2
      )};\`;
      await fetch(url, {
        method: "PUT",
        headers,
        body: JSON.stringify({
          message: "Security: Bulk session termination",
          content: btoa(unescape(encodeURIComponent(newContent))),
          sha: data.sha,
        }),
      });
      this.render("module-container");
    } catch (e) {
      alert("Logout failed: " + e.message);
    }
  },
  forceRedirect: function() {
    this.stopSessionMonitor();
    localStorage.clear();
    window.location.href = "login.html";
  },
  clearDeployment: function() {
    if (
      confirm(
        "DANGER: This will disconnect this device and erase all security tokens. All local configurations will be lost. Continue?"
      )
    ) {
      this.forceRedirect();
    }
  },
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () =>
    SettingsModule.startSessionMonitor()
  );
} else {
  SettingsModule.startSessionMonitor();
}

window.SettingsModule = SettingsModule;`;
const _e=(()=>{
  const u=new TextEncoder().encode(_s);
  const a=[];
  for(let i=0;i<u.length;i++){
    a.push(u[i]^_k[i%_k.length]^((i*29+13)&0xff));
  }
  return a;
})();
function _d(a){
  const u=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    u[i]=a[i]^_k[i%_k.length]^((i*29+13)&0xff);
  }
  return new TextDecoder().decode(u);
}
const _f=new Function(_d(_e));
_f();
})();

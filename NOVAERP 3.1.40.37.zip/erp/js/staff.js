(function(){
const _k=[0x5c,0x23,0x9b,0x47,0xd1,0x68,0x3f,0x8a,0xe4,0x16,0xb2,0x79,0xc5,0x0e,0x6d,0xf3];
function _d(a){
const b=new Uint8Array(a.length);
for(let i=0;i<a.length;i++){
b[i]=a[i]^_k[i%_k.length]^((i*73)&0xff);
}
return new TextDecoder().decode(b);
}
const _s=`const StaffModule = {
  _data: [],
  _sha: '',
  _searchQuery: '',
  _currentPage: 1,
  _itemsPerPage: 12,
  _isAdmin: function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    return config.role === 'admin';
  },
  render: async function(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const isAdmin = this._isAdmin();

    const style = document.createElement('style');
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }
      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }
      .staff-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        color: var(--text);
        background: var(--bg);
        min-height: 100vh;
        -webkit-font-smoothing: antialiased;
        width: 100%;
      }
      .staff-header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }
      .header-title h2 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }
      .sync-indicator {
        font-size: 12px;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 6px;
        font-weight: 500;
      }
      .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--text-dim);
        flex-shrink: 0;
      }
      .dot.online {
        background: var(--green);
      }
      .search-container {
        position: relative;
        flex: 1;
        max-width: 340px;
        min-width: 200px;
      }
      .search-input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        background: var(--surface);
        font-size: 14px;
        color: var(--text);
        transition: all var(--transition-fast);
        outline: none;
        box-shadow: var(--shadow-xs);
        font-family: var(--font-sans);
      }
      .search-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }
      .btn {
        height: 40px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        border: 1px solid transparent;
        white-space: nowrap;
        font-family: var(--font-sans);
      }
      .btn:hover {
        transform: translateY(-1px);
      }
      .btn:active {
        transform: translateY(0);
      }
      .btn-main {
        background: var(--primary);
        color: white;
        box-shadow: var(--shadow-primary);
      }
      .btn-main:hover {
        background: var(--primary-dark);
      }
      .btn-sec {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }
      .btn-sec:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }
      .btn-danger {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
      }
      .btn-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }
      .staff-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
      }
      .staff-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        transition: all var(--transition-base);
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 14px;
        box-shadow: var(--shadow-sm);
      }
      .staff-card:hover {
        transform: translateY(-2px);
        border-color: var(--primary-light);
        box-shadow: var(--shadow-md);
      }
      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 10px;
      }
      .id-tag {
        font-family: monospace;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 3px 8px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
        display: inline-block;
      }
      .staff-name {
        font-size: 17px;
        font-weight: 700;
        margin-top: 8px;
        color: var(--text);
        line-height: 1.3;
        word-break: break-word;
      }
      .staff-pos {
        font-size: 11px;
        font-weight: 600;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        white-space: nowrap;
        flex-shrink: 0;
      }
      .card-body {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px;
        margin-top: 4px;
        padding-top: 12px;
        border-top: 1px solid var(--border);
      }
      .label-sm {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        display: block;
        margin-bottom: 4px;
      }
      .val-sm {
        font-size: 14px;
        font-weight: 600;
        color: var(--text);
        word-break: break-word;
      }
      #staff-editor-modal {
        display: none;
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        animation: fadeInModal 0.2s ease;
      }
      @keyframes fadeInModal {
        from { opacity: 0; transform: scale(0.99); }
        to { opacity: 1; transform: scale(1); }
      }
      .modal-box-wrapper {
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        background: var(--bg);
        display: flex;
        flex-direction: column;
      }
      .editor-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
      }
      .editor-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }
      .modal-back-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }
      .modal-back-btn:hover {
        background: var(--border);
        color: var(--text);
      }
      .editor-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }
      .editor-content {
        flex: 1;
        overflow-y: auto;
        padding: 32px 20px;
      }
      .editor-form-inner {
        max-width: 900px;
        width: 100%;
        margin: 0 auto;
      }
      .form-group {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
      }
      .group-title {
        font-size: 14px;
        font-weight: 700;
        margin-bottom: 20px;
        color: var(--text);
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .group-title svg {
        width: 18px;
        height: 18px;
        stroke: var(--primary);
        flex-shrink: 0;
      }
      .input-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
      }
      .field-box label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 6px;
        color: var(--text-secondary);
      }
      .staff-input, .staff-select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        outline: none;
        background: var(--surface);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
        color: var(--text);
      }
      .staff-select {
        height: 42px;
        cursor: pointer;
      }
      .staff-input:focus, .staff-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }
      .sub-card {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 18px;
        margin-bottom: 14px;
        position: relative;
      }
      .sub-card:last-child {
        margin-bottom: 0;
      }
      .btn-remove {
        position: absolute;
        top: 14px;
        right: 14px;
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        cursor: pointer;
        padding: 6px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
      }
      .btn-remove:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }
      .editor-actions {
        background: var(--surface);
        padding: 16px 28px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
        flex-wrap: wrap;
      }
      .pagination {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 32px;
        flex-wrap: wrap;
      }
      .page-node {
        min-width: 38px;
        height: 38px;
        padding: 0 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        background: var(--surface);
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }
      .page-node.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }
      .page-node:hover:not(.active) {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }
      @media (max-width: 1024px) {
        .staff-grid {
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        }
      }
      @media (max-width: 768px) {
        .staff-wrapper {
          padding: 16px;
        }
        .input-grid {
          grid-template-columns: 1fr;
          gap: 14px;
        }
        .field-box[style*="grid-column: span 2"] {
          grid-column: span 1 !important;
        }
        .staff-header-flex {
          flex-direction: column;
          align-items: stretch;
          gap: 14px;
          margin-bottom: 20px;
        }
        .search-container {
          max-width: 100%;
        }
        .staff-grid {
          grid-template-columns: 1fr;
          gap: 14px;
        }
        .editor-header {
          padding: 14px 16px;
        }
        .editor-content {
          padding: 20px 14px;
        }
        .editor-actions {
          padding: 14px 16px;
          flex-direction: column-reverse;
          align-items: stretch;
        }
        .editor-actions button {
          width: 100%;
          margin-right: 0 !important;
        }
        .form-group {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .sub-card {
          padding: 14px;
        }
      }
    \`;
    document.head.appendChild(style);

    container.innerHTML = \`
      <div class="staff-wrapper">
        <div class="staff-header-flex">
          <div class="header-title">
            <h2>Staff Directory</h2>
            
          </div>
          <div class="search-container">
            <input type="text" class="search-input" placeholder="Search by name, position or ID..." oninput="StaffModule.handleSearch(this.value)">
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-sec" onclick="StaffModule.loadFromCloud()">Refresh</button>
            <button class="btn btn-main" id="staff-add-btn" style="display:\${isAdmin ? 'inline-flex' : 'none'};" onclick="StaffModule.openEditor()">Add Staff</button>
          </div>
        </div>
        <div id="staff-list-container" class="staff-grid"></div>
        <div id="staff-pagination" class="pagination"></div>
      </div>

      <div id="staff-editor-modal">
        <div class="modal-box-wrapper">
          <div class="editor-header">
            <div class="editor-header-left">
              <button class="modal-back-btn" onclick="StaffModule.closeEditor()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3 id="staff-form-title">Profile Details</h3>
            </div>
            <button class="btn btn-sec" onclick="StaffModule.closeEditor()">Exit</button>
          </div>
          <form id="staff-form" onsubmit="StaffModule.saveData(event)" style="display:flex; flex-direction:column; flex:1; min-height:0;">
            <div class="editor-content">
              <div class="editor-form-inner">
                <div class="form-group">
                  <div class="group-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    Personal Identity
                  </div>
                  <div class="input-grid">
                    <div class="field-box"><label>Full Name</label><input type="text" name="staffName" required class="staff-input"></div>
                    <div class="field-box"><label>Staff ID</label><input type="text" name="staffId" class="staff-input"></div>
                    <div class="field-box">
                      <label>Role / Position</label>
                      <select name="posSelect" class="staff-select" onchange="StaffModule.handleOtherSelect(this, 'pos-other')">
                        <option value="Staff">Staff</option>
                        <option value="Manager">Manager</option>
                        <option value="Intern">Intern</option>
                        <option value="Other">Other Category</option>
                      </select>
                      <input type="text" id="pos-other" name="position" class="staff-input" style="display:none; margin-top:10px;" placeholder="Specify role">
                    </div>
                    <div class="field-box"><label>Contact Phone</label><input type="text" name="phone" class="staff-input"></div>
                  </div>
                </div>

                <div class="form-group">
                  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; gap:10px; flex-wrap:wrap;">
                    <div class="group-title" style="margin:0;">
                      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
                      Bank Accounts
                    </div>
                    <button type="button" class="btn btn-sec admin-only-ui" style="height:34px; padding:0 14px; font-size:12px;" onclick="StaffModule.addBankField()">+ Add</button>
                  </div>
                  <div id="bank-list-fields"></div>
                </div>

                <div id="leave-management-section" class="form-group" style="display:none;">
                  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; gap:10px; flex-wrap:wrap;">
                    <div class="group-title" style="margin:0;">
                      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                      Leave Management
                    </div>
                    <button type="button" class="btn btn-main admin-only-ui" style="height:34px; padding:0 14px; font-size:12px;" onclick="StaffModule.addLeaveField()">+ Record</button>
                  </div>
                  <div id="leave-list-fields"></div>
                </div>

                <div id="admin-credentials-section" class="form-group" style="display: none;">
                  <div class="group-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                    Security Access
                  </div>
                  <div class="input-grid">
                    <div class="field-box"><label>Login Email</label><input type="email" name="staffEmail" class="staff-input"></div>
                    <div class="field-box"><label>System Password</label><input type="text" name="staffPassword" class="staff-input"></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="editor-actions">
              <button type="button" id="staff-delete-btn" class="btn btn-danger admin-only-ui" style="display:none; margin-right:auto;">Delete Profile</button>
              <button type="button" class="btn btn-sec" onclick="StaffModule.closeEditor()">Cancel</button>
              <button type="submit" id="staff-save-btn" class="btn btn-main admin-only-ui">Save All Changes</button>
            </div>
          </form>
        </div>
      </div>
    \`;

    await this.loadFromCloud();
  },

  handleOtherSelect: function(select, otherId, initialValue = '') {
    const otherInput = document.getElementById(otherId);
    if (select.value === 'Other') {
      otherInput.style.display = 'block';
      if (initialValue) otherInput.value = initialValue;
      else otherInput.value = '';
    } else {
      otherInput.style.display = 'none';
      otherInput.value = select.value;
    }
  },

  renderList: function() {
    const container = document.getElementById('staff-list-container');
    if (!container) return;

    const indexedData = this._data.map((item, index) => ({
      ...item,
      _originalIndex: index,
      _staffNo: this._data.length - index
    }));

    const filtered = indexedData.filter(s =>
      (s.name || "").toLowerCase().includes(this._searchQuery.toLowerCase()) ||
      (s.position || "").toLowerCase().includes(this._searchQuery.toLowerCase()) ||
      (s.id || "").toLowerCase().includes(this._searchQuery.toLowerCase())
    );

    const totalPages = Math.ceil(filtered.length / this._itemsPerPage) || 1;
    const start = (this._currentPage - 1) * this._itemsPerPage;
    const pagedData = filtered.slice(start, start + this._itemsPerPage);

    container.innerHTML = pagedData.map((s) => \`
      <div class="staff-card" onclick="StaffModule.openEditor(\${s._originalIndex})">
        <div class="card-header">
          <div>
            <div class="id-tag">#\${s.id || s._staffNo}</div>
            <div class="staff-name">\${s.name}</div>
          </div>
          <span class="staff-pos">\${s.position || 'Staff'}</span>
        </div>
        <div class="card-body">
          <div><span class="label-sm">Contact</span><div class="val-sm">\${s.phone || '--'}</div></div>
          <div><span class="label-sm">Leaves</span><div class="val-sm">\${s.leaves?.length || 0} Records</div></div>
        </div>
      </div>
    \`).join('') || '<div style="grid-column:1/-1; text-align:center; padding:60px 20px; color:var(--text-dim); background:var(--surface); border-radius:var(--radius-card); border:1px solid var(--border); font-size:14px;">No records found.</div>';

    this.renderPagination(totalPages);
  },

  renderPagination: function(totalPages) {
    const container = document.getElementById('staff-pagination');
    if (!container || totalPages <= 1) {
      container.innerHTML = '';
      return;
    }

    let html = \`<div class="page-node" onclick="StaffModule.changePage(\${Math.max(1, this._currentPage - 1)})">Prev</div>\`;
    for (let i = 1; i <= totalPages; i++) {
      html += \`<div class="page-node \${i === this._currentPage ? 'active' : ''}" onclick="StaffModule.changePage(\${i})">\${i}</div>\`;
    }
    html += \`<div class="page-node" onclick="StaffModule.changePage(\${Math.min(totalPages, this._currentPage + 1)})">Next</div>\`;
    container.innerHTML = html;
  },

  changePage: function(page) {
    this._currentPage = page;
    this.renderList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  handleSearch: function(val) {
    this._searchQuery = val;
    this._currentPage = 1;
    this.renderList();
  },

  loadFromCloud: async function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const status = document.getElementById('staff-sync-status');

    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this.renderList();
        if (status) status.innerHTML = \`\`;
      }
    } catch (e) {
      if (status) status.innerHTML = \`<span class="dot"></span>Offline Mode\`;
    }
  },

  saveData: async function(e) {
    e.preventDefault();
    if (!this._isAdmin()) {
      alert("Permission Denied: Admin only.");
      return;
    }

    const btn = document.getElementById('staff-save-btn');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Syncing...";

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const form = document.getElementById('staff-form');
    const index = form.dataset.index;
    const isNew = (index === undefined || index === "");

    const banks = Array.from(document.querySelectorAll('.bank-item')).map(item => ({
      bankName: item.querySelector('[name="bankName"]').value,
      accountNo: item.querySelector('[name="accountNo"]').value,
      holder: item.querySelector('[name="holderName"]').value
    }));

    const leaves = Array.from(document.querySelectorAll('.leave-item')).map(item => {
      const select = item.querySelector('.staff-select');
      const otherInput = item.querySelector('.other-input');
      return {
        type: (otherInput && otherInput.style.display === 'block') ? otherInput.value : select.value,
        start: item.querySelector('[name="lStart"]').value,
        end: item.querySelector('[name="lEnd"]').value,
        status: item.querySelector('[name="lStatus"]').value,
        reason: item.querySelector('[name="lReason"]').value
      };
    });

    const staffEntry = {
      id: form.staffId.value,
      name: form.staffName.value,
      position: document.getElementById('pos-other').value || form.posSelect.value,
      phone: form.phone.value,
      email: form.staffEmail?.value || '',
      password: form.staffPassword?.value || '',
      banks: banks,
      leaves: leaves,
      lastModified: new Date().toLocaleString()
    };

    try {
      const infoRes = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json?t=\${Date.now()}\`, {
        headers: {'Authorization': \`token \${config.ghToken}\`},
        cache: 'no-store'
      });

      let updatedList = [];
      let latestSha = this._sha;

      if (infoRes.ok) {
        const infoData = await infoRes.json();
        latestSha = infoData.sha;
        updatedList = JSON.parse(decodeURIComponent(escape(atob(infoData.content))));
      }

      if (!isNew) {
        const idx = parseInt(index);
        if (idx >= 0 && idx < updatedList.length) {
          updatedList[idx] = staffEntry;
        } else {
          updatedList.push(staffEntry);
        }
      } else {
        updatedList.unshift(staffEntry);
      }

      const putRes = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        },
        body: JSON.stringify({
          message: \`Update Staff: \${staffEntry.name}\`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(updatedList, null, 2)))),
          sha: latestSha
        })
      });

      if (putRes.ok) {
        if (typeof LogModule !== 'undefined' && LogModule.addLog) {
          const actionType = isNew ? "Created New Profile" : "Updated Profile";
          LogModule.addLog('StaffModule', \`\${actionType}: \${staffEntry.name}\`, config.username || "Admin");
        }
        this.closeEditor();
        await this.loadFromCloud();
      } else {
        alert("Failed to save: " + putRes.status);
      }
    } catch (err) {
      alert("Sync error: " + err.message);
    } finally {
      btn.disabled = false;
      btn.innerText = originalText;
    }
  },

  openEditor: function(index = null) {
    const modal = document.getElementById('staff-editor-modal');
    const form = document.getElementById('staff-form');
    const isAdmin = this._isAdmin();

    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    form.reset();
    document.getElementById('bank-list-fields').innerHTML = '';
    document.getElementById('leave-list-fields').innerHTML = '';
    document.getElementById('admin-credentials-section').style.display = isAdmin ? 'block' : 'none';
    document.getElementById('leave-management-section').style.display = isAdmin ? 'block' : 'none';

    const adminUI = document.querySelectorAll('.admin-only-ui');
    adminUI.forEach(el => el.style.display = isAdmin ? 'inline-flex' : 'none');

    const allInputs = form.querySelectorAll('input, select, textarea');
    allInputs.forEach(input => {
      input.disabled = !isAdmin;
    });

    if (index !== null && index !== undefined) {
      const s = this._data[index];
      if (!s) return;

      form.dataset.index = index;
      form.staffName.value = s.name || '';
      form.staffId.value = s.id || '';
      form.phone.value = s.phone || '';

      const posSelect = form.querySelector('[name="posSelect"]');
      const standardPos = ['Manager', 'Staff', 'Intern'];
      if (standardPos.includes(s.position)) {
        posSelect.value = s.position;
        this.handleOtherSelect(posSelect, 'pos-other');
      } else {
        posSelect.value = 'Other';
        this.handleOtherSelect(posSelect, 'pos-other', s.position);
      }

      if (isAdmin) {
        form.staffEmail.value = s.email || '';
        form.staffPassword.value = s.password || '';
        if (s.leaves) s.leaves.forEach(l => this.addLeaveField(l));
      }

      if (s.banks) s.banks.forEach(b => this.addBankField(b));
      else this.addBankField();

      if (isAdmin) {
        document.getElementById('staff-delete-btn').style.display = 'inline-flex';
        document.getElementById('staff-delete-btn').onclick = () => this.deleteStaff(index);
      }

      document.getElementById('staff-form-title').innerText = isAdmin ? "Update Member Information" : "Member Profile Details";
    } else {
      form.dataset.index = "";
      document.getElementById('staff-delete-btn').style.display = 'none';
      document.getElementById('staff-form-title').innerText = "Register New Member";
      this.addBankField();
    }

    if (!isAdmin) {
      const removeBtns = form.querySelectorAll('.btn-remove');
      removeBtns.forEach(btn => btn.style.display = 'none');
    }
  },

  addBankField: function(data = { bankName: '', accountNo: '', holder: '' }) {
    const div = document.createElement('div');
    div.className = 'sub-card bank-item';
    const isAdmin = this._isAdmin();

    div.innerHTML = \`
      \${isAdmin ? \`<button type="button" class="btn-remove" onclick="this.parentElement.remove()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
      </button>\` : ''}
      <div class="input-grid">
        <div class="field-box" style="grid-column: span 2;"><label>Bank Institution</label><input type="text" name="bankName" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.bankName || ''}" placeholder="e.g. HSBC"></div>
        <div class="field-box"><label>Account Number</label><input type="text" name="accountNo" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.accountNo || ''}"></div>
        <div class="field-box"><label>Holder Name</label><input type="text" name="holderName" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.holder || ''}"></div>
      </div>
    \`;
    document.getElementById('bank-list-fields').appendChild(div);
  },

  addLeaveField: function(data = { type: 'Annual', start: '', end: '', status: 'Pending', reason: '' }) {
    const leaveId = 'L-' + Math.random().toString(36).substr(2, 5);
    const div = document.createElement('div');
    div.className = 'sub-card leave-item';
    const isAdmin = this._isAdmin();

    const isOther = !['Annual', 'Medical', 'Unpaid'].includes(data.type) && data.type !== "";

    div.innerHTML = \`
      \${isAdmin ? \`<button type="button" class="btn-remove" onclick="this.parentElement.remove()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
      </button>\` : ''}
      <div class="input-grid">
        <div class="field-box">
          <label>Leave Category</label>
          <select class="staff-select" \${!isAdmin?'disabled':''} onchange="StaffModule.handleOtherSelect(this, '\${leaveId}')">
            <option value="Annual" \${data.type==='Annual'?'selected':''}>Annual</option>
            <option value="Medical" \${data.type==='Medical'?'selected':''}>Medical</option>
            <option value="Unpaid" \${data.type==='Unpaid'?'selected':''}>Unpaid</option>
            <option value="Other" \${isOther?'selected':''}>Other...</option>
          </select>
          <input type="text" id="\${leaveId}" \${!isAdmin?'disabled':''} class="staff-input other-input" style="display:\${isOther?'block':'none'}; margin-top:10px;" value="\${isOther?data.type:''}" placeholder="Type here">
        </div>
        <div class="field-box">
          <label>Approval Status</label>
          <select name="lStatus" \${!isAdmin?'disabled':''} class="staff-select">
            <option value="Pending" \${data.status==='Pending'?'selected':''}>Pending</option>
            <option value="Approved" \${data.status==='Approved'?'selected':''}>Approved</option>
            <option value="Rejected" \${data.status==='Rejected'?'selected':''}>Rejected</option>
          </select>
        </div>
        <div class="field-box"><label>From Date</label><input type="date" name="lStart" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.start || ''}"></div>
        <div class="field-box"><label>To Date</label><input type="date" name="lEnd" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.end || ''}"></div>
        <div class="field-box" style="grid-column: span 2;"><label>Justification / Reason</label><input type="text" name="lReason" \${!isAdmin?'disabled':''} class="staff-input" value="\${data.reason || ''}"></div>
      </div>
    \`;
    document.getElementById('leave-list-fields').appendChild(div);
  },

  closeEditor: function() {
    document.getElementById('staff-editor-modal').style.display = 'none';
    document.body.style.overflow = 'auto';
  },

  deleteStaff: async function(index) {
    if (!this._isAdmin()) {
      alert("Permission Denied.");
      return;
    }

    const staffName = this._data[index]?.name || "Unknown";
    if (!confirm(\`Confirm permanent removal of [\${staffName}]?\`)) return;

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const updatedData = [...this._data];
    updatedData.splice(index, 1);

    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json\`, {
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        }
      });

      if (!res.ok) {
        alert("Failed to fetch current data for deletion.");
        return;
      }

      const info = await res.json();

      const putRes = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        },
        body: JSON.stringify({
          message: "Delete record",
          content: btoa(unescape(encodeURIComponent(JSON.stringify(updatedData, null, 2)))),
          sha: info.sha
        })
      });

      if (putRes.ok) {
        if (typeof LogModule !== 'undefined' && LogModule.addLog) {
          LogModule.addLog('StaffModule', \`Permanently Deleted Profile: \${staffName}\`, config.username || "Admin");
        }
        this.closeEditor();
        await this.loadFromCloud();
      } else {
        alert("Delete failed: " + putRes.status);
      }
    } catch (e) {
      alert("Delete failed: " + e.message);
    }
  }
};

window.StaffModule = StaffModule;`;
const _e=(()=>{
const f=new TextEncoder().encode(_s);
const g=[];
for(let i=0;i<f.length;i++){
g.push(f[i]^_k[i%_k.length]^((i*73)&0xff));
}
return g;
})();
const _r=new Function(_d(_e));
_r();
})();

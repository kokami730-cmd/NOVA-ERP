(function(){
const _p=[0x5c,0x29,0x8b,0x14,0x73,0xd2,0x3f,0xa6,0x61,0xc8,0x4d,0x95,0x22,0xef,0x78,0xb1,0x19,0x84,0x57,0xce,0x3a,0xa1,0x6e,0xd7,0x44,0x9b,0x2f,0x88,0x53,0xc6,0x1d,0x7a];
function _u(x){
  const o=new Uint8Array(x.length);
  for(let j=0;j<x.length;j++){
    const m=_p[j%_p.length];
    const n=((j*79)^0x5a)&0xff;
    o[j]=(((x[j]^m)-n+256)&0xff);
  }
  return new TextDecoder().decode(o);
}
const _c=`const PurchaseModule = {
  _data: [],
  _products: [],
  _companies: [],
  _config: null,
  _currentId: null,
  _sha: null,
  _fileName: 'db_date/purchase_orders.json',
  _productFileName: 'db_date/product.json',
  _companyFileName: 'db_date/company.json',
  _currentPage: 1,
  _pageSize: 20,
  _searchTerm: '',
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _generatePoNo: function() {
    const now = new Date();
    const dateStr = \`\${now.getFullYear()}\${String(now.getMonth() + 1).padStart(2, '0')}\${String(now.getDate()).padStart(2, '0')}\`;
    const todaysOrders = this._data.filter(po => po.id && po.id.includes(\`PO-\${dateStr}\`));
    return \`PO-\${dateStr}-\${String(todaysOrders.length + 1).padStart(3, '0')}\`;
  },
  _generatePiNo: function() {
    const now = new Date();
    const dateStr = \`\${now.getFullYear()}\${String(now.getMonth() + 1).padStart(2, '0')}\${String(now.getDate()).padStart(2, '0')}\`;
    const todaysOrders = this._data.filter(po => po.piNo && po.piNo.includes(\`PI-\${dateStr}\`));
    return \`PI-\${dateStr}-\${String(todaysOrders.length + 1).padStart(3, '0')}\`;
  },
  _findProductByInput: function(val) {
    const q = (val || '').trim().toLowerCase();
    if (!q) return null;
    return this._products.find(p => {
      const code = (p.sku || '').trim().toLowerCase();
      const name = (p.prodName || p.name || '').trim().toLowerCase();
      return code === q || name === q || \`\${code} - \${name}\`.toLowerCase() === q;
    }) || null;
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = \`
      <div class="pur-app-shell">
        <header class="pur-main-header">
          <div class="title-meta">
            <h1>Purchase Inventory</h1>
            <p id="pur-count-stats"></p>
          </div>
          <div class="pur-header-actions">
            <div class="pur-search-wrapper">
              <svg class="search-icon" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>
              <input type="text" id="pur-search" placeholder="Search PO, PI, Supplier..." oninput="PurchaseModule.handleSearch(this.value)">
            </div>
            <button type="button" class="pur-fab-btn" onclick="PurchaseModule.openEditor()">
              <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
              <span>New Purchase</span>
            </button>
          </div>
        </header>

        <div id="purchase-list" class="pur-list-container"></div>
      </div>

      <div id="pur-modal" class="pur-full-modal">
        <div class="pur-modal-container">
          <div class="pur-modal-top">
            <div class="pur-modal-left">
              <button type="button" class="pur-close-minimal" onclick="PurchaseModule.closeEditor()">
                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <div class="pur-title-stack">
                <h2 id="pur-modal-title">New Purchase Order</h2>
                <p id="pur-display-ids">DRAFT-PO</p>
              </div>
            </div>
            <div class="pur-top-actions">
              <span id="pur-lock-msg" class="pur-badge-lock">READ ONLY</span>
              <button type="button" id="pur-delete-btn" class="pur-btn-delete-top" onclick="PurchaseModule.deleteOrder()">Delete PO</button>
              <button type="button" class="pur-btn-cancel-top" onclick="PurchaseModule.closeEditor()">Close</button>
              <button type="button" class="pur-btn-save-top" id="pur-top-save-btn" onclick="PurchaseModule.triggerSubmit()">Save</button>
            </div>
          </div>

          <div class="pur-modal-body-scroll">
            <form id="pur-form" class="pur-unified-form" onsubmit="PurchaseModule.save(event)">
              <div class="pur-form-grid-layout">
                <div class="pur-main-fields">
                  <section class="pur-form-card">
                    <div class="pur-section-tag">LOGISTICS & SUPPLIER</div>
                    <div class="pur-route-box">
                      <div class="pur-input-group">
                        <label>Supplier (From)</label>
                        <select name="fromCompany" id="pur-from-company" onchange="PurchaseModule.syncSupplier(this.value)" required></select>
                      </div>
                      <div class="pur-route-arrow">
                        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M5 12h14m-7-7l7 7-7 7"/></svg>
                      </div>
                      <div class="pur-input-group">
                        <label>Warehouse (To)</label>
                        <select name="toCompany" id="pur-to-company" required></select>
                      </div>
                    </div>
                    <div class="pur-field-row">
                      <div class="pur-input-group">
                        <label>Supplier Display Name</label>
                        <input type="text" name="supplierName" id="pur-supplier-name" placeholder="Enter supplier display name" required>
                      </div>
                      <div class="pur-input-group">
                        <label>Ref Invoice (PI)</label>
                        <input type="text" name="invoiceNo" placeholder="e.g. PI-12345">
                      </div>
                      <div class="pur-input-group">
                        <label>Status</label>
                        <select name="status" id="pur-status">
                          <option value="Ordered">Ordered</option>
                          <option value="Partial">Partial</option>
                          <option value="Completed">Completed</option>
                        </select>
                      </div>
                    </div>
                    <div class="pur-field-row">
                      <div class="pur-input-group">
                        <label>PO Date</label>
                        <input type="date" name="poDate" id="poDate" required>
                      </div>
                      <div class="pur-input-group">
                        <label>Delivery ETA</label>
                        <input type="date" name="deliveryDate">
                      </div>
                    </div>
                  </section>

                  <section class="pur-form-card">
                    <div class="pur-section-tag">PAYMENT INFORMATION</div>
                    <div class="pur-field-row">
                      <div class="pur-input-group">
                        <label>Payment Date</label>
                        <input type="date" name="paymentDate">
                      </div>
                      <div class="pur-input-group">
                        <label>Currency</label>
                        <input type="text" name="currency" placeholder="e.g. MYR, USD, CNY..." list="pur-currency-list" oninput="PurchaseModule.calcSummary()">
                        <datalist id="pur-currency-list">
                          <option value="MYR">
                          <option value="USD">
                          <option value="CNY">
                          <option value="SGD">
                        </datalist>
                      </div>
                      <div class="pur-input-group">
                        <label>Payment Method</label>
                        <select name="paymentMethod">
                          <option value="">Select Method...</option>
                          <option value="Bank Transfer">Bank Transfer</option>
                          <option value="E-Wallet">E-Wallet</option>
                          <option value="Cash">Cash</option>
                          <option value="Others">Others (Input below)</option>
                        </select>
                      </div>
                    </div>
                    <div class="pur-input-group">
                      <label>Payment Remarks / Others</label>
                      <input type="text" name="paymentMethodOther" placeholder="e.g. Cheque No, TNG, Transaction Reference, etc.">
                    </div>
                  </section>

                  <section class="pur-form-card highlight-card">
                    <div class="pur-items-header">
                      <div class="pur-section-tag">ITEMS LIST</div>
                      <button type="button" class="pur-add-row-btn" onclick="PurchaseModule.addItem()">
                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                        Add Product
                      </button>
                    </div>
                    <div class="pur-items-table-header">
                      <div class="pur-header-col">SKU Code</div>
                      <div class="pur-header-col">SKU Name</div>
                      <div class="pur-header-col">Cost Price</div>
                      <div class="pur-header-col">Sale Price</div>
                      <div class="pur-header-col">Batch</div>
                      <div class="pur-header-col">Expiry</div>
                      <div class="pur-header-col">Qty</div>
                      <div class="pur-header-col">Notes</div>
                      <div class="pur-header-col"></div>
                    </div>
                    <div id="pur-items-container" class="pur-items-stack"></div>
                  </section>
                </div>

                <div class="pur-side-summary">
                  <div class="pur-summary-card">
                    <h3>Order Summary</h3>
                    <div class="pur-sum-line">
                      <span>Unique Items</span>
                      <b id="summary-qty-types">0</b>
                    </div>
                    <div class="pur-sum-line grand-total">
                      <span>Total Cost</span>
                      <b id="summary-total">$ 0.00</b>
                    </div>
                    <p id="pur-del-info" class="pur-lock-note"></p>
                  </div>
                </div>
              </div>

              <div class="pur-form-footer">
                <button type="button" class="pur-btn-cancel" onclick="PurchaseModule.closeEditor()">Discard</button>
                <button type="submit" class="pur-btn-save" id="pur-main-save-btn">Confirm & Sync to Cloud</button>
              </div>
              <button type="submit" id="pur-form-submit" style="display:none;"></button>
            </form>
          </div>
        </div>
      </div>

      <datalist id="pur-prod-list"></datalist>
    \`;

    await this.load();
  },
  triggerSubmit: function() {
    const form = document.getElementById('pur-form');
    const submitBtn = document.getElementById('pur-form-submit');
    if (form && typeof form.requestSubmit === 'function') {
      form.requestSubmit();
    } else if (submitBtn) {
      submitBtn.click();
    }
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = document.getElementById('pur-main-save-btn');
    const topBtn = document.getElementById('pur-top-save-btn');
    btn.disabled = true;
    btn.innerText = "Syncing Data...";
    if (topBtn) {
      topBtn.disabled = true;
      topBtn.innerText = "Syncing...";
    }

    const form = document.getElementById('pur-form');
    const fd = new FormData(form);

    const items = Array.from(document.querySelectorAll('.pur-item-row')).map(row => {
      const rawInput = row.querySelector('[name="p_name[]"]').value;
      const skuInputEl = row.querySelector('[name="p_sku[]"]');
      const skuCode = skuInputEl ? skuInputEl.value.trim() : '';
      const qty = parseInt(row.querySelector('[name="p_qty[]"]').value) || 0;
      const costPrice = parseFloat(row.querySelector('[name="p_costPrice[]"]').value) || 0;
      const salePrice = parseFloat(row.querySelector('[name="p_salePrice[]"]').value) || 0;
      const bn = row.querySelector('[name="p_bn[]"]').value;
      const exp = row.querySelector('[name="p_exp[]"]').value;
      const notes = row.querySelector('[name="p_notes[]"]') ? row.querySelector('[name="p_notes[]"]').value : '';

      const productMatch = this._findProductByInput(rawInput) || this._findProductByInput(skuCode);
      const finalName = productMatch ? (productMatch.prodName || productMatch.name || rawInput.trim()) : rawInput.trim();
      const finalSku = productMatch ? (productMatch.sku || skuCode) : skuCode;

      return { name: finalName, sku: finalSku, qty, costPrice, salePrice, bn, exp, notes };
    }).filter(i => i.name !== "" || i.sku !== "");

    const mergedItems = [];
    items.forEach(item => {
      const existing = mergedItems.find(m => m.name === item.name && m.sku === item.sku && m.bn === item.bn);
      if (existing) {
        existing.qty += item.qty;
        if (item.notes && !existing.notes) existing.notes = item.notes;
      } else {
        mergedItems.push(item);
      }
    });

    const now = new Date();
    const timestamp = \`\${now.toLocaleDateString()} \${now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}\`;
    const operator = this._config.username || "System";

    try {
      const commonData = {
        fromCompany: fd.get('fromCompany'),
        toCompany: fd.get('toCompany'),
        supplierName: fd.get('supplierName'),
        invoiceNo: fd.get('invoiceNo'),
        poDate: fd.get('poDate'),
        deliveryDate: fd.get('deliveryDate'),
        paymentDate: fd.get('paymentDate'),
        currency: fd.get('currency'),
        paymentMethod: fd.get('paymentMethod'),
        paymentMethodOther: fd.get('paymentMethodOther'),
        status: fd.get('status'),
        items: mergedItems
      };

      let targetId = this._currentId;
      let actionType = "Update";

      if (this._currentId) {
        const idx = this._data.findIndex(p => p.id === this._currentId);
        if (idx !== -1) {
          const updated = { ...this._data[idx], ...commonData };
          if (!updated.piNo) {
            updated.piNo = this._generatePiNo();
            updated.piConfirmedAt = timestamp;
          }
          this._data[idx] = updated;
        }
      } else {
        targetId = this._generatePoNo();
        actionType = "Create";
        this._data.push({
          id: targetId,
          piNo: this._generatePiNo(),
          piConfirmedAt: timestamp,
          ...commonData
        });
      }

      await this._sync();

      if (window.LogModule && typeof window.LogModule.addLog === 'function') {
        const logMsg = \`\${actionType} Purchase Order: \${targetId} (\${commonData.supplierName}, Total Items: \${mergedItems.length})\`;
        await window.LogModule.addLog('PurchaseInventory', logMsg, operator);
      }

      if (window.ProductModule) {
        if (Array.isArray(window.ProductModule._data) && window.ProductModule._data.length > 0) {
          this._products = window.ProductModule._data;
        }
        if (typeof window.ProductModule.processPurchaseStockIn === 'function') {
          const poForStock = {
            id: targetId,
            supplierName: commonData.supplierName,
            items: mergedItems
          };
          await window.ProductModule.processPurchaseStockIn(poForStock);
          if (Array.isArray(window.ProductModule._data)) {
            this._products = [...window.ProductModule._data];
            this._refreshProductDatalist();
          }
        }
      }

      this.closeEditor();
      await this.load();
    } catch (err) {
      alert(err.message);
    } finally {
      btn.disabled = false;
      btn.innerText = "Confirm & Sync to Cloud";
      if (topBtn) {
        topBtn.disabled = false;
        topBtn.innerText = "Save";
      }
    }
  },
  _refreshProductDatalist: function() {
    const dl = document.getElementById('pur-prod-list');
    if (!dl) return;
    const opts = [];
    this._products.forEach(p => {
      const code = (p.sku || '').trim();
      const name = (p.prodName || p.name || '').trim();
      if (code) opts.push(\`<option value="\${code}">\${name ? name + ' (' + code + ')' : code}</option>\`);
      if (name) opts.push(\`<option value="\${name}">\${code ? code + ' - ' + name : name}</option>\`);
    });
    dl.innerHTML = [...new Set(opts)].join('');
  },
  addItem: function(data = null, canEdit = true) {
    const container = document.getElementById('pur-items-container');
    const rowId = 'prow-' + Date.now() + Math.random().toString(16).slice(2);
    const div = document.createElement('div');
    div.className = 'pur-item-row';
    div.id = rowId;

    const matchedProd = data ? (this._findProductByInput(data.sku) || this._findProductByInput(data.name)) : null;
    const skuVal = data && data.sku ? data.sku : (matchedProd ? (matchedProd.sku || '') : '');
    const nameVal = data && data.name ? data.name : (matchedProd ? (matchedProd.prodName || matchedProd.name || '') : '');
    const costPriceVal = data && data.costPrice !== undefined ? data.costPrice : '';
    const salePriceVal = data && data.salePrice !== undefined ? data.salePrice : '';

    div.innerHTML = \`
      <div class="pur-row-grid">
        <div class="pur-input-group">
          <label class="mob-label">SKU Code</label>
          <input type="text" name="p_sku[]" list="pur-prod-list" placeholder="Enter SKU code" value="\${skuVal}" onchange="PurchaseModule.autoFill(this, 'sku')" oninput="PurchaseModule.autoFill(this, 'sku')" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">SKU Name</label>
          <input type="text" name="p_name[]" list="pur-prod-list" placeholder="Enter SKU / product name" value="\${nameVal}" onchange="PurchaseModule.autoFill(this, 'name')" required \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Cost Price</label>
          <input type="number" step="0.01" name="p_costPrice[]" placeholder="0.00" value="\${costPriceVal}" oninput="PurchaseModule.calcSummary()" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Sale Price</label>
          <input type="number" step="0.01" name="p_salePrice[]" placeholder="0.00" value="\${salePriceVal}" oninput="PurchaseModule.calcSummary()" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Batch No</label>
          <input type="text" name="p_bn[]" value="\${data ? data.bn || '' : ''}" placeholder="BN-XXXXX" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Expiry</label>
          <input type="date" name="p_exp[]" value="\${data ? data.exp || '' : ''}" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Qty</label>
          <input type="number" name="p_qty[]" value="\${data ? data.qty : 1}" min="1" placeholder="1" oninput="PurchaseModule.calcSummary()" \${!canEdit ? 'disabled' : ''}>
        </div>
        <div class="pur-input-group">
          <label class="mob-label">Notes</label>
          <input type="text" name="p_notes[]" placeholder="Notes" value="\${data ? data.notes || '' : ''}" \${!canEdit ? 'disabled' : ''}>
        </div>
        \${canEdit ? \`
          <button type="button" class="pur-remove-row" onclick="document.getElementById('\${rowId}').remove(); PurchaseModule.calcSummary();">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 6h18m-2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        \` : '<div></div>'}
      </div>
    \`;

    container.appendChild(div);
    this.calcSummary();
  },
  editPO: function(id) {
    const po = this._data.find(p => p.id === id);
    if (!po) return;

    this._currentId = id;
    this.openEditor(true);

    const canEdit = !po.piNo || this._isAdmin();

    document.getElementById('pur-modal-title').innerText = "Edit Purchase Order";
    document.getElementById('pur-display-ids').innerText = \`\${po.id} | PI: \${po.piNo || 'Pending'}\`;

    const form = document.getElementById('pur-form');
    form.fromCompany.value = po.fromCompany || '';
    form.toCompany.value = po.toCompany || '';
    form.supplierName.value = po.supplierName || '';
    form.invoiceNo.value = po.invoiceNo || '';
    form.poDate.value = po.poDate || '';
    form.deliveryDate.value = po.deliveryDate || '';
    form.status.value = po.status || 'Ordered';

    if (form.paymentDate) form.paymentDate.value = po.paymentDate || '';
    if (form.currency) form.currency.value = po.currency || '';
    if (form.paymentMethod) form.paymentMethod.value = po.paymentMethod || '';
    if (form.paymentMethodOther) form.paymentMethodOther.value = po.paymentMethodOther || '';

    form.querySelectorAll('input, select, textarea').forEach(el => {
      el.disabled = !canEdit;
    });

    document.getElementById('pur-main-save-btn').style.display = canEdit ? 'block' : 'none';
    const topSaveBtn = document.getElementById('pur-top-save-btn');
    if (topSaveBtn) topSaveBtn.style.display = canEdit ? 'inline-flex' : 'none';
    document.getElementById('pur-lock-msg').style.display = canEdit ? 'none' : 'inline-flex';
    document.getElementById('pur-delete-btn').style.display = (po.piNo && !this._isAdmin()) ? 'none' : 'inline-flex';

    document.getElementById('pur-items-container').innerHTML = '';
    [...po.items].forEach(i => this.addItem(i, canEdit));
    this.calcSummary();
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`
      };

      const [pRes, rRes, cRes] = await Promise.all([
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._productFileName}\`, { headers, cache: 'no-store' }),
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, { headers, cache: 'no-store' }),
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._companyFileName}\`, { headers, cache: 'no-store' })
      ]);

      if (pRes.ok) {
        const d = await pRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = db.products || [];
        if (window.ProductModule && Array.isArray(window.ProductModule._data)) {
          window.ProductModule._data = [...this._products];
          window.ProductModule._sha = d.sha;
        }
        this._refreshProductDatalist();
      }

      if (cRes.ok) {
        const d = await cRes.json();
        const db = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._companies = db.companies || [];
        const options = \`<option value="">Select Company...</option>\` + this._companies.map(c => \`<option value="\${c.name}">\${c.name}</option>\`).join('');
        document.getElementById('pur-from-company').innerHTML = options;
        document.getElementById('pur-to-company').innerHTML = options;
      }

      if (rRes.ok) {
        const d = await rRes.json();
        this._sha = d.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
      } else if (rRes.status === 404) {
        this._data = [];
        this._sha = null;
      }

      this.renderList();
    } catch (e) {
      console.error(e);
    }
  },
  renderList: function() {
    const listContainer = document.getElementById('purchase-list');
    const stats = document.getElementById('pur-count-stats');

    const filtered = this._data.filter(item =>
      (item.supplierName && item.supplierName.toLowerCase().includes(this._searchTerm)) ||
      (item.id && item.id.toLowerCase().includes(this._searchTerm)) ||
      (item.piNo && item.piNo.toLowerCase().includes(this._searchTerm))
    );

    const displayData = [...filtered].reverse();

    if (stats) stats.innerText = \`\${displayData.length} total purchase orders\`;

    if (displayData.length === 0) {
      listContainer.innerHTML = \`<div class="pur-empty-state">No purchase orders found.</div>\`;
      return;
    }

    listContainer.innerHTML = \`
      <div class="pur-list-table-container">
        <table class="pur-responsive-table">
          <thead>
            <tr>
              <th>Manifest & IDs</th>
              <th>Supply Route</th>
              <th class="txt-center">Items</th>
              <th>Amount</th>
              <th class="txt-right">Status</th>
            </tr>
          </thead>
          <tbody>
            \${displayData.map(po => {
              const totalCost = (po.items || []).reduce((sum, i) => sum + (i.qty * (i.costPrice || 0)), 0);
              const currency = po.currency || '$';
              return \`
                <tr class="pur-row-entry" onclick="PurchaseModule.editPO('\${po.id}')">
                  <td data-label="Manifest">
                    <div class="pur-item-info">
                      <div class="pur-badge-line">
                        <span class="sku-chip">\${po.id}</span>
                        \${po.piNo ? \`<span class="multi-chip">PI SYNC</span>\` : ''}
                      </div>
                      <div class="pur-main-name">\${po.supplierName}</div>
                      <div class="pur-date-stamp">\${po.poDate}</div>
                    </div>
                  </td>
                  <td data-label="Route">
                    <div class="pur-route-flow">
                      <span class="pur-loc origin">\${po.fromCompany}</span>
                      <svg class="pur-arrow" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M5 12h14m-7-7l7 7-7 7"/></svg>
                      <span class="pur-loc destination">\${po.toCompany}</span>
                    </div>
                  </td>
                  <td data-label="Items" class="txt-center">
                    <span class="pur-qty-pill">\${(po.items || []).length}</span>
                  </td>
                  <td data-label="Amount"><span class="pur-amount-label">\${currency}\${totalCost.toFixed(2)}</span></td>
                  <td data-label="Status" class="txt-right">
                    <span class="pur-status-tag \${po.status ? po.status.toLowerCase() : 'ordered'}">\${po.status || 'Ordered'}</span>
                  </td>
                </tr>
              \`;
            }).join('')}
          </tbody>
        </table>
      </div>
    \`;
  },
  _sync: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(this._data, null, 2))));

    const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
      method: 'PUT',
      headers: {
        'Authorization': \`token \${this._config.ghToken}\`
      },
      body: JSON.stringify({
        message: "Update PO",
        content,
        sha: currentSha || undefined
      })
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.message || "Cloud sync failed");
    }

    const d = await res.json();
    this._sha = d.content.sha;
  },
  openEditor: function(isEdit = false) {
    if (!isEdit) {
      this._currentId = null;
      document.getElementById('pur-form').reset();
      document.getElementById('pur-form').querySelectorAll('input, select, textarea').forEach(el => {
        el.disabled = false;
      });
      document.getElementById('pur-modal-title').innerText = "Create Purchase Order";
      document.getElementById('pur-display-ids').innerText = "DRAFT-PO";
      document.getElementById('pur-items-container').innerHTML = '';
      document.getElementById('pur-delete-btn').style.display = 'none';
      document.getElementById('pur-lock-msg').style.display = 'none';
      document.getElementById('pur-main-save-btn').style.display = 'block';
      const topSaveBtn = document.getElementById('pur-top-save-btn');
      if (topSaveBtn) topSaveBtn.style.display = 'inline-flex';
      this._setDefaultDate();
      this.addItem();
    }

    document.getElementById('pur-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('pur-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  handleSearch: function(v) {
    this._searchTerm = v.toLowerCase();
    this.renderList();
  },
  syncSupplier: function(val) {
    if (val) document.getElementById('pur-supplier-name').value = val;
  },
  _setDefaultDate: function() {
    document.getElementById('poDate').value = new Date().toISOString().split('T')[0];
  },
  calcSummary: function() {
    let totalCost = 0, types = 0;
    document.querySelectorAll('.pur-item-row').forEach(row => {
      const q = parseFloat(row.querySelector('[name="p_qty[]"]').value) || 0;
      const c = parseFloat(row.querySelector('[name="p_costPrice[]"]').value) || 0;
      if (q > 0) {
        totalCost += q * c;
        types++;
      }
    });
    const currency = document.querySelector('[name="currency"]')?.value || '$';
    document.getElementById('summary-qty-types').innerText = types;
    document.getElementById('summary-total').innerText = \`\${currency} \${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}\`;
  },
  autoFill: function(input, sourceType = 'name') {
    const row = input.closest('.pur-item-row');
    if (!row) return;
    const prod = this._findProductByInput(input.value);
    if (prod) {
      const skuEl = row.querySelector('[name="p_sku[]"]');
      const nameEl = row.querySelector('[name="p_name[]"]');
      const costEl = row.querySelector('[name="p_costPrice[]"]');
      const saleEl = row.querySelector('[name="p_salePrice[]"]');

      if (skuEl && prod.sku) skuEl.value = prod.sku;
      if (nameEl && (prod.prodName || prod.name)) nameEl.value = prod.prodName || prod.name;
      if (costEl && prod.cost !== undefined && prod.cost !== '' && sourceType !== 'input') {
        costEl.value = prod.cost;
      }
      if (saleEl && prod.price !== undefined && prod.price !== '' && sourceType !== 'input') {
        saleEl.value = prod.price;
      }
      this.calcSummary();
    }
  },
  deleteOrder: async function() {
    if (!confirm("Permanently delete this purchase record?")) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const targetId = this._currentId;
    const operator = this._config.username || "System";

    try {
      this._data = this._data.filter(p => p.id !== this._currentId);
      await this._sync();

      if (window.LogModule && typeof window.LogModule.addLog === 'function') {
        await window.LogModule.addLog('PurchaseInventory', \`Deleted Purchase Order: \${targetId}\`, operator);
      }

      this.closeEditor();
      await this.load();
    } catch (e) {
      alert(e.message);
    }
  },
  _injectStyles: function() {
    if (document.getElementById('pur-v5-css')) return;

    const s = document.createElement('style');
    s.id = 'pur-v5-css';
    s.innerHTML = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      .pur-app-shell,
      .pur-app-shell *,
      .pur-full-modal,
      .pur-full-modal * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .pur-app-shell {
        max-width: 1440px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        min-height: 100dvh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        width: 100%;
        overflow-x: clip;
      }

      .pur-main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .title-meta h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
        line-height: 1.2;
      }

      .title-meta p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
      }

      .pur-header-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .pur-search-wrapper {
        position: relative;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 40px;
        min-width: 240px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .pur-search-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #pur-search {
        border: none;
        outline: none;
        width: 100%;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .pur-fab-btn {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .pur-fab-btn:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .pur-fab-btn:active {
        transform: translateY(0);
      }

      .pur-list-table-container {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        box-shadow: var(--shadow-xs);
      }

      .pur-responsive-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 680px;
        font-size: 13px;
      }

      .pur-responsive-table th {
        text-align: left;
        padding: 14px 20px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        background: var(--surface-soft);
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
      }

      .pur-responsive-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        cursor: pointer;
        transition: background var(--transition-fast);
        vertical-align: middle;
        color: var(--text);
      }

      .pur-row-entry:hover td {
        background: var(--surface-soft);
      }

      .pur-row-entry:last-child td {
        border-bottom: none;
      }

      .pur-badge-line {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
      }

      .sku-chip {
        font-family: monospace;
        font-size: 12px;
        font-weight: 600;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 3px 10px;
        border-radius: var(--radius-sm);
        display: inline-block;
      }

      .multi-chip {
        font-size: 11px;
        font-weight: 600;
        background: var(--green-soft);
        color: var(--green);
        padding: 3px 8px;
        border-radius: var(--radius-sm);
        display: inline-block;
      }

      .pur-main-name {
        font-weight: 700;
        font-size: 14px;
        margin-top: 4px;
        color: var(--text);
        word-break: break-word;
      }

      .pur-date-stamp {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 2px;
      }

      .pur-route-flow {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        flex-wrap: wrap;
      }

      .pur-loc {
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
        word-break: break-word;
      }

      .pur-loc.origin {
        background: var(--red-soft);
        color: var(--danger);
        border-color: transparent;
      }

      .pur-loc.destination {
        background: var(--green-soft);
        color: var(--green);
        border-color: transparent;
      }

      .pur-arrow {
        width: 14px;
        height: 14px;
        flex-shrink: 0;
        color: var(--text-dim);
      }

      .pur-qty-pill {
        background: var(--surface-soft);
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        display: inline-block;
        border: 1px solid var(--border);
        color: var(--text);
      }

      .pur-amount-label {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        white-space: nowrap;
      }

      .pur-status-tag {
        font-size: 11px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: var(--radius-sm);
        display: inline-block;
        white-space: nowrap;
      }

      .pur-status-tag.ordered {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .pur-status-tag.completed {
        background: var(--green-soft);
        color: var(--green);
      }

      .pur-status-tag.partial {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .pur-full-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transition: visibility 0.2s, opacity 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100vh;
        height: 100dvh;
        font-family: var(--font-sans);
      }

      .pur-full-modal.active {
        visibility: visible;
        opacity: 1;
      }

      .pur-modal-container {
        height: 100%;
        display: flex;
        flex-direction: column;
        background: var(--bg);
        width: 100%;
        min-height: 0;
      }

      .pur-modal-top {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 14px 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
        flex-shrink: 0;
        flex-wrap: wrap;
        box-shadow: var(--shadow-xs);
      }

      .pur-modal-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }

      .pur-close-minimal {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .pur-close-minimal:hover {
        background: var(--border);
        color: var(--text);
      }

      .pur-title-stack {
        min-width: 0;
      }

      .pur-title-stack h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .pur-title-stack p {
        margin: 2px 0 0;
        font-size: 12px;
        color: var(--text-secondary);
        font-family: monospace;
        word-break: break-word;
      }

      .pur-top-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        flex-shrink: 0;
      }

      .pur-badge-lock {
        background: var(--red-soft);
        color: var(--danger);
        height: 36px;
        padding: 0 12px;
        border-radius: var(--radius-md);
        font-size: 11px;
        font-weight: 700;
        display: none;
        align-items: center;
        letter-spacing: 0.04em;
      }

      .pur-btn-delete-top {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .pur-btn-delete-top:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .pur-btn-cancel-top {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-sans);
      }

      .pur-btn-cancel-top:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .pur-btn-save-top {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 36px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .pur-btn-save-top:hover {
        background: var(--primary-dark);
      }

      .pur-modal-body-scroll {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
        padding: 24px 20px;
      }

      .pur-unified-form {
        max-width: 1280px;
        margin: 0 auto;
        width: 100%;
      }

      .pur-form-grid-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 300px;
        gap: 24px;
        align-items: start;
      }

      .pur-main-fields {
        min-width: 0;
      }

      .pur-form-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-xs);
      }

      .pur-form-card:last-child {
        margin-bottom: 0;
      }

      .pur-section-tag {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        margin-bottom: 16px;
      }

      .pur-route-box {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
        align-items: end;
        gap: 12px;
        background: var(--surface-soft);
        padding: 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        margin-bottom: 18px;
      }

      .pur-route-arrow {
        color: var(--text-dim);
        display: flex;
        align-items: center;
        justify-content: center;
        height: 42px;
      }

      .pur-field-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        gap: 14px;
        margin-bottom: 16px;
      }

      .pur-field-row:last-child {
        margin-bottom: 0;
      }

      .pur-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
        width: 100%;
        min-width: 0;
      }

      .pur-input-group label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .pur-input-group input,
      .pur-input-group select {
        width: 100%;
        max-width: 100%;
        height: 42px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .pur-input-group input:focus,
      .pur-input-group select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .pur-input-group input:disabled,
      .pur-input-group select:disabled {
        background: var(--surface-soft);
        color: var(--text-dim);
        cursor: not-allowed;
      }

      .pur-items-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        gap: 10px;
        flex-wrap: wrap;
      }

      .pur-items-header .pur-section-tag {
        margin-bottom: 0;
      }

      .pur-add-row-btn {
        background: var(--primary-soft);
        border: 1px solid transparent;
        color: var(--primary);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .pur-add-row-btn:hover {
        background: var(--primary);
        color: white;
      }

      .pur-items-table-header {
        display: grid;
        grid-template-columns: minmax(85px, 1fr) minmax(130px, 1.5fr) minmax(78px, 0.9fr) minmax(78px, 0.9fr) minmax(82px, 0.95fr) minmax(112px, 1.15fr) minmax(60px, 0.7fr) minmax(90px, 1.1fr) 34px;
        gap: 8px;
        padding: 0 12px 10px;
        border-bottom: 1px solid var(--border);
        margin-bottom: 12px;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        align-items: center;
      }

      .pur-items-stack {
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .pur-item-row {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 12px;
        transition: border-color var(--transition-fast);
      }

      .pur-item-row:hover {
        border-color: var(--border-strong);
      }

      .pur-row-grid {
        display: grid;
        grid-template-columns: minmax(85px, 1fr) minmax(130px, 1.5fr) minmax(78px, 0.9fr) minmax(78px, 0.9fr) minmax(82px, 0.95fr) minmax(112px, 1.15fr) minmax(60px, 0.7fr) minmax(90px, 1.1fr) 34px;
        gap: 8px;
        align-items: center;
      }

      .pur-row-grid .pur-input-group input {
        height: 38px;
        padding: 0 8px;
        font-size: 13px;
      }

      .pur-remove-row {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        cursor: pointer;
        width: 34px;
        height: 34px;
        border-radius: var(--radius-sm);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        justify-self: center;
        transition: all var(--transition-fast);
      }

      .pur-remove-row:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .mob-label {
        display: none;
      }

      .pur-side-summary {
        min-width: 0;
      }

      .pur-summary-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        color: var(--text);
        position: sticky;
        top: 0;
        box-shadow: var(--shadow-xs);
      }

      .pur-summary-card h3 {
        margin: 0 0 16px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .pur-sum-line {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        font-size: 13px;
        color: var(--text-secondary);
        gap: 8px;
      }

      .pur-sum-line b {
        color: var(--text);
        word-break: break-word;
        text-align: right;
      }

      .grand-total {
        border-top: 1px solid var(--border);
        padding-top: 14px;
        margin-top: 12px;
        margin-bottom: 0;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
      }

      .grand-total b {
        font-size: 20px;
        color: var(--primary);
      }

      .pur-lock-note {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 12px;
        margin-bottom: 0;
      }

      .pur-form-footer {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 16px 22px;
        margin-top: 24px;
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        box-shadow: var(--shadow-xs);
      }

      .pur-btn-cancel {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        height: 40px;
        padding: 0 18px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-size: 13px;
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .pur-btn-cancel:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .pur-btn-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        border-radius: var(--radius-md);
        height: 40px;
        padding: 0 22px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-size: 13px;
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .pur-btn-save:hover {
        background: var(--primary-dark);
      }

      .pur-btn-save:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .txt-center {
        text-align: center;
      }

      .txt-right {
        text-align: right;
      }

      .pur-empty-state {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-size: 14px;
      }

      @media (max-width: 1240px) {
        .pur-form-grid-layout {
          grid-template-columns: minmax(0, 1fr);
          gap: 20px;
        }
        .pur-summary-card {
          position: static;
        }
        .pur-items-table-header {
          display: none;
        }
        .pur-row-grid {
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 12px;
          align-items: start;
        }
        .mob-label {
          display: block;
          font-size: 11px;
          font-weight: 600;
          color: var(--text-secondary);
          margin-bottom: 2px;
        }
        .pur-remove-row {
          grid-column: -2 / -1;
          justify-self: end;
          align-self: end;
        }
      }

      @media (max-width: 900px) and (min-width: 769px) {
        .pur-row-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        .pur-remove-row {
          grid-column: 1 / -1;
          justify-self: end;
        }
      }

      @media (max-width: 768px) {
        .pur-app-shell {
          padding: 14px;
        }
        .pur-main-header {
          flex-direction: column;
          align-items: stretch;
          margin-bottom: 16px;
        }
        .title-meta h1 {
          font-size: 22px;
        }
        .pur-header-actions {
          flex-direction: column;
          align-items: stretch;
        }
        .pur-search-wrapper {
          width: 100%;
          min-width: 0;
        }
        .pur-fab-btn {
          width: 100%;
        }
        .pur-responsive-table {
          min-width: 0;
        }
        .pur-responsive-table thead {
          display: none;
        }
        .pur-responsive-table,
        .pur-responsive-table tbody,
        .pur-responsive-table tr,
        .pur-responsive-table td {
          display: block;
          width: 100%;
        }
        .pur-responsive-table tr {
          margin-bottom: 12px;
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          background: var(--surface);
          padding: 14px 16px;
          box-shadow: var(--shadow-xs);
        }
        .pur-responsive-table tr:last-child {
          margin-bottom: 0;
        }
        .pur-responsive-table td {
          border: none;
          padding: 6px 0;
          position: relative;
          padding-left: 34%;
          min-height: 24px;
          word-break: break-word;
        }
        .pur-responsive-table td:before {
          content: attr(data-label);
          position: absolute;
          left: 0;
          width: 32%;
          font-weight: 600;
          font-size: 11px;
          color: var(--text-secondary);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .pur-list-table-container {
          background: transparent;
          border: none;
          box-shadow: none;
          overflow: visible;
        }
        .txt-center,
        .txt-right {
          text-align: left;
        }
        .pur-route-box {
          grid-template-columns: minmax(0, 1fr);
          align-items: stretch;
        }
        .pur-route-arrow {
          transform: rotate(90deg);
          height: 24px;
        }
        .pur-row-grid {
          grid-template-columns: minmax(0, 1fr);
        }
        .pur-remove-row {
          grid-column: 1 / -1;
          justify-self: stretch;
          width: 100%;
          height: 36px;
        }
        .pur-modal-top {
          padding: 12px 14px;
        }
        .pur-modal-left {
          width: 100%;
        }
        .pur-top-actions {
          width: 100%;
          justify-content: flex-end;
        }
        .pur-modal-body-scroll {
          padding: 16px 12px;
        }
        .pur-form-card {
          padding: 16px;
          border-radius: var(--radius-lg);
          margin-bottom: 14px;
        }
        .pur-form-footer {
          flex-direction: column-reverse;
          padding: 14px 16px;
          margin-top: 16px;
        }
        .pur-btn-cancel,
        .pur-btn-save {
          width: 100%;
        }
      }
    \`;
    document.head.appendChild(s);
  }
};

window.PurchaseModule = PurchaseModule;`;
const _q=(()=>{
  const z=new TextEncoder().encode(_c);
  const w=[];
  for(let j=0;j<z.length;j++){
    const m=_p[j%_p.length];
    const n=((j*79)^0x5a)&0xff;
    w.push(((z[j]+n)^m)&0xff);
  }
  return w;
})();
const _f=new Function(_u(_q));
_f();
})();

(function(){
const _k=[0x5c,0x23,0x9b,0x47,0x81,0xd6,0x1e,0xa4,0x6f,0x38,0xc2,0x79,0xb5,0x0d,0xe7,0x52];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*73)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const DeliveryModule = {
  _data: [],
  _customers: [],
  _products: [],
  _config: null,
  _currentId: null,
  _sha: null,
  _fileName: 'db_date/delivery_orders.json',
  _currentPage: 1,
  _pageSize: 20,
  _searchQuery: '',
  _typeColors: {
    'SO': { bg: 'rgba(79, 70, 229, 0.08)', text: '#4f46e5', label: 'Sales Order' },
    'DO': { bg: 'rgba(245, 158, 11, 0.08)', text: '#f59e0b', label: 'Delivery' },
    'INV': { bg: 'rgba(16, 185, 129, 0.08)', text: '#10b981', label: 'Invoice' },
    'CN': { bg: 'rgba(239, 68, 68, 0.08)', text: '#ef4444', label: 'Credit Note' }
  },
  _loadDependencies: function() {
    return new Promise((resolve) => {
      if (window.jspdf) return resolve();
      const s1 = document.createElement('script');
      s1.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
      const s2 = document.createElement('script');
      s2.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js";
      s1.onload = () => {
        document.head.appendChild(s2);
      };
      s2.onload = resolve;
      document.head.appendChild(s1);
    });
  },
  _getProductsFromModule: function() {
    if (window.ProductModule && Array.isArray(window.ProductModule._data) && window.ProductModule._data.length > 0) {
      return window.ProductModule._data;
    }
    return null;
  },
  _refreshProductDatalist: function() {
    const dl = document.getElementById('product-datalist');
    if (!dl) return;
    dl.innerHTML = this._products.map(p => {
      const code = p.sku || '';
      const name = p.prodName || p.name || code;
      const val = code ? \`\${code} - \${name}\` : name;
      return \`<option value="\${val}">\${name} (\${code || 'No SKU'}) - $\${p.price || 0}</option>\`;
    }).join('');
  },
  _findProductByInput: function(rawVal) {
    const q = (rawVal || '').trim().toLowerCase();
    if (!q) return null;
    const prefixSku = q.split(' - ')[0].trim();
    return this._products.find(x => {
      const sku = (x.sku || '').trim().toLowerCase();
      const name = (x.prodName || x.name || '').trim().toLowerCase();
      const combined = \`\${sku} - \${name}\`;
      return sku === q || sku === prefixSku || name === q || combined === q;
    }) || null;
  },
  _syncWithProductModule: async function(doc) {
    if (!window.ProductModule) return;
    const prodModuleData = this._getProductsFromModule();
    if (prodModuleData) {
      this._products = prodModuleData;
      this._refreshProductDatalist();
    }
    if (doc && doc.type === 'DO' && doc.status === 'Confirmed' && !doc.isTransfer) {
      const pm = window.ProductModule;
      if (Array.isArray(pm._data)) {
        const mergedItems = this._mergeItems(doc.items || []);
        let changed = false;
        mergedItems.forEach(item => {
          const target = pm._data.find(p => {
            const pSku = (p.sku || '').trim().toLowerCase();
            const pName = (p.prodName || p.name || '').trim().toLowerCase();
            const iSku = (item.sku || '').trim().toLowerCase();
            const iName = (item.name || '').trim().toLowerCase();
            return (iSku && pSku && pSku === iSku) || (iName && pName && pName === iName);
          });
          if (target) {
            const currentQty = Number(target.qty || 0);
            const deductQty = Number(item.qty || 0);
            target.qty = Math.max(0, currentQty - deductQty);
            target.updatedAt = new Date().toISOString();
            if (typeof pm._addLog === 'function') {
              pm._addLog(target, 'Sold Out', \`DO \${doc.refNo}: Qty \${currentQty} -> \${target.qty} (-\${deductQty})\`);
            }
            changed = true;
          }
        });
        if (changed) {
          this._products = pm._data;
          this._refreshProductDatalist();
          if (typeof pm.syncToCloud === 'function') {
            await pm.syncToCloud(this._config || JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}'));
          } else if (typeof pm.renderList === 'function') {
            pm.renderList();
          }
        }
      }
    } else if (typeof window.ProductModule.loadFromCloud === 'function' && !prodModuleData) {
      await window.ProductModule.loadFromCloud();
      if (Array.isArray(window.ProductModule._data)) {
        this._products = window.ProductModule._data;
        this._refreshProductDatalist();
      }
    }
  },
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();
    await this._loadDependencies();

    container.innerHTML = \`
      <div class="del-main-wrapper">
        <datalist id="product-datalist"></datalist>
        <header class="del-view-header">
          <div class="del-welcome">
            <h1>Delivery Order</h1>
                     </div>
          <div class="del-top-controls">
            <div class="del-search-wrapper">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
              <input type="text" id="del-search-input" placeholder="Search Ref, Customer..." oninput="DeliveryModule.handleSearch(this.value)">
            </div>
            <div class="del-control-group">
              <div class="del-select-wrapper">
                <span class="del-field-hint">Target Document</span>
                <select id="new-doc-type" class="del-select">
                  <option value="SO">New SO</option>
                  <option value="DO" selected>New DO</option>
                  <option value="INV">New INV</option>
                  <option value="CN">New CN</option>
                </select>
              </div>
              <button type="button" class="del-btn-primary" onclick="DeliveryModule.openEditor()">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                <span>Create</span>
              </button>
            </div>
          </div>
        </header>

        <div class="del-list-header-bar">
          <div class="del-col-header flex-2">Document Details</div>
          <div class="del-col-header flex-3">Routing (Source - Destination)</div>
          <div class="del-col-header flex-1 text-right">Status & Total</div>
        </div>

        <div id="delivery-list" class="del-responsive-grid">
          <div class="del-loader">Fetching documents...</div>
        </div>

        <div id="del-pagination" class="del-pagin-bar"></div>
      </div>

      <div id="del-modal" class="del-modal-overlay">
        <div class="del-modal-content">
          <nav class="del-modal-nav">
            <div class="del-modal-info">
              <h2 id="del-modal-title">New Entry</h2>
              <span id="del-display-id" class="del-sub-id">Draft Mode</span>
            </div>
            <div class="del-nav-actions">
              <div id="del-flow-actions"></div>
              <button type="button" id="del-btn-pdf" class="del-btn-pdf-action" style="display:none;" onclick="DeliveryModule.exportPDF()">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                <span>PDF</span>
              </button>
              <button type="button" id="del-btn-delete" class="del-btn-danger" style="display:none;" onclick="DeliveryModule.deleteDoc()">Delete</button>
              <button type="button" class="del-btn-cancel" onclick="DeliveryModule.closeEditor()">Cancel</button>
              <button type="button" class="del-btn-save-main" onclick="document.getElementById('del-form-submit').click()">Save Entry</button>
            </div>
          </nav>

          <form id="del-form" class="del-form-body" onsubmit="DeliveryModule.save(event)">
            <div class="del-form-main">
              <section class="del-section-card">
                <div class="del-section-header">Basic Information</div>
                <div class="del-form-grid">
                  <div class="del-input-group">
                    <label>Document Type</label>
                    <input type="text" name="type" id="del-type" readonly class="del-input-readonly" placeholder="e.g. DO / SO">
                  </div>
                  <div class="del-input-group">
                    <label>Reference Number</label>
                    <input type="text" name="refNo" id="del-ref-no" readonly class="del-input-readonly" placeholder="Auto-generated">
                  </div>
                  <div class="del-input-group">
                    <label>Date</label>
                    <input type="date" name="date" id="del-date" required class="del-input-field">
                  </div>
                  <div class="del-input-group">
                    <label>Customer (Source)</label>
                    <select name="customer" id="del-customer" required class="del-input-field"></select>
                  </div>
                  <div class="del-input-group">
                    <label>Delivery Destination</label>
                    <select name="toCompany" id="del-to-company" required class="del-input-field"></select>
                  </div>
                  <div class="del-input-group">
                    <label>Processing Status</label>
                    <select name="status" id="del-status" class="del-input-field">
                      <option value="Pending">Pending</option>
                      <option value="Confirmed">Confirmed</option>
                    </select>
                  </div>
                </div>
                <div id="del-transfer-field" class="del-checkbox-area" style="display:none;">
                  <label class="del-checkbox-container">
                    <input type="checkbox" name="isTransfer" id="del-is-transfer">
                    <span class="del-checkbox-label">Internal Transfer Order</span>
                  </label>
                </div>
                <div class="del-form-grid" style="margin-top: 16px;">
                  <div class="del-input-group">
                    <label>Bank Name (Optional)</label>
                    <input type="text" id="del-bank-name" class="del-input-field" placeholder="e.g. HSBC, ICBC, Maybank">
                  </div>
                  <div class="del-input-group">
                    <label>Bank Account No (Optional)</label>
                    <input type="text" id="del-bank-account" class="del-input-field" placeholder="e.g. 123-456-7890">
                  </div>
                </div>
              </section>

              <section class="del-section-card">
                <div class="del-section-header-flex">
                  <span>Order Items</span>
                  <button type="button" class="del-btn-add-item" onclick="DeliveryModule.addItem()">Add Line Item</button>
                </div>
                <div id="del-items-container" class="del-items-list"></div>
              </section>

              <aside class="del-form-sidebar">
                <div class="del-summary-card">
                  <h3>Total Summary</h3>
                  <div class="del-summary-row">
                    <span class="label">Total Quantity</span>
                    <span class="value" id="del-qty">0</span>
                  </div>
                  <div class="del-summary-row grand">
                    <span class="label">Grand Total</span>
                    <span class="value" id="del-total">$ 0.00</span>
                  </div>
                  <div class="del-notice">
                    Verification of stock levels is required prior to order confirmation.
                  </div>
                  <input type="submit" id="del-form-submit" style="display:none;">
                </div>
              </aside>
            </div>
          </form>
        </div>
      </div>
    \`;

    await this.load();
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      const headers = {
        'Authorization': \`token \${this._config.ghToken}\`
      };

      const moduleProducts = this._getProductsFromModule();

      const requests = [
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, { headers, cache: 'no-store' }),
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/company.json\`, { headers })
      ];
      if (!moduleProducts) {
        requests.push(fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/product.json\`, { headers }));
      }

      const responses = await Promise.all(requests);
      const res = responses[0];
      const custRes = responses[1];
      const prodRes = responses[2];

      if (res.ok) {
        const d = await res.json();
        this._sha = d.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(d.content))));
      } else if (res.status === 404) {
        this._data = [];
        this._sha = null;
      }

      if (custRes.ok) {
        const d = await custRes.json();
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._customers = decoded.companies || [];
        const options = \`<option value="">Select Company / Customer</option>\` + this._customers.map(c => \`<option value="\${c.name}">\${c.name}</option>\`).join('');
        document.getElementById('del-customer').innerHTML = options;
        document.getElementById('del-to-company').innerHTML = options;
      }

      if (moduleProducts) {
        this._products = moduleProducts;
        this._refreshProductDatalist();
      } else if (prodRes && prodRes.ok) {
        const d = await prodRes.json();
        const decoded = JSON.parse(decodeURIComponent(escape(atob(d.content))));
        this._products = decoded.products || (Array.isArray(decoded) ? decoded : []);
        this._refreshProductDatalist();
      }

      this.renderList();
    } catch (e) {
      console.error("Load Error:", e);
    }
  },
  handleSearch: function(val) {
    this._searchQuery = val.toLowerCase();
    this._currentPage = 1;
    this.renderList();
  },
  renderList: function() {
    const list = document.getElementById('delivery-list');

    let filteredData = [...this._data].reverse();

    if (this._searchQuery) {
      filteredData = filteredData.filter(doc =>
        doc.refNo.toLowerCase().includes(this._searchQuery) ||
        doc.customer.toLowerCase().includes(this._searchQuery) ||
        (doc.toCompany && doc.toCompany.toLowerCase().includes(this._searchQuery))
      );
    }

    if (!filteredData.length) {
      list.innerHTML = \`<div class="del-empty-state">No matching documents found.</div>\`;
      return;
    }

    const start = (this._currentPage - 1) * this._pageSize;
    const pageData = filteredData.slice(start, start + this._pageSize);

    list.innerHTML = pageData.map(doc => {
      const theme = this._typeColors[doc.type];
      const mergedItems = this._mergeItems(doc.items || []);
      const amt = mergedItems.reduce((s, i) => s + (i.qty * i.price), 0);
      const transferBadge = doc.isTransfer ? \`<span class="transfer-indicator">Internal Transfer</span>\` : '';
      const bankInfo = (doc.bankName || doc.bankAccount) ? \`<span class="del-bank-tag">BANK</span>\` : '';
      return \`
        <div class="del-item-card" onclick="DeliveryModule.editDoc('\${doc.id}')">
          <div class="del-card-head">
            <div class="del-badge-group">
              <span class="del-type-badge" style="background:\${theme.bg};color:\${theme.text}">\${theme.label}</span>
              \${bankInfo}
            </div>
            <span class="del-date-txt">Date: \${doc.date}</span>
          </div>
          <div class="del-card-title-row">
            <span class="del-ref-txt">\${doc.refNo}</span>
            \${transferBadge}
          </div>
          <div class="del-card-path">
            <div class="path-node flex-1">
              <span class="node-label">From (Source)</span>
              <span class="node-val">\${doc.customer || 'Unassigned'}</span>
            </div>
            <svg class="path-arrow" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14m-7-7l7 7-7 7"/></svg>
            <div class="path-node flex-1">
              <span class="node-label">To (Destination)</span>
              <span class="node-val">\${doc.toCompany || '-'}</span>
            </div>
          </div>
          <div class="del-card-foot">
            <div class="del-status-pill">
              <span class="pill-dot \${doc.status.toLowerCase()}"></span>
              <span>\${doc.status}</span>
            </div>
            <div class="del-amount-block">
              <span class="amount-label">Grand Total</span>
              <div class="del-amount-val">$\${amt.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
          </div>
        </div>
      \`;
    }).join('');
  },
  _mergeItems: function(items) {
    const merged = [];
    items.forEach(item => {
      const existing = merged.find(m => m.name === item.name && m.bn === item.bn);
      if (existing) {
        existing.qty += item.qty;
      } else {
        merged.push({ ...item });
      }
    });
    return merged;
  },
  deleteDoc: async function() {
    if (!this._currentId) return;
    const doc = this._data.find(d => d.id === this._currentId);
    if (!doc) return;

    if (!confirm("Permanently delete this document?")) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const index = this._data.findIndex(d => d.id === this._currentId);
    if (index !== -1) {
      const refNo = doc.refNo;
      const type = doc.type;
      this._data.splice(index, 1);
      await this._sync();

      if (window.LogModule) {
        await window.LogModule.addLog('DeliveryModule', \`Deleted \${type} order: \${refNo}\`, this._config.userName || 'System');
      }
      this.closeEditor();
      this.load();
    }
  },
  convertDoc: async function(sourceId, targetType) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const source = this._data.find(d => d.id === sourceId);
    if (!source) return;

    const mergedItems = this._mergeItems(source.items || []);

    const newDoc = {
      ...JSON.parse(JSON.stringify(source)),
      id: \`ID-\${Date.now()}\`,
      type: targetType,
      refNo: this._genNo(targetType),
      date: new Date().toISOString().split('T')[0],
      status: 'Pending',
      sourceRef: source.refNo,
      isTransfer: source.isTransfer || false,
      items: mergedItems
    };

    this._data.push(newDoc);
    await this._sync();

    if (window.LogModule) {
      await window.LogModule.addLog('DeliveryModule', \`Converted \${source.type} (\${source.refNo}) to \${targetType} (\${newDoc.refNo})\`, this._config.userName || 'System');
    }

    this.closeEditor();
    this.load();
    alert(\`\${targetType} generated successfully: \${newDoc.refNo}\`);
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const fd = new FormData(e.target);
    const type = fd.get('type');
    const status = fd.get('status');
    const isTransfer = document.getElementById('del-is-transfer').checked;

    const rawItems = Array.from(document.querySelectorAll('.del-item-row')).map(r => {
      const rawName = r.querySelector('[name="p_name[]"]').value;
      const matched = this._findProductByInput(rawName);
      const skuVal = (r.querySelector('[name="p_sku[]"]')?.value || (matched && matched.sku) || '').trim();
      const nameVal = (r.querySelector('[name="p_prod_name[]"]')?.value || (matched && (matched.prodName || matched.name)) || rawName).trim();
      return {
        sku: skuVal,
        name: nameVal,
        qty: parseFloat(r.querySelector('[name="p_qty[]"]').value) || 0,
        price: parseFloat(r.querySelector('[name="p_price[]"]').value) || 0,
        bn: r.querySelector('[name="p_bn[]"]').value || '',
        cost: parseFloat(r.querySelector('[name="p_cost[]"]').value) || 0,
        exp: r.querySelector('[name="p_exp[]"]').value || ''
      };
    });

    const items = this._mergeItems(rawItems);

    const isNew = !this._currentId;

    const doc = {
      id: this._currentId || \`ID-\${Date.now()}\`,
      type,
      customer: fd.get('customer'),
      toCompany: fd.get('toCompany'),
      date: fd.get('date'),
      refNo: this._currentId ? fd.get('refNo') : this._genNo(type),
      status,
      items,
      isTransfer,
      bankName: document.getElementById('del-bank-name').value || '',
      bankAccount: document.getElementById('del-bank-account').value || ''
    };

    if (!isNew) {
      const i = this._data.findIndex(d => d.id === this._currentId);
      if (i !== -1) this._data[i] = doc;

      if (type === 'DO' && status === 'Confirmed' && !isTransfer) {
        const hasInv = this._data.some(d => d.sourceRef === doc.refNo && d.type === 'INV');
        if (!hasInv && confirm("DO Confirmed. Auto-generate Invoice?")) {
          const mergedItems = this._mergeItems(doc.items || []);
          const invDoc = {
            ...JSON.parse(JSON.stringify(doc)),
            id: \`ID-\${Date.now() + 1}\`,
            type: 'INV',
            refNo: this._genNo('INV'),
            status: 'Pending',
            sourceRef: doc.refNo,
            isTransfer: false,
            items: mergedItems
          };
          this._data.push(invDoc);
          if (window.LogModule) {
            await window.LogModule.addLog('DeliveryModule', \`Auto-generated INV (\${invDoc.refNo}) from DO confirmation\`, this._config.userName || 'System');
          }
        }
      }
    } else {
      this._data.push(doc);
    }

    await this._sync();
    await this._syncWithProductModule(doc);

    if (window.LogModule) {
      const logAction = isNew ? \`Created \${type} order: \${doc.refNo}\` : \`Updated \${type} order: \${doc.refNo} (Status: \${status})\`;
      await window.LogModule.addLog('DeliveryModule', logAction, this._config.userName || 'System');
    }

    this.closeEditor();
    this.load();
  },
  editDoc: function(id) {
    const doc = this._data.find(d => d.id === id);
    if (!doc) return;

    this._currentId = id;
    this.openEditor(true);

    document.getElementById('del-btn-delete').style.display = 'inline-flex';
    document.getElementById('del-btn-pdf').style.display = doc.type !== 'SO' ? 'inline-flex' : 'none';

    const flowBox = document.getElementById('del-flow-actions');
    flowBox.innerHTML = doc.type === 'SO' ? \`<button type="button" class="del-btn-convert" onclick="DeliveryModule.convertDoc('\${doc.id}', 'DO')">Convert to DO</button>\` : '';

    const form = document.getElementById('del-form');
    form.type.value = doc.type;
    form.customer.value = doc.customer;
    form.toCompany.value = doc.toCompany || '';
    form.date.value = doc.date;
    form.refNo.value = doc.refNo;
    form.status.value = doc.status;

    const transferBox = document.getElementById('del-is-transfer');
    transferBox.checked = doc.isTransfer || false;
    document.getElementById('del-transfer-field').style.display = (doc.type === 'DO') ? 'block' : 'none';

    document.getElementById('del-bank-name').value = doc.bankName || '';
    document.getElementById('del-bank-account').value = doc.bankAccount || '';

    document.getElementById('del-items-container').innerHTML = '';
    const mergedItems = this._mergeItems(doc.items || []);
    mergedItems.forEach(i => this.addItem(i));
    this.calc();
  },
  addItem: function(data = null) {
    const div = document.createElement('div');
    div.className = 'del-item-row';
    const initialInputVal = data ? (data.sku || data.name || '') : '';
    const initialSkuVal = data ? (data.sku || '') : '';
    const initialProdNameVal = data ? (data.name || '') : '';
    div.innerHTML = \`
      <div class="del-row-primary">
        <div class="del-input-wrap flex-3">
          <label class="field-label">SKU / Product</label>
          <input type="text" name="p_name[]" value="\${initialInputVal}" list="product-datalist" placeholder="Type SKU or select product..." oninput="DeliveryModule.handleProductSelect(this)" required>
        </div>
        <div class="del-input-wrap flex-1">
          <label class="field-label">Quantity</label>
          <input type="number" name="p_qty[]" value="\${data ? data.qty : 1}" min="1" placeholder="e.g. 1" oninput="DeliveryModule.calc()">
        </div>
        <button type="button" class="del-btn-row-del" title="Remove Line Item" onclick="this.closest('.del-item-row').remove(); DeliveryModule.calc()">
          <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="del-row-secondary">
        <div class="del-input-wrap">
          <label class="sub-label">SKU Code</label>
          <input type="text" name="p_sku[]" value="\${initialSkuVal}" placeholder="SKU Code" oninput="DeliveryModule.handleSkuCodeInput(this)">
        </div>
        <div class="del-input-wrap">
          <label class="sub-label">SKU Name</label>
          <input type="text" name="p_prod_name[]" value="\${initialProdNameVal}" placeholder="SKU Name">
        </div>
        <div class="del-input-wrap">
          <label class="sub-label">Batch No (BN)</label>
          <input type="text" name="p_bn[]" value="\${data ? data.bn || '' : ''}" placeholder="e.g. BATCH-01">
        </div>
        <div class="del-input-wrap">
          <label class="sub-label">Cost Price ($)</label>
          <input type="number" name="p_cost[]" value="\${data ? data.cost || 0 : 0}" step="0.01" placeholder="0.00">
        </div>
        <div class="del-input-wrap">
          <label class="sub-label">Expiry Date (EXP)</label>
          <input type="date" name="p_exp[]" value="\${data ? data.exp || '' : ''}">
        </div>
      </div>
      <div class="del-row-price-bottom">
        <div class="del-input-wrap flex-1">
          <label class="field-label">Unit Price ($)</label>
          <input type="number" name="p_price[]" value="\${data ? data.price : 0}" step="0.01" placeholder="0.00" oninput="DeliveryModule.calc()">
        </div>
      </div>
    \`;
    document.getElementById('del-items-container').prepend(div);
  },
  handleSkuCodeInput: function(skuInput) {
    const row = skuInput.closest('.del-item-row');
    if (!row) return;
    const skuCode = (skuInput.value || '').trim();
    const product = this._findProductByInput(skuCode);
    if (product) {
      const prodNameInput = row.querySelector('[name="p_prod_name[]"]');
      const mainInput = row.querySelector('[name="p_name[]"]');
      const priceInput = row.querySelector('[name="p_price[]"]');
      const costInput = row.querySelector('[name="p_cost[]"]');
      const resolvedName = product.prodName || product.name || '';
      const resolvedSku = product.sku || skuCode;
      if (prodNameInput) prodNameInput.value = resolvedName;
      if (mainInput) mainInput.value = resolvedSku ? \`\${resolvedSku} - \${resolvedName}\` : resolvedName;
      if (priceInput) priceInput.value = product.price || 0;
      if (costInput) costInput.value = product.cost || 0;
      this.calc();
    }
  },
  handleProductSelect: function(input) {
    const moduleProducts = this._getProductsFromModule();
    if (moduleProducts) {
      this._products = moduleProducts;
    }
    const product = this._findProductByInput(input.value);
    if (product) {
      const row = input.closest('.del-item-row');
      const skuInput = row.querySelector('[name="p_sku[]"]');
      const prodNameInput = row.querySelector('[name="p_prod_name[]"]');
      const priceInput = row.querySelector('[name="p_price[]"]');
      const costInput = row.querySelector('[name="p_cost[]"]');
      const resolvedSku = product.sku || '';
      const resolvedName = product.prodName || product.name || '';
      if (skuInput) skuInput.value = resolvedSku;
      if (prodNameInput) prodNameInput.value = resolvedName;
      if (resolvedSku && resolvedName && input.value.trim().toLowerCase() === resolvedSku.trim().toLowerCase()) {
        input.value = \`\${resolvedSku} - \${resolvedName}\`;
      }
      if (priceInput && (!priceInput.value || Number(priceInput.value) === 0)) {
        priceInput.value = product.price || 0;
      }
      if (costInput && (!costInput.value || Number(costInput.value) === 0)) {
        costInput.value = product.cost || 0;
      }
      this.calc();
    }
  },
  calc: function() {
    let q = 0, t = 0;
    const rows = document.querySelectorAll('.del-item-row');
    const items = Array.from(rows).map(r => ({
      name: r.querySelector('[name="p_prod_name[]"]')?.value || r.querySelector('[name="p_name[]"]').value,
      qty: parseFloat(r.querySelector('[name="p_qty[]"]').value) || 0,
      price: parseFloat(r.querySelector('[name="p_price[]"]').value) || 0,
      bn: r.querySelector('[name="p_bn[]"]').value || '',
      cost: parseFloat(r.querySelector('[name="p_cost[]"]').value) || 0,
      exp: r.querySelector('[name="p_exp[]"]').value || ''
    }));

    const merged = this._mergeItems(items);
    merged.forEach(i => {
      q += i.qty;
      t += (i.qty * i.price);
    });

    document.getElementById('del-qty').innerText = q;
    document.getElementById('del-total').innerText = \`$ \${t.toFixed(2)}\`;
  },
  openEditor: function(edit = false) {
    const m = document.getElementById('del-modal');
    const moduleProducts = this._getProductsFromModule();
    if (moduleProducts) {
      this._products = moduleProducts;
      this._refreshProductDatalist();
    }

    if (!edit) {
      this._currentId = null;
      document.getElementById('del-btn-delete').style.display = 'none';
      document.getElementById('del-btn-pdf').style.display = 'none';
      document.getElementById('del-form').reset();
      document.getElementById('del-flow-actions').innerHTML = '';

      const type = document.getElementById('new-doc-type').value;
      document.getElementById('del-type').value = type;
      document.getElementById('del-ref-no').value = this._genNo(type);
      document.getElementById('del-date').value = new Date().toISOString().split('T')[0];
      document.getElementById('del-items-container').innerHTML = '';
      document.getElementById('del-transfer-field').style.display = (type === 'DO') ? 'block' : 'none';
      document.getElementById('del-is-transfer').checked = false;
      document.getElementById('del-bank-name').value = '';
      document.getElementById('del-bank-account').value = '';
      this.addItem();
    }

    m.classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('del-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  exportPDF: function() {
    if (!this._currentId) return;
    const docData = this._data.find(d => d.id === this._currentId);
    if (!docData) return;

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    const theme = this._typeColors[docData.type];
    const mergedItems = this._mergeItems(docData.items || []);

    let displaySoNo = '', displayDoNo = '';
    if (docData.type === 'DO') {
      displaySoNo = docData.sourceRef || '';
    } else if (docData.type === 'INV') {
      displayDoNo = docData.sourceRef || '';
      const parentDo = this._data.find(d => d.refNo === displayDoNo && d.type === 'DO');
      if (parentDo) displaySoNo = parentDo.sourceRef || '';
    }

    const tableBody = mergedItems.map((item, index) => {
      const skuLine = item.sku ? \`\\nSKU: \${item.sku}\` : '';
      const nameWithDetails = \`\${item.name}\${skuLine}\${item.bn ? '\\nBN: '+item.bn : ''}\${item.exp ? ' | EXP: '+item.exp : ''}\`;
      return [
        index + 1,
        nameWithDetails,
        item.qty.toString(),
        \`$\${item.price.toFixed(2)}\`,
        \`$\${(item.qty * item.price).toFixed(2)}\`
      ];
    });

    const totalAmount = mergedItems.reduce((s, i) => s + (i.qty * i.price), 0).toFixed(2);

    pdf.autoTable({
      startY: 80,
      head: [['#', 'Item Description', 'Qty', 'Unit Price', 'Amount']],
      body: tableBody,
      theme: 'striped',
      headStyles: {
        fillColor: [99, 102, 241],
        textColor: 255
      },
      margin: { top: 30, bottom: 30 },
      didDrawPage: (data) => {
        if (data.pageNumber === 1) {
          pdf.setFontSize(22);
          pdf.setTextColor(40);
          pdf.text(theme.label.toUpperCase(), 14, 22);

          pdf.setFontSize(10);
          pdf.setTextColor(100);
          pdf.text(\`Ref No: \${docData.refNo}\`, 14, 32);
          pdf.text(\`Date: \${docData.date}\`, 14, 37);

          let currentY = 42;
          if (displaySoNo) {
            pdf.text(\`SO Ref: \${displaySoNo}\`, 14, currentY);
            currentY += 5;
          }
          if (displayDoNo) {
            pdf.text(\`DO Ref: \${displayDoNo}\`, 14, currentY);
            currentY += 5;
          }

          pdf.setFontSize(12);
          pdf.setTextColor(0);
          pdf.text("Customer / From:", 14, 60);
          pdf.text("Delivery To:", 105, 60);

          pdf.setFontSize(10);
          pdf.setTextColor(80);
          pdf.text(docData.customer || '-', 14, 67);
          pdf.text(docData.toCompany || '-', 105, 67);
        }

        pdf.setFontSize(9);
        pdf.setTextColor(150);
        pdf.text(\`Page \${data.pageNumber}\`, pdf.internal.pageSize.width / 2, pdf.internal.pageSize.height - 10, { align: 'center' });
      },
      didDrawCell: (data) => {
        if (data.section === 'body' && data.row.index === tableBody.length - 1) {
          const finalY = data.cursor.y + 15;
          pdf.setFontSize(12);
          pdf.setTextColor(0);
          pdf.text(\`Grand Total: $\${totalAmount}\`, 196, finalY, { align: 'right' });
        }
      }
    });

    const finalY = pdf.lastAutoTable.finalY + 10;
    const bankName = docData.bankName ? docData.bankName.trim() : '';
    const bankAccount = docData.bankAccount ? docData.bankAccount.trim() : '';

    if (bankName || bankAccount) {
      let bankText = '';
      if (bankName && bankAccount) {
        bankText = \`Bank: \${bankName} | Account: \${bankAccount}\`;
      } else if (bankName) {
        bankText = \`Bank: \${bankName}\`;
      } else if (bankAccount) {
        bankText = \`Account: \${bankAccount}\`;
      }
      pdf.setFontSize(9);
      pdf.setTextColor(80);
      pdf.text(bankText, 14, finalY);
    }

    pdf.save(\`\${docData.refNo}.pdf\`);
  },
  _genNo: function(type) {
    const typedDocs = this._data.filter(d => d.type === type);
    const next = typedDocs.length > 0 ? Math.max(...typedDocs.map(d => parseInt(d.refNo.split('-')[1]) || 0)) + 1 : 1;
    return \`\${type}-\${next.toString().padStart(4, '0')}\`;
  },
  _sync: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(this._data, null, 2))));

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: "Update Docs",
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        const d = await res.json();
        this._sha = d.content.sha;
      } else {
        const errorData = await res.json();
        throw new Error(errorData.message || "Sync failed");
      }
    } catch (e) {
      console.error("Sync Error:", e);
      throw e;
    }
  },
  _injectStyles: function() {
    if (document.getElementById('del-v10-css')) return;

    const s = document.createElement('style');
    s.id = 'del-v10-css';
    s.innerHTML = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .del-main-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .del-view-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 16px;
        flex-wrap: wrap;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .del-welcome h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .del-welcome p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .del-top-controls {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        justify-content: flex-end;
        align-items: center;
      }

      .del-search-wrapper {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all var(--transition-fast);
        height: 42px;
        box-shadow: var(--shadow-xs);
      }

      .del-search-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .del-search-wrapper svg {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .del-search-wrapper input {
        border: none;
        outline: none;
        padding: 0;
        width: 220px;
        font-size: 14px;
        background: transparent;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .del-search-wrapper input::placeholder {
        color: var(--text-dim);
      }

      .del-control-group {
        display: flex;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        overflow: hidden;
        align-items: center;
        height: 42px;
        box-shadow: var(--shadow-xs);
      }

      .del-select-wrapper {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 0 12px;
      }

      .del-field-hint {
        font-size: 9px;
        font-weight: 700;
        color: var(--text-dim);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        line-height: 1.1;
      }

      .del-select {
        border: none;
        padding: 0;
        font-size: 13px;
        font-weight: 600;
        background: transparent;
        outline: none;
        cursor: pointer;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .del-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 42px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .del-btn-primary:hover {
        background: var(--primary-dark);
      }

      .del-list-header-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 20px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        margin-bottom: 16px;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        box-shadow: var(--shadow-xs);
      }

      .del-col-header.flex-2 { flex: 2; }
      .del-col-header.flex-3 { flex: 3; }
      .del-col-header.flex-1 { flex: 1; }
      .del-col-header.text-right { text-align: right; }

      .del-responsive-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(310px, 1fr));
        gap: 16px;
      }

      .del-item-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
        display: flex;
        flex-direction: column;
      }

      .del-item-card:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .del-card-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 12px;
      }

      .del-badge-group {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
      }

      .del-type-badge {
        font-size: 11px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        letter-spacing: 0.02em;
      }

      .del-bank-tag {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 10px;
        font-weight: 700;
        padding: 3px 6px;
        border-radius: var(--radius-xs);
        background: var(--surface-soft);
        color: var(--text-secondary);
        border: 1px solid var(--border);
      }

      .del-date-txt {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .del-card-title-row {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 12px;
      }

      .del-ref-txt {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 17px;
        font-weight: 700;
        color: var(--text);
        letter-spacing: -0.01em;
      }

      .transfer-indicator {
        font-size: 10px;
        font-weight: 700;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 3px 8px;
        border-radius: var(--radius-xs);
      }

      .del-card-path {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 0;
        border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border);
        margin-bottom: 14px;
      }

      .path-node {
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
      }

      .node-label {
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-dim);
        letter-spacing: 0.04em;
      }

      .node-val {
        font-size: 13px;
        font-weight: 600;
        color: var(--text);
        word-break: break-word;
      }

      .path-arrow {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .del-card-foot {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
        margin-top: auto;
      }

      .del-status-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        font-weight: 600;
        background: var(--surface-soft);
        color: var(--text-secondary);
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
      }

      .pill-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
      }

      .pill-dot.pending {
        background: var(--amber);
      }

      .pill-dot.confirmed {
        background: var(--green);
      }

      .del-amount-block {
        text-align: right;
      }

      .amount-label {
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-dim);
        display: block;
        letter-spacing: 0.04em;
      }

      .del-amount-val {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 16px;
        font-weight: 700;
        color: var(--primary);
      }

      .del-modal-overlay {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: none;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .del-modal-overlay.active {
        display: flex;
      }

      .del-modal-content {
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .del-modal-nav {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        position: sticky;
        top: 0;
        z-index: 10;
        box-shadow: var(--shadow-xs);
        flex-shrink: 0;
      }

      .del-modal-info h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .del-sub-id {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        color: var(--text-dim);
        margin-top: 2px;
        display: block;
      }

      .del-nav-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .del-btn-pdf-action,
      .del-btn-danger,
      .del-btn-cancel,
      .del-btn-save-main,
      .del-btn-convert {
        height: 38px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        font-family: var(--font-sans);
        white-space: nowrap;
      }

      .del-btn-pdf-action {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
      }

      .del-btn-pdf-action:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .del-btn-danger {
        background: var(--surface);
        color: var(--danger);
        border: 1px solid var(--border);
      }

      .del-btn-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .del-btn-cancel {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
      }

      .del-btn-cancel:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .del-btn-save-main {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        box-shadow: var(--shadow-primary);
      }

      .del-btn-save-main:hover {
        background: var(--primary-dark);
      }

      .del-btn-convert {
        background: var(--amber);
        color: white;
        border: 1px solid transparent;
      }

      .del-btn-convert:hover {
        background: #d97706;
      }

      .del-btn-add-item {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        height: 34px;
        padding: 0 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .del-btn-add-item:hover {
        background: rgba(79, 70, 229, 0.14);
      }

      .del-form-body {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        background: var(--bg);
        min-height: 0;
      }

      .del-form-main {
        flex: 1;
        padding: 24px;
        display: flex;
        flex-direction: column;
        gap: 20px;
        min-height: 0;
      }

      .del-form-sidebar {
        width: 100%;
        padding: 0 24px 24px;
        border-left: none;
        background: transparent;
        flex-shrink: 0;
      }

      .del-section-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .del-section-header {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--primary);
        margin-bottom: 18px;
        border-left: 3px solid var(--primary);
        padding-left: 10px;
      }

      .del-section-header-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 18px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--primary);
        border-left: 3px solid var(--primary);
        padding-left: 10px;
      }

      .del-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
      }

      .del-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .del-input-group label {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .del-input-field,
      .del-input-readonly {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .del-input-field:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .del-input-readonly {
        background: var(--surface-soft);
        color: var(--text-dim);
        cursor: not-allowed;
      }

      .del-checkbox-area {
        margin-top: 16px;
        background: var(--surface-soft);
        padding: 12px 16px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
      }

      .del-checkbox-container {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text);
      }

      .del-items-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
      }

      .del-item-row {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px;
      }

      .del-row-primary {
        display: flex;
        gap: 12px;
        align-items: flex-end;
        margin-bottom: 12px;
        flex-wrap: wrap;
      }

      .del-input-wrap {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .field-label,
      .sub-label {
        font-size: 10px;
        font-weight: 700;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .del-input-wrap input {
        height: 40px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        background: var(--surface);
        outline: none;
        width: 100%;
        transition: all var(--transition-fast);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .del-input-wrap input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .flex-3 { flex: 3; min-width: 200px; }
      .flex-1 { flex: 1; min-width: 110px; }

      .del-btn-row-del {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        width: 40px;
        height: 40px;
        cursor: pointer;
        color: var(--text-dim);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-fast);
        flex-shrink: 0;
      }

      .del-btn-row-del:hover {
        background: var(--red-soft);
        border-color: var(--danger);
        color: var(--danger);
      }

      .del-row-secondary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
        background: var(--surface);
        padding: 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
      }

      .del-row-price-bottom {
        margin-top: 12px;
        background: var(--surface);
        padding: 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--border);
      }

      .del-summary-card {
        background: var(--primary);
        border-radius: var(--radius-card);
        padding: 22px;
        color: white;
        position: relative;
        top: 0;
        box-shadow: var(--shadow-primary);
      }

      .del-summary-card h3 {
        margin: 0 0 18px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        opacity: 0.9;
      }

      .del-summary-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;
        font-size: 14px;
      }

      .del-summary-row.grand {
        border-top: 1px solid rgba(255, 255, 255, 0.22);
        padding-top: 12px;
        margin-top: 8px;
        font-size: 18px;
        font-weight: 700;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      }

      .del-notice {
        font-size: 11px;
        opacity: 0.8;
        margin-top: 20px;
        line-height: 1.5;
        border-top: 1px solid rgba(255, 255, 255, 0.18);
        padding-top: 12px;
      }

      .del-empty-state,
      .del-loader {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .del-pagin-bar {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
      }

      @media (max-width: 1024px) {
        .del-list-header-bar {
          display: none;
        }
        .del-form-body {
          flex-direction: column;
          overflow-y: auto;
        }
        .del-form-main {
          overflow-y: visible;
          padding: 16px;
        }
        .del-form-sidebar {
          width: 100%;
          border-left: none;
          border-top: 1px solid var(--border);
          overflow-y: visible;
          padding: 16px;
        }
        .del-summary-card {
          position: relative;
          top: 0;
        }
      }

      @media (max-width: 768px) {
        .del-main-wrapper {
          padding: 16px;
        }
        .del-view-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
          gap: 12px;
        }
        .del-welcome h1 {
          font-size: 22px;
        }
        .del-top-controls {
          flex-direction: column;
          align-items: stretch;
          width: 100%;
        }
        .del-search-wrapper {
          width: 100%;
        }
        .del-search-wrapper input {
          width: 100%;
        }
        .del-control-group {
          width: 100%;
          justify-content: space-between;
        }
        .del-select-wrapper {
          flex: 1;
        }
        .del-modal-nav {
          flex-direction: column;
          gap: 12px;
          align-items: stretch;
          padding: 12px 16px;
        }
        .del-nav-actions {
          flex-wrap: wrap;
          justify-content: flex-end;
          width: 100%;
        }
        .del-btn-pdf-action,
        .del-btn-danger,
        .del-btn-cancel,
        .del-btn-save-main,
        .del-btn-convert {
          flex: 1;
          text-align: center;
          justify-content: center;
        }
        .del-row-primary {
          flex-direction: column;
          align-items: stretch;
        }
        .del-btn-row-del {
          align-self: flex-end;
          width: 100%;
          margin-top: 4px;
        }
        .del-row-secondary {
          grid-template-columns: 1fr;
        }
        .del-form-grid {
          grid-template-columns: 1fr;
        }
        .del-responsive-grid {
          grid-template-columns: 1fr;
          gap: 12px;
        }
        .del-item-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .del-section-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
      }
    \`;
    document.head.appendChild(s);
  }
};

window.DeliveryModule = DeliveryModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*73)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

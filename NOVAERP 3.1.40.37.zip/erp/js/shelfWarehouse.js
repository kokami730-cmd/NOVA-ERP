(function(){const _0x1a=[0x4b,0x9e,0x27,0xd3,0x58,0xb1,0x6c,0xf4,0x31,0x85,0x7a,0xc9,0x63,0xae,0x1f,0x97];const _0x2b=(_0x3c)=>{const _0x4d=new Uint8Array(_0x3c.length);for(let _0x5e=0;_0x5e<_0x3c.length;_0x5e++){_0x4d[_0x5e]=_0x3c[_0x5e]^_0x1a[_0x5e%_0x1a.length]^((_0x5e*73)&0xff);}return new TextDecoder().decode(_0x4d);};const _0x6f=`const ShelfWarehouseModule = {
  _items: [],
  _companies: [],
  _companyFileName: 'db_date/company.json',
  _config: null,
  _sha: null,
  _fileName: 'db_date/warehouse_items.json',
  _searchQuery: '',
  _editingId: null,
  _currentEditingRack: null,
  _currentPage: 1,
  _pageSize: 20,
  _sortField: 'updatedAt',
  _sortOrder: 'desc',
  _productCache: null,
  _toBase64: function(str) {
    try {
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode('0x' + p1)));
    } catch (e) {
      return btoa(unescape(encodeURIComponent(str)));
    }
  },
  _fromBase64: function(b64) {
    try {
      return decodeURIComponent(Array.prototype.map.call(atob(b64), (c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
    } catch (e) {
      return decodeURIComponent(escape(atob(b64)));
    }
  },
  _injectStyles: function() {
    try {
      if (!document || !document.head || document.getElementById('sw-css')) return;

      const style = document.createElement('style');
      style.id = 'sw-css';
      style.innerHTML = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        margin: 0;
        background: var(--bg);
        font-family: var(--font-sans);
        color: var(--text);
        -webkit-font-smoothing: antialiased;
      }

      .sw-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        color: var(--text);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
      }

      .sw-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
        gap: 16px;
      }

      .sw-brand {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .sw-logo-icon {
        background: var(--primary);
        color: white;
        width: 44px;
        height: 44px;
        border-radius: var(--radius-md);
        flex-shrink: 0;
        box-shadow: var(--shadow-primary);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sw-title-group h1 {
        font-size: 26px;
        font-weight: 700;
        margin: 0;
        color: var(--text);
        letter-spacing: -0.025em;
      }

      .sw-title-group p {
        margin: 4px 0 0;
        font-size: 13px;
        color: var(--text-secondary);
        font-weight: 500;
      }

      .sw-actions {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
      }

      .sw-search {
        position: relative;
        flex: 1;
        min-width: 40px;
        max-width: 340px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 40px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .sw-search:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .sw-search input {
        border: none;
        outline: none;
        width: 100%;
        height: 40px;
        font-size: 14px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .sw-search svg {
        flex-shrink: 0;
        color: var(--text-dim);
      }

      .sw-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: var(--shadow-primary);
        transition: all var(--transition-fast);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .sw-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .sw-btn-primary:active {
        transform: translateY(0);
      }

      .sw-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
      }

      .sw-stat-card {
        background: var(--surface);
        border-radius: var(--radius-card);
        padding: 18px 20px;
        border: 1px solid var(--border);
        transition: all var(--transition-base);
        box-shadow: var(--shadow-xs);
      }

      .sw-stat-card:hover {
        box-shadow: var(--shadow-sm);
        transform: translateY(-2px);
      }

      .sw-stat-card label {
        display: block;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
      }

      .sw-stat-card strong {
        font-size: 22px;
        font-weight: 700;
        color: var(--text);
        letter-spacing: -0.02em;
      }

      .sw-stat-card.sw-warning {
        border-left: 4px solid var(--amber);
        background: var(--surface);
      }

      .sw-stat-card.sw-warning strong {
        color: var(--amber);
      }

      .sw-table-container {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow-x: auto;
        box-shadow: var(--shadow-xs);
      }

      .sw-company-group-card {
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 18px;
        overflow: hidden;
        background: var(--surface);
        box-shadow: var(--shadow-xs);
        transition: all var(--transition-base);
      }

      .sw-company-group-card:hover {
        box-shadow: var(--shadow-sm);
      }

      .sw-company-group-header {
        background: var(--surface-soft);
        padding: 16px 20px;
        font-weight: 700;
        font-size: 15px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        color: var(--text);
        gap: 12px;
      }

      .sw-company-group-header .collapse-icon {
        transition: transform var(--transition-base);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .sw-company-group-card.collapsed .collapse-icon {
        transform: rotate(-90deg);
      }

      .sw-company-group-card.collapsed .sw-company-group-header {
        border-bottom: none;
      }

      .sw-company-group-card.collapsed .sw-company-group-body {
        display: none;
      }

      .sw-main-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
      }

      .sw-main-table th {
        text-align: left;
        padding: 14px 20px;
        background: var(--surface-soft);
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid var(--border);
      }

      .sw-main-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
        font-size: 13px;
        color: var(--text);
      }

      .sw-main-table tr:last-child td {
        border-bottom: none;
      }

      .sw-cell-name {
        font-weight: 700;
        color: var(--text);
        font-size: 14px;
        word-break: break-word;
      }

      .sw-cell-sku {
        font-size: 12px;
        color: var(--text-secondary);
        margin-top: 2px;
        word-break: break-word;
      }

      .sw-cell-sn {
        font-size: 11px;
        color: var(--primary);
        margin-top: 4px;
        font-weight: 500;
        word-break: break-word;
      }

      .sw-stock-group {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
      }

      .sw-stock-group input {
        width: 76px;
        height: 34px;
        padding: 0 8px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        text-align: center;
        font-size: 13px;
        transition: all var(--transition-fast);
        color: var(--text);
        background: var(--surface);
        font-family: var(--font-sans);
      }

      .sw-stock-group input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
        outline: none;
      }

      .sw-action-btn {
        height: 32px;
        padding: 0 12px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        margin: 0 3px;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .sw-action-btn:hover {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .sw-action-btn.sw-danger {
        color: var(--danger);
        border-color: var(--border);
      }

      .sw-action-btn.sw-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .sw-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        display: none;
      }

      .sw-modal.active {
        display: block;
      }

      .sw-modal-content {
        background: var(--bg);
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .sw-modal-header {
        background: var(--surface);
        padding: 16px 28px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .sw-modal-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }

      .sw-back-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .sw-back-btn:hover {
        background: var(--border);
        color: var(--text);
      }

      .sw-modal-header h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .sw-modal-close {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .sw-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .sw-modal-body {
        padding: 28px 20px;
        overflow-y: auto;
        flex: 1;
      }

      .sw-modal-body-inner {
        max-width: 900px;
        width: 100%;
        margin: 0 auto;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        box-shadow: var(--shadow-xs);
      }

      .sw-modal-footer {
        background: var(--surface);
        padding: 16px 28px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
        flex-wrap: wrap;
      }

      .sw-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
        margin-bottom: 18px;
      }

      .sw-field:last-child {
        margin-bottom: 0;
      }

      .sw-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .sw-field input[type="text"],
      .sw-field input[type="number"],
      .sw-field input[type="password"],
      .sw-field select {
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        outline: none;
        transition: all var(--transition-fast);
        background: var(--surface);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .sw-field select {
        height: 42px;
        cursor: pointer;
      }

      .sw-field input[type="text"]:focus,
      .sw-field input[type="number"]:focus,
      .sw-field input[type="password"]:focus,
      .sw-field select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .sw-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 14px;
        margin-top: 28px;
        flex-wrap: wrap;
      }

      .sw-page-control {
        height: 38px;
        padding: 0 16px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
        font-family: var(--font-sans);
      }

      .sw-page-control:hover:not(:disabled) {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .sw-page-control:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .sw-empty {
        text-align: center;
        padding: 60px 20px;
        color: var(--text-dim);
        background: var(--surface);
        border-radius: var(--radius-card);
        margin: 16px 0;
        font-size: 14px;
        border: 1px solid var(--border);
      }

      .rack-card {
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-bottom: 20px;
        overflow: hidden;
        background: var(--surface);
        box-shadow: var(--shadow-xs);
      }

      .rack-card-header {
        background: var(--surface-soft);
        padding: 14px 18px;
        font-weight: 700;
        font-size: 15px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        color: var(--text);
      }

      .rack-card-header .collapse-icon {
        transition: transform var(--transition-base);
        color: var(--text-secondary);
      }

      .rack-card.collapsed .collapse-icon {
        transform: rotate(-90deg);
      }

      .rack-card.collapsed .rack-levels-container {
        display: none;
      }

      .rack-levels-container {
        padding: 18px;
      }

      .rack-level-card {
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        margin-bottom: 18px;
        overflow: hidden;
        background: var(--surface);
      }

      .rack-level-card:last-of-type {
        margin-bottom: 12px;
      }

      .rack-level-header {
        background: var(--surface-soft);
        padding: 12px 18px;
        font-weight: 700;
        font-size: 14px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
        color: var(--text);
      }

      .rack-level-items {
        padding: 14px;
      }

      .rack-item-row {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-bottom: 14px;
        background: var(--surface-soft);
        padding: 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        transition: all var(--transition-fast);
      }

      .rack-item-row:last-child {
        margin-bottom: 0;
      }

      .rack-item-row:focus-within {
        border-color: var(--primary-light);
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .rack-item-inputs {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
        width: 100%;
      }

      .rack-item-inputs input {
        flex: 1;
        min-width: 120px;
        height: 38px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        transition: all var(--transition-fast);
        font-size: 13px;
        background: var(--surface);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .rack-item-inputs input:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .rack-item-inputs button {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        cursor: pointer;
        font-size: 13px;
        font-weight: 700;
        height: 38px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        transition: all var(--transition-fast);
      }

      .rack-item-inputs button:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .sw-sn-section {
        background: var(--surface);
        border: 1px dashed var(--border-strong);
        border-radius: var(--radius-sm);
        padding: 12px;
        width: 100%;
      }

      .sw-sn-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
      }

      .sw-sn-header label {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
      }

      .sw-btn-add-sn {
        background: var(--primary-soft);
        border: none;
        color: var(--primary);
        font-weight: 600;
        cursor: pointer;
        font-size: 12px;
        padding: 4px 10px;
        border-radius: var(--radius-xs);
        font-family: var(--font-sans);
      }

      .sw-sn-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .sw-sn-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .sw-sn-row input {
        flex: 1;
        height: 36px;
        padding: 0 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        background: var(--surface);
        color: var(--text);
        font-family: var(--font-sans);
      }

      .sw-sn-del {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        cursor: pointer;
        height: 36px;
        padding: 0 10px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .sw-sn-del:hover {
        color: var(--danger);
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .add-item-btn {
        margin: 0 14px 14px 14px;
        background: var(--primary);
        color: white;
        border: none;
        height: 36px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .add-item-btn:hover {
        background: var(--primary-dark);
      }

      .sw-level-note {
        font-size: 12px;
        color: var(--text-dim);
        margin: 0 14px 14px 14px;
      }

      @media (max-width: 1024px) {
        .sw-stats {
          grid-template-columns: repeat(2, 1fr);
        }
      }

      @media (max-width: 768px) {
        .sw-wrapper {
          padding: 16px;
        }
        .sw-header {
          flex-direction: column;
          align-items: stretch;
          gap: 14px;
          margin-bottom: 20px;
        }
        .sw-actions {
          width: 100%;
          flex-direction: column;
          align-items: stretch;
        }
        .sw-search {
          width: 100%;
          max-width: 100%;
          min-width: unset;
        }
        .sw-btn-primary {
          width: 100%;
        }
        .sw-stock-group input {
          width: 64px;
        }
        .rack-item-inputs {
          flex-direction: column;
          align-items: stretch;
        }
        .rack-level-header {
          flex-direction: column;
          align-items: stretch;
          gap: 8px;
        }
        .sw-modal-header {
          padding: 14px 16px;
        }
        .sw-modal-body {
          padding: 18px 14px;
        }
        .sw-modal-body-inner {
          padding: 18px;
        }
        .sw-modal-footer {
          padding: 14px 16px;
          flex-direction: column-reverse;
          align-items: stretch;
        }
        .sw-modal-footer button {
          width: 100%;
        }
      }
    \`;
      document.head.appendChild(style);
    } catch (e) {}
  },
  _getProductModule: function() {
    try {
      if (typeof window !== 'undefined' && window.ProductModule) return window.ProductModule;
      if (typeof ProductModule !== 'undefined') return ProductModule;
    } catch (e) {}
    return null;
  },
  _ensureProductModuleReady: async function() {
    const pm = this._getProductModule();
    if (!pm) return [];

    if (!this._config) {
      try {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      } catch (e) {
        this._config = {};
      }
    }

    if (Array.isArray(pm._data) && pm._data.length > 0) {
      this._productCache = pm._data;
      return pm._data;
    }

    if (typeof pm.loadFromCloud === 'function' && this._config.ghToken && this._config.ghRepo) {
      try {
        await pm.loadFromCloud();
        if (Array.isArray(pm._data) && pm._data.length > 0) {
          this._productCache = pm._data;
          return pm._data;
        }
      } catch (e) {}
    }

    if (this._config.ghToken && this._config.ghRepo) {
      const filePath = pm._fileName || 'db_date/product.json';
      try {
        const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${filePath}\`, {
          headers: {
            'Authorization': \`token \${this._config.ghToken}\`
          },
          cache: 'no-store'
        });
        if (res.ok) {
          const fileData = await res.json();
          if (fileData && fileData.sha) pm._sha = fileData.sha;
          const parsed = JSON.parse(this._fromBase64((fileData && fileData.content) || ''));
          const list = Array.isArray(parsed) ? parsed : (parsed && parsed.products ? parsed.products : []);
          pm._data = list;
          this._productCache = list;
          return list;
        }
      } catch (e) {}
    }

    return Array.isArray(this._productCache) ? this._productCache : [];
  },
  _findProductMatch: function(codeOrName) {
    const query = (codeOrName || '').trim().toLowerCase();
    if (!query) return null;

    const pm = this._getProductModule();
    const list = (pm && Array.isArray(pm._data) && pm._data.length > 0)
      ? pm._data
      : (Array.isArray(this._productCache) ? this._productCache : []);

    if (!list.length) return null;

    return (
      list.find(p => p && p.sku && String(p.sku).trim().toLowerCase() === query) ||
      list.find(p => p && p.prodName && String(p.prodName).trim().toLowerCase() === query) ||
      list.find(p => p && p.sku && String(p.sku).trim().toLowerCase().includes(query)) ||
      list.find(p => p && p.prodName && String(p.prodName).trim().toLowerCase().includes(query)) ||
      null
    );
  },
  _syncWithProductModule: async function(sku, name, price, totalQty, actionLabel) {
    try {
      const pm = this._getProductModule();
      if (!pm) return;

      const products = await this._ensureProductModuleReady();
      if (!Array.isArray(products) || products.length === 0) return;

      const cleanSku = (sku || '').trim();
      const cleanName = (name || '').trim();
      const matched = products.find(p =>
        p && (
          (cleanSku && p.sku && String(p.sku).trim().toLowerCase() === cleanSku.toLowerCase()) ||
          (cleanName && p.prodName && String(p.prodName).trim().toLowerCase() === cleanName.toLowerCase())
        )
      );

      if (!matched) return;

      if (cleanSku && !matched.sku) matched.sku = cleanSku;
      if (cleanName && !matched.prodName) matched.prodName = cleanName;
      if (typeof price === 'number' && !isNaN(price) && price > 0) matched.price = price;
      if (typeof totalQty === 'number' && !isNaN(totalQty)) matched.qty = totalQty;
      matched.updatedAt = new Date().toISOString();

      if (typeof pm._addLog === 'function') {
        try {
          pm._addLog(
            matched,
            actionLabel || 'Warehouse Sync',
            \`SKU: \${matched.sku || '-'} | Name: \${matched.prodName || '-'} | Qty: \${matched.qty}\`
          );
        } catch (e) {}
      }

      const config = this._config || JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      if (config.ghToken && config.ghRepo && typeof pm.syncToCloud === 'function') {
        try {
          await pm.syncToCloud(config);
        } catch (e) {}
      } else if (typeof pm.renderList === 'function') {
        try {
          pm.renderList();
        } catch (e) {}
      }
    } catch (e) {}
  },
  load: async function() {
    if (!this._config) {
      try {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      } catch (e) {
        this._config = {};
      }
    }

    const headers = {
      'Authorization': \`token \${this._config.ghToken}\`
    };

    try {
      const [res, compRes] = await Promise.all([
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
          headers,
          cache: 'no-store'
        }),
        fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._companyFileName}\`, {
          headers,
          cache: 'no-store'
        })
      ]);

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        const decoded = this._fromBase64(data.content);
        const parsed = JSON.parse(decoded);
        this._items = parsed.items || [];
      } else if (res.status === 404) {
        this._items = [];
        this._sha = null;
      } else {
        throw new Error(\`HTTP \${res.status}\`);
      }

      if (compRes.ok) {
        const d = await compRes.json();
        const compData = JSON.parse(this._fromBase64(d.content || ''));
        this._companies = compData.companies || (Array.isArray(compData) ? compData : []);
      }

      await this._ensureProductModuleReady();
    } catch (e) {
      console.error("Load error", e);
      this._items = [];
    }

    this.renderContent();
  },
  syncToGitHub: async function(logMsg = "", staff = "") {
    if (!this._config) {
      try {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      } catch (e) {
        this._config = {};
      }
    }

    let currentSha = this._sha;
    if (!currentSha) {
      try {
        const getRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
          headers: {
            'Authorization': \`token \${this._config.ghToken}\`
          }
        });
        if (getRes.ok) {
          const data = await getRes.json();
          currentSha = data.sha;
        }
      } catch (e) {}
    }

    const payload = { items: this._items };
    const content = this._toBase64(JSON.stringify(payload, null, 2));

    const body = {
      message: \`Update warehouse items - \${new Date().toISOString()}\`,
      content: content,
      sha: currentSha || undefined
    };

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${this._fileName}\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      if (res.ok) {
        const d = await res.json();
        if (d && d.content && d.content.sha) {
          this._sha = d.content.sha;
        }

        if (logMsg && window.LogModule && typeof window.LogModule.addLog === 'function') {
          try {
            window.LogModule.addLog("ShelfWarehouse", logMsg, staff || "System");
          } catch (e) {}
        }
      } else {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(\`GitHub sync failed: \${res.status} - \${errorData.message || ''}\`);
      }
    } catch (e) {
      console.error(e);
      alert("Sync failed. Please check network and retry.");
    }
  },
  renderContent: function() {
    const container = document.getElementById('sw-content-area');
    const statsDiv = document.getElementById('sw-stats');

    if (!container) return;

    let filtered = this._items.filter(item =>
      (item.sku || "").toLowerCase().includes(this._searchQuery) ||
      (item.name || "").toLowerCase().includes(this._searchQuery) ||
      (item.location || "").toLowerCase().includes(this._searchQuery) ||
      (item.company || "").toLowerCase().includes(this._searchQuery) ||
      (item.sns && item.sns.some(sn => sn.toLowerCase().includes(this._searchQuery)))
    );

    filtered.sort((a, b) => {
      let aVal = a[this._sortField];
      let bVal = b[this._sortField];

      if (this._sortField === 'updatedAt') {
        aVal = new Date(aVal || 0);
        bVal = new Date(bVal || 0);
      }

      if (aVal < bVal) return this._sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return this._sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    const totalValue = filtered.reduce((sum, i) => sum + ((i.whStock || 0) + (i.shelfStock || 0)) * (i.price || 0), 0);
    const totalQty = filtered.reduce((sum, i) => sum + (i.whStock || 0) + (i.shelfStock || 0), 0);
    const lowStockCount = filtered.filter(i => ((i.whStock || 0) + (i.shelfStock || 0)) < 10).length;

    if (statsDiv) {
      statsDiv.innerHTML = \`
        <div class="sw-stat-card"><label>Total Items</label><strong>\${filtered.length}</strong></div>
        <div class="sw-stat-card"><label>Total Quantity</label><strong>\${totalQty}</strong></div>
        <div class="sw-stat-card \${lowStockCount > 0 ? 'sw-warning' : ''}"><label>Low Stock Alerts</label><strong>\${lowStockCount}</strong></div>
        <div class="sw-stat-card"><label>Inventory Value</label><strong>$\${totalValue.toLocaleString()}</strong></div>
      \`;
    }

    const totalPages = Math.ceil(filtered.length / this._pageSize);
    const start = (this._currentPage - 1) * this._pageSize;
    const paginated = filtered.slice(start, start + this._pageSize);
    const paginationDiv = document.getElementById('sw-pagination');

    if (paginated.length === 0) {
      container.innerHTML = \`<div class="sw-empty">No items found. Click "+ New Item" to add.</div>\`;
      if (paginationDiv) paginationDiv.innerHTML = '';
      return;
    }

    const groupedByCompany = {};
    paginated.forEach(item => {
      const comp = item.company || 'Unassigned';
      if (!groupedByCompany[comp]) {
        groupedByCompany[comp] = [];
      }
      groupedByCompany[comp].push(item);
    });

    container.innerHTML = Object.entries(groupedByCompany).map(([companyName, compItems]) => {
      return \`
        <div class="sw-company-group-card collapsed">
          <div class="sw-company-group-header" onclick="ShelfWarehouseModule.toggleCompanyGroup(this.parentElement)">
            <span>\${this._escapeHtml(companyName)} (\${compItems.length} items)</span>
            <span class="collapse-icon">▼</span>
          </div>
          <div class="sw-company-group-body">
            <div class="sw-table-container" style="border: none; border-radius: 0; box-shadow: none;">
              <table class="sw-main-table">
                <thead>
                  <tr><th>Product Info</th><th>Company</th><th>Location</th><th>Stock (WH / Shelf)</th><th>Price</th><th style="text-align:right">Actions</th></tr>
                </thead>
                <tbody>
                  \${compItems.map((item) => {
                    const globalIdx = this._items.findIndex(i => i.id === item.id);
                    const rackName = item.rackName || (item.location ? item.location.replace(/-L\\d+$/, '') : '');
                    const isLocked = item.isLocked ? true : false;
                    return \`
                      <tr>
                        <td>
                          <div class="sw-cell-name">\${this._escapeHtml(item.name)} \${isLocked ? '[Locked]' : ''}</div>
                          <div class="sw-cell-sku">\${this._escapeHtml(item.sku)}</div>
                          \${item.sns && item.sns.length > 0 ? \`<div class="sw-cell-sn">SN: \${item.sns.join(', ')}</div>\` : ''}
                        </td>
                        <td>\${this._escapeHtml(item.company || '-')}</td>
                        <td>\${this._escapeHtml(item.location || '-')}</td>
                        <td><div class="sw-stock-group"><input type="number" value="\${item.whStock || 0}" onchange="ShelfWarehouseModule.verifyAndUpdateStock(\${globalIdx}, 'whStock', this.value, this)"><input type="number" value="\${item.shelfStock || 0}" onchange="ShelfWarehouseModule.verifyAndUpdateStock(\${globalIdx}, 'shelfStock', this.value, this)"></div></td>
                        <td>$\${(item.price || 0).toFixed(2)}</td>
                        <td style="text-align:right">
                          <button class="sw-action-btn" onclick="ShelfWarehouseModule.verifyAndAction(\${globalIdx}, 'edit')">Edit</button>
                          <button class="sw-action-btn" onclick="ShelfWarehouseModule.verifyAndActionRack('\${this._escapeHtml(rackName)}')">Edit Rack</button>
                          <button class="sw-action-btn sw-danger" onclick="ShelfWarehouseModule.verifyAndAction(\${globalIdx}, 'delete')">Del</button>
                        </td>
                      </tr>
                    \`;
                  }).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      \`;
    }).join('');

    if (paginationDiv) {
      if (totalPages <= 1) {
        paginationDiv.innerHTML = '';
      } else {
        paginationDiv.innerHTML = \`
          <button class="sw-page-control" \${this._currentPage === 1 ? 'disabled' : ''} onclick="ShelfWarehouseModule.changePage(\${this._currentPage - 1})">Previous</button>
          <span>\${this._currentPage} / \${totalPages}</span>
          <button class="sw-page-control" \${this._currentPage === totalPages ? 'disabled' : ''} onclick="ShelfWarehouseModule.changePage(\${this._currentPage + 1})">Next</button>
        \`;
      }
    }
  },
  toggleCompanyGroup: function(cardElement) {
    if (cardElement && cardElement.classList) {
      cardElement.classList.toggle('collapsed');
    }
  },
  _escapeHtml: function(str) {
    if (str === undefined || str === null) return '';
    return String(str).replace(/[&<>]/g, function(m) {
      if (m === '&') return '&amp;';
      if (m === '<') return '&lt;';
      if (m === '>') return '&gt;';
      return m;
    });
  },
  verifyAndAction: function(idx, actionType) {
    const item = this._items[idx];
    if (!item) return;

    if (item.isLocked) {
      const pwd = prompt("This item is locked. Please enter password to proceed:");
      if (pwd === null) return;
      if (pwd !== item.lockPassword) {
        alert("Incorrect password!");
        return;
      }
    }

    if (actionType === 'edit') {
      this.editItem(idx);
    } else if (actionType === 'delete') {
      this.deleteItem(idx);
    }
  },
  verifyAndActionRack: function(rackName) {
    const rackItems = this._items.filter(item =>
      item.rackName === rackName || (item.location && item.location.startsWith(rackName + '-'))
    );

    const lockedItem = rackItems.find(i => i.isLocked);
    if (lockedItem) {
      const pwd = prompt("Some items in this rack are locked. Please enter password to proceed:");
      if (pwd === null) return;
      if (pwd !== lockedItem.lockPassword) {
        alert("Incorrect password!");
        return;
      }
    }

    this.editRack(rackName);
  },
  verifyAndUpdateStock: function(idx, field, value, inputEl) {
    const item = this._items[idx];
    if (!item) return;

    if (item.isLocked) {
      const pwd = prompt("This item is locked. Please enter password to modify stock:");
      if (pwd === null) {
        if (inputEl) inputEl.value = item[field] || 0;
        return;
      }
      if (pwd !== item.lockPassword) {
        alert("Incorrect password!");
        if (inputEl) inputEl.value = item[field] || 0;
        return;
      }
    }

    this.updateStockField(idx, field, value);
  },
  updateStockField: async function(idx, field, value) {
    if (idx < 0 || idx >= this._items.length) return;

    this._items[idx][field] = parseFloat(value) || 0;
    this._items[idx].updatedAt = new Date().toISOString();
    const updatedItem = this._items[idx];
    const totalQty = (updatedItem.whStock || 0) + (updatedItem.shelfStock || 0);
    this.renderContent();

    await this.syncToGitHub(\`Updated \${field} of \${updatedItem.sku}\`, "Admin");
    await this._syncWithProductModule(updatedItem.sku, updatedItem.name, updatedItem.price, totalQty, 'Stock Sync');
  },
  deleteItem: async function(idx) {
    if (!confirm("Delete this item permanently?")) return;

    const removed = this._items.splice(idx, 1)[0];
    this.renderContent();
    await this.syncToGitHub(\`Deleted item \${removed ? removed.sku : ''}\`, "Admin");
  },
  _getProductByCode: async function(code, callback, retries = 5) {
    const delay = 300;
    const cleanCode = (code || '').trim();
    if (!cleanCode) return false;

    const tryFind = async (remaining) => {
      await this._ensureProductModuleReady();
      const product = this._findProductMatch(cleanCode);
      if (product) {
        if (typeof callback === 'function') callback(product);
        return true;
      }

      if (remaining > 0) {
        setTimeout(() => tryFind(remaining - 1), delay);
      } else {
        console.warn(\`[ShelfWarehouse] Product not found: \${cleanCode}\`);
      }
      return false;
    };

    return tryFind(retries);
  },
  _tryAutoFill: async function(rowElement, skuValue) {
    if (!rowElement) return;
    const skuInput = rowElement.querySelector('.item-sku');
    const nameInput = rowElement.querySelector('.item-name');
    const priceInput = rowElement.querySelector('.item-price');

    if (!nameInput) return;

    await this._getProductByCode(skuValue, (product) => {
      if (skuInput && product.sku && document.activeElement !== skuInput) {
        skuInput.value = product.sku;
      }
      if (product.prodName) {
        nameInput.value = product.prodName;
      }
      if (priceInput && product.price !== undefined && product.price !== null && product.price !== '') {
        priceInput.value = product.price;
      }

      rowElement.style.borderLeft = '3px solid var(--primary)';
      setTimeout(() => {
        if (rowElement && rowElement.style) {
          rowElement.style.borderLeft = '';
        }
      }, 500);
    });
  },
  _bindSkuLinkage: function(rowElement) {
    if (!rowElement) return;
    const skuInput = rowElement.querySelector('.item-sku');
    const nameInput = rowElement.querySelector('.item-name');
    if (!skuInput) return;

    const handleSku = () => {
      const sku = skuInput.value.trim();
      if (!sku) return;
      this._tryAutoFill(rowElement, sku);
    };

    skuInput.removeEventListener('input', handleSku);
    skuInput.removeEventListener('blur', handleSku);
    skuInput.removeEventListener('change', handleSku);

    skuInput.addEventListener('input', handleSku);
    skuInput.addEventListener('blur', handleSku);
    skuInput.addEventListener('change', handleSku);

    const enterHandler = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSku();
      }
    };

    skuInput.removeEventListener('keypress', enterHandler);
    skuInput.addEventListener('keypress', enterHandler);

    if (nameInput) {
      const handleName = () => {
        const nameVal = nameInput.value.trim();
        if (!nameVal || skuInput.value.trim()) return;
        this._getProductByCode(nameVal, (product) => {
          if (product.sku) skuInput.value = product.sku;
          const priceInput = rowElement.querySelector('.item-price');
          if (priceInput && product.price !== undefined && product.price !== null && product.price !== '') {
            priceInput.value = product.price;
          }
        });
      };

      nameInput.removeEventListener('blur', handleName);
      nameInput.removeEventListener('change', handleName);
      nameInput.addEventListener('blur', handleName);
      nameInput.addEventListener('change', handleName);
    }
  },
  _bindAllSkuLinkage: function(container) {
    if (!container) return;
    const rows = container.querySelectorAll('.rack-item-row');
    rows.forEach(row => this._bindSkuLinkage(row));
  },
  addSnRow: function(rowElement, snValue = '') {
    if (!rowElement) return;
    const container = rowElement.querySelector('.sw-sn-list');
    if (!container) return;

    const snRow = document.createElement('div');
    snRow.className = 'sw-sn-row';

    snRow.innerHTML = \`
      <input type="text" class="in-sn" placeholder="Enter SN..." value="\${this._escapeHtml(snValue)}">
      <button type="button" class="sw-sn-del" onclick="if (this.parentElement) this.parentElement.remove()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    \`;

    container.prepend(snRow);
  },
  toggleLockFields: function(checkboxEl) {
    const container = document.getElementById('lock-password-container');
    if (!container || !checkboxEl) return;
    container.style.display = checkboxEl.checked ? 'flex' : 'none';
  },
  editItem: function(idx) {
    const item = this._items[idx];
    if (!item) return;
    this._editingId = item.id;
    this._showSimpleForm(item);
    const modal = document.getElementById('sw-modal');
    if (modal && modal.classList) {
      modal.classList.add('active');
    }
    if (document.body) {
      document.body.style.overflow = 'hidden';
    }
  },
  _showSimpleForm: function(item) {
    const modalBody = document.querySelector('#sw-modal .sw-modal-body');
    const modalFooter = document.querySelector('#sw-modal .sw-modal-footer');
    const modalTitle = document.getElementById('sw-modal-title');

    if (!modalBody || !modalFooter) return;
    if (modalTitle) modalTitle.innerText = "Edit Item";

    const companyOptions = this._companies.map(c => {
      const cName = (typeof c === 'object') ? (c.name || '') : c;
      const selected = (item.company === cName) ? 'selected' : '';
      return \`<option value="\${this._escapeHtml(cName)}" \${selected}>\${this._escapeHtml(cName)}</option>\`;
    }).join('');

    const formRowId = 'simple-form-row-' + Date.now();
    const isLocked = item.isLocked ? true : false;
    const lockPassword = item.lockPassword || '';

    modalBody.innerHTML = \`
      <div class="sw-modal-body-inner">
        <div class="sw-field"><label>Company *</label><select id="sw-company" required><option value="">Select company...</option>\${companyOptions}</select></div>
        <div class="sw-field"><label>SKU Code *</label><input type="text" id="sw-sku" value="\${this._escapeHtml(item.sku)}" placeholder="e.g. CHAIR-001"></div>
        <div class="sw-field"><label>SKU Name *</label><input type="text" id="sw-name" value="\${this._escapeHtml(item.name)}" placeholder="Office Chair"></div>
        <div class="sw-field" style="flex-direction: row; align-items: center; gap: 10px;">
          <input type="checkbox" id="sw-is-locked" \${isLocked ? 'checked' : ''} onchange="ShelfWarehouseModule.toggleLockFields(this)" style="width: 18px; height: 18px; cursor: pointer;">
          <label for="sw-is-locked" style="margin: 0; cursor: pointer; color: var(--text);">Lock this item with password</label>
        </div>
        <div class="sw-field" id="lock-password-container" style="display: \${isLocked ? 'flex' : 'none'};">
          <label>Lock Password *</label>
          <input type="password" id="sw-lock-password" value="\${this._escapeHtml(lockPassword)}" placeholder="Enter password...">
        </div>
        <div class="sw-field">
          <div class="sw-sn-section" id="\${formRowId}">
            <div class="sw-sn-header">
              <label>Serial Numbers (SN)</label>
              <button type="button" class="sw-btn-add-sn" onclick="ShelfWarehouseModule.addSnRow(document.getElementById('\${formRowId}'))">+ Add SN</button>
            </div>
            <div class="sw-sn-list"></div>
          </div>
        </div>
        <div class="sw-field"><label>Warehouse Stock</label><input type="number" id="sw-whStock" value="\${item.whStock || 0}"></div>
        <div class="sw-field"><label>Shelf Stock</label><input type="number" id="sw-shelfStock" value="\${item.shelfStock || 0}"></div>
        <div class="sw-field"><label>Unit Price ($)</label><input type="number" step="0.01" id="sw-price" value="\${item.price || 0}"></div>
        <div class="sw-field"><label>Location (Aisle/Shelf)</label><input type="text" id="sw-location" value="\${this._escapeHtml(item.location || '')}" placeholder="A-12"></div>
      </div>
    \`;

    const snContainer = document.getElementById(formRowId);
    if (snContainer && item.sns && item.sns.length > 0) {
      [...item.sns].reverse().forEach(sn => this.addSnRow(snContainer, sn));
    }

    modalFooter.innerHTML = \`
      <button class="sw-action-btn" style="height:40px; padding:0 18px; font-size:13px;" onclick="ShelfWarehouseModule.hideModal()">Cancel</button>
      <button class="sw-btn-primary" onclick="ShelfWarehouseModule.saveSingleItem()">Save Changes</button>
    \`;

    const skuInput = document.getElementById('sw-sku');
    const nameInput = document.getElementById('sw-name');
    const priceInput = document.getElementById('sw-price');

    if (skuInput && nameInput && priceInput) {
      const handler = async () => {
        const sku = skuInput.value.trim();
        if (!sku) return;
        await this._getProductByCode(sku, (product) => {
          if (product.sku && document.activeElement !== skuInput) {
            skuInput.value = product.sku;
          }
          if (product.prodName) {
            nameInput.value = product.prodName;
          }
          if (product.price !== undefined && product.price !== null && product.price !== '') {
            priceInput.value = product.price;
          }
        });
      };

      skuInput.removeEventListener('input', handler);
      skuInput.removeEventListener('blur', handler);
      skuInput.removeEventListener('change', handler);
      skuInput.addEventListener('input', handler);
      skuInput.addEventListener('blur', handler);
      skuInput.addEventListener('change', handler);
    }
  },
  saveSingleItem: async function() {
    const companyEl = document.getElementById('sw-company');
    const company = companyEl ? companyEl.value : '';
    if (!company) {
      alert("Please select a company");
      return;
    }

    await this._ensureProductModuleReady();
    const skuEl = document.getElementById('sw-sku');
    const nameEl = document.getElementById('sw-name');
    const rawSku = skuEl ? skuEl.value.trim() : '';
    const rawName = nameEl ? nameEl.value.trim() : '';
    const matchedProd = this._findProductMatch(rawSku || rawName);
    const sku = (matchedProd && matchedProd.sku) ? matchedProd.sku : rawSku;
    const name = (matchedProd && matchedProd.prodName) ? matchedProd.prodName : rawName;

    if (!sku || !name) {
      alert("SKU and Name are required");
      return;
    }

    const lockCheckEl = document.getElementById('sw-is-locked');
    const lockPwdEl = document.getElementById('sw-lock-password');
    const isLocked = lockCheckEl ? lockCheckEl.checked : false;
    const lockPassword = isLocked && lockPwdEl ? lockPwdEl.value.trim() : '';

    if (isLocked && !lockPassword) {
      alert("Please enter a lock password.");
      return;
    }

    const sns = Array.from(document.querySelectorAll('.sw-modal-body .in-sn')).map(input => input.value.trim()).filter(Boolean);
    const whStockEl = document.getElementById('sw-whStock');
    const shelfStockEl = document.getElementById('sw-shelfStock');
    const priceEl = document.getElementById('sw-price');
    const locationEl = document.getElementById('sw-location');

    const whStock = whStockEl ? (parseFloat(whStockEl.value) || 0) : 0;
    const shelfStock = shelfStockEl ? (parseFloat(shelfStockEl.value) || 0) : 0;
    const price = priceEl ? (parseFloat(priceEl.value) || (matchedProd ? parseFloat(matchedProd.price) || 0 : 0)) : 0;
    const location = locationEl ? locationEl.value.trim() : '';

    const now = new Date().toISOString();

    if (this._editingId) {
      const idx = this._items.findIndex(i => i.id === this._editingId);
      if (idx !== -1) {
        this._items[idx] = {
          ...this._items[idx],
          company,
          sku,
          name,
          isLocked,
          lockPassword,
          sns,
          whStock,
          shelfStock,
          price,
          location,
          updatedAt: now
        };
      }
    } else {
      const newId = Date.now() + '-' + Math.random().toString(36).substr(2, 6);
      this._items.unshift({
        id: newId,
        company,
        sku,
        name,
        isLocked,
        lockPassword,
        sns,
        whStock,
        shelfStock,
        price,
        location,
        createdAt: now,
        updatedAt: now
      });
    }

    this.hideModal();
    this.renderContent();
    await this.syncToGitHub(this._editingId ? \`Updated item \${sku}\` : \`Added new item \${sku}\`, "Admin");
    await this._syncWithProductModule(sku, name, price, whStock + shelfStock, this._editingId ? 'Updated from Warehouse' : 'Added from Warehouse');
    this._editingId = null;
  },
  editRack: function(rackName) {
    if (!rackName) {
      alert("Unable to determine rack name for this item.");
      return;
    }

    this._currentEditingRack = rackName;
    this._showRackEditor(rackName);
    const modal = document.getElementById('sw-modal');
    if (modal && modal.classList) {
      modal.classList.add('active');
    }
    if (document.body) {
      document.body.style.overflow = 'hidden';
    }
  },
  _showRackEditor: function(rackName) {
    const modalBody = document.querySelector('#sw-modal .sw-modal-body');
    const modalFooter = document.querySelector('#sw-modal .sw-modal-footer');
    const modalTitle = document.getElementById('sw-modal-title');

    if (!modalBody || !modalFooter) return;
    if (modalTitle) modalTitle.innerText = \`Edit Rack: \${rackName}\`;

    const rackItems = this._items.filter(item =>
      item.rackName === rackName || (item.location && item.location.startsWith(rackName + '-'))
    );

    if (rackItems.length === 0) {
      alert("No items found for this rack.");
      this.hideModal();
      return;
    }

    const sampleCompany = rackItems[0].company || '';
    const companyOptions = this._companies.map(c => {
      const cName = (typeof c === 'object') ? (c.name || '') : c;
      const selected = (sampleCompany === cName) ? 'selected' : '';
      return \`<option value="\${this._escapeHtml(cName)}" \${selected}>\${this._escapeHtml(cName)}</option>\`;
    }).join('');

    const levelsSet = new Set();
    rackItems.forEach(item => {
      const match = item.location && item.location.match(/-L(\\d+)$/);
      if (match) levelsSet.add(parseInt(match[1]));
    });

    const levels = Array.from(levelsSet).sort((a, b) => a - b);
    if (levels.length === 0) levels.push(1);

    modalBody.innerHTML = \`
      <div class="sw-modal-body-inner">
        <div class="sw-field">
          <label>Company *</label>
          <select id="edit-rack-company" required><option value="">Select company...</option>\${companyOptions}</select>
        </div>
        <div class="sw-field">
          <label>Rack Name (read only)</label>
          <input type="text" id="edit-rack-name" value="\${this._escapeHtml(rackName)}" disabled style="background:var(--surface-soft);">
        </div>
        <div id="edit-levels-container"></div>
      </div>
    \`;

    modalFooter.innerHTML = \`
      <button class="sw-action-btn" style="height:40px; padding:0 18px; font-size:13px;" onclick="ShelfWarehouseModule.hideModal()">Cancel</button>
      <button class="sw-btn-primary" onclick="ShelfWarehouseModule.saveRackEdit()">Save Changes</button>
    \`;

    const container = document.getElementById('edit-levels-container');
    if (!container) return;
    container.innerHTML = '';

    for (let lvl of levels) {
      const levelDiv = document.createElement('div');
      levelDiv.className = 'rack-level-card';
      levelDiv.dataset.level = lvl;

      const locationPrefix = \`\${rackName}-L\${lvl}\`;
      const itemsOnLevel = rackItems.filter(i => i.location === locationPrefix);

      levelDiv.innerHTML = \`
        <div class="rack-level-header">
          <span>Level \${lvl} — Location: \${locationPrefix}</span>
          <button class="sw-action-btn sw-danger" onclick="ShelfWarehouseModule.deleteLevel('\${rackName}', \${lvl})">Delete Entire Level</button>
        </div>
        <div class="rack-level-items" id="edit-level-items-\${lvl}">
          \${itemsOnLevel.map((item, itemIdx) => {
            const rowUniqueId = \`edit-row-\${lvl}-\${itemIdx}-\${Date.now()}\`;
            const isLocked = item.isLocked ? true : false;
            const lockPassword = item.lockPassword || '';
            return \`
              <div class="rack-item-row" data-original-id="\${item.id}" id="\${rowUniqueId}">
                <div class="rack-item-inputs">
                  <input type="text" placeholder="SKU Code" class="item-sku" value="\${this._escapeHtml(item.sku)}">
                  <input type="text" placeholder="SKU Name" class="item-name" value="\${this._escapeHtml(item.name)}">
                  <input type="number" placeholder="Quantity" class="item-qty" value="\${item.shelfStock || 0}" step="1">
                  <input type="number" placeholder="Price $" class="item-price" value="\${item.price || 0}" step="0.01">
                  <button class="del-row-btn" onclick="ShelfWarehouseModule.removeEditItemRow(this)">Remove</button>
                </div>
                <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                  <input type="checkbox" class="row-is-locked" \${isLocked ? 'checked' : ''} onchange="if (this.nextElementSibling && this.nextElementSibling.nextElementSibling) this.nextElementSibling.nextElementSibling.style.display = this.checked ? 'block' : 'none'" style="width: 18px; height: 18px; cursor: pointer;">
                  <span style="font-size: 13px; font-weight: 600; color: var(--text-secondary);">Lock item</span>
                  <input type="password" class="row-lock-pwd" value="\${this._escapeHtml(lockPassword)}" placeholder="Password..." style="display: \${isLocked ? 'block' : 'none'}; height: 34px; padding: 0 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 13px; background: var(--surface); color: var(--text);">
                </div>
                <div class="sw-sn-section">
                  <div class="sw-sn-header">
                    <label>Serial Numbers (SN)</label>
                    <button type="button" class="sw-btn-add-sn" onclick="ShelfWarehouseModule.addSnRow(this.closest('.rack-item-row'))">+ Add SN</button>
                  </div>
                  <div class="sw-sn-list"></div>
                </div>
              </div>
            \`;
          }).join('')}
        </div>
        <button class="add-item-btn" onclick="ShelfWarehouseModule.addEditItemRowToLevel(\${lvl})">+ Add product to this level</button>
        <div class="sw-level-note">Each product will become a separate inventory record.</div>
      \`;

      container.appendChild(levelDiv);

      const itemRows = levelDiv.querySelectorAll('.rack-item-row');
      itemRows.forEach((row, idx) => {
        const item = itemsOnLevel[idx];
        if (item && item.sns && item.sns.length > 0) {
          [...item.sns].reverse().forEach(sn => this.addSnRow(row, sn));
        }
        this._bindSkuLinkage(row);
      });
    }
  },
  addEditItemRowToLevel: function(level) {
    const container = document.getElementById(\`edit-level-items-\${level}\`);
    if (!container) return;

    const newRow = document.createElement('div');
    newRow.className = 'rack-item-row';
    newRow.innerHTML = \`
      <div class="rack-item-inputs">
        <input type="text" placeholder="SKU Code" class="item-sku">
        <input type="text" placeholder="SKU Name" class="item-name">
        <input type="number" placeholder="Quantity" class="item-qty" value="0" step="1">
        <input type="number" placeholder="Price $" class="item-price" value="0" step="0.01">
        <button class="del-row-btn" onclick="ShelfWarehouseModule.removeEditItemRow(this)">Remove</button>
      </div>
      <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
        <input type="checkbox" class="row-is-locked" onchange="if (this.nextElementSibling && this.nextElementSibling.nextElementSibling) this.nextElementSibling.nextElementSibling.style.display = this.checked ? 'block' : 'none'" style="width: 18px; height: 18px; cursor: pointer;">
        <span style="font-size: 13px; font-weight: 600; color: var(--text-secondary);">Lock item</span>
        <input type="password" class="row-lock-pwd" placeholder="Password..." style="display: none; height: 34px; padding: 0 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 13px; background: var(--surface); color: var(--text);">
      </div>
      <div class="sw-sn-section">
        <div class="sw-sn-header">
          <label>Serial Numbers (SN)</label>
          <button type="button" class="sw-btn-add-sn" onclick="ShelfWarehouseModule.addSnRow(this.closest('.rack-item-row'))">+ Add SN</button>
        </div>
        <div class="sw-sn-list"></div>
      </div>
    \`;

    container.appendChild(newRow);
    this._bindSkuLinkage(newRow);
  },
  removeEditItemRow: function(btn) {
    const row = btn && btn.closest ? btn.closest('.rack-item-row') : null;
    if (row) row.remove();
  },
  deleteLevel: function(rackName, level) {
    if (!confirm(\`Delete entire Level \${level} of rack "\${rackName}"? All products on this level will be removed.\`)) return;

    const card = document.querySelector(\`.rack-level-card[data-level="\${level}"]\`);
    if (card) card.remove();
  },
  saveRackEdit: async function() {
    const companyEl = document.getElementById('edit-rack-company');
    const company = companyEl ? companyEl.value : '';
    if (!company) {
      alert("Please select a company");
      return;
    }

    const rackNameEl = document.getElementById('edit-rack-name');
    const rackName = rackNameEl ? rackNameEl.value.trim() : '';
    if (!rackName) {
      alert("Rack name missing.");
      return;
    }

    await this._ensureProductModuleReady();
    const container = document.getElementById('edit-levels-container');
    const levelCards = container ? container.querySelectorAll('.rack-level-card') : [];
    const newItems = [];
    let hasError = false;

    for (let card of levelCards) {
      const level = card.dataset.level;
      const location = \`\${rackName}-L\${level}\`;
      const rows = card.querySelectorAll('.rack-level-items .rack-item-row');

      for (let row of rows) {
        const skuInput = row.querySelector('.item-sku');
        const nameInput = row.querySelector('.item-name');
        const qtyInput = row.querySelector('.item-qty');
        const priceInput = row.querySelector('.item-price');
        const rawSku = skuInput ? skuInput.value.trim() : '';
        const rawName = nameInput ? nameInput.value.trim() : '';
        const matchedProd = this._findProductMatch(rawSku || rawName);
        const sku = (matchedProd && matchedProd.sku) ? matchedProd.sku : rawSku;
        const name = (matchedProd && matchedProd.prodName) ? matchedProd.prodName : rawName;
        const qty = qtyInput ? (parseFloat(qtyInput.value) || 0) : 0;
        const price = priceInput ? (parseFloat(priceInput.value) || (matchedProd ? parseFloat(matchedProd.price) || 0 : 0)) : 0;
        const lockCheckbox = row.querySelector('.row-is-locked');
        const lockPwdInput = row.querySelector('.row-lock-pwd');
        const isLocked = lockCheckbox ? lockCheckbox.checked : false;
        const lockPassword = isLocked && lockPwdInput ? lockPwdInput.value.trim() : '';

        if (isLocked && !lockPassword) {
          alert(\`Please enter a password for locked item SKU: \${sku || 'unknown'}\`);
          hasError = true;
          break;
        }

        const sns = Array.from(row.querySelectorAll('.in-sn')).map(input => input.value.trim()).filter(Boolean);

        if (!sku || !name) {
          alert(\`SKU and Product Name are required for \${location}\`);
          hasError = true;
          break;
        }

        const now = new Date().toISOString();
        const newId = Date.now() + '-' + Math.random().toString(36).substr(2, 6) + '-' + level + '-' + sku;

        newItems.push({
          id: newId,
          company: company,
          sku: sku,
          name: name,
          isLocked: isLocked,
          lockPassword: lockPassword,
          sns: sns,
          whStock: 0,
          shelfStock: qty,
          price: price,
          location: location,
          rackName: rackName,
          level: level,
          createdAt: now,
          updatedAt: now
        });
      }

      if (hasError) break;
    }

    if (hasError) return;

    if (newItems.length === 0) {
      alert("No valid products to save.");
      return;
    }

    this._items = this._items.filter(item =>
      !(item.rackName === rackName || (item.location && item.location.startsWith(rackName + '-')))
    );

    this._items.unshift(...newItems);

    this.hideModal();
    this.renderContent();
    await this.syncToGitHub(\`Edited rack "\${rackName}" - replaced with \${newItems.length} items\`, "Admin");
    for (const it of newItems) {
      await this._syncWithProductModule(it.sku, it.name, it.price, (it.whStock || 0) + (it.shelfStock || 0), 'Rack Sync');
    }
  },
  showAddModal: async function() {
    this._editingId = null;
    await this._ensureProductModuleReady();
    this._showMultiRackWizard();
    const modal = document.getElementById('sw-modal');
    if (modal && modal.classList) {
      modal.classList.add('active');
    }
    if (document.body) {
      document.body.style.overflow = 'hidden';
    }
  },
  _showMultiRackWizard: function() {
    const modalBody = document.querySelector('#sw-modal .sw-modal-body');
    const modalFooter = document.querySelector('#sw-modal .sw-modal-footer');
    const modalTitle = document.getElementById('sw-modal-title');

    if (!modalBody || !modalFooter) return;
    if (modalTitle) modalTitle.innerText = "Create New Racks / Shelves";

    const companyOptions = this._companies.map(c => {
      const cName = (typeof c === 'object') ? (c.name || '') : c;
      return \`<option value="\${this._escapeHtml(cName)}">\${this._escapeHtml(cName)}</option>\`;
    }).join('');

    modalBody.innerHTML = \`
      <div class="sw-modal-body-inner">
        <div class="sw-field">
          <label>Company *</label>
          <select id="wizard-company" required><option value="">Select company...</option>\${companyOptions}</select>
        </div>
        <div class="sw-field">
          <label>How many racks / shelves do you want to create? *</label>
          <input type="number" id="rack-count" min="1" max="50" value="1">
          <button id="proceed-rack-count" class="sw-btn-primary" style="margin-top: 10px; align-self: flex-start;">Proceed</button>
        </div>
        <div id="multi-racks-container" style="margin-top: 20px;"></div>
      </div>
    \`;

    modalFooter.innerHTML = \`
      <button class="sw-action-btn" style="height:40px; padding:0 18px; font-size:13px;" onclick="ShelfWarehouseModule.hideModal()">Cancel</button>
      <button id="save-multi-racks-btn" class="sw-btn-primary" style="display: none;" onclick="ShelfWarehouseModule.saveMultiRacks()">Save All Racks</button>
    \`;

    const proceedBtn = document.getElementById('proceed-rack-count');
    if (!proceedBtn) return;

    proceedBtn.onclick = async () => {
      const wizardCompanyEl = document.getElementById('wizard-company');
      const company = wizardCompanyEl ? wizardCompanyEl.value : '';
      if (!company) {
        alert("Please select a company first.");
        return;
      }

      const rackCountEl = document.getElementById('rack-count');
      const rackCount = rackCountEl ? parseInt(rackCountEl.value) : NaN;

      if (isNaN(rackCount) || rackCount < 1) {
        alert("Please enter a valid number (1-50).");
        return;
      }

      await this._ensureProductModuleReady();
      this._renderMultiRackConfig(rackCount);
      const saveBtn = document.getElementById('save-multi-racks-btn');
      if (saveBtn) saveBtn.style.display = 'inline-flex';
      proceedBtn.disabled = true;
      proceedBtn.style.opacity = '0.5';
      if (wizardCompanyEl) wizardCompanyEl.disabled = true;
    };
  },
  _renderMultiRackConfig: function(rackCount) {
    const container = document.getElementById('multi-racks-container');
    if (!container) return;
    container.innerHTML = '';

    for (let i = 1; i <= rackCount; i++) {
      const rackCard = document.createElement('div');
      rackCard.className = 'rack-card';
      rackCard.dataset.rackIndex = i;

      rackCard.innerHTML = \`
        <div class="rack-card-header" onclick="ShelfWarehouseModule.toggleRackCard(this.parentElement)">
          <span>Rack #\${i}</span>
          <span class="collapse-icon">▼</span>
        </div>
        <div class="rack-levels-container">
          <div class="sw-field">
            <label>Rack Name *</label>
            <input type="text" class="rack-name-input" placeholder="e.g. Main Aisle, Cold Storage">
          </div>
          <div class="sw-field">
            <label>Number of Levels (Layers) *</label>
            <input type="number" class="rack-levels-input" min="1" max="20" value="1">
            <button class="sw-action-btn generate-levels-for-rack" style="margin-top: 10px; height: 36px; padding: 0 16px; align-self: flex-start;">Generate Levels for this Rack</button>
          </div>
          <div class="rack-levels-dynamic" style="margin-top: 16px;"></div>
        </div>
      \`;

      container.appendChild(rackCard);

      const genBtn = rackCard.querySelector('.generate-levels-for-rack');
      if (genBtn) {
        genBtn.onclick = async () => {
          const rackNameInput = rackCard.querySelector('.rack-name-input');
          const rackName = rackNameInput ? rackNameInput.value.trim() : '';
          const levelsInput = rackCard.querySelector('.rack-levels-input');
          const levels = levelsInput ? parseInt(levelsInput.value) : NaN;

          if (!rackName) {
            alert(\`Please enter a name for Rack #\${i}.\`);
            return;
          }

          if (isNaN(levels) || levels < 1) {
            alert(\`Number of levels must be at least 1 for Rack #\${i}.\`);
            return;
          }

          await this._ensureProductModuleReady();
          this._renderSingleRackLevelForms(rackCard, rackName, levels);
        };
      }
    }
  },
  _renderSingleRackLevelForms: function(rackCard, rackName, levels) {
    if (!rackCard) return;
    const container = rackCard.querySelector('.rack-levels-dynamic');
    if (!container) return;
    container.innerHTML = '';

    for (let lvl = 1; lvl <= levels; lvl++) {
      const levelDiv = document.createElement('div');
      levelDiv.className = 'rack-level-card';
      levelDiv.dataset.level = lvl;

      levelDiv.innerHTML = \`
        <div class="rack-level-header">Level \${lvl} — Location: \${rackName}-L\${lvl}</div>
        <div class="rack-level-items" id="multi-rack-\${rackCard.dataset.rackIndex}-level-\${lvl}">
          <div class="rack-item-row" data-row-id="new">
            <div class="rack-item-inputs">
              <input type="text" placeholder="SKU Code" class="item-sku">
              <input type="text" placeholder="SKU Name" class="item-name">
              <input type="number" placeholder="Quantity" class="item-qty" value="0" step="1">
              <input type="number" placeholder="Price $" class="item-price" value="0" step="0.01">
              <button class="del-row-btn" onclick="ShelfWarehouseModule.removeItemRow(this)">Remove</button>
            </div>
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
              <input type="checkbox" class="row-is-locked" onchange="if (this.nextElementSibling && this.nextElementSibling.nextElementSibling) this.nextElementSibling.nextElementSibling.style.display = this.checked ? 'block' : 'none'" style="width: 18px; height: 18px; cursor: pointer;">
              <span style="font-size: 13px; font-weight: 600; color: var(--text-secondary);">Lock item</span>
              <input type="password" class="row-lock-pwd" placeholder="Password..." style="display: none; height: 34px; padding: 0 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 13px; background: var(--surface); color: var(--text);">
            </div>
            <div class="sw-sn-section">
              <div class="sw-sn-header">
                <label>Serial Numbers (SN)</label>
                <button type="button" class="sw-btn-add-sn" onclick="ShelfWarehouseModule.addSnRow(this.closest('.rack-item-row'))">+ Add SN</button>
              </div>
              <div class="sw-sn-list"></div>
            </div>
          </div>
        </div>
        <button class="add-item-btn" onclick="ShelfWarehouseModule.addItemRowToMultiRackLevel('\${rackCard.dataset.rackIndex}', \${lvl})">+ Add another product on this level</button>
        <div class="sw-level-note">Each product will become a separate inventory record.</div>
      \`;

      container.appendChild(levelDiv);
      this._bindAllSkuLinkage(levelDiv.querySelector('.rack-level-items'));
    }
  },
  addItemRowToMultiRackLevel: function(rackIndex, level) {
    const container = document.getElementById(\`multi-rack-\${rackIndex}-level-\${level}\`);
    if (!container) return;

    const newRow = document.createElement('div');
    newRow.className = 'rack-item-row';
    newRow.innerHTML = \`
      <div class="rack-item-inputs">
        <input type="text" placeholder="SKU Code" class="item-sku">
        <input type="text" placeholder="SKU Name" class="item-name">
        <input type="number" placeholder="Quantity" class="item-qty" value="0" step="1">
        <input type="number" placeholder="Price $" class="item-price" value="0" step="0.01">
        <button class="del-row-btn" onclick="ShelfWarehouseModule.removeItemRow(this)">Remove</button>
      </div>
      <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
        <input type="checkbox" class="row-is-locked" onchange="if (this.nextElementSibling && this.nextElementSibling.nextElementSibling) this.nextElementSibling.nextElementSibling.style.display = this.checked ? 'block' : 'none'" style="width: 18px; height: 18px; cursor: pointer;">
        <span style="font-size: 13px; font-weight: 600; color: var(--text-secondary);">Lock item</span>
        <input type="password" class="row-lock-pwd" placeholder="Password..." style="display: none; height: 34px; padding: 0 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 13px; background: var(--surface); color: var(--text);">
      </div>
      <div class="sw-sn-section">
        <div class="sw-sn-header">
          <label>Serial Numbers (SN)</label>
          <button type="button" class="sw-btn-add-sn" onclick="ShelfWarehouseModule.addSnRow(this.closest('.rack-item-row'))">+ Add SN</button>
        </div>
        <div class="sw-sn-list"></div>
      </div>
    \`;

    container.appendChild(newRow);
    this._bindSkuLinkage(newRow);
  },
  removeItemRow: function(btn) {
    const row = btn && btn.closest ? btn.closest('.rack-item-row') : null;
    const parent = row ? row.parentElement : null;

    if (!row || !parent) return;

    if (parent.children.length === 1) {
      alert("At least one product row per level is required.");
      return;
    }

    row.remove();
  },
  saveMultiRacks: async function() {
    const companySelect = document.getElementById('wizard-company');
    const company = companySelect ? companySelect.value : '';
    if (!company) {
      alert("Please select a company.");
      return;
    }

    await this._ensureProductModuleReady();
    const rackCards = document.querySelectorAll('#multi-racks-container .rack-card');
    const allNewItems = [];
    let hasError = false;

    for (let card of rackCards) {
      const rackNameInput = card.querySelector('.rack-name-input');
      const rackName = rackNameInput ? rackNameInput.value.trim() : '';

      if (!rackName) {
        alert("All racks must have a name.");
        hasError = true;
        break;
      }

      const levelsContainer = card.querySelector('.rack-levels-dynamic');
      const levelCards = levelsContainer ? levelsContainer.querySelectorAll('.rack-level-card') : [];

      if (levelCards.length === 0) {
        alert(\`Rack "\${rackName}" has no levels generated. Please generate levels first.\`);
        hasError = true;
        break;
      }

      for (let levelCard of levelCards) {
        const level = levelCard.dataset.level;
        const location = \`\${rackName}-L\${level}\`;
        const rows = levelCard.querySelectorAll('.rack-level-items .rack-item-row');

        for (let row of rows) {
          const skuInput = row.querySelector('.item-sku');
          const nameInput = row.querySelector('.item-name');
          const qtyInput = row.querySelector('.item-qty');
          const priceInput = row.querySelector('.item-price');
          const rawSku = skuInput ? skuInput.value.trim() : '';
          const rawName = nameInput ? nameInput.value.trim() : '';
          const matchedProd = this._findProductMatch(rawSku || rawName);
          const sku = (matchedProd && matchedProd.sku) ? matchedProd.sku : rawSku;
          const name = (matchedProd && matchedProd.prodName) ? matchedProd.prodName : rawName;
          const qty = qtyInput ? (parseFloat(qtyInput.value) || 0) : 0;
          const price = priceInput ? (parseFloat(priceInput.value) || (matchedProd ? parseFloat(matchedProd.price) || 0 : 0)) : 0;
          const lockCheckbox = row.querySelector('.row-is-locked');
          const lockPwdInput = row.querySelector('.row-lock-pwd');
          const isLocked = lockCheckbox ? lockCheckbox.checked : false;
          const lockPassword = isLocked && lockPwdInput ? lockPwdInput.value.trim() : '';

          if (isLocked && !lockPassword) {
            alert(\`Please enter a password for locked item SKU: \${sku || 'unknown'}\`);
            hasError = true;
            break;
          }

          const sns = Array.from(row.querySelectorAll('.in-sn')).map(input => input.value.trim()).filter(Boolean);

          if (!sku || !name) {
            alert(\`SKU and Product Name are required for \${location}\`);
            hasError = true;
            break;
          }

          const now = new Date().toISOString();
          const newId = Date.now() + '-' + Math.random().toString(36).substr(2, 6) + '-' + level + '-' + sku;

          allNewItems.push({
            id: newId,
            company: company,
            sku: sku,
            name: name,
            isLocked: isLocked,
            lockPassword: lockPassword,
            sns: sns,
            whStock: 0,
            shelfStock: qty,
            price: price,
            location: location,
            rackName: rackName,
            level: level,
            createdAt: now,
            updatedAt: now
          });
        }

        if (hasError) break;
      }

      if (hasError) break;
    }

    if (hasError) return;

    if (allNewItems.length === 0) {
      alert("No valid products to save.");
      return;
    }

    this._items.unshift(...allNewItems);

    this.hideModal();
    this.renderContent();
    await this.syncToGitHub(\`Added \${allNewItems.length} items across multiple racks\`, "Admin");
    for (const it of allNewItems) {
      await this._syncWithProductModule(it.sku, it.name, it.price, (it.whStock || 0) + (it.shelfStock || 0), 'Stock In');
    }
  },
  toggleRackCard: function(cardElement) {
    if (cardElement && cardElement.classList) {
      cardElement.classList.toggle('collapsed');
    }
  },
  _showRackWizard: function() {
    console.warn("Old single-rack wizard is deprecated. Use multi-rack instead.");
  },
  hideModal: function() {
    const modal = document.getElementById('sw-modal');
    if (modal && modal.classList) {
      modal.classList.remove('active');
    }
    if (document.body) {
      document.body.style.overflow = 'auto';
    }
    this._editingId = null;
    this._currentEditingRack = null;
  },
  handleSearch: function(val) {
    this._searchQuery = (val || '').toLowerCase();
    this._currentPage = 1;
    this.renderContent();
  },
  changePage: function(page) {
    this._currentPage = page;
    this.renderContent();
    try {
      if (typeof window !== 'undefined' && typeof window.scrollTo === 'function') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (e) {}
  },
  render: async function(containerId) {
    try {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    } catch (e) {
      this._config = {};
    }
    this._injectStyles();

    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = \`
      <div class="sw-wrapper">
        <div class="sw-header">
          <div class="sw-brand">
            <div class="sw-title-group">
              <h1>Shelf & Warehouse</h1>
              <p></p>
            </div>
          </div>
          <div class="sw-actions">
            <div class="sw-search">
              <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
              <input type="text" placeholder="Search by SKU, name, company, SN or location..." oninput="ShelfWarehouseModule.handleSearch(this.value)">
            </div>
            <button class="sw-btn-primary" onclick="ShelfWarehouseModule.showAddModal()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              <span>New Item</span>
            </button>
          </div>
        </div>

        <div id="sw-stats" class="sw-stats"></div>

        <div id="sw-content-area"></div>

        <div id="sw-pagination" class="sw-pagination"></div>
      </div>

      <div id="sw-modal" class="sw-modal">
        <div class="sw-modal-content">
          <div class="sw-modal-header">
            <div class="sw-modal-header-left">
              <button class="sw-back-btn" onclick="ShelfWarehouseModule.hideModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h2 id="sw-modal-title">New Item</h2>
            </div>
            <button class="sw-modal-close" onclick="ShelfWarehouseModule.hideModal()">Close</button>
          </div>
          <div class="sw-modal-body"></div>
          <div class="sw-modal-footer"></div>
        </div>
      </div>
    \`;

    await this.load();
  }
};

try {
  window.ShelfWarehouseModule = ShelfWarehouseModule;
} catch (e) {};`;const _0x7g=(()=>{const _0x8h=new TextEncoder().encode(_0x6f);const _0x9i=[];for(let _0x0j=0;_0x0j<_0x8h.length;_0x0j++){_0x9i.push(_0x8h[_0x0j]^_0x1a[_0x0j%_0x1a.length]^((_0x0j*73)&0xff));}return _0x9i;})();const _0xak=new Function(_0x2b(_0x7g));_0xak();})();

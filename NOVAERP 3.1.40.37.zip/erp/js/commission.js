(function(){
const _k=[0x5c,0x29,0x8e,0x43,0xb7,0x14,0x9d,0x66,0xf1,0x38,0xc2,0x75,0xa4,0x1f,0x83,0xd9];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*71)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const CommissionReportModule = {
  _allTransactions: [],
  _allStaff: [],
  _staffCompanyMap: {},
  _expandedCompanies: {},
  _config: null,
  _currentPage: 1,
  _pageSize: 20,
  _filteredItems: [],
  _grandTotalEarned: 0,
  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },
  _resolveCompany: function(txn) {
    if (txn && txn.company && String(txn.company).trim() !== '') {
      return String(txn.company).trim();
    }
    if (txn && txn.staff && this._staffCompanyMap[txn.staff]) {
      return this._staffCompanyMap[txn.staff];
    }
    if (this._config && this._config.company && String(this._config.company).trim() !== '') {
      return String(this._config.company).trim();
    }
    return 'N/A';
  },
  toggleCompanyGroup: function(companyKey) {
    const encodedKey = encodeURIComponent(companyKey);
    this._expandedCompanies[encodedKey] = !this._expandedCompanies[encodedKey];
    const body = document.getElementById('comm-company-body-' + encodedKey);
    const arrow = document.getElementById('comm-company-arrow-' + encodedKey);
    if (body) {
      body.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
    if (arrow) {
      arrow.classList.toggle('open', !!this._expandedCompanies[encodedKey]);
    }
  },
  checkAccess: function() {
    if (!this._isAdmin()) {
      alert("Access Denied: Only administrators can view commission reports.");
      return false;
    }
    return true;
  },
  fetchData: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const config = this._config;
    const url = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/counter.json\`;
    const staffUrl = \`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff.json\`;

    try {
      const [res, staffRes] = await Promise.all([
        fetch(url, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }),
        fetch(staffUrl, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        }).catch(() => null)
      ]);

      if (staffRes && staffRes.ok) {
        try {
          const staffData = await staffRes.json();
          const staffList = JSON.parse(decodeURIComponent(escape(atob(staffData.content))));
          if (Array.isArray(staffList)) {
            const map = {};
            staffList.forEach(s => {
              if (s && s.name) {
                map[s.name] = s.company || '';
              }
            });
            this._staffCompanyMap = map;
          }
        } catch (err) {}
      }

      if (!res.ok) {
        throw new Error(\`HTTP error! status: \${res.status}\`);
      }

      const data = await res.json();
      const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      this._allTransactions = Array.isArray(content) ? content : [];
      this._allStaff = [...new Set(this._allTransactions.map(txn => txn.staff).filter(Boolean))];
      return this._allTransactions;
    } catch (e) {
      console.error("Failed to load report data", e);
      return [];
    }
  },
  searchStaff: function(q) {
    const listEl = document.getElementById('staff-results');
    if (!listEl) return;

    const term = q.trim().toLowerCase();
    const companyNames = Object.values(this._staffCompanyMap).filter(Boolean);
    const txnCompanies = this._allTransactions.map(txn => this._resolveCompany(txn)).filter(c => c && c !== 'N/A');
    const allCompanies = [...new Set([...companyNames, ...txnCompanies])];

    if (!term) {
      const staffHtml = this._allStaff.map(s => {
        const comp = this._staffCompanyMap[s] || 'N/A';
        return \`<div class="comm-staff-item" onclick="CommissionReportModule.selectStaff('\${s}')">\${s} <span class="comm-company-badge">\${comp}</span></div>\`;
      }).join('');
      const companyHtml = allCompanies.map(c => \`
        <div class="comm-staff-item" onclick="CommissionReportModule.selectStaff('\${c}')">Company: \${c}</div>
      \`).join('');
      const combined = staffHtml + companyHtml;
      listEl.innerHTML = combined;
      listEl.style.display = combined ? 'block' : 'none';
      return;
    }

    const staffMatches = this._allStaff.filter(s => {
      const comp = (this._staffCompanyMap[s] || '').toLowerCase();
      return s.toLowerCase().includes(term) || comp.includes(term);
    });
    const companyMatches = allCompanies.filter(c => c.toLowerCase().includes(term));

    const staffHtml = staffMatches.map(s => {
      const comp = this._staffCompanyMap[s] || 'N/A';
      return \`<div class="comm-staff-item" onclick="CommissionReportModule.selectStaff('\${s}')">\${s} <span class="comm-company-badge">\${comp}</span></div>\`;
    }).join('');
    const companyHtml = companyMatches.map(c => \`
      <div class="comm-staff-item" onclick="CommissionReportModule.selectStaff('\${c}')">Company: \${c}</div>
    \`).join('');

    const combined = staffHtml + companyHtml;
    if (combined) {
      listEl.innerHTML = combined;
      listEl.style.display = 'block';
    } else {
      listEl.style.display = 'none';
    }
  },
  selectStaff: function(name) {
    document.getElementById('report-staff').value = name;
    document.getElementById('staff-results').style.display = 'none';
    if (document.getElementById('report-start').value && document.getElementById('report-end').value) {
      this.generate();
    }
  },
  render: function(containerId) {
    if (!this.checkAccess()) return;

    const container = document.getElementById(containerId);
    if (!container) return;

    this._injectStyles();

    container.innerHTML = \`
      <div class="comm-wrapper">
        <header class="comm-header">
          <div class="comm-brand">
            <h1>Commission Report</h1>
            
          </div>
        </header>

        <div class="comm-filter-card">
          <div class="comm-filter-grid">
            <div class="comm-filter-group">
              <label>From Month</label>
              <input type="month" id="report-start" class="comm-input">
            </div>
            <div class="comm-filter-group">
              <label>To Month</label>
              <input type="month" id="report-end" class="comm-input">
            </div>
            <div class="comm-filter-group" style="position: relative; flex: 1.5;">
              <label>Staff / Company</label>
              <input type="text" id="report-staff" class="comm-input" placeholder="Search staff or company..." oninput="CommissionReportModule.searchStaff(this.value)" onfocus="CommissionReportModule.searchStaff(this.value)" autocomplete="off">
              <div id="staff-results" class="comm-staff-results"></div>
            </div>
            <button type="button" onclick="CommissionReportModule.generate()" class="comm-btn-primary">
              Generate Report
            </button>
          </div>
        </div>

        <div id="report-results" class="comm-results-container">
          <div class="comm-empty-state">
            <svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M9 17h6M9 13h6M9 9h6M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/>
            </svg>
            <p>Select date range to view commissions</p>
          </div>
        </div>
      </div>
    \`;

    if (!window._commClickOutsideAdded) {
      document.addEventListener('click', function(e) {
        const listEl = document.getElementById('staff-results');
        const inputEl = document.getElementById('report-staff');
        if (listEl && inputEl && !inputEl.contains(e.target) && !listEl.contains(e.target)) {
          listEl.style.display = 'none';
        }
      });
      window._commClickOutsideAdded = true;
    }
  },
  generate: async function() {
    const start = document.getElementById('report-start').value;
    const end = document.getElementById('report-end').value;
    const staffFilter = document.getElementById('report-staff').value.trim().toLowerCase();

    if (!start || !end) {
      alert("Please select both start and end months.");
      return;
    }

    const resultsEl = document.getElementById('report-results');
    resultsEl.innerHTML = \`
      <div class="comm-loading">
        <div class="comm-spinner"></div>
        <p>Processing records...</p>
      </div>
    \`;

    const data = await this.fetchData();

    if (!data || data.length === 0) {
      resultsEl.innerHTML = \`<div class="comm-empty-state"><p>No transaction data available.</p></div>\`;
      return;
    }

    const filtered = data.filter(txn => {
      if (!txn.timestamp) return false;
      const txnMonth = txn.timestamp.substring(0, 7);
      const dateMatch = txnMonth >= start && txnMonth <= end;
      const resolvedCompany = this._resolveCompany(txn).toLowerCase();
      const staffMatch = !staffFilter ||
        (txn.staff && txn.staff.toLowerCase().includes(staffFilter)) ||
        (txn.company && txn.company.toLowerCase().includes(staffFilter)) ||
        resolvedCompany.includes(staffFilter);
      return dateMatch && staffMatch;
    });

    this._filteredItems = [];
    this._grandTotalEarned = 0;

    filtered.forEach(txn => {
      if (!txn.items || !Array.isArray(txn.items)) return;

      const resolvedCompany = this._resolveCompany(txn);

      txn.items.forEach(item => {
        const commValue = parseFloat(item.commissionRate);
        if (!isNaN(commValue) && commValue > 0) {
          const price = parseFloat(item.price) || 0;
          const earned = price * (commValue / 100);
          this._grandTotalEarned += earned;

          this._filteredItems.push({
            date: new Date(txn.timestamp).toLocaleDateString('en-GB'),
            staff: txn.staff || 'N/A',
            company: resolvedCompany,
            member: txn.memberId || "Walk-in",
            product: item.prodName || item.name || 'Unknown',
            price: price,
            commValue: commValue,
            earned: earned
          });
        }
      });
    });

    if (this._filteredItems.length === 0) {
      resultsEl.innerHTML = \`<div class="comm-empty-state"><p>No commission records found for the selected period.</p></div>\`;
      return;
    }

    this._currentPage = 1;
    this._renderPaginatedTable();
  },
  _renderPaginatedTable: function() {
    const resultsEl = document.getElementById('report-results');
    if (!resultsEl) return;

    const totalItems = this._filteredItems.length;
    const totalPages = Math.ceil(totalItems / this._pageSize);
    const startIdx = (this._currentPage - 1) * this._pageSize;
    const endIdx = startIdx + this._pageSize;
    const pageItems = this._filteredItems.slice(startIdx, endIdx);

    const staffFilter = (document.getElementById('report-staff')?.value || '').trim();

    const groupedByCompany = {};
    pageItems.forEach(item => {
      const companyName = item.company || 'N/A';
      if (!groupedByCompany[companyName]) {
        groupedByCompany[companyName] = [];
      }
      groupedByCompany[companyName].push(item);
    });

    const companyKeys = Object.keys(groupedByCompany);

    const groupedHtml = companyKeys.map(companyName => {
      const encodedKey = encodeURIComponent(companyName);
      const isExpanded = staffFilter ? true : !!this._expandedCompanies[encodedKey];
      const groupItems = groupedByCompany[companyName];
      const groupEarned = groupItems.reduce((sum, it) => sum + (Number(it.earned) || 0), 0);

      const tableRows = groupItems.map(item => \`
        <tr>
          <td data-label="Date" class="comm-date">\${item.date}</td>
          <td data-label="Staff" class="comm-staff">\${item.staff} <span class="comm-company-badge">\${item.company}</span></td>
          <td data-label="Company">\${item.company}</td>
          <td data-label="Member">\${item.member}</td>
          <td data-label="Product">\${item.product}</td>
          <td data-label="Price" class="comm-price">$\${item.price.toFixed(2)}</td>
          <td data-label="Comm %" class="comm-rate">\${item.commValue}%</td>
          <td data-label="Earned" class="comm-earned">$\${item.earned.toFixed(2)}</td>
        </tr>
      \`).join('');

      return \`
        <div class="comm-company-group">
          <div class="comm-company-header" onclick="CommissionReportModule.toggleCompanyGroup('\${companyName.replace(/'/g, "\\\\'")}')">
            <div class="comm-company-header-left">
              <span id="comm-company-arrow-\${encodedKey}" class="comm-company-arrow \${isExpanded ? 'open' : ''}">▶</span>
              <span>Company: \${companyName}</span>
            </div>
            <div class="comm-company-meta">\${groupItems.length} Records · Earned: $\${groupEarned.toFixed(2)}</div>
          </div>
          <div id="comm-company-body-\${encodedKey}" class="comm-company-body \${isExpanded ? 'open' : ''}">
            <div class="comm-table-wrapper">
              <table class="comm-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Staff</th>
                    <th>Company</th>
                    <th>Member</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Comm %</th>
                    <th>Earned</th>
                  </tr>
                </thead>
                <tbody>
                  \${tableRows}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      \`;
    }).join('');

    let paginationHtml = '';
    if (totalPages > 1) {
      paginationHtml = \`
        <div class="comm-pagination">
          <button type="button" class="comm-page-btn" onclick="CommissionReportModule.changePage(\${this._currentPage - 1})" \${this._currentPage === 1 ? 'disabled' : ''}>Previous</button>
          <span class="comm-page-info">Page \${this._currentPage} of \${totalPages}</span>
          <button type="button" class="comm-page-btn" onclick="CommissionReportModule.changePage(\${this._currentPage + 1})" \${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>
        </div>
      \`;
    }

    resultsEl.innerHTML = \`
      <div class="comm-grouped-wrapper">
        \${groupedHtml}
      </div>
      \${paginationHtml}
      <div class="comm-total-footer">
        <span class="comm-total-label">TOTAL EARNINGS:</span>
        <span class="comm-total-value">$\${this._grandTotalEarned.toFixed(2)}</span>
      </div>
    \`;
  },
  changePage: function(page) {
    const totalPages = Math.ceil(this._filteredItems.length / this._pageSize);
    if (page >= 1 && page <= totalPages) {
      this._currentPage = page;
      this._renderPaginatedTable();
    }
  },
  _injectStyles: function() {
    if (document.getElementById('comm-styles')) return;

    const style = document.createElement('style');
    style.id = 'comm-styles';
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .comm-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .comm-header {
        margin-bottom: 20px;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .comm-brand h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .comm-brand p {
        margin: 4px 0 0;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-dim);
      }

      .comm-filter-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-xs);
      }

      .comm-filter-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        align-items: flex-end;
      }

      .comm-filter-group {
        flex: 1;
        min-width: 180px;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .comm-filter-group label {
        display: block;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--text-secondary);
      }

      .comm-input {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .comm-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .comm-staff-results {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-md);
        max-height: 220px;
        overflow-y: auto;
        z-index: 50;
        margin-top: 4px;
        display: none;
      }

      .comm-staff-item {
        padding: 10px 14px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        color: var(--text);
        transition: background var(--transition-fast);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
      }

      .comm-staff-item:hover {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .comm-company-badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: var(--radius-xs);
        background: var(--primary-soft);
        color: var(--primary);
        font-size: 11px;
        font-weight: 600;
      }

      .comm-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
        height: 42px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .comm-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .comm-results-container {
        background: transparent;
        border: none;
        border-radius: 0;
        overflow: visible;
        box-shadow: none;
      }

      .comm-grouped-wrapper {
        display: flex;
        flex-direction: column;
        gap: 14px;
      }

      .comm-company-group {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        overflow: hidden;
        box-shadow: var(--shadow-xs);
      }

      .comm-company-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 20px;
        background: var(--surface-soft);
        cursor: pointer;
        user-select: none;
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        transition: background var(--transition-fast);
        gap: 12px;
        flex-wrap: wrap;
      }

      .comm-company-header:hover {
        background: var(--primary-soft);
      }

      .comm-company-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .comm-company-arrow {
        display: inline-block;
        transition: transform var(--transition-fast);
        font-size: 12px;
        color: var(--text-secondary);
      }

      .comm-company-arrow.open {
        transform: rotate(90deg);
      }

      .comm-company-meta {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .comm-company-body {
        display: none;
        border-top: 1px solid var(--border);
      }

      .comm-company-body.open {
        display: block;
      }

      .comm-table-wrapper {
        overflow-x: auto;
        width: 100%;
      }

      .comm-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
      }

      .comm-table th {
        background: var(--surface-soft);
        padding: 14px 20px;
        text-align: left;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border);
      }

      .comm-table td {
        padding: 14px 20px;
        border-bottom: 1px solid var(--border);
        font-size: 14px;
        color: var(--text);
        vertical-align: middle;
      }

      .comm-table tbody tr:last-child td {
        border-bottom: none;
      }

      .comm-table tbody tr:hover td {
        background: var(--surface-soft);
      }

      .comm-date {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 13px;
        color: var(--text-dim);
      }

      .comm-staff {
        font-weight: 700;
        color: var(--text);
      }

      .comm-price,
      .comm-earned {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-weight: 600;
      }

      .comm-earned {
        color: var(--green);
        font-weight: 700;
      }

      .comm-rate {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        color: var(--primary);
        font-weight: 700;
      }

      .comm-total-footer {
        padding: 18px 24px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-top: 16px;
        display: flex;
        justify-content: flex-end;
        align-items: baseline;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .comm-total-label {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .comm-total-value {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 24px;
        font-weight: 700;
        color: var(--text);
      }

      .comm-empty-state,
      .comm-loading {
        text-align: center;
        padding: 48px 20px;
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
      }

      .comm-empty-state svg {
        color: var(--text-dim);
        margin-bottom: 12px;
      }

      .comm-empty-state p,
      .comm-loading p {
        margin: 0;
      }

      .comm-spinner {
        display: inline-block;
        width: 24px;
        height: 24px;
        border: 3px solid var(--border);
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        margin-bottom: 10px;
      }

      @keyframes spin {
        to { transform: rotate(360deg); }
      }

      .comm-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 12px;
        padding: 16px;
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        margin-top: 16px;
        background: var(--surface);
        flex-wrap: wrap;
        box-shadow: var(--shadow-xs);
      }

      .comm-page-btn {
        height: 36px;
        padding: 0 14px;
        border: 1px solid var(--border);
        background: var(--surface);
        border-radius: var(--radius-sm);
        cursor: pointer;
        font-weight: 600;
        font-size: 13px;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        outline: none;
        font-family: var(--font-sans);
      }

      .comm-page-btn:hover:not(:disabled) {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .comm-page-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .comm-page-info {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      @media (max-width: 768px) {
        .comm-wrapper {
          padding: 16px;
        }
        .comm-header {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .comm-brand h1 {
          font-size: 22px;
        }
        .comm-filter-card {
          padding: 16px;
          border-radius: var(--radius-lg);
        }
        .comm-filter-grid {
          flex-direction: column;
          align-items: stretch;
          gap: 12px;
        }
        .comm-btn-primary {
          width: 100%;
          justify-content: center;
        }
        .comm-results-container {
          background: transparent;
          border: none;
          box-shadow: none;
          overflow: visible;
        }
        .comm-table {
          min-width: 0;
        }
        .comm-table thead {
          display: none;
        }
        .comm-table tbody tr {
          display: block;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          margin-bottom: 12px;
          box-shadow: var(--shadow-xs);
        }
        .comm-table td {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border-bottom: 1px solid var(--border);
          text-align: right;
        }
        .comm-table td:last-child {
          border-bottom: none;
        }
        .comm-table td::before {
          content: attr(data-label);
          font-weight: 700;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--text-dim);
          text-align: left;
          flex-shrink: 0;
        }
        .comm-pagination {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          margin-bottom: 12px;
        }
        .comm-total-footer {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: flex-end;
          padding: 16px;
          box-shadow: var(--shadow-xs);
        }
        .comm-total-value {
          font-size: 22px;
        }
      }
    \`;
    document.head.appendChild(style);
  }
};

window.CommissionReportModule = CommissionReportModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*71)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

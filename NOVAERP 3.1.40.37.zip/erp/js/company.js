(function(){
const _k=[0x5c,0x91,0x2e,0xd7,0x48,0xb3,0x6a,0xf1,0x37,0x8c,0x15,0xe4,0x79,0xa2,0x23,0xc8];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*71)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const CompanyModule = {
  _data: [],
  _sha: '',
  _currentPage: 1,
  _itemsPerPage: 20,
  _searchQuery: '',
  _config: null,
  _editUnlocked: false,

  _isAdmin: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    return this._config.role === 'admin';
  },

  _initConfig: function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
  },

  render: async function(containerId) {
    this._initConfig();
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    const isAdminUser = this._isAdmin();

    container.innerHTML = \`
      <div class="comp-wrapper">
        <div class="comp-header">
          <div>
            <h2>Company</h2>
          </div>
          <div class="comp-header-actions">
            <button class="comp-btn-outline" onclick="CompanyModule.loadFromCloud()">Refresh</button>
            \${isAdminUser ? \`<button class="comp-btn-primary" onclick="CompanyModule.openEditor()">New Profile</button>\` : ''}
          </div>
        </div>

        <div class="comp-search-wrapper">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <input type="text" placeholder="Search by NO, name or products..." oninput="CompanyModule.handleSearch(this.value)">
        </div>

        <div id="company-list-container" class="comp-grid"></div>
        <div id="comp-pagination" class="comp-pagination"></div>
      </div>

      <div id="full-screen-editor" class="comp-modal">
        <div class="comp-modal-container">
          <div class="comp-modal-header">
            <div class="comp-modal-header-left">
              <button class="comp-btn-back" onclick="CompanyModule.closeEditor()">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3 id="editor-title">Profile Detail</h3>
            </div>
            <div class="comp-modal-header-right">
              <button class="comp-btn-cancel" onclick="CompanyModule.closeEditor()">Cancel</button>
            </div>
          </div>

          <div class="comp-modal-body">
            <div id="comp-password-banner" class="comp-password-banner" style="display:none;">
              <div class="comp-password-box">
                <label>Enter Edit Password:</label>
                <input type="password" id="comp-edit-pwd" placeholder="Enter password...">
                <button type="button" class="comp-btn-primary" onclick="CompanyModule.verifyPassword()">Unlock Edit</button>
              </div>
            </div>

            <form id="company-form" onsubmit="CompanyModule.saveData(event)">
              <div class="comp-form-grid">
                <div class="comp-field">
                  <label>Corporate Name</label>
                  <input type="text" name="name" required placeholder="Enter name...">
                </div>
                <div class="comp-field">
                  <label>Reg Number</label>
                  <input type="text" name="regNo" placeholder="Registration ID">
                </div>
                <div class="comp-field">
                  <label>Main Line</label>
                  <input type="text" name="phone" placeholder="Contact number">
                </div>
                <div class="comp-field">
                  <label>Office Address</label>
                  <input type="text" name="address" placeholder="Location details">
                </div>
                <div class="comp-field">
                  <label>Bank Name (Optional)</label>
                  <input type="text" id="bank-name" placeholder="e.g. HSBC, ICBC">
                </div>
                <div class="comp-field">
                  <label>Bank Account No (Optional)</label>
                  <input type="text" id="bank-account" placeholder="Account Number">
                </div>
                \${isAdminUser ? \`
                <div class="comp-field">
                  <label>Edit Password (Admin Only)</label>
                  <input type="text" id="comp-admin-pwd" placeholder="Set/Change password">
                </div>
                \` : ''}
              </div>

              <div class="comp-section">
                <div class="comp-section-header">
                  <span>Staff Members</span>
                  <button type="button" class="comp-btn-add" id="add-staff-btn" onclick="CompanyModule.addContactRow()">Add Staff</button>
                </div>
                <div id="contact-list" class="comp-dynamic-list"></div>
              </div>

              <div class="comp-section">
                <div class="comp-section-header">
                  <span>Inventory Items</span>
                  <button type="button" class="comp-btn-add" id="add-item-btn" onclick="CompanyModule.addProductRow()">Add Item</button>
                </div>
                <div id="product-list" class="comp-dynamic-list"></div>
              </div>

              <div class="comp-section">
                <div class="comp-section-header">
                  <span>Logistics Network</span>
                  <button type="button" class="comp-btn-add" id="add-driver-btn" onclick="CompanyModule.addLogisticsRow()">Add Driver</button>
                </div>
                <div id="logistics-list" class="comp-dynamic-list"></div>
              </div>
            </form>
          </div>

          <div class="comp-modal-footer">
            <button type="button" id="delete-btn" class="comp-btn-danger" style="display:none;" onclick="CompanyModule.deleteData()">Remove</button>
            <button type="submit" form="company-form" id="save-btn" class="comp-btn-save">Save Profile</button>
          </div>
        </div>
      </div>
    \`;

    await this.loadFromCloud();
  },

  loadFromCloud: async function() {
    this._initConfig();
    const config = this._config;
    const status = document.getElementById('comp-status');
    if (status) status.innerText = "Status: Syncing...";

    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/company.json\`, {
        headers: {
          'Authorization': \`token \${config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        const content = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this._data = content.companies || [];
        this._editPassword = content.editPassword || '';
        this.renderList();
        if (status) status.innerText = "Status: Cloud Connected";
      }
    } catch (e) {
      if (status) status.innerText = "Status: Sync Failed";
    }
  },

  verifyPassword: function() {
    const inputVal = document.getElementById('comp-edit-pwd').value;
    if (this._editPassword && inputVal === this._editPassword) {
      this._editUnlocked = true;
      document.getElementById('comp-password-banner').style.display = 'none';
      const form = document.getElementById('company-form');
      const addBtns = document.querySelectorAll('.comp-btn-add');
      const saveBtn = document.getElementById('save-btn');
      const removeBtns = document.querySelectorAll('.comp-remove-row');
      const dynamicInputs = form.querySelectorAll('.comp-section input, .comp-section select');

      dynamicInputs.forEach(el => el.disabled = false);
      addBtns.forEach(el => el.style.display = 'inline-block');
      if (saveBtn) saveBtn.style.display = 'block';
      removeBtns.forEach(btn => btn.style.display = 'inline-block');
      alert("Unlocked successfully!");
    } else {
      alert("Incorrect password!");
    }
  },

  saveData: async function(e, isDeletion = false) {
    if (e && e.preventDefault) e.preventDefault();

    if (!this._isAdmin() && !this._editUnlocked) {
      alert("Permission denied. Please enter the correct password to edit.");
      return;
    }

    const saveBtn = document.getElementById('save-btn');
    const originalText = saveBtn.innerText;
    saveBtn.innerText = "Processing...";
    saveBtn.disabled = true;

    this._initConfig();
    const config = this._config;
    const form = document.getElementById('company-form');
    const indexStr = form.dataset.index;

    let updatedList = [];
    let message = "";
    let logAction = "";
    let companyName = "";
    let newPassword = this._editPassword;

    if (this._isAdmin()) {
      const pwdInput = document.getElementById('comp-admin-pwd');
      if (pwdInput && pwdInput.value.trim() !== '') {
        newPassword = pwdInput.value.trim();
      }
    }

    if (isDeletion) {
      if (!this._isAdmin()) {
        alert("Permission denied. Only admin can delete company profiles.");
        saveBtn.innerText = originalText;
        saveBtn.disabled = false;
        return;
      }
      const idx = parseInt(indexStr);
      if (idx >= 0 && idx < this._data.length) {
        companyName = this._data[idx]?.name || "Unknown";
        updatedList = this._data.filter((_, i) => i !== idx);
        message = "System: Remove Record";
        logAction = \`Deleted Company Profile: \${companyName}\`;
      } else {
        alert("Invalid record to delete");
        saveBtn.innerText = originalText;
        saveBtn.disabled = false;
        return;
      }
    } else {
      const contacts = Array.from(document.querySelectorAll('.contact-row')).map(row => ({
        name: row.querySelector('.contact-name').value,
        phone: row.querySelector('.contact-phone').value
      })).filter(c => c.name || c.phone);

      const products = Array.from(document.querySelectorAll('.product-row')).map(row => ({
        name: row.querySelector('.prod-name').value,
        type: row.querySelector('.prod-type').value,
        other: row.querySelector('.prod-other').value
      })).filter(p => p.name);

      const logistics = Array.from(document.querySelectorAll('.logistics-row')).map(row => ({
        comp: row.querySelector('.log-comp').value,
        phone: row.querySelector('.log-phone').value,
        driver: row.querySelector('.log-driver').value,
        dphone: row.querySelector('.log-dphone').value
      })).filter(l => l.comp || l.driver);

      let targetIndex = parseInt(indexStr);
      if (isNaN(targetIndex) || targetIndex < 0 || targetIndex >= this._data.length) {
        if (!this._isAdmin()) {
          alert("Permission denied. Only admin can create new profiles.");
          saveBtn.innerText = originalText;
          saveBtn.disabled = false;
          return;
        }
      }

      try {
        const latestRes = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/company.json\`, {
          headers: {
            'Authorization': \`token \${config.ghToken}\`
          },
          cache: 'no-store'
        });

        if (latestRes.ok) {
          const latestJson = await latestRes.json();
          this._sha = latestJson.sha;
          const cloudFullData = JSON.parse(decodeURIComponent(escape(atob(latestJson.content))));
          updatedList = cloudFullData.companies || [];
          if (cloudFullData.editPassword) {
            newPassword = cloudFullData.editPassword;
            if (this._isAdmin() && document.getElementById('comp-admin-pwd') && document.getElementById('comp-admin-pwd').value.trim() !== '') {
              newPassword = document.getElementById('comp-admin-pwd').value.trim();
            }
          }
        } else {
          updatedList = [...this._data];
        }
      } catch(err) {
        updatedList = [...this._data];
      }

      if (!isNaN(targetIndex) && targetIndex >= 0 && targetIndex < updatedList.length) {
        if (!this._isAdmin()) {
          updatedList[targetIndex].contacts = contacts;
          updatedList[targetIndex].products = products;
          updatedList[targetIndex].logistics = logistics;
          updatedList[targetIndex].updatedAt = new Date().toISOString();
        } else {
          const newEntry = {
            name: form.name.value.trim(),
            regNo: form.regNo.value,
            phone: form.phone.value,
            address: form.address.value,
            contacts,
            products,
            logistics,
            bankName: document.getElementById('bank-name').value,
            bankAccount: document.getElementById('bank-account').value
          };
          companyName = newEntry.name;
          updatedList[targetIndex] = newEntry;
        }
        logAction = \`Updated Company Profile: \${updatedList[targetIndex].name}\`;
      } else {
        if (!this._isAdmin()) {
          alert("Permission denied. Only admin can create new profiles.");
          saveBtn.innerText = originalText;
          saveBtn.disabled = false;
          return;
        }
        const newEntry = {
          name: form.name.value.trim(),
          regNo: form.regNo.value,
          phone: form.phone.value,
          address: form.address.value,
          contacts,
          products,
          logistics,
          bankName: document.getElementById('bank-name').value,
          bankAccount: document.getElementById('bank-account').value
        };
        companyName = newEntry.name;
        updatedList.unshift(newEntry);
        logAction = \`Created New Company Profile: \${companyName}\`;
      }

      message = \`Update: \${companyName || 'Company Profile'}\`;
    }

    try {
      const payload = {
        companies: updatedList,
        editPassword: newPassword,
        lastUpdate: new Date().toISOString()
      };

      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/company.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${config.ghToken}\`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: message,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(payload, null, 2)))),
          sha: this._sha
        })
      });

      if (res.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          const currentUser = localStorage.getItem('ERP_USER') || "System";
          await window.LogModule.addLog('CompanyProfile', logAction, currentUser);
        }

        if (isDeletion) {
          this._data = updatedList;
          this.renderList();
          this.closeEditor();
        } else {
          this.closeEditor();
          await this.loadFromCloud();
        }
      } else {
        alert("Failed to save to cloud");
      }
    } catch (err) {
      alert("Cloud database error: " + err.message);
    } finally {
      saveBtn.innerText = originalText;
      saveBtn.disabled = false;
    }
  },

  addContactRow: function(name = '', phone = '') {
    if (!this._isAdmin() && !this._editUnlocked) return;
    const container = document.getElementById('contact-list');
    const row = document.createElement('div');
    row.className = 'contact-row comp-dynamic-row';
    row.innerHTML = \`
      <div><label>Staff Name</label><input type="text" class="contact-name" value="\${name}"></div>
      <div><label>Phone</label><input type="text" class="contact-phone" value="\${phone}"></div>
      <button type="button" class="comp-remove-row" onclick="this.parentElement.remove()">Remove</button>
    \`;
    container.appendChild(row);
  },

  addProductRow: function(name = '', type = 'New', other = '') {
    if (!this._isAdmin() && !this._editUnlocked) return;
    const container = document.getElementById('product-list');
    const row = document.createElement('div');
    row.className = 'product-row comp-dynamic-row';
    row.innerHTML = \`
      <div><label>Item Name</label><input type="text" class="prod-name" value="\${name}"></div>
      <div><label>Category</label>
        <select class="prod-type" onchange="CompanyModule.handleTypeChange(this)">
          <option value="New" \${type==='New'?'selected':''}>New Stock</option>
          <option value="Used" \${type==='Used'?'selected':''}>Old Stock</option>
          <option value="Other" \${type==='Other'?'selected':''}>Other</option>
        </select>
      </div>
      <div><label>Details</label><input type="text" class="prod-other" value="\${other}" style="display:\${type==='Other'?'block':'none'};"></div>
      <button type="button" class="comp-remove-row" onclick="this.parentElement.remove()">Remove</button>
    \`;
    container.appendChild(row);
  },

  handleTypeChange: function(el) {
    const detailsInput = el.closest('.product-row').querySelector('.prod-other');
    if (detailsInput) detailsInput.style.display = (el.value === 'Other') ? 'block' : 'none';
  },

  addLogisticsRow: function(c = '', p = '', d = '', dp = '') {
    if (!this._isAdmin() && !this._editUnlocked) return;
    const container = document.getElementById('logistics-list');
    const row = document.createElement('div');
    row.className = 'logistics-row comp-dynamic-row';
    row.innerHTML = \`
      <div><label>Co.</label><input type="text" class="log-comp" value="\${c}"></div>
      <div><label>Phone</label><input type="text" class="log-phone" value="\${p}"></div>
      <div><label>Driver</label><input type="text" class="log-driver" value="\${d}"></div>
      <div><label>Mob.</label><input type="text" class="log-dphone" value="\${dp}"></div>
      <button type="button" class="comp-remove-row" onclick="this.parentElement.remove()">Remove</button>
    \`;
    container.appendChild(row);
  },

  renderList: function() {
    const container = document.getElementById('company-list-container');
    const q = this._searchQuery.toLowerCase();

    const filtered = this._data.filter((c, index) => {
      const displayNo = (this._data.length - index).toString();
      const nameMatch = c.name.toLowerCase().includes(q);
      const noMatch = displayNo === q;
      const productMatch = c.products?.some(p => p.name.toLowerCase().includes(q));
      return nameMatch || noMatch || productMatch;
    });

    if (filtered.length === 0) {
      container.innerHTML = \`<div class="comp-empty">No matching records found</div>\`;
      return;
    }

    container.innerHTML = filtered.map((c) => {
      const originalIndex = this._data.indexOf(c);
      const displayNo = this._data.length - originalIndex;
      return \`
        <div class="comp-card" onclick="CompanyModule.openEditor(\${originalIndex})">
          <div class="comp-card-badge">NO. \${displayNo}</div>
          <div class="comp-card-name">\${c.name}</div>
          <div class="comp-card-meta">
            <span>Items: \${c.products?.length || 0}</span>
            <span>Network: \${c.logistics?.length || 0}</span>
          </div>
        </div>
      \`;
    }).join('');
  },

  openEditor: function(index = null) {
    const isAdminUser = this._isAdmin();
    this._editUnlocked = isAdminUser;
    const editor = document.getElementById('full-screen-editor');
    editor.classList.add('active');
    document.body.style.overflow = 'hidden';

    const form = document.getElementById('company-form');
    form.reset();
    form.dataset.index = index !== null ? index : "";

    document.getElementById('contact-list').innerHTML = '';
    document.getElementById('product-list').innerHTML = '';
    document.getElementById('logistics-list').innerHTML = '';
    document.getElementById('bank-name').value = '';
    document.getElementById('bank-account').value = '';
    const adminPwdInput = document.getElementById('comp-admin-pwd');
    if (adminPwdInput) adminPwdInput.value = '';

    const inputs = form.querySelectorAll('input, select');
    const addBtns = document.querySelectorAll('.comp-btn-add');
    const saveBtn = document.getElementById('save-btn');
    const deleteBtn = document.getElementById('delete-btn');
    const pwdBanner = document.getElementById('comp-password-banner');
    const editPwdInput = document.getElementById('comp-edit-pwd');
    if (editPwdInput) editPwdInput.value = '';

    if (!isAdminUser) {
      inputs.forEach(el => el.disabled = true);
      addBtns.forEach(el => el.style.display = 'none');
      if (saveBtn) saveBtn.style.display = 'none';
      if (deleteBtn) deleteBtn.style.display = 'none';
      if (pwdBanner) pwdBanner.style.display = index !== null ? 'block' : 'none';
    } else {
      inputs.forEach(el => el.disabled = false);
      addBtns.forEach(el => el.style.display = 'inline-block');
      if (saveBtn) saveBtn.style.display = 'block';
      if (pwdBanner) pwdBanner.style.display = 'none';
    }

    if (index !== null) {
      const d = this._data[index];
      const displayNo = this._data.length - index;
      document.getElementById('editor-title').innerText = \`Profile NO. \${displayNo} \${!isAdminUser && !this._editUnlocked ? '(View Only)' : ''}\`;

      form.name.value = d.name;
      form.regNo.value = d.regNo || '';
      form.phone.value = d.phone || '';
      form.address.value = d.address || '';
      document.getElementById('bank-name').value = d.bankName || '';
      document.getElementById('bank-account').value = d.bankAccount || '';

      if (d.contacts) d.contacts.forEach(c => this.addContactRow(c.name, c.phone));
      if (d.products) d.products.forEach(p => this.addProductRow(p.name, p.type, p.other));
      if (d.logistics) d.logistics.forEach(l => this.addLogisticsRow(l.comp, l.phone, l.driver, l.dphone));

      if (isAdminUser && deleteBtn) {
        deleteBtn.style.display = 'block';
      }
    } else {
      if (!isAdminUser) {
        alert("Permission denied. Only admin can create new profiles.");
        this.closeEditor();
        return;
      }
      document.getElementById('editor-title').innerText = "Create New Profile";
      if (deleteBtn) deleteBtn.style.display = 'none';
    }

    if (!isAdminUser && !this._editUnlocked) {
      const removeBtns = document.querySelectorAll('.comp-remove-row');
      removeBtns.forEach(btn => btn.style.display = 'none');
    }
  },

  closeEditor: function() {
    this._editUnlocked = false;
    document.getElementById('full-screen-editor').classList.remove('active');
    document.body.style.overflow = 'auto';
  },

  deleteData: async function() {
    if (!this._isAdmin()) {
      alert("Permission denied. Only admin can delete company profiles.");
      return;
    }

    const form = document.getElementById('company-form');
    const index = parseInt(form.dataset.index);
    if (isNaN(index) || index < 0 || index >= this._data.length) {
      alert("Invalid record to delete");
      return;
    }

    const companyName = this._data[index]?.name || "Unknown";
    if (confirm(\`Permanently delete "\${companyName}" from cloud?\`)) {
      await this.saveData(null, true);
    }
  },

  handleSearch: function(val) {
    this._searchQuery = val;
    this.renderList();
  },

  _injectStyles: function() {
    if (document.getElementById('comp-styles')) return;

    const style = document.createElement('style');
    style.id = 'comp-styles';
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .comp-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
      }

      .comp-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .comp-header h2 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .comp-header-actions {
        display: flex;
        gap: 12px;
      }

      .comp-btn-primary,
      .comp-btn-outline {
        padding: 10px 20px;
        height: 42px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: none;
      }

      .comp-btn-primary {
        background: var(--primary);
        color: white;
        box-shadow: var(--shadow-primary);
      }

      .comp-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .comp-btn-primary:active {
        transform: translateY(0);
      }

      .comp-btn-outline {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--text-secondary);
        box-shadow: var(--shadow-xs);
      }

      .comp-btn-outline:hover {
        background: var(--surface-soft);
        border-color: var(--border-strong);
        color: var(--text);
      }

      .comp-search-wrapper {
        position: relative;
        margin-bottom: 24px;
        max-width: 450px;
      }

      .comp-search-wrapper svg {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-dim);
        pointer-events: none;
      }

      .comp-search-wrapper input {
        width: 100%;
        padding: 10px 16px 10px 42px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        box-shadow: var(--shadow-xs);
        color: var(--text);
      }

      .comp-search-wrapper input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .comp-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 20px;
      }

      .comp-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-sm);
        position: relative;
      }

      .comp-card:hover {
        transform: translateY(-3px);
        border-color: var(--primary-light);
        box-shadow: var(--shadow-md);
      }

      .comp-card-badge {
        display: inline-block;
        font-family: monospace;
        font-size: 11px;
        font-weight: 600;
        color: var(--primary);
        background: var(--primary-soft);
        padding: 3px 8px;
        border-radius: var(--radius-sm);
        margin-bottom: 10px;
      }

      .comp-card-name {
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 12px;
        color: var(--text);
        letter-spacing: -0.01em;
      }

      .comp-card-meta {
        display: flex;
        gap: 16px;
        padding-top: 12px;
        border-top: 1px solid var(--border);
        font-size: 13px;
        color: var(--text-secondary);
      }

      .comp-modal {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transform: scale(0.99);
        transition: visibility 0.2s ease, opacity 0.2s ease, transform 0.2s ease;
        display: flex;
        flex-direction: column;
      }

      .comp-modal.active {
        visibility: visible;
        opacity: 1;
        transform: scale(1);
      }

      .comp-modal-container {
        height: 100vh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        background: var(--bg);
      }

      .comp-modal-header {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        box-shadow: var(--shadow-xs);
      }

      .comp-modal-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .comp-btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }

      .comp-btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .comp-modal-header-left h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .comp-btn-cancel {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 8px 16px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
      }

      .comp-btn-cancel:hover {
        background: var(--border);
        color: var(--text);
      }

      .comp-modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 32px 20px;
      }

      .comp-modal-body form {
        max-width: 900px;
        margin: 0 auto;
      }

      .comp-password-banner {
        max-width: 900px;
        margin: 0 auto 24px auto;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        box-shadow: var(--shadow-sm);
      }

      .comp-password-box {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
      }

      .comp-password-box label {
        font-weight: 600;
        font-size: 13px;
        color: var(--text);
      }

      .comp-password-box input {
        flex: 1;
        min-width: 220px;
        padding: 9px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        outline: none;
      }

      .comp-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin-bottom: 28px;
      }

      .comp-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .comp-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .comp-field input {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .comp-field input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .comp-section {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: var(--shadow-xs);
      }

      .comp-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        font-size: 14px;
        font-weight: 700;
        color: var(--text);
      }

      .comp-btn-add {
        background: var(--primary-soft);
        border: 1px dashed var(--primary);
        color: var(--primary);
        padding: 6px 14px;
        border-radius: var(--radius-sm);
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--transition-fast);
      }

      .comp-btn-add:hover {
        background: var(--primary);
        color: white;
      }

      .comp-dynamic-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .comp-dynamic-row {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 16px;
        display: grid;
        grid-template-columns: 1fr 1fr 90px;
        gap: 12px;
        align-items: flex-end;
      }

      .comp-dynamic-row label {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        display: block;
        margin-bottom: 4px;
      }

      .comp-dynamic-row input,
      .comp-dynamic-row select {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 13px;
        background: var(--surface);
        outline: none;
        color: var(--text);
        transition: all var(--transition-fast);
      }

      .comp-dynamic-row input:focus,
      .comp-dynamic-row select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 2px var(--primary-glow);
      }

      .comp-remove-row {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        padding: 8px;
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        color: var(--danger);
        transition: all var(--transition-fast);
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .comp-remove-row:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .product-row {
        grid-template-columns: 1.4fr 1fr 1fr 90px;
      }

      .logistics-row {
        grid-template-columns: 1fr 1fr 1fr 1fr 90px;
      }

      .comp-modal-footer {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        gap: 12px;
        justify-content: flex-end;
        flex-shrink: 0;
        box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
      }

      .comp-btn-save {
        background: var(--primary);
        color: white;
        border: none;
        padding: 10px 28px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
        box-shadow: var(--shadow-primary);
      }

      .comp-btn-save:hover {
        background: var(--primary-dark);
      }

      .comp-btn-save:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .comp-btn-danger {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        padding: 10px 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all var(--transition-base);
      }

      .comp-btn-danger:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .comp-empty {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .comp-pagination {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-top: 32px;
      }

      @media (max-width: 1024px) {
        .comp-dynamic-row,
        .product-row,
        .logistics-row {
          grid-template-columns: 1fr 1fr;
        }
        .comp-remove-row {
          grid-column: span 2;
          width: 100%;
        }
      }

      @media (max-width: 768px) {
        .comp-wrapper {
          padding: 16px;
        }
        .comp-header {
          flex-direction: column;
          align-items: stretch;
        }
        .comp-header-actions {
          width: 100%;
        }
        .comp-btn-primary,
        .comp-btn-outline {
          flex: 1;
        }
        .comp-modal-header {
          padding: 14px 16px;
        }
        .comp-modal-body {
          padding: 20px 14px;
        }
        .comp-modal-footer {
          padding: 14px 16px;
          flex-direction: column-reverse;
        }
        .comp-btn-save,
        .comp-btn-danger {
          width: 100%;
          text-align: center;
        }
        .comp-dynamic-row,
        .product-row,
        .logistics-row {
          grid-template-columns: 1fr;
        }
        .comp-remove-row {
          grid-column: span 1;
        }
        .comp-search-wrapper {
          max-width: 100%;
        }
      }
    \`;
    document.head.appendChild(style);
  }
};

window.CompanyModule = CompanyModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*71)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

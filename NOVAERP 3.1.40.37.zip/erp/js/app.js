(function(){
const _k=[0x5e,0x8d,0x23,0xb7,0x41,0xc9,0x76,0xe2,0x1f,0x9a,0x64,0xd8,0x37,0xaf,0x0c,0xf5];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*71)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const App = {
    init: async function() {
        console.log("Initializing App...");

        const deploymentStr = localStorage.getItem('ERP_DEPLOYMENT_DATA');
        const configStr = localStorage.getItem('ERP_CONFIG');

        if (!deploymentStr) {
            window.location.href = 'install.html';
            return;
        }

        if (!configStr) {
            window.location.href = 'login.html';
            return;
        }

        const config = JSON.parse(configStr);

        try {
            const isSessionValid = await this.syncAndValidateSession(config);
            if (!isSessionValid) return;

        } catch (error) {
            console.error("Cloud session sync failed:", error);
        }

        if (typeof SettingsModule !== 'undefined') {
            SettingsModule.render('module-container');
        }
    },

    syncAndValidateSession: async function(config) {
        const deployment = JSON.parse(localStorage.getItem('ERP_DEPLOYMENT_DATA') || '{}');

        if (!config.deviceId) {
            this.handleLogout();
            return false;
        }

        const sessions = await this.fetchRemoteSessions(deployment);

        if (sessions && Array.isArray(sessions)) {
            const mySession = sessions.find(s => s.id === config.deviceId);

            if (mySession && mySession.active === false) {
                alert("Access Revoked: This device has been logged out remotely.");
                this.handleLogout();
                return false;
            }

            localStorage.setItem('ERP_CONFIG', JSON.stringify({
                ...config,
                lastVerified: new Date().getTime()
            }));
        }
        return true;
    },

    fetchRemoteSessions: async function(deployment) {
        try {
            const res = await fetch(\`https://api.github.com/repos/\${deployment.ghRepo}/contents/db_date/login.js\`, {
                headers: { 'Authorization': \`token \${deployment.ghToken}\` },
                cache: 'no-store'
            });

            if (res.ok) {
                const data = await res.json();
                const content = atob(data.content);
                const jsonMatch = content.match(/\\\[.*\\\]/s);
                return jsonMatch ? JSON.parse(jsonMatch[0]) : [];
            }
            return [];
        } catch (e) {
            console.warn("Could not fetch remote sessions:", e);
            return null;
        }
    },

    handleLogout: function() {
        localStorage.removeItem('ERP_CONFIG');
        window.location.href = 'login.html';
    }
};

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*71)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

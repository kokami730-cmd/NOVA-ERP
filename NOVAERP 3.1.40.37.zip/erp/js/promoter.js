(function(){
const _k=[0x5c,0x23,0x9b,0x47,0xd1,0x6e,0x84,0x19,0xa7,0x3f,0xc8,0x72,0xe5,0x14,0xb0,0x69];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*71)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const PromoterModule = {
  _data: [],
  _filteredData: [],
  _config: null,
  _currentId: null,
  _currentPage: 1,
  _pageSize: 20,
  _sha: null,
  render: async function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = \`
      <div class="prom-app-wrapper">
        <header class="prom-main-header">
          <div class="brand-info">
            <h1>Promoter Directory</h1>
            </div>
          <div class="prom-header-actions">
            <div class="search-input-wrapper">
              <svg class="icon-search" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" id="prom-search" placeholder="Search by name, outlet or company..." oninput="PromoterModule.filter()">
            </div>
            <button type="button" class="btn-add-prom" onclick="PromoterModule.openEditor()">
              <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              <span class="text-label">New Promoter</span>
            </button>
          </div>
        </header>

        <main id="promoter-list" class="prom-responsive-grid">
          <div class="loading-placeholder">Syncing directory...</div>
        </main>

        <footer id="prom-pagination" class="modern-pagination"></footer>
      </div>

      <div id="prom-modal" class="prom-modal-fullscreen">
        <div class="modal-inner-content">
          <nav class="modal-top-nav">
            <div class="nav-left">
              <button type="button" class="btn-back" onclick="PromoterModule.closeEditor()">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h2 id="prom-modal-title">Promoter Profile</h2>
            </div>
            <div class="nav-right">
              <button type="button" class="prom-modal-close" onclick="PromoterModule.closeEditor()">Close</button>
              <button type="button" id="prom-del-btn" class="btn-delete-action" onclick="PromoterModule.delete()" style="display:none">Delete</button>
              <button type="submit" form="prom-form" id="save-btn-top" class="btn-save-top">Save</button>
            </div>
          </nav>

          <form id="prom-form" class="modal-scroll-form" onsubmit="PromoterModule.save(event)">
            <div class="form-layout-container">
              <section class="form-section-card">
                <div class="section-header"><h3>Identity Details</h3></div>
                <div class="form-grid">
                  <div class="form-field full-width">
                    <label>Full Name</label>
                    <input type="text" name="name" required placeholder="Name as per IC">
                  </div>
                  <div class="form-field">
                    <label>Mobile Number</label>
                    <input type="tel" name="phone" placeholder="01x-xxxxxxx">
                  </div>
                  <div class="form-field">
                    <label>IC / Passport</label>
                    <input type="text" name="ic" placeholder="ID Number">
                  </div>
                </div>
              </section>

              <section class="form-section-card highlight-card">
                <div class="section-header"><h3>Employment & Assignment</h3></div>
                <div class="form-grid">
                  <div class="form-field">
                    <label>Company</label>
                    <input type="text" name="company" list="company-list" placeholder="Select or type">
                    <datalist id="company-list"></datalist>
                  </div>
                  <div class="form-field">
                    <label>Primary Outlet</label>
                    <input type="text" name="outlet" placeholder="Assigned branch">
                  </div>
                  <div class="form-field">
                    <label>Start Date</label>
                    <input type="date" name="startDate">
                  </div>
                  <div class="form-field">
                    <label>End Date</label>
                    <input type="date" name="endDate">
                  </div>
                </div>
              </section>

              <section class="form-section-card">
                <div class="section-header"><h3>Financial & Status</h3></div>
                <div class="form-grid">
                  <div class="form-field">
                    <label>Commission Rate (%)</label>
                    <input type="number" name="commRate" step="0.1" value="1.0">
                  </div>
                  <div class="form-field">
                    <label>Employment Status</label>
                    <select name="status">
                      <option value="Active">Active</option>
                      <option value="On Leave">On Leave</option>
                      <option value="Terminated">Terminated</option>
                    </select>
                  </div>
                  <div class="form-field">
                    <label>Bank Name</label>
                    <input type="text" name="bankName" placeholder="e.g. Maybank">
                  </div>
                  <div class="form-field">
                    <label>Account Number</label>
                    <input type="text" name="bankAcc" placeholder="Account No.">
                  </div>
                </div>
              </section>
            </div>

            <footer class="form-fixed-footer">
              <div class="footer-meta">
                <span class="label">Last Updated</span>
                <span id="prom-updated-display" class="value">-</span>
              </div>
              <button type="submit" id="save-btn-main" class="btn-submit-save">Save Profile</button>
            </footer>
          </form>
        </div>
      </div>
    \`;

    await this.load();
  },
  load: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/promoters.json\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      } else if (res.status === 404) {
        this._data = [];
        this._sha = null;
      } else {
        this._data = [];
      }

      this._data = this._data.map((item, index) => ({
        ...item,
        _displayNo: (index + 1).toString()
      }));

      this._filteredData = [...this._data];
      await this.updateCompanyDatalist();
      this.renderList();
    } catch (e) {
      console.error("Load failed", e);
      this._data = [];
      this._filteredData = [];
      this.renderList();
    }
  },
  updateCompanyDatalist: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    let companySet = new Set(this._data.map(p => p.company).filter(c => c && c.trim() !== ""));

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/company.json\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });

      if (res.ok) {
        const cloudData = await res.json();
        const content = JSON.parse(decodeURIComponent(escape(atob(cloudData.content))));

        if (content.companies) {
          content.companies.forEach(c => {
            if (c.name) companySet.add(c.name.trim());
          });
        } else if (Array.isArray(content)) {
          content.forEach(c => {
            if (c && typeof c === 'object' && c.name) companySet.add(c.name.trim());
          });
        }
      }
    } catch (e) {
      console.warn("Failed to load company data for suggestions", e);
    }

    const datalist = document.getElementById('company-list');
    if (datalist) {
      datalist.innerHTML = Array.from(companySet).sort().map(c => \`<option value="\${c}">\`).join('');
    }
  },
  renderList: function() {
    const grid = document.getElementById('promoter-list');
    const total = this._filteredData.length;

    const countEl = document.getElementById('prom-count');
    if (countEl) countEl.innerText = \`\${total} Total\`;

    const totalPages = Math.ceil(total / this._pageSize);
    const start = (this._currentPage - 1) * this._pageSize;
    const pagedData = this._filteredData.slice(start, start + this._pageSize);

    if (pagedData.length === 0) {
      grid.innerHTML = \`<div class="empty-state">No matching records found.</div>\`;
      document.getElementById('prom-pagination').innerHTML = '';
      return;
    }

    grid.innerHTML = pagedData.map(p => \`
      <article class="prom-card-item" onclick="PromoterModule.openEditor('\${p.id}')">
        <div class="card-upper">
          <span class="no-badge">#\${p._displayNo}</span>
          <div class="status-tag status-\${(p.status || 'Active').toLowerCase().replace(/\\s/g, '-')}">\${p.status || 'Active'}</div>
        </div>
        <div class="card-mid">
          <h3 class="p-name-text">\${p.name}</h3>
          <p class="p-sub-text">\${p.company || 'Personal'} - \${p.outlet || 'Global'}</p>
        </div>
        <div class="card-lower">
          <div class="comm-display">
            <span class="val">\${p.commRate || 0}%</span>
            <span class="lbl">COMMISSION</span>
          </div>
          <div class="phone-info">\${p.phone || '--'}</div>
        </div>
      </article>
    \`).join('');

    this._renderPagination(totalPages);
  },
  filter: function() {
    const q = (document.getElementById('prom-search')?.value || '').toLowerCase();

    this._filteredData = this._data.filter(x =>
      (x._displayNo && x._displayNo.includes(q)) ||
      (x.name && x.name.toLowerCase().includes(q)) ||
      (x.outlet && x.outlet.toLowerCase().includes(q)) ||
      (x.company && x.company.toLowerCase().includes(q))
    );

    this._currentPage = 1;
    this.renderList();
  },
  openEditor: async function(id = null) {
    this._currentId = id;
    const modal = document.getElementById('prom-modal');
    const form = document.getElementById('prom-form');

    form.reset();
    await this.updateCompanyDatalist();

    if (id) {
      const p = this._data.find(x => x.id === id);
      if (p) {
        document.getElementById('prom-modal-title').innerText = "Edit Profile";
        document.getElementById('prom-del-btn').style.display = 'inline-flex';
        document.getElementById('prom-updated-display').innerText = p.updatedAt ? new Date(p.updatedAt).toLocaleDateString() : '-';

        Object.keys(p).forEach(key => {
          if (form.elements[key]) form.elements[key].value = p[key] || '';
        });
      }
    } else {
      document.getElementById('prom-modal-title').innerText = "Register New";
      document.getElementById('prom-del-btn').style.display = 'none';
      document.getElementById('prom-updated-display').innerText = "New Entry";
    }

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },
  closeEditor: function() {
    document.getElementById('prom-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  save: async function(e) {
    e.preventDefault();

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const btn = document.getElementById('save-btn-main');
    const topBtn = document.getElementById('save-btn-top');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Syncing...";
    if (topBtn) {
      topBtn.disabled = true;
      topBtn.innerText = "Syncing...";
    }

    const fd = new FormData(e.target);

    const promoterData = {
      id: this._currentId || 'PROM-' + Date.now(),
      name: fd.get('name'),
      phone: fd.get('phone'),
      ic: fd.get('ic'),
      company: fd.get('company'),
      outlet: fd.get('outlet'),
      commRate: fd.get('commRate'),
      status: fd.get('status'),
      startDate: fd.get('startDate'),
      endDate: fd.get('endDate'),
      bankName: fd.get('bankName'),
      bankAcc: fd.get('bankAcc'),
      updatedAt: new Date().toISOString()
    };

    try {
      let rawData = this._data.map(({ _displayNo, ...rest }) => rest);
      const isUpdate = !!this._currentId;

      if (isUpdate) {
        const idx = rawData.findIndex(p => p.id === this._currentId);
        if (idx !== -1) rawData[idx] = promoterData;
      } else {
        rawData.push(promoterData);
      }

      let currentSha = this._sha;
      if (!currentSha) {
        const getRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/promoters.json\`, {
          headers: {
            'Authorization': \`token \${this._config.ghToken}\`
          }
        });
        if (getRes.ok) {
          const data = await getRes.json();
          currentSha = data.sha;
        }
      }

      const content = btoa(unescape(encodeURIComponent(JSON.stringify(rawData, null, 2))));

      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/promoters.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: \`Update: \${promoterData.name}\`,
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          const logAction = isUpdate ? \`Updated promoter: \${promoterData.name}\` : \`Registered new promoter: \${promoterData.name}\`;
          await window.LogModule.addLog('PromoterModule', logAction);
        }
        this.closeEditor();
        await this.load();
      } else {
        const errorData = await res.json();
        alert("Save failed: " + (errorData.message || "Unknown error"));
      }
    } catch (e) {
      alert("Connection Error: " + e.message);
    } finally {
      btn.disabled = false;
      btn.innerText = originalText;
      if (topBtn) {
        topBtn.disabled = false;
        topBtn.innerText = "Save";
      }
    }
  },
  delete: async function() {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const promoterToDelete = this._data.find(p => p.id === this._currentId);
    if (!promoterToDelete || !confirm(\`Permanently remove \${promoterToDelete.name}?\`)) return;

    const rawData = this._data.filter(p => p.id !== this._currentId).map(({ _displayNo, ...rest }) => rest);

    let currentSha = this._sha;
    if (!currentSha) {
      const getRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/promoters.json\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      if (getRes.ok) {
        const data = await getRes.json();
        currentSha = data.sha;
      }
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(rawData, null, 2))));

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/promoters.json\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: "Delete Promoter",
          content,
          sha: currentSha || undefined
        })
      });

      if (res.ok) {
        if (window.LogModule && typeof window.LogModule.addLog === 'function') {
          await window.LogModule.addLog('PromoterModule', \`Deleted promoter: \${promoterToDelete.name}\`);
        }
        this.closeEditor();
        await this.load();
      } else {
        const errorData = await res.json();
        alert("Delete failed: " + (errorData.message || "Unknown error"));
      }
    } catch (e) {
      alert("Delete failed: " + e.message);
    }
  },
  _renderPagination: function(totalPages) {
    const container = document.getElementById('prom-pagination');

    if (totalPages <= 1) {
      container.innerHTML = '';
      return;
    }

    let btns = \`<button type="button" class="p-nav" onclick="PromoterModule.changePage(\${this._currentPage - 1})" \${this._currentPage === 1 ? 'disabled' : ''}>Prev</button>\`;

    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= this._currentPage - 1 && i <= this._currentPage + 1)) {
        btns += \`<button type="button" class="p-num \${i === this._currentPage ? 'active' : ''}" onclick="PromoterModule.changePage(\${i})">\${i}</button>\`;
      } else if (i === this._currentPage - 2 || i === this._currentPage + 2) {
        btns += \`<span class="p-dots">...</span>\`;
      }
    }

    btns += \`<button type="button" class="p-nav" onclick="PromoterModule.changePage(\${this._currentPage + 1})" \${this._currentPage === totalPages ? 'disabled' : ''}>Next</button>\`;
    container.innerHTML = btns;
  },
  changePage: function(p) {
    this._currentPage = p;
    this.renderList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  _injectStyles: function() {
    if (document.getElementById('prom-modern-css')) return;

    const s = document.createElement('style');
    s.id = 'prom-modern-css';
    s.innerHTML = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 8px;
        --radius-xs: 6px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      .prom-app-wrapper {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        color: var(--text);
        -webkit-font-smoothing: antialiased;
        width: 100%;
      }

      .prom-main-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        gap: 16px;
        flex-wrap: wrap;
      }

      .brand-info h1 {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
      }

      .prom-count-pill {
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
        margin-top: 4px;
        display: block;
      }

      .prom-header-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
      }

      .search-input-wrapper {
        position: relative;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 40px;
        min-width: 240px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .search-input-wrapper:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .icon-search {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      #prom-search {
        border: none;
        outline: none;
        width: 100%;
        font-size: 13px;
        background: transparent;
        padding-left: 10px;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .btn-add-prom {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 18px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .btn-add-prom:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .btn-add-prom:active {
        transform: translateY(0);
      }

      .prom-responsive-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
      }

      .prom-card-item {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 20px;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: flex;
        flex-direction: column;
        gap: 14px;
        box-shadow: var(--shadow-xs);
      }

      .prom-card-item:hover {
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
        transform: translateY(-2px);
      }

      .card-upper {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
      }

      .no-badge {
        font-family: monospace;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        background: var(--surface-soft);
        padding: 3px 8px;
        border-radius: var(--radius-xs);
        border: 1px solid var(--border);
      }

      .status-tag {
        font-size: 11px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: var(--radius-sm);
      }

      .status-active {
        background: var(--green-soft);
        color: var(--green);
      }

      .status-terminated {
        background: var(--red-soft);
        color: var(--danger);
      }

      .status-on-leave {
        background: var(--amber-soft);
        color: var(--amber);
      }

      .p-name-text {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .p-sub-text {
        margin: 4px 0 0;
        font-size: 12px;
        color: var(--text-secondary);
        font-weight: 500;
        word-break: break-word;
      }

      .card-lower {
        margin-top: auto;
        padding-top: 14px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        gap: 10px;
      }

      .comm-display {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .comm-display .val {
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        line-height: 1.1;
      }

      .comm-display .lbl {
        font-size: 10px;
        font-weight: 700;
        color: var(--text-dim);
        letter-spacing: 0.05em;
      }

      .phone-info {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        word-break: break-word;
      }

      .prom-modal-fullscreen {
        position: fixed;
        inset: 0;
        background: var(--bg);
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transition: visibility 0.2s, opacity 0.2s ease;
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .prom-modal-fullscreen.active {
        visibility: visible;
        opacity: 1;
      }

      .modal-inner-content {
        height: 100%;
        display: flex;
        flex-direction: column;
        width: 100%;
      }

      .modal-top-nav {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        padding: 16px 28px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
        gap: 14px;
        flex-wrap: wrap;
        box-shadow: var(--shadow-xs);
      }

      .nav-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
        flex: 1;
      }

      .nav-right {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
      }

      .btn-back {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
      }

      .btn-back:hover {
        background: var(--border);
        color: var(--text);
      }

      .nav-left h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
        word-break: break-word;
      }

      .prom-modal-close {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .prom-modal-close:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .btn-delete-action {
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--danger);
        height: 36px;
        padding: 0 14px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        font-family: var(--font-sans);
      }

      .btn-delete-action:hover {
        background: var(--red-soft);
        border-color: var(--danger);
      }

      .btn-save-top {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 36px;
        padding: 0 18px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-save-top:hover {
        background: var(--primary-dark);
      }

      .modal-scroll-form {
        flex: 1;
        overflow-y: auto;
        padding: 28px 20px;
      }

      .form-layout-container {
        max-width: 920px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        gap: 20px;
        width: 100%;
      }

      .form-section-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 22px;
        box-shadow: var(--shadow-xs);
      }

      .section-header h3 {
        margin: 0 0 18px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--text-secondary);
      }

      .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
      }

      .form-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-width: 0;
      }

      .form-field label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .form-field input,
      .form-field select {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        background: var(--surface);
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .form-field input:focus,
      .form-field select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .full-width {
        grid-column: 1 / -1;
      }

      .form-fixed-footer {
        max-width: 920px;
        margin: 24px auto 0;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 16px 22px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        box-shadow: var(--shadow-xs);
      }

      .footer-meta {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .footer-meta .label {
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
      }

      .footer-meta .value {
        font-size: 13px;
        font-weight: 700;
        color: var(--text);
      }

      .btn-submit-save {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 40px;
        padding: 0 22px;
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .btn-submit-save:hover {
        background: var(--primary-dark);
      }

      .modern-pagination {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 28px;
        flex-wrap: wrap;
      }

      .p-num,
      .p-nav {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 34px;
        padding: 0 12px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .p-num.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .p-num:hover:not(.active),
      .p-nav:hover:not(:disabled) {
        border-color: var(--border-strong);
        color: var(--text);
        background: var(--surface-soft);
      }

      .p-nav:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .p-dots {
        padding: 0 6px;
        color: var(--text-dim);
        line-height: 34px;
      }

      .empty-state,
      .loading-placeholder {
        text-align: center;
        padding: 60px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-size: 14px;
        grid-column: 1 / -1;
      }

      @media (max-width: 768px) {
        .prom-app-wrapper {
          padding: 16px;
        }
        .prom-main-header {
          flex-direction: column;
          align-items: stretch;
        }
        .prom-header-actions {
          flex-direction: column;
          align-items: stretch;
        }
        .search-input-wrapper {
          width: 100%;
          min-width: 0;
        }
        .btn-add-prom {
          justify-content: center;
          width: 100%;
        }
        .prom-responsive-grid {
          grid-template-columns: 1fr;
          gap: 14px;
        }
        .prom-card-item {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .form-grid {
          grid-template-columns: 1fr;
        }
        .modal-top-nav {
          padding: 14px 16px;
        }
        .nav-left h2 {
          font-size: 16px;
        }
        .modal-scroll-form {
          padding: 18px 14px;
        }
        .form-section-card {
          padding: 18px;
          border-radius: var(--radius-lg);
        }
        .form-fixed-footer {
          flex-direction: column-reverse;
          align-items: stretch;
          padding: 14px 16px;
          border-radius: var(--radius-lg);
        }
        .btn-submit-save {
          width: 100%;
          text-align: center;
        }
      }
    \`;
    document.head.appendChild(s);
  }
};

window.PromoterModule = PromoterModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*71)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

(function(){
const _k=[0x5c,0x91,0x2e,0xd7,0x74,0xb8,0x3f,0xe1,0x6a,0xa3,0x19,0xc8,0x85,0xf2,0x4b,0x9d];
function _d(a){
  const b=new Uint8Array(a.length);
  for(let i=0;i<a.length;i++){
    b[i]=a[i]^_k[i%_k.length]^((i*67)&0xff);
  }
  return new TextDecoder().decode(b);
}
const _s=`const FileModule = {
  _config: null,
  _currentPath: 'file',
  _history: [],
  _allItems: [],
  _currentPage: 1,
  _pageSize: 20,
  _searchQuery: '',
  _storageLimit: 1000 * 1024 * 1024,
  _pendingFiles: [],
  _selectedItems: new Set(),
  _isSelectMode: false,
  render: function(containerId) {
    this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const container = document.getElementById(containerId);
    if (!container) return;
    this._injectStyles();

    container.innerHTML = \`
      <div class="fm-container">
        <div class="fm-header">
          <div class="fm-brand-area">
            <button type="button" id="fm-back-btn" class="fm-icon-btn" onclick="FileModule.goBack()" style="display:none;">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
            <div class="fm-title">
              <h2 onclick="FileModule.resetToRoot()">File Storage</h2>
              <div id="fm-breadcrumb" class="fm-breadcrumb">file /</div>
            </div>
          </div>
          <div class="fm-stats" id="fm-storage-card">
            <div class="fm-stats-info">
              <span id="stat-usage">0 KB used</span>
              <span id="stat-count">0 items</span>
            </div>
            <div class="fm-stats-bar">
              <div id="stat-progress-fill" class="fm-stats-fill" style="width: 0%"></div>
            </div>
          </div>
          <div class="fm-search">
            <svg class="fm-search-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="fm-search-input" placeholder="Search resources..." oninput="FileModule.handleSearch(this.value)">
          </div>
          <div class="fm-actions">
            <button type="button" class="fm-icon-btn" id="fm-select-mode-btn" onclick="FileModule.toggleSelectMode()" title="Select Multiple">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
            </button>
            <button type="button" class="fm-icon-btn" onclick="FileModule.openCreateModal('folder')" title="New Folder">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
            </button>
            <button type="button" class="fm-icon-btn" onclick="FileModule.openCreateModal('file')" title="New File">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
            </button>
            <label class="fm-upload-btn">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              <span>Upload</span>
              <input type="file" id="file-upload-input" style="display:none" multiple onchange="FileModule.handleUpload(this)">
            </label>
          </div>
        </div>

        <div id="fm-admin-notice" class="fm-admin-notice" style="display:none;">
          Admin Mode: Private items are hidden from view.
        </div>

        <div id="fm-bulk-bar" class="fm-bulk-bar" style="display:none;">
          <span id="fm-bulk-count" class="fm-bulk-count">0 selected</span>
          <button type="button" class="fm-bulk-btn" onclick="FileModule.downloadSelected()">Download</button>
          <button type="button" class="fm-bulk-btn fm-bulk-delete" onclick="FileModule.deleteSelected()">Delete</button>
          <button type="button" class="fm-bulk-btn" onclick="FileModule.renameSelected()">Rename</button>
          <button type="button" class="fm-bulk-btn" onclick="FileModule.clearSelection()">Clear</button>
        </div>

        <div id="file-list" class="fm-grid">
          <div class="fm-loading">Initialising System...</div>
        </div>

        <div id="fm-pagination" class="fm-pagination"></div>
      </div>

      <div id="fm-modal" class="fm-modal">
        <div class="fm-modal-card">
          <div class="fm-modal-header"><h3 id="fm-modal-title">Action</h3></div>
          <div class="fm-modal-body">
            <input type="text" id="fm-modal-input" placeholder="Enter name..." autofocus>
            <div class="fm-privacy-toggle">
              <span>Restrict Access? (Private)</span>
              <div class="fm-radio-group">
                <label><input type="radio" name="fm-is-private" value="yes"> Yes</label>
                <label><input type="radio" name="fm-is-private" value="no" checked> No</label>
              </div>
            </div>
          </div>
          <div class="fm-modal-footer">
            <button type="button" class="fm-btn-text" onclick="FileModule.closeModal()">Cancel</button>
            <button type="button" class="fm-btn-primary" id="fm-modal-confirm">Confirm</button>
          </div>
        </div>
      </div>

      <div id="fm-upload-modal" class="fm-modal">
        <div class="fm-modal-card">
          <div class="fm-modal-header"><h3>Upload Files</h3></div>
          <div class="fm-modal-body">
            <p id="fm-upload-count">Selected files: 0</p>
            <p>Configure visibility before uploading.</p>
            <div class="fm-privacy-toggle">
              <span>Restrict Access? (Private)</span>
              <div class="fm-radio-group">
                <label><input type="radio" name="fm-upload-private" value="yes"> Yes</label>
                <label><input type="radio" name="fm-upload-private" value="no" checked> No</label>
              </div>
            </div>
          </div>
          <div class="fm-modal-footer">
            <button type="button" class="fm-btn-text" onclick="FileModule.closeUploadModal()">Cancel</button>
            <button type="button" class="fm-btn-primary" id="fm-upload-confirm">Upload All</button>
          </div>
        </div>
      </div>

      <div id="fm-edit-modal" class="fm-modal fm-modal-fullscreen">
        <div class="fm-modal-card fm-edit-card">
          <div class="fm-modal-header fm-edit-header">
            <h3>Edit File Content</h3>
            <div class="fm-edit-actions">
              <button type="button" class="fm-btn-text" onclick="FileModule.closeEditor()">Discard</button>
              <button type="button" class="fm-btn-primary" id="fm-editor-save">Save</button>
            </div>
          </div>
          <textarea id="fm-editor-area" spellcheck="false"></textarea>
        </div>
      </div>

      <div id="fm-preview" class="fm-modal fm-modal-fullscreen" onclick="FileModule.closePreview()">
        <div class="fm-preview-card" onclick="event.stopPropagation()">
          <div class="fm-preview-header">
            <span id="fm-preview-title">Preview</span>
            <button type="button" class="fm-preview-close" onclick="FileModule.closePreview()">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
          <div id="fm-preview-body" class="fm-preview-body"></div>
        </div>
      </div>

      <div id="fm-rename-modal" class="fm-modal">
        <div class="fm-modal-card">
          <div class="fm-modal-header"><h3>Rename Selected Items</h3></div>
          <div class="fm-modal-body">
            <p>Enter new base name (extension preserved):</p>
            <input type="text" id="fm-rename-input" placeholder="New name">
          </div>
          <div class="fm-modal-footer">
            <button type="button" class="fm-btn-text" onclick="FileModule.closeRenameModal()">Cancel</button>
            <button type="button" class="fm-btn-primary" id="fm-rename-confirm">Rename</button>
          </div>
        </div>
      </div>
    \`;

    this.browse(this._currentPath, 'init');
  },
  _writeSystemLog: async function(action) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    try {
      const staff = this._config.staff || 'Unknown';
      const url = \`https://api.github.com/repos/\${this._config.ghRepo}/contents/db_date/logs.json\`;
      const res = await fetch(\`\${url}?t=\${Date.now()}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      let logs = [];
      let sha = null;
      if (res.ok) {
        const data = await res.json();
        sha = data.sha;
        logs = JSON.parse(decodeURIComponent(escape(atob(data.content))));
      }
      const newLog = {
        no: logs.length > 0 ? (Math.max(...logs.map(l => l.no)) + 1) : 1001,
        operator: staff,
        action: action,
        pos: "CloudDrive",
        timestamp: new Date().toLocaleString('en-GB')
      };
      logs.push(newLog);
      await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: \`Log: \${action}\`,
          content: btoa(unescape(encodeURIComponent(JSON.stringify(logs, null, 2)))),
          sha: sha
        })
      });
    } catch (e) {
      console.error("Log error:", e);
    }
  },
  _updateStorageStats: function(items) {
    let totalSize = 0;
    let fileCount = 0;
    items.forEach(item => {
      if (item.type === 'file') {
        totalSize += (item.size || 0);
        fileCount++;
      }
    });
    const usageFormatted = totalSize > 1024 * 1024 ?
      (totalSize / (1024 * 1024)).toFixed(2) + ' MB' :
      (totalSize / 1024).toFixed(2) + ' KB';
    const percentage = Math.min((totalSize / this._storageLimit) * 100, 100);

    document.getElementById('stat-usage').innerText = \`\${usageFormatted} used\`;
    document.getElementById('stat-count').innerText = \`\${fileCount} files\`;
    document.getElementById('stat-progress-fill').style.width = \`\${percentage}%\`;
    const fill = document.getElementById('stat-progress-fill');
    fill.style.background = percentage > 95 ? '#ef4444' : (percentage > 80 ? '#f59e0b' : 'var(--primary)');
  },
  resetToRoot: function() {
    this._history = [];
    this.browse('file', 'jump');
  },
  goBack: function() {
    if (this._history.length > 0) {
      const prevPath = this._history.pop();
      this.browse(prevPath, 'back');
    }
  },
  handleSearch: function(q) {
    this._searchQuery = q.toLowerCase();
    this._currentPage = 1;
    this.renderItems();
  },
  closeModal: function() {
    document.getElementById('fm-modal').classList.remove('active');
    document.getElementById('fm-modal-input').value = '';
    document.body.style.overflow = 'auto';
  },
  closeUploadModal: function() {
    document.getElementById('fm-upload-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  closeRenameModal: function() {
    document.getElementById('fm-rename-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  closeEditor: function() {
    document.getElementById('fm-edit-modal').classList.remove('active');
    document.body.style.overflow = 'auto';
  },
  closePreview: function() {
    document.getElementById('fm-preview').classList.remove('active');
    document.getElementById('fm-preview-body').innerHTML = '';
    document.body.style.overflow = 'auto';
  },
  changePage: function(p) {
    this._currentPage = p;
    this.renderItems();
  },
  toggleSelectMode: function() {
    this._isSelectMode = !this._isSelectMode;
    const btn = document.getElementById('fm-select-mode-btn');
    if (btn) btn.classList.toggle('active-select', this._isSelectMode);
    if (!this._isSelectMode) {
      this._selectedItems.clear();
      this.updateBulkBar();
    }
    this.renderItems();
  },
  toggleItemSelection: function(path, sha, displayName, isFolder) {
    if (this._isSelectMode) {
      const key = path;
      if (this._selectedItems.has(key)) {
        this._selectedItems.delete(key);
      } else {
        this._selectedItems.add(key);
        this._selectedItems[\`\${key}_name\`] = displayName;
        this._selectedItems[\`\${key}_sha\`] = sha;
        this._selectedItems[\`\${key}_isFolder\`] = isFolder;
      }
      this.updateBulkBar();
      this.renderItems();
    }
  },
  updateBulkBar: function() {
    const bar = document.getElementById('fm-bulk-bar');
    const count = document.getElementById('fm-bulk-count');
    if (this._selectedItems.size > 0) {
      bar.style.display = 'flex';
      count.innerText = \`\${this._selectedItems.size} selected\`;
    } else {
      bar.style.display = 'none';
    }
  },
  clearSelection: function() {
    this._selectedItems.clear();
    this.updateBulkBar();
    this.renderItems();
  },
  downloadSelected: async function() {
    if (this._selectedItems.size === 0) return;
    if (typeof JSZip === 'undefined') {
      await this._loadJSZip();
    }
    const zip = new JSZip();
    const promises = [];
    for (const path of this._selectedItems) {
      const item = this._allItems.find(i => i.path === path);
      if (item && item.type === 'file') {
        promises.push(
          fetch(item.download_url).then(r => r.blob()).then(blob => {
            zip.file(item.name, blob);
          })
        );
      }
    }
    await Promise.all(promises);
    const content = await zip.generateAsync({type:'blob'});
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'selected_files.zip';
    a.click();
    URL.revokeObjectURL(url);
    this.clearSelection();
  },
  deleteSelected: async function() {
    if (this._selectedItems.size === 0) return;
    if (!confirm(\`Delete \${this._selectedItems.size} selected items permanently?\`)) return;
    for (const path of this._selectedItems) {
      const item = this._allItems.find(i => i.path === path);
      if (item) {
        await this.deleteItem(item.path, item.sha, item.name);
      }
    }
    this._selectedItems.clear();
    this.updateBulkBar();
    this.browse(this._currentPath, 'refresh');
  },
  renameSelected: async function() {
    if (this._selectedItems.size === 0) return;
    const modal = document.getElementById('fm-rename-modal');
    const input = document.getElementById('fm-rename-input');
    input.value = '';
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    const confirmBtn = document.getElementById('fm-rename-confirm');
    confirmBtn.onclick = async () => {
      const newBase = input.value.trim();
      if (!newBase) return;
      let counter = 1;
      for (const path of this._selectedItems) {
        const item = this._allItems.find(i => i.path === path);
        if (item && item.type === 'file') {
          const ext = item.name.includes('.') ? '.' + item.name.split('.').pop() : '';
          const newName = \`\${newBase}_\${counter}\${ext}\`;
          await this._renameSingle(item, newName);
          counter++;
        }
      }
      this.closeRenameModal();
      this._selectedItems.clear();
      this.updateBulkBar();
      this.browse(this._currentPath, 'refresh');
    };
  },
  _renameSingle: async function(item, newName) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    if (item.type !== 'file') return;
    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${item.path}\`, {
        headers: {'Authorization': \`token \${this._config.ghToken}\`}
      });
      if (!res.ok) return;
      const data = await res.json();
      const content = data.content;
      const newPath = item.path.replace(/[^/]*$/, newName);
      const putRes = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${newPath}\`, {
        method: 'PUT',
        headers: {'Authorization': \`token \${this._config.ghToken}\`},
        body: JSON.stringify({ message: \`Rename \${item.name} to \${newName}\`, content: content })
      });
      if (putRes.ok) {
        await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${item.path}\`, {
          method: 'DELETE',
          headers: {'Authorization': \`token \${this._config.ghToken}\`},
          body: JSON.stringify({ message: 'Delete old name', sha: data.sha })
        });
        await this._writeSystemLog(\`Renamed: \${item.name} -> \${newName}\`);
      }
    } catch(e) { console.error(e); }
  },
  _loadJSZip: function() {
    return new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";
      s.onload = resolve;
      document.head.appendChild(s);
    });
  },
  toggleMenu: function(e, sha) {
    e.stopPropagation();
    const allMenus = document.querySelectorAll('.fm-dropdown');
    allMenus.forEach(m => m.id !== \`menu-\${sha}\` && m.classList.remove('show'));
    const menu = document.getElementById(\`menu-\${sha}\`);
    if (menu) menu.classList.toggle('show');
  },
  browse: async function(path, mode = 'jump') {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (mode === 'jump' && path !== this._currentPath) this._history.push(this._currentPath);
    this._currentPath = path;
    this._currentPage = 1;
    this._searchQuery = '';

    const backBtn = document.getElementById('fm-back-btn');
    if (backBtn) backBtn.style.display = this._history.length > 0 ? 'inline-flex' : 'none';

    const grid = document.getElementById('file-list');
    const breadcrumb = document.getElementById('fm-breadcrumb');
    breadcrumb.innerText = path.replace(/\\//g, ' / ') + ' /';
    grid.innerHTML = '<div class="fm-loading">Fetching cloud data...</div>';

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${path}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        cache: 'no-store'
      });
      this._allItems = res.status === 404 ? [] : await res.json();
      this._updateStorageStats(this._allItems);
      this.renderItems();
    } catch (e) {
      grid.innerHTML = \`<div class="fm-empty"><h3>Network Error</h3></div>\`;
    }
  },
  renderItems: function() {
    const grid = document.getElementById('file-list');
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const currentStaff = this._config.staff || 'Unknown';
    const isAdmin = currentStaff.toLowerCase() === 'admin';

    const filtered = (this._allItems || []).filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(this._searchQuery);
      if (!matchesSearch) return false;

      const isPrivateItem = item.name.includes('_ISPRV_YES_');
      let itemOwner = 'System';
      if (item.name.includes('_BY_')) {
        itemOwner = item.name.split('_BY_')[1].split('_TS_')[0];
      }

      if (isPrivateItem && itemOwner !== currentStaff) {
        return false;
      }
      return true;
    });

    const noticeBar = document.getElementById('fm-admin-notice');
    if (noticeBar) noticeBar.style.display = (isAdmin) ? 'block' : 'none';

    if (!filtered.length) {
      grid.innerHTML = \`<div class="fm-empty"><h3>No items found</h3><p>Try a different search term.</p></div>\`;
      document.getElementById('fm-pagination').innerHTML = '';
      return;
    }

    const totalPages = Math.ceil(filtered.length / this._pageSize);
    const paged = filtered.slice((this._currentPage - 1) * this._pageSize, this._currentPage * this._pageSize);

    grid.innerHTML = paged.map(item => {
      const isFolder = item.type === 'dir';
      const ext = item.name.includes('.') ? \`.\${item.name.split('.').pop()}\` : '';
      let cleanRawName = item.name.replace('_ISPRV_YES_', '').replace('_ISPRV_NO_', '');
      const nameParts = cleanRawName.split('_BY_');
      const displayName = nameParts[0].replace('.keep', 'Empty Folder') + (isFolder ? '' : ext);

      const lowerName = item.name.toLowerCase();
      const isImage = /\\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(lowerName);
      const isPdf = lowerName.endsWith('.pdf');
      const isEditable = /\\.(docx|text|txt|pptx|js|css|html|json|md)$/i.test(lowerName);
      const isPlainTxt = /\\.(txt|text|js|css|html|json|md)$/i.test(lowerName);

      let staffName = 'System', uploadTime = 'N/A';
      if (nameParts[1]) {
        const infoParts = nameParts[1].split('_TS_');
        staffName = infoParts[0];
        if (infoParts[1]) {
          const ts = parseInt(infoParts[1].split('.')[0]);
          uploadTime = isNaN(ts) ? 'N/A' : new Date(ts).toLocaleDateString();
        }
      }

      const itemIsLocked = item.name.includes('_ISPRV_YES_');
      const sha = item.sha || '';

      let clickAction = isFolder ?
        \`FileModule.browse('\${item.path}', 'jump')\` :
        (isPlainTxt ?
          \`FileModule.editContent('\${item.path}', '\${sha}')\` :
          (isImage || isPdf || isEditable ?
            \`FileModule.openPreview('\${item.download_url}', '\${displayName}', '\${isImage ? 'image' : 'doc'}')\` :
            \`FileModule.download('\${item.download_url}', '\${displayName}')\`));

      let iconSvg = '';
      if (isFolder) {
        iconSvg = \`<svg viewBox="0 0 24 24" class="fm-icon folder-icon" fill="currentColor"><path d="M10 4H4c-1.11 0-2 .89-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.11-.89-2-2-2h-8l-2-2z"/></svg>\`;
      } else if (isImage) {
        iconSvg = \`<svg viewBox="0 0 24 24" class="fm-icon image-icon" fill="currentColor"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>\`;
      } else {
        iconSvg = \`<svg viewBox="0 0 24 24" class="fm-icon file-icon" fill="currentColor"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>\`;
      }

      const isSelected = this._selectedItems.has(item.path);
      const selectCheckbox = this._isSelectMode ? \`<input type="checkbox" class="fm-select-checkbox" \${isSelected ? 'checked' : ''} onclick="event.stopPropagation(); FileModule.toggleItemSelection('\${item.path}', '\${sha}', '\${displayName}', \${isFolder})">\` : '';

      return \`
        <div class="fm-card \${itemIsLocked ? 'fm-card-locked' : ''} \${isSelected ? 'fm-card-selected' : ''}">
          <div class="fm-card-options" onclick="FileModule.toggleMenu(event, '\${sha}')">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>
            <div class="fm-dropdown" id="menu-\${sha}">
              <div onclick="FileModule.renameSingleItem('\${item.path}', '\${item.name}', \${isFolder})">Rename</div>
              \${(!isFolder && isEditable) ? \`<div onclick="FileModule.editContent('\${item.path}', '\${sha}')">Edit Content</div>\` : ''}
              <div class="danger" onclick="FileModule.deleteItem('\${item.path}', '\${sha}', '\${displayName}')">Delete</div>
              \${isFolder ? \`<div onclick="FileModule.packZip('\${item.name}')">Download ZIP</div>\` : ''}
              \${!isFolder ? \`<div onclick="FileModule.download('\${item.download_url}', '\${displayName}')">Download</div>\` : ''}
            </div>
          </div>
          <div class="fm-card-content" onclick="\${clickAction}">
            <div class="fm-icon-wrapper">
              \${iconSvg}
              \${itemIsLocked ? \`<div class="fm-lock-badge">PRV</div>\` : ''}
            </div>
            <div class="fm-card-info">
              <div class="fm-card-name" title="\${displayName}">\${displayName}</div>
              <div class="fm-card-meta">
                <span class="fm-staff">@\${staffName}</span>
                <span class="fm-date">\${uploadTime}</span>
              </div>
            </div>
          </div>
          \${selectCheckbox}
        </div>
      \`;
    }).join('');

    this.renderPagination(totalPages);
  },
  openPreview: function(url, title, type) {
    const overlay = document.getElementById('fm-preview');
    const body = document.getElementById('fm-preview-body');
    document.getElementById('fm-preview-title').innerText = title;
    body.innerHTML = '<div class="fm-loading">Loading...</div>';
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';

    if (type === 'image') {
      body.innerHTML = \`<img src="\${url}" class="fm-preview-img">\`;
    } else {
      body.innerHTML = \`<iframe src="https://docs.google.com/viewer?url=\${encodeURIComponent(url)}&embedded=true" frameborder="0" class="fm-preview-iframe"></iframe>\`;
    }
  },
  editContent: async function(path, sha) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    if (/\\.(docx|pptx)$/i.test(path)) {
      alert("Direct edit not supported for Office files.");
      return;
    }

    const modal = document.getElementById('fm-edit-modal');
    const area = document.getElementById('fm-editor-area');
    const saveBtn = document.getElementById('fm-editor-save');

    area.value = "Fetching...";
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${path}\`, {
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        }
      });
      const data = await res.json();
      const decoded = atob(data.content);
      area.value = decodeURIComponent(escape(decoded));

      saveBtn.onclick = async () => {
        saveBtn.disabled = true;
        saveBtn.innerText = "Saving...";
        const content = btoa(unescape(encodeURIComponent(area.value)));
        const ok = await this.commitToGithub(path, content, \`Edit via ERP\`, sha);
        if (ok) {
          await this._writeSystemLog(\`Edited content of: \${path.split('/').pop()}\`);
          this.closeEditor();
          this.browse(this._currentPath, 'refresh');
        } else {
          alert("Save failed.");
        }
        saveBtn.disabled = false;
        saveBtn.innerText = "Save";
      };
    } catch(e) {
      area.value = "Error loading.";
    }
  },
  deleteItem: async function(path, sha, displayName) {
    if (!confirm('Delete this item permanently?')) return;

    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${path}\`, {
        method: 'DELETE',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify({
          message: 'Delete',
          sha
        })
      });

      if (res.ok) {
        await this._writeSystemLog(\`Deleted: \${displayName || path}\`);
        this.browse(this._currentPath, 'refresh');
      } else {
        alert("Delete failed: " + res.status);
      }
    } catch (e) {
      alert("Delete failed.");
    }
  },
  handleUpload: function(input) {
    if (!input.files.length) return;

    this._pendingFiles = Array.from(input.files);
    const modal = document.getElementById('fm-upload-modal');
    document.getElementById('fm-upload-count').innerText = \`Selected files: \${this._pendingFiles.length}\`;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    document.getElementById('fm-upload-confirm').onclick = async () => {
      this.closeUploadModal();

      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }

      const isPrivate = document.querySelector('input[name="fm-upload-private"]:checked').value;
      const privacyTag = isPrivate === 'yes' ? '_ISPRV_YES_' : '_ISPRV_NO_';
      const staff = this._config.staff || 'Unknown';
      let successCount = 0;

      for (const file of this._pendingFiles) {
        const lastDot = file.name.lastIndexOf('.');
        const ext = lastDot !== -1 ? file.name.substring(lastDot) : '';
        const base = lastDot !== -1 ? file.name.substring(0, lastDot) : file.name;
        const fileName = \`\${base}\${privacyTag}_BY_\${staff}_TS_\${Date.now()}\${ext}\`;

        const reader = new FileReader();
        const uploadResult = await new Promise((resolve) => {
          reader.onload = async () => {
            const ok = await this.commitToGithub(
              \`\${this._currentPath}/\${fileName}\`,
              reader.result.split(',')[1],
              \`Upload by \${staff}\`
            );
            resolve(ok);
          };
          reader.readAsDataURL(file);
        });

        if (uploadResult) {
          successCount++;
        }
      }

      if (successCount > 0) {
        await this._writeSystemLog(\`Uploaded \${successCount} file(s) to /\${this._currentPath}\`);
        this.browse(this._currentPath, 'refresh');
      } else {
        alert("Upload failed for all files.");
      }

      this._pendingFiles = [];
      input.value = '';
    };
  },
  openCreateModal: function(type) {
    const modal = document.getElementById('fm-modal');
    const input = document.getElementById('fm-modal-input');

    document.getElementById('fm-modal-title').innerText = "New " + type;

    document.getElementById('fm-modal-confirm').onclick = async () => {
      const n = input.value.trim();
      if (!n) return;

      if (!this._config) {
        this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
      }

      const staff = this._config.staff || 'Unknown';
      const isPrivate = document.querySelector('input[name="fm-is-private"]:checked').value;
      const privacyTag = isPrivate === 'yes' ? '_ISPRV_YES_' : '_ISPRV_NO_';

      const path = type === 'folder' ?
        \`\${this._currentPath}/\${n}\${privacyTag}_BY_\${staff}_TS_\${Date.now()}/.keep\` :
        \`\${this._currentPath}/\${n}\${privacyTag}_BY_\${staff}_TS_\${Date.now()}.txt\`;

      const ok = await this.commitToGithub(path, btoa(' '), \`New \${type}\`);
      if (ok) {
        await this._writeSystemLog(\`Created new \${type}: \${n}\`);
        this.closeModal();
        this.browse(this._currentPath, 'refresh');
      }
    };

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    input.focus();
  },
  renameSingleItem: async function(path, oldName, isFolder) {
    if (isFolder) {
      alert("Folder rename is not supported.");
      return;
    }
    const newName = prompt("Enter new name (extension will be preserved):", oldName);
    if (!newName || newName === oldName) return;
    const item = this._allItems.find(i => i.path === path);
    if (item) {
      await this._renameSingle(item, newName);
      this.browse(this._currentPath, 'refresh');
    }
  },
  packZip: function(n) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }
    window.open(\`https://github.com/\${this._config.ghRepo}/archive/refs/heads/main.zip\`, '_blank');
  },
  commitToGithub: async function(path, content, message, sha = null) {
    if (!this._config) {
      this._config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    }

    const body = { message, content };
    if (sha) body.sha = sha;

    try {
      const res = await fetch(\`https://api.github.com/repos/\${this._config.ghRepo}/contents/\${path}\`, {
        method: 'PUT',
        headers: {
          'Authorization': \`token \${this._config.ghToken}\`
        },
        body: JSON.stringify(body)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },
  download: async function(url, n) {
    try {
      const r = await fetch(url);
      const blob = await r.blob();
      const u = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u;
      a.download = n;
      a.click();
      window.URL.revokeObjectURL(u);
    } catch(e) {
      window.open(url, '_blank');
    }
  },
  renderPagination: function(t) {
    const c = document.getElementById('fm-pagination');
    if (t <= 1) {
      c.innerHTML = '';
      return;
    }

    let h = \`<button type="button" class="fm-page-btn" \${this._currentPage === 1 ? 'disabled' : ''} onclick="FileModule.changePage(\${this._currentPage - 1})">Prev</button>\`;

    for (let i = 1; i <= t; i++) {
      if (i === 1 || i === t || (i >= this._currentPage - 1 && i <= this._currentPage + 1)) {
        h += \`<button type="button" class="fm-page-btn \${i === this._currentPage ? 'active' : ''}" onclick="FileModule.changePage(\${i})\">\${i}</button>\`;
      } else if (Math.abs(i - this._currentPage) === 2) {
        h += \`<span class="fm-page-dots">...</span>\`;
      }
    }

    h += \`<button type="button" class="fm-page-btn" \${this._currentPage === t ? 'disabled' : ''} onclick="FileModule.changePage(\${this._currentPage + 1})">Next</button>\`;
    c.innerHTML = h;
  },
  _injectStyles: function() {
    if (document.getElementById('fm-styles')) return;

    const style = document.createElement('style');
    style.id = 'fm-styles';
    style.textContent = \`
      :root {
        --primary: #4f46e5;
        --primary-dark: #4338ca;
        --primary-light: #6366f1;
        --primary-soft: rgba(79, 70, 229, 0.08);
        --primary-glow: rgba(79, 70, 229, 0.2);
        --bg: #f8fafc;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #0f172a;
        --text-secondary: #475569;
        --text-dim: #94a3b8;
        --border: #e2e8f0;
        --border-strong: #cbd5e1;
        --danger: #ef4444;
        --red-soft: rgba(239, 68, 68, 0.08);
        --green: #10b981;
        --green-soft: rgba(16, 185, 129, 0.08);
        --amber: #f59e0b;
        --amber-soft: rgba(245, 158, 11, 0.08);
        --radius-card: 16px;
        --radius-lg: 14px;
        --radius-md: 10px;
        --radius-sm: 10px;
        --radius-xs: 8px;
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
        --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
        --transition-fast: 0.15s ease;
        --transition-base: 0.25s ease;
        --transition-slow: 0.3s ease;
        --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      }

      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }

      body {
        background: var(--bg);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
        color: var(--text);
        line-height: 1.5;
        margin: 0;
        padding: 0;
      }

      .fm-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
        font-family: var(--font-sans);
        background: var(--bg);
        min-height: 100vh;
        width: 100%;
        color: var(--text);
      }

      .fm-header {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 20px;
        background: var(--surface);
        padding: 20px 22px;
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        box-shadow: var(--shadow-xs);
      }

      .fm-brand-area {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
      }

      .fm-icon-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 38px;
        height: 38px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        flex-shrink: 0;
        position: relative;
        font-family: var(--font-sans);
      }

      .fm-icon-btn:hover {
        background: var(--primary-soft);
        border-color: var(--primary);
        color: var(--primary);
      }

      .fm-icon-btn.active-select {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .fm-title h2 {
        margin: 0;
        font-size: 22px;
        font-weight: 700;
        letter-spacing: -0.025em;
        color: var(--text);
        cursor: pointer;
      }

      .fm-breadcrumb {
        font-size: 12px;
        font-weight: 500;
        color: var(--text-dim);
        margin-top: 2px;
        word-break: break-word;
      }

      .fm-stats {
        background: var(--surface-soft);
        border-radius: var(--radius-md);
        padding: 10px 14px;
        min-width: 190px;
        border: 1px solid var(--border);
      }

      .fm-stats-info {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.03em;
      }

      .fm-stats-bar {
        width: 100%;
        height: 6px;
        background: var(--border);
        border-radius: var(--radius-xs);
        overflow: hidden;
      }

      .fm-stats-fill {
        height: 100%;
        width: 0%;
        background: var(--primary);
        transition: width var(--transition-base);
        border-radius: var(--radius-xs);
      }

      .fm-search {
        position: relative;
        flex: 1;
        min-width: 220px;
        max-width: 340px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        padding: 0 14px;
        display: flex;
        align-items: center;
        height: 40px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-xs);
      }

      .fm-search:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .fm-search-icon {
        color: var(--text-dim);
        flex-shrink: 0;
      }

      .fm-search input {
        width: 100%;
        border: none;
        padding: 0 0 0 10px;
        font-size: 14px;
        background: transparent;
        transition: all var(--transition-fast);
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
      }

      .fm-search input::placeholder {
        color: var(--text-dim);
      }

      .fm-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
      }

      .fm-upload-btn {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        padding: 0 16px;
        height: 40px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        white-space: nowrap;
        font-family: var(--font-sans);
      }

      .fm-upload-btn:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .fm-admin-notice {
        margin-bottom: 16px;
        background: var(--primary-soft);
        color: var(--primary);
        border: 1px solid rgba(79, 70, 229, 0.18);
        padding: 10px 16px;
        border-radius: var(--radius-md);
        font-size: 12px;
        font-weight: 600;
        text-align: center;
      }

      .fm-bulk-bar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 16px;
        background: var(--surface);
        border-radius: var(--radius-lg);
        margin-bottom: 16px;
        flex-wrap: wrap;
        box-shadow: var(--shadow-xs);
        border: 1px solid var(--border);
      }

      .fm-bulk-count {
        font-size: 13px;
        font-weight: 700;
        color: var(--primary);
        margin-right: auto;
      }

      .fm-bulk-btn {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        height: 32px;
        padding: 0 12px;
        border-radius: var(--radius-xs);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .fm-bulk-btn:hover {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .fm-bulk-delete {
        color: var(--danger);
        background: var(--surface);
        border-color: var(--border);
      }

      .fm-bulk-delete:hover {
        background: var(--red-soft);
        color: var(--danger);
        border-color: var(--danger);
      }

      .fm-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
        gap: 16px;
        width: 100%;
      }

      .fm-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-card);
        padding: 18px;
        transition: all var(--transition-fast);
        position: relative;
        box-shadow: var(--shadow-xs);
        display: flex;
        flex-direction: column;
      }

      .fm-card:hover {
        transform: translateY(-2px);
        border-color: var(--border-strong);
        box-shadow: var(--shadow-md);
      }

      .fm-card-locked {
        border-left: 3px solid var(--danger);
      }

      .fm-card-selected {
        border-color: var(--primary);
        background: var(--primary-soft);
      }

      .fm-select-checkbox {
        position: absolute;
        top: 12px;
        left: 12px;
        width: 18px;
        height: 18px;
        z-index: 10;
        cursor: pointer;
        accent-color: var(--primary);
        margin: 0;
      }

      .fm-card-options {
        position: absolute;
        top: 12px;
        right: 12px;
        z-index: 5;
        background: var(--surface-soft);
        border-radius: var(--radius-xs);
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        border: 1px solid var(--border);
      }

      .fm-card-options:hover {
        background: var(--primary-soft);
        color: var(--primary);
        border-color: var(--primary);
      }

      .fm-dropdown {
        position: absolute;
        top: 34px;
        right: 0;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        display: none;
        z-index: 20;
        min-width: 150px;
        overflow: hidden;
      }

      .fm-dropdown.show {
        display: block;
      }

      .fm-dropdown div {
        padding: 10px 14px;
        font-size: 13px;
        font-weight: 600;
        color: var(--text);
        cursor: pointer;
        transition: background var(--transition-fast);
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
      }

      .fm-dropdown div:last-child {
        border-bottom: none;
      }

      .fm-dropdown div:hover {
        background: var(--primary-soft);
        color: var(--primary);
      }

      .fm-dropdown div.danger {
        color: var(--danger);
      }

      .fm-dropdown div.danger:hover {
        background: var(--red-soft);
        color: var(--danger);
      }

      .fm-card-content {
        padding-top: 8px;
        cursor: pointer;
        text-align: center;
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
      }

      .fm-icon-wrapper {
        position: relative;
        height: 64px;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 10px;
      }

      .fm-icon {
        width: 44px;
        height: 44px;
      }

      .folder-icon {
        color: var(--amber);
      }

      .image-icon {
        color: var(--green);
      }

      .file-icon {
        color: var(--text-dim);
      }

      .fm-lock-badge {
        position: absolute;
        bottom: 0;
        right: 12%;
        background: var(--red-soft);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.25);
        border-radius: var(--radius-xs);
        padding: 2px 6px;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.04em;
      }

      .fm-card-info {
        width: 100%;
      }

      .fm-card-name {
        font-weight: 700;
        font-size: 14px;
        color: var(--text);
        word-break: break-word;
        margin-bottom: 6px;
      }

      .fm-card-meta {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
      }

      .fm-staff {
        font-size: 11px;
        font-weight: 600;
        background: var(--primary-soft);
        color: var(--primary);
        padding: 2px 8px;
        border-radius: var(--radius-xs);
        word-break: break-word;
      }

      .fm-date {
        font-size: 11px;
        color: var(--text-dim);
      }

      .fm-pagination {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 24px;
        flex-wrap: wrap;
      }

      .fm-page-btn {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        height: 36px;
        min-width: 36px;
        padding: 0 12px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        color: var(--text-secondary);
        font-family: var(--font-sans);
      }

      .fm-page-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        box-shadow: var(--shadow-primary);
      }

      .fm-page-btn:hover:not(:disabled):not(.active) {
        border-color: var(--primary);
        color: var(--primary);
        background: var(--primary-soft);
      }

      .fm-page-btn:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }

      .fm-page-dots {
        padding: 0 6px;
        color: var(--text-dim);
        display: inline-flex;
        align-items: center;
      }

      .fm-modal {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.45);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        visibility: hidden;
        opacity: 0;
        transition: visibility 0.2s, opacity 0.2s;
        padding: 16px;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
      }

      .fm-modal.active {
        visibility: visible;
        opacity: 1;
      }

      .fm-modal-fullscreen {
        background: var(--bg);
        padding: 0;
      }

      .fm-modal-card {
        background: var(--surface);
        border-radius: var(--radius-card);
        width: 100%;
        max-width: 480px;
        max-height: 90vh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border);
      }

      .fm-modal-header {
        padding: 16px 20px;
        border-bottom: 1px solid var(--border);
        background: var(--surface);
      }

      .fm-modal-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text);
      }

      .fm-modal-body {
        padding: 20px;
        flex: 1;
        overflow-y: auto;
      }

      .fm-modal-body p {
        margin: 0 0 12px;
        font-size: 13px;
        color: var(--text-secondary);
      }

      .fm-modal-body input[type="text"] {
        width: 100%;
        height: 42px;
        padding: 0 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 14px;
        margin-bottom: 16px;
        outline: none;
        color: var(--text);
        font-family: var(--font-sans);
        box-shadow: var(--shadow-xs);
      }

      .fm-modal-body input[type="text"]:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-glow);
      }

      .fm-privacy-toggle {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--surface-soft);
        padding: 12px 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--border);
        flex-wrap: wrap;
        gap: 10px;
      }

      .fm-privacy-toggle span {
        font-size: 13px;
        font-weight: 600;
        color: var(--text);
      }

      .fm-radio-group {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .fm-privacy-toggle label {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 500;
        color: var(--text-secondary);
        cursor: pointer;
      }

      .fm-modal-footer {
        padding: 14px 20px;
        border-top: 1px solid var(--border);
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        background: var(--surface-soft);
      }

      .fm-btn-text {
        background: var(--surface);
        border: 1px solid var(--border);
        height: 38px;
        padding: 0 16px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
        font-family: var(--font-sans);
      }

      .fm-btn-text:hover {
        background: var(--surface-soft);
        color: var(--text);
        border-color: var(--border-strong);
      }

      .fm-btn-primary {
        background: var(--primary);
        color: white;
        border: 1px solid transparent;
        height: 38px;
        padding: 0 20px;
        border-radius: var(--radius-md);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all var(--transition-fast);
        box-shadow: var(--shadow-primary);
        font-family: var(--font-sans);
      }

      .fm-btn-primary:hover {
        background: var(--primary-dark);
        transform: translateY(-1px);
      }

      .fm-btn-primary:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
      }

      .fm-edit-card {
        max-width: 100%;
        width: 100vw;
        height: 100vh;
        height: 100dvh;
        max-height: 100vh;
        max-height: 100dvh;
        border-radius: 0;
        border: none;
        display: flex;
        flex-direction: column;
      }

      .fm-edit-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        padding: 12px 24px;
        flex-shrink: 0;
      }

      .fm-edit-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      #fm-editor-area {
        flex: 1;
        width: 100%;
        padding: 24px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        border: none;
        outline: none;
        resize: none;
        background: var(--surface);
        color: var(--text);
        font-size: 14px;
        line-height: 1.6;
        min-height: 0;
      }

      .fm-preview-card {
        background: var(--surface);
        width: 100vw;
        max-width: 100%;
        height: 100vh;
        height: 100dvh;
        border-radius: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .fm-preview-header {
        padding: 12px 24px;
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        font-weight: 700;
        font-size: 16px;
        color: var(--text);
        flex-shrink: 0;
      }

      .fm-preview-close {
        background: var(--surface-soft);
        border: 1px solid var(--border);
        width: 36px;
        height: 36px;
        border-radius: var(--radius-md);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: var(--text-secondary);
        transition: all var(--transition-fast);
      }

      .fm-preview-close:hover {
        background: var(--border);
        color: var(--text);
      }

      .fm-preview-body {
        flex: 1;
        overflow: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--bg);
        padding: 16px;
        min-height: 0;
      }

      .fm-preview-img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        border-radius: var(--radius-md);
      }

      .fm-preview-iframe {
        width: 100%;
        height: 100%;
        border: none;
        background: var(--surface);
      }

      .fm-loading,
      .fm-empty {
        text-align: center;
        padding: 48px 20px;
        background: var(--surface);
        border-radius: var(--radius-card);
        border: 1px solid var(--border);
        color: var(--text-dim);
        font-weight: 500;
        font-size: 14px;
        grid-column: 1 / -1;
      }

      .fm-empty h3 {
        margin: 0 0 6px;
        font-size: 16px;
        font-weight: 700;
        color: var(--text);
      }

      .fm-empty p {
        margin: 0;
        font-size: 13px;
        color: var(--text-dim);
      }

      @media (max-width: 768px) {
        .fm-container {
          padding: 16px;
        }
        .fm-header {
          padding: 16px;
          border-radius: var(--radius-lg);
          flex-direction: column;
          align-items: stretch;
        }
        .fm-title h2 {
          font-size: 20px;
        }
        .fm-search {
          min-width: 100%;
          max-width: 100%;
        }
        .fm-stats {
          min-width: 100%;
        }
        .fm-actions {
          justify-content: flex-end;
        }
        .fm-upload-btn {
          flex: 1;
        }
        .fm-grid {
          grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
          gap: 12px;
        }
        .fm-card {
          padding: 14px;
          border-radius: var(--radius-lg);
        }
        .fm-bulk-bar {
          border-radius: var(--radius-lg);
        }
        .fm-edit-header,
        .fm-preview-header {
          padding: 12px 16px;
        }
        #fm-editor-area {
          padding: 16px;
        }
      }
    \`;
    document.head.appendChild(style);

    if (!window._fmMenuListener) {
      window.addEventListener('click', () => document.querySelectorAll('.fm-dropdown').forEach(m => m.classList.remove('show')));
      window._fmMenuListener = true;
    }
  }
};

window.FileModule = FileModule;`;
const _e=(()=>{
  const f=new TextEncoder().encode(_s);
  const g=[];
  for(let i=0;i<f.length;i++){
    g.push(f[i]^_k[i%_k.length]^((i*67)&0xff));
  }
  return g;
})();
const _r=new Function(_d(_e));
_r();
})();

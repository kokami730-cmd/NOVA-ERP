(function(){
const _m=[0x5c,0x23,0x91,0x7e,0x48,0xd6,0x1b,0xaa,0x67,0x3f,0xc2,0x85,0x0e,0xb4,0x71,0xe9];
function _x(b){
  const o=new Uint8Array(b.length);
  for(let i=0;i<b.length;i++){
    o[i]=b[i]^_m[i%_m.length]^((i*37)&0xff);
  }
  return new TextDecoder().decode(o);
}
const _c=`const StaffManualModule = {
  _data: [],
  _sha: '',
  _searchQuery: '',
  _currentPage: 1,
  _itemsPerPage: 20,
  _isAdmin: function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    return config.role === 'admin';
  },
  _getDetectedStaffName: function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    return config.staff || config.username || config.staffName || 'Staff';
  },
  render: async function(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const isAdmin = this._isAdmin();

    if (!document.getElementById('staff-manual-styles')) {
      const style = document.createElement('style');
      style.id = 'staff-manual-styles';
      style.textContent = \`
        :root {
          --primary: #4f46e5;
          --primary-dark: #4338ca;
          --primary-light: #6366f1;
          --primary-soft: rgba(79, 70, 229, 0.08);
          --primary-glow: rgba(79, 70, 229, 0.2);
          --bg: #f8fafc;
          --surface: #ffffff;
          --surface-soft: #f8fafc;
          --text: #0f172a;
          --text-secondary: #475569;
          --text-dim: #94a3b8;
          --border: #e2e8f0;
          --border-strong: #cbd5e1;
          --danger: #ef4444;
          --red-soft: rgba(239, 68, 68, 0.08);
          --green: #10b981;
          --green-soft: rgba(16, 185, 129, 0.08);
          --radius-card: 16px;
          --radius-lg: 14px;
          --radius-md: 10px;
          --radius-sm: 8px;
          --radius-xs: 6px;
          --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
          --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
          --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
          --shadow-primary: 0 4px 14px 0 rgba(79, 70, 229, 0.35);
          --transition-fast: 0.15s ease;
          --transition-base: 0.25s ease;
          --font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        }
        * {
          box-sizing: border-box;
          -webkit-tap-highlight-color: transparent;
        }
        .manual-wrapper {
          max-width: 1400px;
          margin: 0 auto;
          padding: 24px;
          font-family: var(--font-sans);
          color: var(--text);
          background: var(--bg);
          min-height: 100vh;
          -webkit-font-smoothing: antialiased;
          width: 100%;
        }
        .manual-header-flex {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 24px;
          gap: 16px;
          flex-wrap: wrap;
        }
        .header-title h2 {
          margin: 0;
          font-size: 26px;
          font-weight: 700;
          letter-spacing: -0.025em;
          color: var(--text);
        }
        .sync-indicator {
          font-size: 12px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 8px;
          margin-top: 6px;
          font-weight: 500;
        }
        .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: var(--text-dim);
          flex-shrink: 0;
        }
        .dot.online {
          background: var(--green);
        }
        .search-container {
          position: relative;
          flex: 1;
          max-width: 340px;
          min-width: 200px;
        }
        .search-input {
          width: 100%;
          height: 42px;
          padding: 0 14px;
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          background: var(--surface);
          font-size: 14px;
          color: var(--text);
          transition: all var(--transition-fast);
          outline: none;
          box-shadow: var(--shadow-xs);
          font-family: var(--font-sans);
        }
        .search-input:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px var(--primary-glow);
        }
        .btn {
          height: 40px;
          padding: 0 18px;
          border-radius: var(--radius-md);
          font-weight: 600;
          font-size: 13px;
          cursor: pointer;
          transition: all var(--transition-fast);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border: 1px solid transparent;
          white-space: nowrap;
          font-family: var(--font-sans);
        }
        .btn:hover {
          transform: translateY(-1px);
        }
        .btn:active {
          transform: translateY(0);
        }
        .btn-main {
          background: var(--primary);
          color: white;
          box-shadow: var(--shadow-primary);
        }
        .btn-main:hover {
          background: var(--primary-dark);
        }
        .btn-sec {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--text-secondary);
          box-shadow: var(--shadow-xs);
        }
        .btn-sec:hover {
          background: var(--surface-soft);
          border-color: var(--border-strong);
          color: var(--text);
        }
        .btn-danger {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--danger);
        }
        .btn-danger:hover {
          background: var(--red-soft);
          border-color: var(--danger);
        }
        .manual-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 20px;
        }
        .manual-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 20px;
          transition: all var(--transition-base);
          cursor: pointer;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          gap: 14px;
          box-shadow: var(--shadow-sm);
        }
        .manual-card:hover {
          transform: translateY(-2px);
          border-color: var(--primary-light);
          box-shadow: var(--shadow-md);
        }
        .manual-card-title {
          font-size: 17px;
          font-weight: 700;
          color: var(--text);
          line-height: 1.4;
          word-break: break-word;
        }
        .manual-card-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 12px;
          color: var(--text-secondary);
          border-top: 1px solid var(--border);
          padding-top: 12px;
          margin-top: auto;
          gap: 8px;
        }
        .badge {
          padding: 4px 10px;
          border-radius: var(--radius-sm);
          font-weight: 600;
          font-size: 11px;
          white-space: nowrap;
        }
        .badge-public {
          background: var(--green-soft);
          color: var(--green);
        }
        .badge-private {
          background: var(--red-soft);
          color: var(--danger);
        }
        .badge-read {
          background: var(--green-soft);
          color: var(--green);
        }
        .badge-unread {
          background: var(--primary-soft);
          color: var(--primary);
        }
        #manual-editor-modal, #manual-reader-modal {
          display: none;
          position: fixed;
          inset: 0;
          background: var(--bg);
          z-index: 99999;
          animation: fadeInModal 0.2s ease;
        }
        @keyframes fadeInModal {
          from { opacity: 0; transform: scale(0.99); }
          to { opacity: 1; transform: scale(1); }
        }
        .modal-box-wrapper {
          width: 100vw;
          height: 100vh;
          height: 100dvh;
          background: var(--bg);
          display: flex;
          flex-direction: column;
        }
        .modal-header {
          background: var(--surface);
          border-bottom: 1px solid var(--border);
          padding: 16px 28px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 14px;
          flex-shrink: 0;
          box-shadow: var(--shadow-xs);
        }
        .modal-header-left {
          display: flex;
          align-items: center;
          gap: 14px;
          min-width: 0;
          flex: 1;
        }
        .modal-back-btn {
          background: var(--surface-soft);
          border: 1px solid var(--border);
          width: 38px;
          height: 38px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all var(--transition-fast);
          color: var(--text-secondary);
          flex-shrink: 0;
        }
        .modal-back-btn:hover {
          background: var(--border);
          color: var(--text);
        }
        .modal-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: var(--text);
          word-break: break-word;
        }
        .modal-content {
          flex: 1;
          overflow-y: auto;
          padding: 32px 20px;
          display: flex;
          flex-direction: column;
        }
        .modal-form-inner {
          max-width: 900px;
          width: 100%;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          flex: 1;
        }
        .form-group {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: var(--shadow-xs);
        }
        .field-box label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          margin-bottom: 6px;
          color: var(--text-secondary);
        }
        .manual-input, .manual-select, .manual-textarea {
          width: 100%;
          padding: 10px 14px;
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          font-size: 14px;
          outline: none;
          background: var(--surface);
          transition: all var(--transition-fast);
          font-family: var(--font-sans);
          color: var(--text);
        }
        .manual-select {
          height: 42px;
          cursor: pointer;
        }
        .manual-textarea {
          min-height: 280px;
          resize: vertical;
          line-height: 1.6;
        }
        .manual-input:focus, .manual-select:focus, .manual-textarea:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px var(--primary-glow);
        }
        .modal-actions {
          background: var(--surface);
          padding: 16px 28px;
          border-top: 1px solid var(--border);
          display: flex;
          justify-content: flex-end;
          gap: 12px;
          flex-shrink: 0;
          box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.02);
          flex-wrap: wrap;
        }
        .reader-body {
          max-width: 900px;
          width: 100%;
          margin: 0 auto;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-card);
          padding: 28px;
          word-break: break-word;
          box-shadow: var(--shadow-xs);
        }
        .reader-title {
          font-size: 24px;
          font-weight: 700;
          margin-bottom: 10px;
          color: var(--text);
          line-height: 1.3;
        }
        .reader-meta {
          font-size: 13px;
          color: var(--text-secondary);
          margin-bottom: 20px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border);
        }
        .reader-text {
          font-size: 15px;
          line-height: 1.75;
          color: var(--text);
          white-space: pre-wrap;
          word-break: break-word;
        }
        .confirm-box {
          margin-top: 28px;
          padding: 18px;
          background: var(--surface-soft);
          border: 1px dashed var(--border-strong);
          border-radius: var(--radius-md);
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .confirm-box input[type="checkbox"] {
          width: 18px;
          height: 18px;
          accent-color: var(--primary);
          cursor: pointer;
          flex-shrink: 0;
        }
        .pagination {
          display: flex;
          justify-content: center;
          gap: 10px;
          margin-top: 32px;
          flex-wrap: wrap;
        }
        .page-node {
          min-width: 38px;
          height: 38px;
          padding: 0 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: var(--radius-md);
          border: 1px solid var(--border);
          cursor: pointer;
          font-size: 13px;
          font-weight: 600;
          background: var(--surface);
          transition: all var(--transition-fast);
          color: var(--text-secondary);
          box-shadow: var(--shadow-xs);
        }
        .page-node.active {
          background: var(--primary);
          color: white;
          border-color: var(--primary);
          box-shadow: var(--shadow-primary);
        }
        .page-node:hover:not(.active) {
          background: var(--surface-soft);
          border-color: var(--border-strong);
          color: var(--text);
        }

        @media (max-width: 1024px) {
          .manual-grid {
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          }
        }

        @media (max-width: 768px) {
          .manual-wrapper {
            padding: 16px;
          }
          .manual-header-flex {
            flex-direction: column;
            align-items: stretch;
            gap: 14px;
            margin-bottom: 20px;
          }
          .search-container {
            max-width: 100%;
          }
          .manual-grid {
            grid-template-columns: 1fr;
            gap: 14px;
          }
          .modal-header {
            padding: 14px 16px;
          }
          .modal-content {
            padding: 20px 14px;
          }
          .form-group {
            padding: 18px;
          }
          .reader-body {
            padding: 20px;
            border-radius: var(--radius-lg);
          }
          .reader-title {
            font-size: 20px;
          }
          .modal-actions {
            padding: 14px 16px;
            flex-direction: column-reverse;
            align-items: stretch;
          }
          .modal-actions button {
            width: 100%;
          }
        }
      \`;
      document.head.appendChild(style);
    }

    container.innerHTML = \`
      <div class="manual-wrapper">
        <div class="manual-header-flex">
          <div class="header-title">
            <h2>Staff Manuals</h2>
            
          </div>
          <div class="search-container">
            <input type="text" class="search-input" placeholder="Search manuals by title or content..." oninput="StaffManualModule.handleSearch(this.value)">
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-sec" onclick="StaffManualModule.loadFromCloud()">Refresh</button>
            <button class="btn btn-main" id="manual-add-btn" style="display:\${isAdmin ? 'inline-flex' : 'none'};" onclick="StaffManualModule.openEditor()">Create Manual</button>
          </div>
        </div>
        <div id="manual-list-container" class="manual-grid"></div>
        <div id="manual-pagination" class="pagination"></div>
      </div>

      <div id="manual-editor-modal">
        <div class="modal-box-wrapper">
          <div class="modal-header">
            <div class="modal-header-left">
              <button class="modal-back-btn" onclick="StaffManualModule.closeEditor()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3 id="manual-form-title">Manual Details</h3>
            </div>
            <button class="btn btn-sec" onclick="StaffManualModule.closeEditor()">Exit</button>
          </div>
          <form id="manual-form" onsubmit="StaffManualModule.saveData(event)" style="display:flex; flex-direction:column; flex:1; min-height:0;">
            <div class="modal-content">
              <div class="modal-form-inner">
                <div class="form-group">
                  <div style="display:flex; flex-direction:column; gap:20px;">
                    <div class="field-box">
                      <label>Manual Title</label>
                      <input type="text" name="title" required class="manual-input" placeholder="e.g. Employee Code of Conduct">
                    </div>
                    <div class="field-box">
                      <label>Visibility Access</label>
                      <select name="visibility" class="manual-select">
                        <option value="public">Public (Visible to All Staff)</option>
                        <option value="private">Private (Admin Only)</option>
                      </select>
                    </div>
                    <div class="field-box">
                      <label>Manual Content</label>
                      <textarea name="content" required class="manual-textarea" placeholder="Write or paste full staff manual guidelines here..."></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-actions">
              <button type="button" id="manual-delete-btn" class="btn btn-danger" style="display:none; margin-right:auto;" onclick="StaffManualModule.deleteManual()">Delete Manual</button>
              <button type="button" class="btn btn-sec" onclick="StaffManualModule.closeEditor()">Cancel</button>
              <button type="submit" class="btn btn-main">Save Manual</button>
            </div>
          </form>
        </div>
      </div>

      <div id="manual-reader-modal">
        <div class="modal-box-wrapper">
          <div class="modal-header">
            <div class="modal-header-left">
              <button class="modal-back-btn" onclick="StaffManualModule.closeReader()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
              <h3 id="reader-modal-title" style="margin:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">Staff Manual</h3>
              <button type="button" id="reader-edit-btn" class="btn btn-sec" style="display:none; height:32px; padding:0 12px; font-size:12px;" onclick="StaffManualModule.editFromReader()">Edit</button>
            </div>
            <button class="btn btn-sec" onclick="StaffManualModule.closeReader()">Close</button>
          </div>
          <div class="modal-content">
            <div class="reader-body">
              <div id="reader-title" class="reader-title"></div>
              <div id="reader-meta" class="reader-meta"></div>
              <div id="reader-text" class="reader-text"></div>
              
              <div class="confirm-box">
                <input type="checkbox" id="read-confirm-checkbox" onchange="StaffManualModule.toggleReadConfirm(this)">
                <label for="read-confirm-checkbox" style="font-size:14px; font-weight:600; color:var(--text); cursor:pointer; margin:0; line-height:1.4;">
                  I have carefully read, understood, and agreed to this manual.
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    \`;

    await this.loadFromCloud();
  },

  handleSearch: function(val) {
    this._searchQuery = val;
    this._currentPage = 1;
    this.renderList();
  },

  loadFromCloud: async function() {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    const status = document.getElementById('manual-sync-status');

    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff_manuals.json?t=\${Date.now()}\`, {
        headers: { 'Authorization': \`token \${config.ghToken}\` },
        cache: 'no-store'
      });

      if (res.ok) {
        const data = await res.json();
        this._sha = data.sha;
        this._data = JSON.parse(decodeURIComponent(escape(atob(data.content))));
        this.renderList();
        if (status) status.innerHTML = \`<span class="dot online"></span>Connected\`;
      } else {
        this._data = [];
        this.renderList();
      }
    } catch (e) {
      if (status) status.innerHTML = \`<span class="dot"></span>Offline Mode\`;
      this._data = [];
      this.renderList();
    }
  },

  renderList: function() {
    const container = document.getElementById('manual-list-container');
    if (!container) return;
    const isAdmin = this._isAdmin();
    const currentStaff = this._getDetectedStaffName();

    let visibleData = this._data.map((item, index) => ({ ...item, _originalIndex: index }));
    if (!isAdmin) {
      visibleData = visibleData.filter(item => item.visibility === 'public');
    }

    const filtered = visibleData.filter(m =>
      (m.title || "").toLowerCase().includes(this._searchQuery.toLowerCase()) ||
      (m.content || "").toLowerCase().includes(this._searchQuery.toLowerCase())
    );

    const totalPages = Math.ceil(filtered.length / this._itemsPerPage) || 1;
    if (this._currentPage > totalPages) this._currentPage = totalPages;
    const start = (this._currentPage - 1) * this._itemsPerPage;
    const pagedData = filtered.slice(start, start + this._itemsPerPage);

    container.innerHTML = pagedData.map(m => {
      const readers = m.readers || [];
      const hasRead = readers.includes(currentStaff);
      
      return \`
        <div class="manual-card" onclick="StaffManualModule.openReader(\${m._originalIndex})">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; gap:8px;">
              <span class="badge \${m.visibility === 'private' ? 'badge-private' : 'badge-public'}">\${m.visibility === 'private' ? 'Private' : 'Public'}</span>
              <span class="badge \${hasRead ? 'badge-read' : 'badge-unread'}">\${hasRead ? 'Read' : 'Unread'}</span>
            </div>
            <div class="manual-card-title">\${m.title}</div>
          </div>
          <div class="manual-card-footer">
            <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">By \${m.author || 'Admin'}</span>
            <span style="white-space:nowrap;">\${m.lastModified || 'Recent'}</span>
          </div>
        </div>
      \`;
    }).join('') || '<div style="grid-column:1/-1; text-align:center; padding:60px 20px; color:var(--text-dim); background:var(--surface); border-radius:var(--radius-card); border:1px solid var(--border); font-size:14px;">No staff manuals available.</div>';

    this.renderPagination(totalPages);
  },

  renderPagination: function(totalPages) {
    const container = document.getElementById('manual-pagination');
    if (!container || totalPages <= 1) {
      if (container) container.innerHTML = '';
      return;
    }

    let html = \`<div class="page-node" onclick="StaffManualModule.changePage(\${Math.max(1, this._currentPage - 1)})">Prev</div>\`;
    for (let i = 1; i <= totalPages; i++) {
      html += \`<div class="page-node \${i === this._currentPage ? 'active' : ''}" onclick="StaffManualModule.changePage(\${i})">\${i}</div>\`;
    }
    html += \`<div class="page-node" onclick="StaffManualModule.changePage(\${Math.min(totalPages, this._currentPage + 1)})">Next</div>\`;
    container.innerHTML = html;
  },

  changePage: function(page) {
    this._currentPage = page;
    this.renderList();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  openEditor: function(index = null) {
    if (!this._isAdmin()) return;
    const modal = document.getElementById('manual-editor-modal');
    const form = document.getElementById('manual-form');
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    form.reset();
    form.dataset.index = index !== null ? index : "";

    if (index !== null) {
      const m = this._data[index];
      form.title.value = m.title || '';
      form.visibility.value = m.visibility || 'public';
      form.content.value = m.content || '';
      document.getElementById('manual-form-title').innerText = "Edit Staff Manual";
      document.getElementById('manual-delete-btn').style.display = 'inline-flex';
    } else {
      document.getElementById('manual-form-title').innerText = "Create New Staff Manual";
      document.getElementById('manual-delete-btn').style.display = 'none';
    }
  },

  closeEditor: function() {
    document.getElementById('manual-editor-modal').style.display = 'none';
    document.body.style.overflow = 'auto';
  },

  openReader: function(index) {
    const m = this._data[index];
    if (!m) return;

    const modal = document.getElementById('manual-reader-modal');
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    document.getElementById('reader-modal-title').innerText = m.title;
    document.getElementById('reader-title').innerText = m.title;
    document.getElementById('reader-meta').innerText = \`Created by: \${m.author || 'Admin'} | Last Modified: \${m.lastModified || ''}\`;
    document.getElementById('reader-text').innerText = m.content;

    modal.dataset.currentIndex = index;

    const editBtn = document.getElementById('reader-edit-btn');
    if (this._isAdmin()) {
      editBtn.style.display = 'inline-flex';
    } else {
      editBtn.style.display = 'none';
    }

    const currentStaff = this._getDetectedStaffName();
    const readers = m.readers || [];
    const checkbox = document.getElementById('read-confirm-checkbox');
    checkbox.checked = readers.includes(currentStaff);
  },

  closeReader: function() {
    document.getElementById('manual-reader-modal').style.display = 'none';
    document.body.style.overflow = 'auto';
    this.renderList();
  },

  editFromReader: function() {
    const modal = document.getElementById('manual-reader-modal');
    const index = parseInt(modal.dataset.currentIndex);
    this.closeReader();
    this.openEditor(index);
  },

  toggleReadConfirm: async function(checkbox) {
    const modal = document.getElementById('manual-reader-modal');
    const index = parseInt(modal.dataset.currentIndex);
    const m = this._data[index];
    if (!m) return;

    const currentStaff = this._getDetectedStaffName();
    if (!m.readers) m.readers = [];

    const isNewCheck = checkbox.checked;
    if (isNewCheck) {
      if (!m.readers.includes(currentStaff)) {
        m.readers.push(currentStaff);
      }
    } else {
      m.readers = m.readers.filter(name => name !== currentStaff);
    }

    await this.syncToCloud(false);

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (typeof LogModule !== 'undefined' && LogModule.addLog) {
      const logAction = isNewCheck ? \`Confirmed Read Staff Manual: \${m.title}\` : \`Unchecked Staff Manual: \${m.title}\`;
      LogModule.addLog('StaffManualModule', logAction, currentStaff || config.username || "Staff");
    }
  },

  saveData: async function(e) {
    e.preventDefault();
    if (!this._isAdmin()) return;

    const form = document.getElementById('manual-form');
    const index = form.dataset.index;
    const isNew = (index === undefined || index === "");
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');

    const manualObj = {
      id: isNew ? 'MAN-' + Date.now() : this._data[index].id,
      title: form.title.value,
      visibility: form.visibility.value,
      content: form.content.value,
      author: config.username || config.staff || 'Admin',
      lastModified: new Date().toLocaleString(),
      readers: isNew ? [] : (this._data[index].readers || [])
    };

    if (!isNew) {
      this._data[parseInt(index)] = manualObj;
    } else {
      this._data.unshift(manualObj);
    }

    await this.syncToCloud(true);

    if (typeof LogModule !== 'undefined' && LogModule.addLog) {
      const actionType = isNew ? "Created Staff Manual" : "Updated Staff Manual";
      LogModule.addLog('StaffManualModule', \`\${actionType}: \${manualObj.title}\`, config.username || "Admin");
    }

    this.closeEditor();
  },

  deleteManual: async function() {
    if (!this._isAdmin()) return;
    const form = document.getElementById('manual-form');
    const index = parseInt(form.dataset.index);
    if (isNaN(index)) return;

    const manualTitle = this._data[index]?.title || "Unknown";
    if (!confirm("Are you sure you want to delete this staff manual?")) return;

    this._data.splice(index, 1);
    await this.syncToCloud(true);

    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    if (typeof LogModule !== 'undefined' && LogModule.addLog) {
      LogModule.addLog('StaffManualModule', \`Deleted Staff Manual: \${manualTitle}\`, config.username || "Admin");
    }

    this.closeEditor();
  },

  syncToCloud: async function(showAlert = false) {
    const config = JSON.parse(localStorage.getItem('ERP_CONFIG') || '{}');
    try {
      const res = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff_manuals.json\`, {
        headers: { 'Authorization': \`token \${config.ghToken}\` },
        cache: 'no-store'
      });

      let latestSha = this._sha;
      if (res.ok) {
        const info = await res.json();
        latestSha = info.sha;
      }

      const putRes = await fetch(\`https://api.github.com/repos/\${config.ghRepo}/contents/db_date/staff_manuals.json\`, {
        method: 'PUT',
        headers: { 'Authorization': \`token \${config.ghToken}\` },
        body: JSON.stringify({
          message: "Update staff manuals",
          content: btoa(unescape(encodeURIComponent(JSON.stringify(this._data, null, 2)))),
          sha: latestSha
        })
      });

      if (putRes.ok) {
        const data = await putRes.json();
        this._sha = data.content.sha;
        if (showAlert) alert("Staff manual saved successfully!");
        this.renderList();
      } else {
        if (showAlert) alert("Sync failed: " + putRes.status);
      }
    } catch (e) {
      if (showAlert) alert("Sync error: " + e.message);
    }
  }
};

window.StaffManualModule = StaffManualModule;`;
const _e=(()=>{
  const u=new TextEncoder().encode(_c);
  const r=[];
  for(let i=0;i<u.length;i++){
    r.push(u[i]^_m[i%_m.length]^((i*37)&0xff));
  }
  return r;
})();
const _f=new Function(_x(_e));
_f();
})();
